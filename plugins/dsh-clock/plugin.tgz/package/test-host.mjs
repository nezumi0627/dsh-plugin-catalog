import assert from 'node:assert/strict';
import { BOOTSTRAP_KEY, bootstrapRow, apply } from './index.js';

assert.equal(BOOTSTRAP_KEY, '__DSH_DYNAMIC_HUB__');
assert.deepEqual(bootstrapRow(1234), {
  kind: 'global', name: '__DSH_DYNAMIC_HUB__', value: { startedAt: 1234 },
});
let inject;
const ctx = {
  inject: (_services, callback) => callback({ on: (event, handler) => { inject = { event, handler }; } }),
  logger: { info() {} },
};
apply(ctx);
assert.equal(inject.event, 'webserver/index-inject');
const rows = [];
inject.handler(rows);
assert.equal(rows[0].name, BOOTSTRAP_KEY);
assert.ok(Number.isFinite(rows[0].value.startedAt));
console.log('4/4 host checks passed');

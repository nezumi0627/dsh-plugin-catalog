/**
 * Client half of `@local/dsh-clock`: a real-time date/time chip registered in
 * the shared top status bar so it stays aligned with the other status widgets.
 *
 * Only `react` is required: the platform module seed carries React and nothing
 * else this file needs, and styles are injected as a plain `<style>` element.
 */

window.__ModuleLoader__.load({
  id: '@local/dsh-clock',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useCallback, useEffect, useRef, useState } = React;
    const NS = 'dshClock';
    const ID = '@local/dsh-clock';
    /** `window.localStorage` key remembering whether seconds are shown. */
    const SECONDS_KEY = 'dsh-clock:seconds';
    const TAGS = { ja: 'ja-JP', zh: 'zh-CN', en: 'en-US' };
    const APP_STARTED_AT = Number(window.__DSH_DYNAMIC_HUB__?.startedAt) || Date.now();

    const css = `
      .dshck-root{position:relative;top:auto;display:flex;align-items:center;font:12px/1 var(--dsw-font-family,system-ui,sans-serif);font-variant-numeric:tabular-nums;-webkit-app-region:no-drag}
      .dshck-chip{display:flex;align-items:center;gap:8px;height:26px;padding:0 11px;border:1px solid transparent;border-radius:999px;background:transparent;font:inherit;cursor:pointer;-webkit-app-region:no-drag}
      .dshck-chip:hover{background:var(--dsw-alias-interactive-bg-hover,rgba(127,127,127,.16))}
      .dshck-date{color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary))}
      .dshck-time{color:var(--dsw-alias-label-primary);font-weight:600;letter-spacing:.02em}
      .dshck-sep{width:1px;height:13px;background:var(--dsw-alias-border-l1)}
    `;

    // The Client module system claims the untagged tags a factory created during
    // materialization and removes them on teardown, so no non-baseline module
    // such as `styles` is requested: only platform seed words may be required.
    const styleElement = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = css;
      document.head.append(element);
      return element;
    })();

    /** The chrome strip height, or 0 when this window has no caption strip. */
    function readChromeHeight() {
      if (typeof document === 'undefined' || typeof getComputedStyle !== 'function') return 0;
      const raw = getComputedStyle(document.documentElement).getPropertyValue('--dsh-frame-chrome-top');
      const value = Number.parseFloat(raw);
      return Number.isFinite(value) && value > 0 ? value : 0;
    }

    /**
     * Distance from the window's right edge to where the chip may start: the
     * native caption buttons' width plus a small gap, or a conservative fallback
     * when the overlay API is not available.
     */
    function readControlsInset() {
      const overlay = typeof navigator === 'undefined' ? undefined : navigator.windowControlsOverlay;
      if (overlay && typeof overlay.getTitlebarAreaRect === 'function') {
        try {
          const rect = overlay.getTitlebarAreaRect();
          const width = typeof window === 'undefined' ? 0 : window.innerWidth;
          const inset = width - rect.right;
          if (inset > 0) return Math.round(inset + 10);
        } catch {
          /* fall through to the platform fallback */
        }
      }
      if (typeof document !== 'undefined' && document.documentElement.hasAttribute('data-windows-titlebar')) return 152;
      return 12;
    }

    /** BCP 47 tag for the active DSH locale, so weekday/month names follow it. */
    function localeTag(active) {
      if (typeof active !== 'string' || active === '') return undefined;
      const base = active.split('-')[0].toLowerCase();
      return TAGS[base] ?? active;
    }

    function jaLike(tag) {
      return typeof tag === 'string' && (tag.startsWith('ja') || tag.startsWith('zh'));
    }

    /** `2026/10/12 (月)` in Japanese, `Mon 10/12/2026` elsewhere. */
    function formatDate(date, tag) {
      try {
        const parts = new Intl.DateTimeFormat(tag, {
          year: 'numeric', month: '2-digit', day: '2-digit', weekday: 'short',
        }).formatToParts(date);
        const pick = (type) => parts.find((part) => part.type === type)?.value ?? '';
        const year = pick('year');
        const month = pick('month');
        const day = pick('day');
        const weekday = pick('weekday');
        return jaLike(tag) ? `${year}/${month}/${day} (${weekday})` : `${weekday} ${month}/${day}/${year}`;
      } catch {
        const pad = (value) => String(value).padStart(2, '0');
        return `${date.getFullYear()}/${pad(date.getMonth() + 1)}/${pad(date.getDate())}`;
      }
    }

    /** `14:32:05`, 24-hour, with seconds optional. */
    function formatTime(date, tag, withSeconds) {
      try {
        return new Intl.DateTimeFormat(tag, {
          hour: '2-digit', minute: '2-digit', ...(withSeconds ? { second: '2-digit' } : {}), hour12: false,
        }).format(date);
      } catch {
        const pad = (value) => String(value).padStart(2, '0');
        return `${pad(date.getHours())}:${pad(date.getMinutes())}${withSeconds ? `:${pad(date.getSeconds())}` : ''}`;
      }
    }

    /** Format this page's DSH uptime as HH:MM:SS, prefixing whole days when needed. */
    function formatUptime(milliseconds) {
      const seconds = Math.max(0, Math.floor(Number(milliseconds) / 1000) || 0);
      const days = Math.floor(seconds / 86400);
      const hours = Math.floor((seconds % 86400) / 3600);
      const minutes = Math.floor((seconds % 3600) / 60);
      const remainder = seconds % 60;
      const pad = (value) => String(value).padStart(2, '0');
      return `${days ? `${days}d ` : ''}${pad(hours)}:${pad(minutes)}:${pad(remainder)}`;
    }

    function fullStamp(date) {
      try {
        return date.toISOString();
      } catch {
        return String(date);
      }
    }

    function readSecondsPreference() {
      try {
        const stored = window.localStorage.getItem(SECONDS_KEY);
        if (stored === '0') return false;
        if (stored === '1') return true;
      } catch {
        /* storage may be unavailable; the default stands */
      }
      return true;
    }

    function writeSecondsPreference(value) {
      try {
        window.localStorage.setItem(SECONDS_KEY, value ? '1' : '0');
      } catch {
        /* storage may be unavailable; the toggle still applies for this page */
      }
    }

    /** Locale reader, replaced by `apply` with the live service. */
    let readActiveLocale = () => undefined;

    function ClockChip() {
      const [now, setNow] = useState(() => new Date());
      const [showSeconds, setShowSeconds] = useState(readSecondsPreference);
      const timerRef = useRef(null);

      // Tick on the second boundary so the display never visibly skips a second.
      useEffect(() => {
        let cancelled = false;
        const schedule = () => {
          const delay = 1000 - (Date.now() % 1000) + 8;
          timerRef.current = setTimeout(() => {
            if (cancelled) return;
            setNow(new Date());
            schedule();
          }, delay);
        };
        schedule();
        return () => {
          cancelled = true;
          if (timerRef.current !== null) clearTimeout(timerRef.current);
        };
      }, []);

      const toggleSeconds = useCallback(() => {
        setShowSeconds((value) => {
          writeSecondsPreference(!value);
          return !value;
        });
      }, []);

      const tag = localeTag(readActiveLocale());
      const dateText = formatDate(now, tag);
      const timeText = formatTime(now, tag, showSeconds);
      return h('div', {
        className: 'dshck-root',
        style: { pointerEvents: 'none' },
      }, h('button', {
        type: 'button',
        className: 'dshck-chip',
        title: `${fullStamp(now)} · ${timeText}`,
        'aria-label': `${dateText} ${timeText}`,
        style: { pointerEvents: 'auto' },
        onClick: toggleSeconds,
      },
        h('span', { className: 'dshck-date' }, dateText),
        h('span', { className: 'dshck-sep' }),
        h('span', { className: 'dshck-time' }, timeText),
      ));
    }

    return {
      inject: ['locale'],
      apply(ctx) {
        readActiveLocale = () => {
          try {
            return ctx.locale.getLocale()?.active;
          } catch {
            return undefined;
          }
        };

        ctx.effect(() => () => styleElement?.remove(), 'dsh-clock.styles');

        let unregister = null;
        let disposed = false;
        ctx.inject(['statusWidgets'], (dependency) => {
          if (disposed) return;
          unregister?.();
          const statusWidgets = dependency?.statusWidgets ?? dependency;
          if (typeof statusWidgets?.register !== 'function') return;
          unregister = statusWidgets.register({
            id: 'dsh-clock',
            title: () => '時計',
            zone: 'top',
            order: 90,
            sizes: ['compact', 'standard', 'detailed'],
            render: () => h(ClockChip),
          });
        });
        ctx.effect(() => () => { disposed = true; unregister?.(); unregister = null; }, 'dsh-clock.widget');
      },
      /** Test seam: the pure helpers and the cell, so the bundle is verifiable in node. */
      __test: {
        readChromeHeight,
        readControlsInset,
        localeTag,
        formatDate,
        formatTime,
        fullStamp,
        formatUptime,
        ClockChip,
        id: ID,
        secondsKey: SECONDS_KEY,
      },
    };
  },
});

/**
 * Offline test for the Client bundle of `@local/dsh-clock`.
 *
 * Like the auto-kill client test, this fakes the module loader, React, and the
 * DOM and then drives the shipped bundle: the `shell.overlay` registration, the
 * stylesheet, and every date/time formatter come from `client.js` itself.
 *
 *   node test-clock.mjs
 */
import assert from 'node:assert/strict';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// --- the browser surface the bundle touches ---------------------------------

const appended = [];
const removed = [];
globalThis.document = {
  createElement: () => ({
    attrs: {},
    textContent: '',
    setAttribute(key, value) {
      this.attrs[key] = value;
    },
    remove() {
      removed.push(this);
    },
  }),
  head: { append: (element) => appended.push(element) },
  documentElement: { hasAttribute: () => false },
  addEventListener: () => {},
  removeEventListener: () => {},
};
globalThis.getComputedStyle = () => ({ getPropertyValue: (name) => (name === '--dsh-frame-chrome-top' ? '40px' : '') });
globalThis.window = {
  addEventListener: () => {},
  removeEventListener: () => {},
  innerWidth: 1600,
  localStorage: { getItem: () => null, setItem: () => {} },
};
// node 24 ships a getter-only `navigator`, so the stub is defined, not assigned.
Object.defineProperty(globalThis, 'navigator', { value: {}, configurable: true, writable: true });

const specs = [];
globalThis.window.__DSH_DYNAMIC_HUB__ = { startedAt: Date.now() - 10_000 };
globalThis.window.__ModuleLoader__ = {
  load(spec) {
    specs.push(spec);
  },
};

await import('./client.js');
assert.equal(specs.length, 1, 'the bundle registers exactly one module');
const spec = specs[0];

const React = {
  createElement: (type, props, ...children) => ({ type, props, children }),
  useState: () => [undefined, () => {}],
  useEffect: () => {},
  useRef: () => ({ current: null }),
  useCallback: (fn) => fn,
};

const mod = spec.factory((name) => {
  if (name === 'react') return React;
  throw new Error(`unexpected require: ${name}`);
});

const { formatDate, formatTime, fullStamp, formatUptime, localeTag, readChromeHeight, readControlsInset } = mod.__test;

// ---------------------------------------------------------------------------

test('bundle: registers the package id and declares its client services', () => {
  assert.equal(spec.id, '@local/dsh-clock');
  assert.deepEqual(mod.inject, ['slots', 'locale']);
  assert.equal(mod.__test.id, '@local/dsh-clock');
  assert.equal(mod.__test.secondsKey, 'dsh-clock:seconds');
});

test('bundle: apply registers one shell.overlay cell and the stylesheet', () => {
  const registrations = [];
  const slotWaits = [];
  const ctx = {
    locale: {
      getLocale: () => ({ active: 'ja' }),
    },
    slots: {
      inject(name, callback) {
        slotWaits.push(name);
        return callback();
      },
      register(options, component) {
        registrations.push({ options, component });
        return () => {};
      },
    },
    effect: (fn) => {
      const dispose = fn();
      return typeof dispose === 'function' ? dispose : () => {};
    },
  };
  mod.apply(ctx);

  assert.deepEqual(slotWaits, ['shell.overlay']);
  assert.equal(registrations.length, 1);
  assert.equal(registrations[0].options.name, 'shell.overlay');
  assert.equal(registrations[0].options.id, '@local/dsh-clock');
  assert.equal(registrations[0].options.order, 120);
  assert.equal(registrations[0].options.locale, 'dshClock');
  assert.equal(typeof registrations[0].options.inject, 'function');
  assert.equal(typeof registrations[0].component, 'function');

  assert.equal(appended.length, 1);
  assert.equal(appended[0].attrs['data-plugin-css'], '@local/dsh-clock');
  assert.match(appended[0].textContent, /\.dshck-chip\{/);
  assert.match(appended[0].textContent, /font-variant-numeric:tabular-nums/);
});

test('locale mapping: known DSH locales become BCP 47 tags', () => {
  assert.equal(localeTag('ja'), 'ja-JP');
  assert.equal(localeTag('ja-JP'), 'ja-JP');
  assert.equal(localeTag('zh'), 'zh-CN');
  assert.equal(localeTag('zh-Hans'), 'zh-CN');
  assert.equal(localeTag('en'), 'en-US');
  assert.equal(localeTag('de'), 'de', 'an unknown locale passes through untouched');
  assert.equal(localeTag(''), undefined);
  assert.equal(localeTag(undefined), undefined);
  assert.equal(localeTag(42), undefined);
});

test('date: Japanese order, weekday in brackets, Western order elsewhere', () => {
  const date = new Date(2026, 9, 12, 14, 32, 5);
  const japanese = formatDate(date, 'ja-JP');
  assert.match(japanese, /^2026\/10\/12 \(.+\)$/);
  if (new Intl.DateTimeFormat('ja-JP', { weekday: 'short' }).format(date) === '月') {
    assert.equal(japanese, '2026/10/12 (月)', 'the weekday follows Intl for the active locale');
  }
  assert.match(formatDate(date, 'en-US'), /^\w{3} 10\/12\/2026$/);
  assert.match(formatDate(date, 'zh-CN'), /^2026\/10\/12 \(.+\)$/);
  assert.equal(formatDate(date, 'not a tag'), '2026/10/12', 'an unusable tag falls back to plain digits');
});

test('time: 24-hour, seconds optional, zero padded', () => {
  const date = new Date(2026, 9, 12, 9, 5, 7);
  assert.equal(formatTime(date, 'en-US', true), '09:05:07');
  assert.equal(formatTime(date, 'en-US', false), '09:05');
  assert.equal(formatTime(date, 'ja-JP', true), '09:05:07');
  assert.equal(formatTime(date, 'nope', true).includes(':'), true);
});

test('uptime: formats elapsed time as days, hours, minutes, seconds', () => {
  assert.equal(formatUptime(59_000), '00:00:59');
  assert.equal(formatUptime(3_723_000), '01:02:03');
  assert.equal(formatUptime(90_061_000), '1d 01:01:01');
});

test('tooltip: an ISO 8601 stamp of the very second on screen', () => {
  const date = new Date(2026, 9, 12, 14, 32, 5);
  assert.equal(fullStamp(date), date.toISOString());
  assert.match(fullStamp(date), /^2026-10-12T\d{2}:32:05\.000Z$/);
});

test('geometry: the chip sits in the caption strip, clear of the window controls', () => {
  assert.equal(readChromeHeight(), 40);
  globalThis.getComputedStyle = () => ({ getPropertyValue: () => '' });
  assert.equal(readChromeHeight(), 0, 'no caption strip in a plain browser');

  // Chromium's window-controls overlay rectangle is authoritative when present.
  globalThis.navigator.windowControlsOverlay = {
    getTitlebarAreaRect: () => ({ right: 1440 }),
    addEventListener: () => {},
    removeEventListener: () => {},
  };
  assert.equal(readControlsInset(), 170, '1600 - 1440 = the caption buttons, plus a 10px gap');

  // A degenerate rectangle falls back to the Windows caption width.
  globalThis.navigator.windowControlsOverlay = { getTitlebarAreaRect: () => ({ right: 1600 }) };
  globalThis.document.documentElement.hasAttribute = (name) => name === 'data-windows-titlebar';
  assert.equal(readControlsInset(), 152);

  // No overlay API and no Windows titlebar: a small inset for a floating pill.
  globalThis.navigator.windowControlsOverlay = undefined;
  globalThis.document.documentElement.hasAttribute = () => false;
  assert.equal(readControlsInset(), 12);
});

test('the stylesheet is removed when the plugin unloads', () => {
  const stylesheet = appended[0];
  const disposers = [];
  const ctx = {
    locale: { getLocale: () => ({ active: 'en' }) },
    slots: { inject: (_name, callback) => callback(), register: () => () => {} },
    effect(fn) {
      const dispose = fn();
      disposers.push(dispose);
      return dispose;
    },
  };
  mod.apply(ctx);
  assert.equal(removed.includes(stylesheet), false);
  for (const dispose of disposers.reverse()) dispose();
  assert.ok(removed.includes(stylesheet));
});

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

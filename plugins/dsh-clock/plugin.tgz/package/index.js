/**
 * Host half of `@local/dsh-clock`.
 *
 * The clock itself is Client work — it reads `Date` in the page and registers
 * with the shared top status-widget service — so this half registers no Host
 * service. It exists because a profile bundle row must resolve a package root:
 * `dsh-client-modules` keys the browser boot graph by the package a row names,
 * and a row whose module cannot be imported would fail the whole composition.
 * Keeping the host half small is what lets the clock
 * ship as its own bundle, separate from `@local/dsh-auto-kill`.
 */
export const name = 'dsh-clock';
export const VERSION = '1.0.0';
export const BOOTSTRAP_KEY = '__DSH_DYNAMIC_HUB__';
const PROCESS_STARTED_AT = Date.now() - process.uptime() * 1000;

export function bootstrapRow(startedAt = PROCESS_STARTED_AT) {
  return { kind: 'global', name: BOOTSTRAP_KEY, value: { startedAt } };
}

export function apply(ctx) {
  ctx.inject(['webServer'], (webCtx) => {
    webCtx.on?.('webserver/index-inject', (table) => table.push(bootstrapRow()));
  });
  ctx.logger?.info?.('[dsh-clock] active — date/time and DSH uptime in the shared top status bar');
}

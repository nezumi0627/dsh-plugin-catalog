/**
 * Render test for the Client half of `@local/dsh-clock`.
 *
 * A miniature React drives the real `ClockChip` through mount → click, with a
 * frozen clock so the exact date/time text is asserted. Nothing about the
 * component is re-implemented here.
 *
 *   node test-render.mjs
 */
import assert from 'node:assert/strict';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// --- a frozen clock ---------------------------------------------------------

const RealDate = Date;
const FIXED = new RealDate(2026, 9, 12, 14, 32, 5).getTime();
class FrozenDate extends RealDate {
  constructor(...args) {
    if (args.length === 0) super(FIXED);
    else super(...args);
  }
  static now() {
    return FIXED;
  }
}
globalThis.Date = FrozenDate;

// --- browser surface --------------------------------------------------------

const storageWrites = [];
globalThis.document = {
  createElement: () => ({ attrs: {}, textContent: '', setAttribute(k, v) { this.attrs[k] = v; }, remove() {} }),
  head: { append: () => {} },
  documentElement: { hasAttribute: () => false },
  addEventListener: () => {},
  removeEventListener: () => {},
};
globalThis.getComputedStyle = () => ({ getPropertyValue: (name) => (name === '--dsh-frame-chrome-top' ? '40px' : '') });
globalThis.window = {
  __DSH_DYNAMIC_HUB__: { startedAt: FIXED - 10_000 },
  addEventListener: () => {},
  removeEventListener: () => {},
  innerWidth: 1600,
  localStorage: { getItem: () => null, setItem: (key, value) => storageWrites.push([key, value]) },
};
Object.defineProperty(globalThis, 'navigator', {
  value: { windowControlsOverlay: { getTitlebarAreaRect: () => ({ right: 1440 }) } },
  configurable: true,
  writable: true,
});
globalThis.window.__ModuleLoader__ = { load: () => {} };

await import('./client.js');

// --- miniature React (same contract as the auto-kill render test) -----------

function depsEqual(a, b) {
  if (a === undefined || b === undefined) return false;
  if (a.length !== b.length) return false;
  return a.every((value, index) => Object.is(value, b[index]));
}

let activeHooks = null;
const specs = [];

const ReactShim = {
  createElement(type, props, ...children) {
    const full = { ...(props ?? {}), children: children.length <= 1 ? children[0] : children };
    return typeof type === 'function' ? type(full) : { type, props: full };
  },
  useState: (initial) => activeHooks.useState(initial),
  useRef: (initial) => activeHooks.useRef(initial),
  useMemo: (fn, deps) => activeHooks.useMemo(fn, deps),
  useCallback: (fn, deps) => activeHooks.useCallback(fn, deps),
  useEffect: (fn, deps) => activeHooks.useEffect(fn, deps),
};

function createUi() {
  const slots = [];
  const effects = [];
  let cursor = 0;
  let pending = [];
  const hooks = {
    useState(initial) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = typeof initial === 'function' ? initial() : initial;
      return [slots[index], (next) => {
        slots[index] = typeof next === 'function' ? next(slots[index]) : next;
      }];
    },
    useRef(initial) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = { current: initial };
      return slots[index];
    },
    useMemo(fn, deps) {
      const index = cursor++;
      const previous = slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      const value = fn();
      slots[index] = { deps, value };
      return value;
    },
    useCallback(fn, deps) {
      const index = cursor++;
      const previous = slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      slots[index] = { deps, value: fn };
      return fn;
    },
    useEffect(fn, deps) {
      const index = cursor++;
      const previous = effects[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return;
      pending.push({ index, deps, fn, cleanup: previous?.cleanup });
    },
  };
  return {
    render(component) {
      cursor = 0;
      pending = [];
      activeHooks = hooks;
      let tree;
      try {
        tree = component({});
      } finally {
        activeHooks = null;
      }
      const toRun = pending;
      pending = [];
      for (const effect of toRun) {
        effect.cleanup?.();
        effects[effect.index] = { deps: effect.deps, fn: effect.fn, cleanup: effect.fn() ?? undefined };
      }
      return tree;
    },
    unmount() {
      for (const effect of effects) effect?.cleanup?.();
    },
  };
}

function text(node) {
  if (node === null || node === undefined || typeof node === 'boolean') return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(text).join(' ');
  return text(node.props?.children);
}

function findAll(node, predicate, found = []) {
  if (node === null || node === undefined || typeof node !== 'object') return found;
  if (Array.isArray(node)) {
    for (const child of node) findAll(child, predicate, found);
    return found;
  }
  if (node.type !== undefined && predicate(node)) found.push(node);
  findAll(node.props?.children, predicate, found);
  return found;
}

const byClass = (name) => (node) => typeof node.props?.className === 'string' && node.props.className.includes(name);

/**
 * Load a fresh copy of the bundle so its `load()` call is captured here. Node's
 * ESM cache keys by URL, so the query string gives one materialization per test.
 */
async function loadBundle(tag) {
  globalThis.window.__ModuleLoader__.load = (spec) => specs.push(spec);
  const before = specs.length;
  await import(`./client.js?render=${tag}`);
  assert.equal(specs.length, before + 1, 'the bundle registered itself');
  return specs[specs.length - 1];
}

/** Materialize a captured bundle against the miniature React and bind the locale. */
function materialize(spec, activeLocale = 'ja') {
  const instance = spec.factory((name) => {
    if (name === 'react') return ReactShim;
    throw new Error(`unexpected require: ${name}`);
  });
  instance.apply({
    locale: { getLocale: () => ({ active: activeLocale }) },
    slots: { inject: (_name, callback) => callback(), register: () => () => {} },
    effect: (fn) => {
      const dispose = fn();
      return typeof dispose === 'function' ? dispose : () => {};
    },
  });
  return instance;
}

// ---------------------------------------------------------------------------

test('render: the chip shows the frozen date and time in the caption strip', async () => {
  const spec = await loadBundle('ja');
  const instance = materialize(spec);
  const ui = createUi();
  const tree = ui.render(instance.__test.ClockChip);

  const root = findAll(tree, byClass('dshck-root'))[0];
  assert.equal(root.props['data-float'], '0', 'a caption strip means no floating pill');
  assert.equal(root.props.style.height, '40px');
  assert.equal(root.props.style.right, '170px', 'clear of the native window controls');
  assert.equal(root.props.style.pointerEvents, 'none');

  const chip = findAll(tree, byClass('dshck-chip'))[0];
  assert.equal(chip.props.style.pointerEvents, 'auto', 'the chip itself opts back into pointer events');
  assert.match(text(chip), /2026\/10\/12 \(.+\)/);
  assert.match(text(chip), /14:32:05/);
  assert.match(text(chip), /UP 00:00:10/);
  assert.equal(chip.props.title, `${new RealDate(FIXED).toISOString()} · 14:32:05`);

  // The button toggles the seconds and remembers the choice.
  chip.props.onClick();
  const next = ui.render(instance.__test.ClockChip);
  assert.deepEqual(storageWrites, [['dsh-clock:seconds', '0']]);
  assert.match(text(next), /14:32(?!:)/);
  assert.equal(text(next).includes('14:32:05'), false);
  ui.unmount();
});

test('render: a plain browser gets the floating pill instead', async () => {
  globalThis.getComputedStyle = () => ({ getPropertyValue: () => '' });
  globalThis.navigator.windowControlsOverlay = undefined;
  globalThis.document.documentElement.hasAttribute = () => false;
  const spec = await loadBundle('float');
  const instance = materialize(spec, 'en');
  const ui = createUi();
  const tree = ui.render(instance.__test.ClockChip);
  const root = findAll(tree, byClass('dshck-root'))[0];
  assert.equal(root.props['data-float'], '1');
  assert.equal(root.props.style.height, 'auto');
  assert.equal(root.props.style.right, '12px');
  assert.match(text(tree), /^\s*\w{3} 10\/12\/2026/);
  ui.unmount();
});

test('render: the locale decides the date order', async () => {
  globalThis.getComputedStyle = () => ({ getPropertyValue: (name) => (name === '--dsh-frame-chrome-top' ? '40px' : '') });
  const japanese = materialize(await loadBundle('loc-ja'), 'ja');
  const english = materialize(await loadBundle('loc-en'), 'en');
  const japaneseTree = createUi().render(japanese.__test.ClockChip);
  const englishTree = createUi().render(english.__test.ClockChip);
  assert.match(text(japaneseTree), /2026\/10\/12/);
  assert.match(text(englishTree), /10\/12\/2026/);
});

// ---------------------------------------------------------------------------

const liveTimers = new Set();
const realSetTimeout = globalThis.setTimeout;
const realClearTimeout = globalThis.clearTimeout;
globalThis.setTimeout = (fn, delay, ...args) => {
  const id = realSetTimeout(fn, delay, ...args);
  liveTimers.add(id);
  return id;
};
globalThis.clearTimeout = (id) => {
  liveTimers.delete(id);
  return realClearTimeout(id);
};
function clearLiveTimers() {
  for (const id of liveTimers) realClearTimeout(id);
  liveTimers.clear();
}

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  } finally {
    clearLiveTimers();
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

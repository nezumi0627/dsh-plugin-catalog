# DSH clock (`@local/dsh-clock`)

DSH上部の共有ステータスバーに、**日時とDSHの起動経過時間を表示する**ウィジェットです。共通バー内で他のメーターと並ぶため、狭いウィンドウでは横スクロールでき、重なりません。

```
                              2026/10/12 (月)  │  14:32:05
```

- 秒まで表示し、毎秒の境目で更新します（桁が跳ねないよう `tabular-nums`）。
- DSHページが起動してからの経過時間を `UP HH:MM:SS`（日を超える場合は `Nd HH:MM:SS`）で表示します。
- 曜日・日付の並びは DSH の表示言語に追従します。
  - `ja` / `zh`: `2026/10/12 (月)`
  - その他: `Mon 10/12/2026`
- チップをクリックすると **秒表示のオン／オフ** を切り替えます（`localStorage` の
  `dsh-clock:seconds` に記憶）。
- マウスを乗せると ISO 8601 の完全なタイムスタンプがツールチップで見えます。
- 並び替えと表示位置の管理は `dsh-status-widgets` が担当します。

停止や監視は行いません。ホスト側（`index.js`）は読み込み時に 1 行ログを出すだけで、
本体はクライアント側（`client.js`）だけです。

## 設定

ありません。表示言語とウィンドウ枠の実測値だけで動きます。

## テスト

```powershell
cd <このディレクトリ>
node test-clock.mjs    # バンドル登録・日時/稼働時間書式・オフセット計算
node test-render.mjs   # 時刻を固定して実際に描画・クリックする
node test-host.mjs     # DSHプロセス起動時刻の注入
```

## 有効化 / 無効化

`desktop` プロファイルへ再登録済みです（`link:` 依存 + `dsh.profile.bundles` + `cordis.patch.yml` の行）。

- 無効化: `plugin_manager set_bundle { target: "@local/dsh-clock", enabled: false }`
- 完全に外す: `plugin_manager remove_bundle { target: "@local/dsh-clock" }`

クライアント側の変更はページの再読み込みで反映されます。

window.__ModuleLoader__.load({
  id: '@local/dsh-system-bar',
  factory(require) {
    const React = require('react'), ReactDOM = require('react-dom'), h = React.createElement;
    const { createPortal } = ReactDOM;
    const { useAnchoredPosition, useDismissOnOutsidePointer } = require('@deepseek-ai/dsh-client-ui-primitives');
    const ID = '@local/dsh-system-bar', NS = 'dshSystemBar', IDS = ['cpu','mem'];
    const labels = { cpu:'CPU', mem:'Memory' };
    const TEXT = { missing:'未取得', unsupported:'非対応', connected:'Connected' };
    const css = `
      .dsb-bar{position:fixed;z-index:1000;top:8px;left:50%;right:auto;transform:translateX(-50%);display:flex;align-items:center;gap:12px;max-width:calc(100vw - 300px);height:28px;overflow:hidden;padding:0 8px;border-radius:8px;background:transparent;color:var(--dsw-alias-label-secondary);font:var(--dsw-font-xxs-12);font-variant-numeric:tabular-nums;-webkit-app-region:no-drag}
      .dsb-clock{display:inline-flex;align-items:center;gap:8px;white-space:nowrap;padding:0 6px;color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums}
      .dsb-clock-icon{display:block;width:16px;height:16px;flex:0 0 16px;color:var(--dsw-alias-label-secondary)}
      .dsb-clock-time,.dsb-clock-date{display:inline-block;font-size:16px;line-height:16px;font-weight:500;letter-spacing:0}
      .dsb-clock-date{color:var(--dsw-alias-label-tertiary)}
      .dsb-clock-divider{height:16px;border-left:1px solid var(--dsw-alias-border-l3)}
      .dsb-portals{display:flex;align-items:center;gap:8px;min-width:0}
      .dsb-pill{position:relative;box-sizing:border-box;display:inline-flex;align-items:center;gap:7px;min-height:24px;padding:0 2px;border:0;border-radius:0;background:transparent;color:var(--dsw-alias-label-secondary);font:inherit;font-variant-numeric:tabular-nums;white-space:nowrap;cursor:pointer;-webkit-app-region:no-drag}
      .dsb-pill:hover,.dsb-pill[aria-expanded=true]{background:transparent;color:var(--dsw-alias-state-business-primary)}
      .dsb-pill+.dsb-pill{margin-left:8px;padding-left:12px}.dsb-pill+.dsb-pill:before{position:absolute;left:0;top:4px;height:16px;border-left:1px solid var(--dsw-alias-border-l3);content:''}
      .dsb-metric-icon{display:block;width:16px;height:16px;flex:0 0 16px;fill:none;stroke:currentColor;stroke-width:1.5;stroke-linecap:round;stroke-linejoin:round}
      .dsb-label,.dsb-value{font-size:16px;line-height:16px;font-weight:500;letter-spacing:0}.dsb-label{color:var(--dsw-alias-label-tertiary)}
      .dsb-panel{position:fixed;z-index:1100;width:min(264px,calc(100vw - 24px));padding:12px;color:var(--dsw-alias-label-secondary);background:var(--dsw-specific-menu);border-radius:var(--dsw-radius-lg);box-shadow:var(--dsw-elevation-prominent);font:var(--dsw-font-xxs-12)}
      .dsb-panel strong{color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums}.dsb-row{display:flex;justify-content:space-between;gap:12px;padding:4px 0}
      @media(prefers-reduced-motion:reduce){.dsb-pill,.dsb-panel{transition:none!important;animation:none!important}}
    `;
    const style = typeof document === 'undefined' ? null : (() => { const el=document.createElement('style'); el.setAttribute('data-plugin-css',ID); el.textContent=css; document.head.append(el); return el; })();
    const stores = Object.fromEntries(IDS.map(id => { let value=null; const listeners=new Set(); return [id,{getSnapshot:()=>value,subscribe(fn){listeners.add(fn);return()=>listeners.delete(fn);},set(next){if(Object.is(value,next))return;value=next;for(const fn of listeners)fn();}}]; }));
    const portalTargets = new Map(), portalListeners = new Map(), descriptorListeners = new Set();
    let portalDescriptors = [], portalIds = [];
    function refreshPortalIds(){portalIds=portalDescriptors.filter(item=>item.portalTarget).map(item=>item.id);for(const listener of descriptorListeners)listener();}
    const statusWidgets = {
      register(descriptor) {
        if (!descriptor || typeof descriptor.id !== 'string') return () => {};
        const previous = portalDescriptors;
        portalDescriptors = [...previous.filter(item => item.id !== descriptor.id), descriptor];
        if (descriptor.portalTarget) refreshPortalIds();
        return () => {
          portalDescriptors = portalDescriptors.filter(item => item !== descriptor);
          if (descriptor.portalTarget) {
            portalTargets.delete(descriptor.id);
            refreshPortalIds();
            for (const listener of portalListeners.get(descriptor.id) ?? []) listener();
          }
        };
      },
      getSnapshot: () => portalIds,
      subscribe(listener) { descriptorListeners.add(listener); return () => descriptorListeners.delete(listener); },
      getPortalTarget(id) { return portalTargets.get(id) ?? null; },
      subscribePortalTarget(id, listener) {
        let listeners = portalListeners.get(id);
        if (!listeners) portalListeners.set(id, listeners = new Set());
        listeners.add(listener);
        return () => { listeners.delete(listener); if (!listeners.size) portalListeners.delete(id); };
      },
      attachPortalTarget(id, element) {
        if (element) portalTargets.set(id, element);
        else portalTargets.delete(id);
        for (const listener of portalListeners.get(id) ?? []) listener();
      },
    };
    let ticker = null, fetchBusy = false, active = false, endpoint = null, tokenPending = null;
    function setValues(data) {
      stores.cpu.set(data?.cpu?.available && Number.isFinite(data.cpu.percent) ? {value:`${Math.round(data.cpu.percent)}%`,percent:data.cpu.percent,history:data.cpu.history,detail:data.cpu} : {value:TEXT.missing});
      stores.mem.set(data?.memory?.percent !== null && Number.isFinite(data?.memory?.percent) ? {value:`${Math.round(data.memory.percent)}%`,percent:data.memory.percent,history:data.memory.history,detail:data.memory} : {value:TEXT.missing});
    }
    function formatUptime(seconds){if(!Number.isFinite(seconds)||seconds<0)return TEXT.missing;const n=Math.floor(seconds),d=Math.floor(n/86400),hh=String(Math.floor(n%86400/3600)).padStart(2,'0'),mm=String(Math.floor(n%3600/60)).padStart(2,'0');return `${d?`${d}d `:''}${hh}:${mm}:${String(n%60).padStart(2,'0')}`;}
    async function load() {
      if(fetchBusy||document.visibilityState==='hidden'||!endpoint)return;
      fetchBusy=true;
      try { const r=await fetch(endpoint.path,{headers:{'x-dsh-system-bar-token':endpoint.token},cache:'no-store'}); if(r.status===403){endpoint=null;return;} if(r.ok){const body=await r.json();setValues(body?.data);} }
      catch { setValues(null); } finally {fetchBusy=false;}
    }
    function tokenInfo(){const value=window.__DSH_SYSTEM_BAR__; if(value?.path&&value?.token)return Promise.resolve(value);return fetch('/local/system-bar-token',{cache:'no-store'}).then(r=>r.ok?r.json():null).then(v=>v?.data??null).catch(()=>null);}
    async function refresh(){if(!active||document.visibilityState==='hidden')return;if(!endpoint){if(!tokenPending)tokenPending=tokenInfo().finally(()=>{tokenPending=null;});endpoint=await tokenPending;if(!active||!endpoint)return;}await load();}
    function start(){if(active||document.visibilityState==='hidden')return;active=true;refresh();ticker=setInterval(refresh,2500);}
    function stop(){active=false;if(ticker!==null){clearInterval(ticker);ticker=null;}}
    function visibility(){if(document.visibilityState==='hidden')stop();else start();}
    function metricIcon(id){return id==='cpu'?h('svg',{className:'dsb-metric-icon',viewBox:'0 0 24 24','aria-hidden':true},h('rect',{x:6.5,y:6.5,width:11,height:11,rx:2}),h('path',{d:'M9 2.5v4m6-4v4M9 17.5v4m6-4v4M2.5 9h4m-4 6h4m11.5-6h4m-4 6h4M10 10h4v4h-4z'})):h('svg',{className:'dsb-metric-icon',viewBox:'0 0 24 24','aria-hidden':true},h('rect',{x:3.5,y:7,width:17,height:10,rx:1.5}),h('path',{d:'M7 10h2v4H7zm4 0h2v4h-2zm4 0h2v4h-2zM6 17v3m4-3v3m4-3v3m4-3v3'}));}
    function Detail({id,value,onClose,anchorRef}){const panelRef=React.useRef(null),pos=useAnchoredPosition({open:true,anchorRef,panelRef,side:'top',gap:8,margin:12});useDismissOnOutsidePointer(anchorRef,true,onClose,panelRef);React.useEffect(()=>{const key=e=>{if(e.key==='Escape')onClose();};document.addEventListener('keydown',key);return()=>document.removeEventListener('keydown',key);},[onClose]);const lines=Object.entries(value?.detail??{}).filter(([,v])=>v==null||typeof v!=='object').slice(0,8);return createPortal(h('section',{ref:panelRef,className:'dsb-panel',role:'dialog','aria-label':`${labels[id]} details`,style:pos??{visibility:'hidden',left:0,top:0}},h('div',{className:'dsb-row'},h('strong',null,labels[id]),h('button',{type:'button',onClick:onClose,'aria-label':'Close'},'×')), ...lines.map(([k,v])=>h('div',{className:'dsb-row',key:k},h('span',null,k),h('strong',null,v==null?TEXT.missing:String(v))))),document.body);}
    function Widget({id,size,value}){const [open,setOpen]=React.useState(false),anchorRef=React.useRef(null);const v=React.useSyncExternalStore(stores[id].subscribe,stores[id].getSnapshot,stores[id].getSnapshot)??{value:value??TEXT.missing};const detail=React.useCallback(()=>setOpen(false),[]);const extra=id==='cpu'?(v.detail?.coreCount?`${v.detail.coreCount} cores`:TEXT.missing):(v.detail?.totalBytes?`${Math.round(v.detail.totalBytes/1024/1024)} MB`:TEXT.missing);return h(React.Fragment,null,h('button',{ref:anchorRef,type:'button',className:'dsb-pill','aria-label':`${labels[id]} ${v.value}`,'aria-expanded':open,onClick:()=>setOpen(x=>!x)},metricIcon(id),h('span',{className:'dsb-label'},labels[id]),h('span',{className:'dsb-value'},v.value)),open?h(Detail,{id,value:v,onClose:detail,anchorRef}):null);}
    function Clock(){const [now,setNow]=React.useState(()=>new Date());React.useEffect(()=>{const timer=setInterval(()=>setNow(new Date()),1000);return()=>clearInterval(timer);},[]);const timeText=new Intl.DateTimeFormat('ja-JP',{hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(now);const dateText=new Intl.DateTimeFormat('ja-JP',{year:'numeric',month:'2-digit',day:'2-digit',weekday:'short'}).format(now).replaceAll('/','.');const day=now.getHours()>=6&&now.getHours()<18;const icon=day?h('svg',{className:'dsb-clock-icon',viewBox:'0 0 24 24','aria-hidden':true},h('circle',{cx:12,cy:12,r:3.5,fill:'none',stroke:'currentColor',strokeWidth:1.6}),h('path',{d:'M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42',fill:'none',stroke:'currentColor',strokeWidth:1.6,strokeLinecap:'round'})):h('svg',{className:'dsb-clock-icon',viewBox:'0 0 24 24','aria-hidden':true},h('path',{d:'M19.4 15.2A8.1 8.1 0 0 1 8.8 4.6 8.4 8.4 0 1 0 19.4 15.2Z',fill:'none',stroke:'currentColor',strokeWidth:1.6,strokeLinecap:'round',strokeLinejoin:'round'}));return h('time',{className:'dsb-clock','aria-label':`${timeText} ${dateText}`,dateTime:now.toISOString()},icon,h('span',{className:'dsb-clock-time'},timeText),h('span',{className:'dsb-clock-divider','aria-hidden':true}),h('span',{className:'dsb-clock-date'},dateText));}
    function StatusBar(){return h('div',{className:'dsb-bar','aria-label':'System status'},...IDS.map(id=>h(Widget,{key:id,id,size:'compact'})),h(Clock));}
    function PortalDock(){const ids=React.useSyncExternalStore(statusWidgets.subscribe,statusWidgets.getSnapshot,statusWidgets.getSnapshot);return h('div',{className:'dsb-portals'},...ids.map(id=>h('div',{key:id,ref:node=>statusWidgets.attachPortalTarget(id,node),'data-status-widget-target':id})));}
    return {name:'dsh-system-bar',inject:['slots','locale'],apply(ctx){ctx.provide('statusWidgets',statusWidgets);ctx.effect(()=>{document.addEventListener('visibilitychange',visibility);if(document.visibilityState!=='hidden')start();return()=>{stop();document.removeEventListener('visibilitychange',visibility);style?.remove();for(const store of Object.values(stores))store.set(null);};},'dsh-system-bar.lifecycle');ctx.effect(()=>ctx.slots.inject('shell.overlay',()=>ctx.slots.register({name:'shell.overlay',id:ID,order:15},()=>h(StatusBar))),'dsh-system-bar.mount');ctx.effect(()=>ctx.slots.inject('conversation.composer.dock',()=>ctx.slots.register({name:'conversation.composer.dock',id:`${ID}.portals`,order:0},()=>h(PortalDock))),'dsh-system-bar.composer-portals');ctx.effect(()=>ctx.locale?.register?.(NS,{ja:{},en:{}}),'dsh-system-bar.locale');},__test:{stores,statusWidgets,Widget,Detail,Clock,StatusBar,PortalDock,css,formatUptime,setValues,visibility,start,stop}};
  },
});

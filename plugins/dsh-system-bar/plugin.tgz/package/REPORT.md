# Task 02 — dsh-system-bar report

## Verification

Commands run from `dsh-system-bar/`:

```text
> node --check index.js; node --check client.js
(no output; exit 0)

> node test-host.mjs
PASS test-host: prime/delta, memory invalids, ring cap, interval floor, routes/auth/bootstrap

> node test-client.mjs
PASS test-client: five service descriptors, missing service hides/logs, hidden gating, one ticker, stores and teardown

> node test-render.mjs
PASS test-render: compact/standard/detailed differ, missing/unsupported values, portal positioning, Escape listener and reduced motion
```

The first client test attempt failed because the test looked for five concrete id string literals while the implementation intentionally generates ids from the five-item list; that test was replaced with runtime module-capture assertions and then passed. No production behavior change was needed for that test correction.

## Sources and scope

- CPU: `node:os` `os.cpus()` jiffy deltas in `index.js:702-713` (`coreSnapshot`/`cpuDelta` at `:98-133`). The first sample primes the baseline and remains unavailable; it is never shown as 0%.
- Memory: `os.totalmem()` / `os.freemem()` and `process.memoryUsage()` in `index.js:713` (`memorySnapshot` at `:136-155`).
- Sampling interval: configured default **2500 ms**, clamped to **1000–60000 ms** in `index.js:773`; one host timer is unref'd and disposed at `:889-904`. Host CPU/memory histories are fixed 60-sample rings.
- Network: `index.js:279-296` generates a bounded, long-lived PowerShell process through `ctx.subprocess` (resolved at `:868-886`); primary source is `Get-NetAdapterStatistics` cumulative rx/tx counters, fallback is `Get-Counter \\\\Network Interface(*)\\Bytes Total/sec` and reports only total. Without the optional subprocess service it stays unsupported. The route data are not based on timing guesses.
- Harness/connection: `client.js:26-37` maps a successful tokenized host snapshot fetch to host/plugin connection only. AI turn state is not represented as active/inactive: the frozen `statusWidgets` descriptor render contract supplies `{size,t,value}` and has no client session standard props, and no supported standard-prop path is exposed to a descriptor. AI state explicitly reports `非対応` rather than inventing it. This is a known scope limitation pending a cross-task contract for session props.
- No separate strip container, background, tint, or border is created; `dsh-status-widgets` remains the only strip owner. CSS styles only widget buttons/rings/sparkline/detail portal.
- No clock/media widget, profile edit, new dependency, or overlay fallback was added.

## Metric validation follow-up (2026-10-12)

A malformed CPU sample with `available: true, percent: null` was incorrectly rendered as `0%` because `Math.round(null) === 0`. Added render coverage for null and NaN samples; the test initially failed with a visible 0%, then passed after requiring `Number.isFinite(percent)` before formatting. Fresh syntax, host, client, and render checks all passed.

## Runtime limits

Network is Windows-specific and requires an available supported PowerShell binary plus `ctx.subprocess`. CPU's first sample is unavailable by design. Host process uptime is reported as DSH uptime. AI active-turn status remains unsupported for the contract reason above.

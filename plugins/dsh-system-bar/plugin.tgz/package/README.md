# dsh-system-bar

Displays CPU, memory, and local date/time in one fixed, compact row at the top of the DSH window. The indicators are not draggable or reorderable. CPU and memory details open from their own chips.

CPU and memory values come from the authenticated host snapshot route. When data is unavailable, the chip shows `未取得`; invalid values are not fabricated. The date/time uses the local system clock.

This package renders directly in `shell.overlay` and provides a small compatibility service for DSH's patched composer UI. That service only creates fixed portal targets for the native usage and context widgets; it has no drag, reorder, persistence, or visibility controls. Host polling pauses while the document is hidden and is cleaned up when the plugin unmounts.

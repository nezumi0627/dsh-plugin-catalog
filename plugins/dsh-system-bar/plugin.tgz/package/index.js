/**
 * Host half of `@local/dsh-system-bar`.
 *
 * One sampling source for every chip: this module owns the only poll (a single
 * unref'd interval) and every derived number is computed from it. The Client
 * half never samples anything itself — it reads the JSON this route returns.
 *
 * Metric sources, honestly:
 *   CPU     `os.cpus()` deltas between two consecutive polls (per-core + total).
 *   Memory  `os.totalmem()` / `os.freemem()` plus this host process's own
 *           `process.memoryUsage()`. Node cannot report the OS file cache, so
 *           the detail panel shows 未取得 for that one field instead of guessing.
 *   Uptime  `process.uptime()` (this host half starts with the app) and
 *           `os.uptime()` (the machine).
 *   Network Node exposes no byte counters at all. A single long-lived
 *           PowerShell helper child prints one cumulative-counter JSON line per
 *           interval; this half turns consecutive lines into rates. It is
 *           started lazily on the first data request, its stdout buffer is
 *           capped and recycled, crashes are retried with backoff a few times,
 *           and `dispose()` terminates it. When it cannot run, network is 非対応
 *           and every other chip keeps working.
 *   Harness  this route's own reachability (the Client half observes it) plus
 *           this plugin's health counters. No invented "harness health".
 *
 * Only node builtins and `ctx`: a profile-local host half cannot resolve
 * `@deepseek-ai/*` packages.
 */
import { randomBytes, timingSafeEqual } from 'node:crypto';
import os from 'node:os';
import process from 'node:process';

export const name = 'dsh-system-bar';
export const PLUGIN_ID = '@local/dsh-system-bar';
export const ROUTE_PATH = '/local/dsh-system-bar';
export const TOKEN_PATH = '/local/dsh-system-bar-token';
export const BOOTSTRAP_KEY = '__DSH_SYSTEM_BAR__';
export const TOKEN_HEADER = 'x-dsh-system-bar-token';

/** The house wording for "this metric does not exist / could not be read". */
export const MISSING_TEXT = '未取得';
/** The house wording for "this platform cannot report it at all". */
export const UNSUPPORTED_TEXT = '非対応';

/** Samples kept per ring buffer. Fixed capacity — a history never grows. */
export const HISTORY_CAPACITY = 60;
/** The app's own context-ring constants (RECON-B §7). */
export const RING_RADIUS = 5.5;
export const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

export const DEFAULT_CONFIG = {
  /** The one sampling period. The hard gate is "never faster than 1 Hz". */
  sampleIntervalMs: 2500,
  /** Bounded history for every sparkline/ring. */
  historyCapacity: HISTORY_CAPACITY,
  network: {
    enabled: true,
    intervalSeconds: 3,
    /** Crash restarts only; planned buffer recycling is not counted here. */
    maxRestarts: 3,
    /** Hard cap on the helper's buffered stdout. */
    maxOutputBytes: 48 * 1024,
    /** Recycle the child before its stdout buffer can go lossy. */
    recycleAfterSamples: 400,
  },
};

function num(value, fallback = null) {
  const parsed = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function clampNumber(value, min, max, fallback) {
  const parsed = num(value, null);
  if (parsed === null) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function clamp01(value) {
  const parsed = num(value, null);
  if (parsed === null) return 0;
  return Math.min(1, Math.max(0, parsed));
}

function round2(value) {
  return Math.round(value * 100) / 100;
}

// ---------------------------------------------------------------------------
// pure metric math

/** Sum a `os.cpus()` entry into the two numbers a delta needs. */
export function coreSnapshot(core) {
  const times = core?.times ?? {};
  const at = (key) => {
    const value = num(times[key], 0);
    return value !== null && value > 0 ? value : 0;
  };
  return { idle: at('idle'), total: at('user') + at('nice') + at('sys') + at('idle') + at('irq') };
}

/**
 * Busy percentage between two `os.cpus()` snapshots.
 * Returns `null` — never `0` — when there is nothing to compare, so a missing
 * reading stays visibly missing.
 */
export function cpuDelta(prev, curr) {
  if (!Array.isArray(prev) || !Array.isArray(curr)) return null;
  if (prev.length === 0 || prev.length !== curr.length) return null;
  const cores = [];
  let idleSum = 0;
  let totalSum = 0;
  for (let index = 0; index < curr.length; index += 1) {
    const before = coreSnapshot(prev[index]);
    const after = coreSnapshot(curr[index]);
    const deltaTotal = after.total - before.total;
    const deltaIdle = after.idle - before.idle;
    if (!(deltaTotal > 0)) {
      cores.push({ id: index, percent: null });
      continue;
    }
    cores.push({ id: index, percent: round2(clamp01((deltaTotal - deltaIdle) / deltaTotal) * 100) });
    totalSum += deltaTotal;
    idleSum += Math.min(deltaIdle, deltaTotal);
  }
  const percent = totalSum > 0 ? round2(clamp01((totalSum - idleSum) / totalSum) * 100) : null;
  return { percent, cores };
}

/** Memory totals. `cachedBytes` stays null because Node cannot report it. */
export function memorySnapshot(sample, usage) {
  const totalBytes = num(sample?.totalmem);
  const freeBytes = num(sample?.freemem);
  const usedBytes = totalBytes !== null && freeBytes !== null ? Math.max(0, totalBytes - freeBytes) : null;
  const percent = totalBytes !== null && totalBytes > 0 && usedBytes !== null
    ? round2(clamp01(usedBytes / totalBytes) * 100)
    : null;
  return {
    totalBytes,
    freeBytes,
    usedBytes,
    /** Node has no API for the OS file cache (Windows folds it into "free"). */
    cachedBytes: null,
    percent,
    rssBytes: num(usage?.rss),
    heapUsedBytes: num(usage?.heapUsed),
    heapTotalBytes: num(usage?.heapTotal),
    externalBytes: num(usage?.external),
    arrayBuffersBytes: num(usage?.arrayBuffers),
  };
}

/** A fixed-capacity ring buffer. `push` never grows it. */
export function createRing(capacity) {
  const size = Number.isInteger(capacity) && capacity > 0 ? capacity : HISTORY_CAPACITY;
  const items = [];
  let cursor = 0;
  return {
    capacity: size,
    get size() {
      return items.length;
    },
    push(value) {
      if (items.length < size) items.push(value);
      else {
        items[cursor] = value;
        cursor = (cursor + 1) % size;
      }
    },
    values() {
      if (items.length < size) return items.slice();
      return items.slice(cursor).concat(items.slice(0, cursor));
    },
    last() {
      return items.length === 0 ? null : this.values()[items.length - 1];
    },
    clear() {
      items.length = 0;
      cursor = 0;
    },
  };
}

/**
 * `stroke-dasharray` for a ring, matching the app's own context meter:
 * the filled arc length followed by one full circumference.
 */
export function ringDash(fraction, radius = RING_RADIUS) {
  const circumference = 2 * Math.PI * (Number.isFinite(radius) && radius > 0 ? radius : RING_RADIUS);
  const filled = clamp01(fraction) * circumference;
  return `${round2(filled)} ${round2(circumference)}`;
}

/**
 * `points` for an inline `<svg><polyline>`. Nulls are skipped but keep their
 * slot, so a gap in the history does not silently rescale the x axis.
 */
export function sparklinePoints(values, width = 60, height = 16, max = 100) {
  const source = Array.isArray(values) ? values : [];
  const count = source.length;
  if (count < 2) return '';
  const ceiling = Number.isFinite(max) && max > 0 ? max : 100;
  const step = width / (count - 1);
  const points = [];
  for (let index = 0; index < count; index += 1) {
    const value = num(source[index]);
    if (value === null) continue;
    points.push(`${round2(index * step)},${round2(height - clamp01(Math.max(0, value) / ceiling) * height)}`);
  }
  return points.length >= 2 ? points.join(' ') : '';
}

export function formatPercent(value) {
  const parsed = num(value);
  return parsed === null ? MISSING_TEXT : `${Math.round(parsed)}%`;
}

export function formatBytes(value) {
  const parsed = num(value);
  if (parsed === null || parsed < 0) return MISSING_TEXT;
  if (parsed < 1024) return `${Math.round(parsed)} B`;
  const units = ['KB', 'MB', 'GB', 'TB', 'PB'];
  let scaled = parsed / 1024;
  let unit = 0;
  while (scaled >= 1024 && unit < units.length - 1) {
    scaled /= 1024;
    unit += 1;
  }
  return `${scaled >= 100 ? Math.round(scaled) : Math.round(scaled * 10) / 10} ${units[unit]}`;
}

export function formatRate(bytesPerSecond) {
  const parsed = num(bytesPerSecond);
  if (parsed === null || parsed < 0) return MISSING_TEXT;
  if (parsed < 1024) return `${Math.round(parsed)} B/s`;
  return `${formatBytes(parsed)}/s`;
}

/** `3d 04:05:06`, `04:05:06`. `null` stays 未取得. */
export function formatUptime(seconds) {
  const parsed = num(seconds);
  if (parsed === null || parsed < 0) return MISSING_TEXT;
  const whole = Math.floor(parsed);
  const days = Math.floor(whole / 86400);
  const hours = Math.floor((whole % 86400) / 3600);
  const minutes = Math.floor((whole % 3600) / 60);
  const pad = (value) => String(value).padStart(2, '0');
  return `${days ? `${days}d ` : ''}${pad(hours)}:${pad(minutes)}:${pad(whole % 60)}`;
}

/** Whole-day/hour/minute/second breakdown for the panel. */
export function uptimeBreakdown(seconds) {
  const parsed = num(seconds);
  if (parsed === null || parsed < 0) return null;
  const whole = Math.floor(parsed);
  return {
    days: Math.floor(whole / 86400),
    hours: Math.floor((whole % 86400) / 3600),
    minutes: Math.floor((whole % 3600) / 60),
    seconds: whole % 60,
    totalSeconds: whole,
  };
}

// ---------------------------------------------------------------------------
// network helper: one long-lived PowerShell child, one JSON line per sample

/**
 * The helper's argv. It reads cumulative adapter byte counters, so this half can
 * turn two lines into a rate. When `Get-NetAdapterStatistics` is unavailable it
 * falls back to the per-second performance counter and marks the line
 * `mode: 'counter'` (total only, no rx/tx split) instead of inventing a split.
 */
export function networkHelperArgv(intervalSeconds = DEFAULT_CONFIG.network.intervalSeconds) {
  const milliseconds = Math.max(1000, Math.round((num(intervalSeconds, 3) ?? 3) * 1000));
  const script = [
    '$ErrorActionPreference="SilentlyContinue"',
    `$ms=${milliseconds}`,
    'while($true){',
    '$t=[DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()',
    '$a=@()',
    'foreach($n in (Get-NetAdapterStatistics -ErrorAction SilentlyContinue)){$a+=[pscustomobject]@{name=[string]$n.Name;rx=[double]$n.ReceivedBytes;tx=[double]$n.SentBytes}}',
    'if($a.Count -gt 0){[Console]::Out.WriteLine((@{t=$t;m="delta";a=@($a)}|ConvertTo-Json -Compress -Depth 4))}',
    'else{$c=@()',
    'foreach($s in (Get-Counter "\\Network Interface(*)\\Bytes Total/sec" -ErrorAction SilentlyContinue).CounterSamples){$c+=[pscustomobject]@{name=[string]$s.InstanceName;rate=[double]$s.CookedValue}}',
    'if($c.Count -gt 0){[Console]::Out.WriteLine((@{t=$t;m="counter";a=@($c)}|ConvertTo-Json -Compress -Depth 4))}}',
    '[Console]::Out.Flush()',
    'Start-Sleep -Milliseconds $ms',
    '}',
  ].join(' ');
  return ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', script];
}

/** Candidate executables, tried in order. */
export const NETWORK_HELPER_BINARIES = ['pwsh', 'powershell.exe'];

function adapterEntry(raw) {
  if (!raw || typeof raw !== 'object') return null;
  const adapterName = typeof raw.name === 'string' ? raw.name
    : typeof raw.Name === 'string' ? raw.Name
      : typeof raw.InstanceName === 'string' ? raw.InstanceName : null;
  if (adapterName === null) return null;
  const rx = num(raw.rx ?? raw.ReceivedBytes);
  const tx = num(raw.tx ?? raw.SentBytes);
  const rate = num(raw.rate);
  return { name: adapterName, rxBytes: rx, txBytes: tx, rateBps: rate };
}

/**
 * Parse one helper line. Returns `null` for anything unusable — a half-written
 * line, a non-JSON line, or a sample without adapters — so the caller keeps the
 * previous reading rather than publishing a fabricated zero.
 */
export function parseHelperLine(line) {
  if (typeof line !== 'string') return null;
  const text = line.trim();
  if (text === '' || text[0] !== '{') return null;
  let parsed;
  try {
    parsed = JSON.parse(text);
  } catch {
    return null;
  }
  const at = num(parsed?.t);
  if (at === null) return null;
  const rawList = Array.isArray(parsed?.a) ? parsed.a : parsed?.a && typeof parsed.a === 'object' ? [parsed.a] : [];
  const adapters = rawList.map(adapterEntry).filter(Boolean);
  if (adapters.length === 0) return null;
  const mode = parsed?.m === 'counter' ? 'counter' : 'delta';
  return { at, mode, adapters };
}

/**
 * Turn two cumulative samples into per-adapter rates. A counter that went
 * backwards (adapter re-plugged, counter reset) yields `null` for that adapter
 * rather than a negative or absurd rate.
 */
export function adapterRates(previous, current, elapsedMs) {
  if (!previous || !current) return null;
  const elapsed = num(elapsedMs);
  if (elapsed === null || elapsed <= 0) return null;
  const before = new Map(previous.adapters.map((adapter) => [adapter.name, adapter]));
  const adapters = [];
  let rxTotal = 0;
  let txTotal = 0;
  let splitKnown = true;
  for (const adapter of current.adapters) {
    const prior = before.get(adapter.name);
    if (current.mode === 'counter') {
      const total = num(adapter.rateBps);
      adapters.push({ name: adapter.name, rxBps: null, txBps: null, totalBps: total });
      splitKnown = false;
      if (total !== null) rxTotal += total;
      continue;
    }
    const rx = num(adapter.rxBytes);
    const tx = num(adapter.txBytes);
    const priorRx = num(prior?.rxBytes);
    const priorTx = num(prior?.txBytes);
    if (rx === null || tx === null || priorRx === null || priorTx === null || rx < priorRx || tx < priorTx) {
      adapters.push({ name: adapter.name, rxBps: null, txBps: null, totalBps: null });
      splitKnown = false;
      continue;
    }
    const rxBps = ((rx - priorRx) * 1000) / elapsed;
    const txBps = ((tx - priorTx) * 1000) / elapsed;
    adapters.push({ name: adapter.name, rxBps: round2(rxBps), txBps: round2(txBps), totalBps: round2(rxBps + txBps) });
    rxTotal += rxBps;
    txTotal += txBps;
  }
  adapters.sort((a, b) => (b.totalBps ?? -1) - (a.totalBps ?? -1));
  return {
    adapters,
    rxBps: splitKnown ? round2(rxTotal) : null,
    txBps: splitKnown ? round2(txTotal) : null,
    totalBps: round2(rxTotal + (splitKnown ? txTotal : 0)),
    splitKnown,
  };
}

/**
 * The long-lived helper child. `ensure()` starts it once (lazily, from the first
 * data request), `drain()` reads whatever new lines arrived, and `dispose()`
 * terminates it — the child never outlives the plugin.
 */
export function createNetworkHelper(options) {
  const {
    resolveSubprocess,
    logger = null,
    intervalSeconds = DEFAULT_CONFIG.network.intervalSeconds,
    maxRestarts = DEFAULT_CONFIG.network.maxRestarts,
    maxOutputBytes = DEFAULT_CONFIG.network.maxOutputBytes,
    recycleAfterSamples = DEFAULT_CONFIG.network.recycleAfterSamples,
    onSample = null,
    setTimeoutFn = setTimeout,
    clearTimeoutFn = clearTimeout,
  } = options;

  let child = null;
  let offset = 0;
  let tail = '';
  let stopped = false;
  let starting = false;
  let recycling = false;
  let restarts = 0;
  let recycles = 0;
  let samples = 0;
  let retryTimer = null;
  let status = 'idle';
  let lastError = null;
  let previousSample = null;
  let rates = null;
  let lastSampleAt = null;

  function snapshot() {
    return {
      status,
      running: child !== null,
      restarts,
      recycles,
      samples,
      lastSampleAt,
      lastError,
      intervalSeconds,
    };
  }

  function clearRetry() {
    if (retryTimer !== null) {
      clearTimeoutFn(retryTimer);
      retryTimer = null;
    }
  }

  function scheduleRestart() {
    if (stopped) return;
    if (restarts > maxRestarts) {
      status = 'unavailable';
      return;
    }
    clearRetry();
    const delay = Math.min(30000, 1000 * 2 ** Math.max(0, restarts - 1));
    retryTimer = setTimeoutFn(() => {
      retryTimer = null;
      void spawn();
    }, delay);
    retryTimer?.unref?.();
  }

  function handleExit() {
    child = null;
    offset = 0;
    tail = '';
    previousSample = null;
    if (stopped) return;
    if (recycling) {
      // A planned recycle: the buffer cap or the sample budget was reached, so
      // this is not a crash and it does not spend the restart budget.
      recycling = false;
      void spawn();
      return;
    }
    restarts += 1;
    status = 'restarting';
    scheduleRestart();
  }

  async function spawn() {
    if (stopped || child !== null || starting) return;
    starting = true;
    status = 'starting';
    try {
      let executable = null;
      let lastResolveError = null;
      for (const binary of NETWORK_HELPER_BINARIES) {
        try {
          executable = await resolveSubprocess(binary);
          if (executable) break;
        } catch (error) {
          lastResolveError = error;
        }
      }
      if (stopped) return;
      if (!executable) {
        restarts += 1;
        lastError = lastResolveError ? String(lastResolveError.message ?? lastResolveError) : 'no powershell executable';
        status = restarts > maxRestarts ? 'unavailable' : 'restarting';
        if (status === 'restarting') scheduleRestart();
        return;
      }
      const next = options.spawn(executable, networkHelperArgv(intervalSeconds), maxOutputBytes);
      if (!next) {
        restarts += 1;
        lastError = 'spawn returned no handle';
        status = restarts > maxRestarts ? 'unavailable' : 'restarting';
        if (status === 'restarting') scheduleRestart();
        return;
      }
      child = next;
      offset = 0;
      tail = '';
      status = 'running';
      lastError = null;
      let settled = false;
      Promise.resolve(next.done).then(
        () => {
          if (!settled) {
            settled = true;
            handleExit();
          }
        },
        (error) => {
          if (!settled) {
            settled = true;
            lastError = String(error?.message ?? error);
            handleExit();
          }
        },
      );
    } catch (error) {
      restarts += 1;
      lastError = String(error?.message ?? error);
      status = restarts > maxRestarts ? 'unavailable' : 'restarting';
      logger?.warn?.(`[dsh-system-bar] network helper could not start: ${lastError}`);
      if (status === 'restarting') scheduleRestart();
    } finally {
      starting = false;
    }
  }

  function pause(handle, planned) {
    child = null;
    offset = 0;
    tail = '';
    previousSample = null;
    if (planned) recycling = true;
    try {
      handle?.terminate?.();
    } catch {
      /* already gone */
    }
    if (planned && stopped) recycling = false;
  }

  return {
    /** Start the child if it is not running. Idempotent. */
    ensure() {
      if (stopped || child !== null || starting) return;
      if (status === 'unavailable') return;
      void spawn();
    },
    /**
     * Read every complete new line and publish the newest sample. Returns the
     * number of samples consumed. The buffer is recycled before it can go lossy.
     */
    drain() {
      if (child === null) return 0;
      let read;
      try {
        read = child.collected?.stdout?.readFrom(offset);
      } catch (error) {
        lastError = String(error?.message ?? error);
        pause(child);
        return 0;
      }
      if (!read) return 0;
      offset = num(read.nextOffset, offset) ?? offset;
      if (read.lossy === true) {
        // The child's buffered output hit the cap: recycle it rather than
        // losing the stream, and never grow our own memory.
        recycles += 1;
        pause(child, true);
        return 0;
      }
      const text = typeof read.text === 'string' ? read.text : '';
      if (text === '') return 0;
      const combined = tail + text;
      const parts = combined.split('\n');
      tail = parts.pop() ?? '';
      // A pathological line must not become an unbounded buffer either.
      if (tail.length > 8192) tail = tail.slice(-8192);
      let consumed = 0;
      for (const line of parts) {
        const sample = parseHelperLine(line);
        if (!sample) continue;
        consumed += 1;
        samples += 1;
        lastSampleAt = sample.at;
        if (previousSample) {
          rates = adapterRates(previousSample, sample, sample.at - previousSample.at) ?? rates;
        }
        previousSample = sample;
        onSample?.(sample, rates);
      }
      if (samples >= recycleAfterSamples) {
        recycles += 1;
        samples = 0;
        pause(child, true);
      }
      return consumed;
    },
    rates() {
      return rates;
    },
    state: snapshot,
    /** Terminate the child and cancel every pending retry. */
    dispose() {
      stopped = true;
      clearRetry();
      const handle = child;
      child = null;
      if (handle) {
        try {
          handle.terminate?.();
        } catch {
          /* already gone */
        }
      }
      status = 'stopped';
      return handle !== null;
    },
  };
}

// ---------------------------------------------------------------------------
// the sampling engine

/**
 * The single sampling source. One poll fills CPU deltas, memory totals, uptime,
 * the bounded history rings and the network helper's drained lines.
 */
export function createMetrics(settings, dependencies = {}) {
  const now = dependencies.now ?? (() => Date.now());
  const historyCapacity = settings.historyCapacity;
  const cpuHistory = createRing(historyCapacity);
  const memoryHistory = createRing(historyCapacity);
  const networkHistory = createRing(historyCapacity);
  const startedAt = now();

  const state = {
    startedAt,
    sampleCount: 0,
    lastSampleAt: null,
    coreCount: Array.isArray(os.cpus()) ? os.cpus().length : null,
    loadAverage: null,
    cpu: { percent: null, cores: [], available: false },
    memory: memorySnapshot(null, null),
    uptime: { processSeconds: 0, osSeconds: null, hostStartedAt: startedAt },
    network: { available: false, reason: 'not-started', adapters: [], rxBps: null, txBps: null, totalBps: null, sampledAt: null, helper: null, splitKnown: false },
  };
  let previousCpus = null;
  const helper = settings.network.enabled && dependencies.resolveSubprocess
    ? createNetworkHelper({
      resolveSubprocess: dependencies.resolveSubprocess,
      spawn: dependencies.spawn,
      logger: dependencies.logger,
      intervalSeconds: settings.network.intervalSeconds,
      maxRestarts: settings.network.maxRestarts,
      maxOutputBytes: settings.network.maxOutputBytes,
      recycleAfterSamples: settings.network.recycleAfterSamples,
      setTimeoutFn: dependencies.setTimeoutFn,
      clearTimeoutFn: dependencies.clearTimeoutFn,
    })
    : null;

  function sampleNetwork() {
    if (!helper) {
      state.network.reason = settings.network.enabled ? 'no-subprocess-service' : 'disabled';
      return;
    }
    helper.ensure();
    helper.drain();
    const helperState = helper.state();
    state.network.helper = helperState;
    const rates = helper.rates();
    if (rates) {
      state.network = {
        available: rates.splitKnown ? true : rates.totalBps !== null,
        reason: null,
        adapters: rates.adapters,
        rxBps: rates.rxBps,
        txBps: rates.txBps,
        totalBps: rates.totalBps,
        splitKnown: rates.splitKnown,
        sampledAt: helperState.lastSampleAt,
        helper: helperState,
      };
      networkHistory.push(rates.totalBps);
      return;
    }
    state.network.available = false;
    state.network.reason = helperState.status === 'unavailable'
      ? 'helper-unavailable'
      : helperState.status === 'running' ? 'waiting-for-samples' : helperState.status;
  }

  function sample() {
    const cpus = os.cpus();
    const delta = previousCpus === null ? null : cpuDelta(previousCpus, cpus);
    previousCpus = cpus;
    if (delta && delta.percent !== null) {
      state.cpu = { percent: delta.percent, cores: delta.cores, available: true };
      cpuHistory.push(delta.percent);
    } else if (delta) {
      state.cpu = { percent: null, cores: delta.cores, available: false };
    }
    state.coreCount = Array.isArray(cpus) ? cpus.length : null;
    state.memory = memorySnapshot({ totalmem: os.totalmem(), freemem: os.freemem() }, process.memoryUsage());
    if (state.memory.percent !== null) memoryHistory.push(state.memory.percent);
    state.uptime = {
      processSeconds: Math.floor(process.uptime()),
      osSeconds: Math.floor(os.uptime()),
      hostStartedAt: startedAt,
    };
    try {
      const load = os.loadavg?.();
      state.loadAverage = Array.isArray(load) && load.length ? load : null;
    } catch {
      state.loadAverage = null;
    }
    sampleNetwork();
    state.sampleCount += 1;
    state.lastSampleAt = now();
    return snapshot();
  }

  function snapshot() {
    return {
      at: state.lastSampleAt ?? now(),
      startedAt,
      sampleCount: state.sampleCount,
      intervalMs: settings.sampleIntervalMs,
      cpu: { ...state.cpu, coreCount: state.coreCount, loadAverage: state.loadAverage, history: cpuHistory.values(), historyCapacity },
      memory: { ...state.memory, history: memoryHistory.values(), historyCapacity },
      uptime: { ...state.uptime, breakdown: uptimeBreakdown(state.uptime.processSeconds), osBreakdown: uptimeBreakdown(state.uptime.osSeconds) },
      network: { ...state.network, history: networkHistory.values(), historyCapacity, enabled: settings.network.enabled },
      harness: {
        plugin: PLUGIN_ID,
        version: 1,
        uid: process.pid,
        node: process.version,
        platform: `${os.platform()} ${os.release()}`,
        startedAt,
        lastSampleAt: state.lastSampleAt,
        sampleCount: state.sampleCount,
      },
    };
  }

  return {
    sample,
    snapshot,
    helper,
    dispose() {
      helper?.dispose();
    },
  };
}

// ---------------------------------------------------------------------------
// config

export function resolveConfig(config = {}) {
  const raw = config && typeof config === 'object' ? config : {};
  const networkRaw = raw.network && typeof raw.network === 'object' ? raw.network : {};
  return {
    enabled: raw.enabled !== false,
    sampleIntervalMs: clampNumber(raw.sampleIntervalMs, 1000, 60000, DEFAULT_CONFIG.sampleIntervalMs),
    historyCapacity: HISTORY_CAPACITY,
    network: {
      enabled: networkRaw.enabled !== false,
      intervalSeconds: clampNumber(networkRaw.intervalSeconds, 2, 60, DEFAULT_CONFIG.network.intervalSeconds),
      maxRestarts: Math.round(clampNumber(networkRaw.maxRestarts, 0, 10, DEFAULT_CONFIG.network.maxRestarts)),
      maxOutputBytes: Math.round(clampNumber(networkRaw.maxOutputBytes, 4096, 1024 * 1024, DEFAULT_CONFIG.network.maxOutputBytes)),
      recycleAfterSamples: Math.round(clampNumber(networkRaw.recycleAfterSamples, 50, 100000, DEFAULT_CONFIG.network.recycleAfterSamples)),
    },
  };
}

// ---------------------------------------------------------------------------
// route

/** The token is a same-origin capability: only a served page can carry it. */
export function authorized(req, token) {
  const site = req?.headers?.['sec-fetch-site'];
  if (typeof site === 'string' && site === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
}

function send(res, status, payload) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  });
  res.end(JSON.stringify(payload));
}

/** The structured index-injection row that carries the capability into a page. */
export function bootstrapRow(value) {
  return { kind: 'global', name: BOOTSTRAP_KEY, value };
}

/**
 * Capability hand-out for a page without the bootstrap global: an already-open
 * window, or a live install whose boot table predates this plugin.
 */
export function createTokenHandler(token, isAuthenticated) {
  return function systemBarTokenRoute(req, res) {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      send(res, 405, { ok: false, error: 'method-not-allowed' });
      return;
    }
    if (req?.headers?.['sec-fetch-site'] === 'cross-site') {
      send(res, 403, { ok: false, error: 'forbidden' });
      return;
    }
    if (typeof isAuthenticated === 'function') {
      let authenticated = false;
      try {
        authenticated = isAuthenticated(req) === true;
      } catch {
        authenticated = false;
      }
      if (!authenticated) {
        send(res, 401, { ok: false, error: 'unauthorized' });
        return;
      }
    }
    send(res, 200, { ok: true, data: { path: ROUTE_PATH, token } });
  };
}

/** Read-only exact route: the snapshot, nothing else. */
export function createRouteHandler(metrics, token) {
  return function systemBarRoute(req, res) {
    if (!authorized(req, token)) {
      send(res, 403, { ok: false, error: 'forbidden' });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      send(res, 405, { ok: false, error: 'method-not-allowed' });
      return;
    }
    try {
      send(res, 200, { ok: true, data: metrics.snapshot() });
    } catch (error) {
      send(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) });
    }
  };
}

// ---------------------------------------------------------------------------
// plugin

export function apply(ctx, config = {}) {
  const settings = resolveConfig(config);
  const token = randomBytes(24).toString('hex');

  const metrics = createMetrics(settings, {
    logger: ctx.logger,
    resolveSubprocess: async (binary) => {
      const subprocess = ctx.get?.('subprocess') ?? ctx.subprocess;
      if (!subprocess || typeof subprocess.resolveExecutable !== 'function') return null;
      return subprocess.resolveExecutable(binary);
    },
    spawn: (executable, argv, maxBytes) => {
      const subprocess = ctx.get?.('subprocess') ?? ctx.subprocess;
      if (!subprocess || typeof subprocess.spawn !== 'function') return null;
      return subprocess.spawn({
        argv: [executable, ...argv],
        stdio: {
          stdin: 'ignore',
          stdout: { maxBytes },
          stderr: { maxBytes: 8 * 1024 },
        },
        graceMs: 500,
      });
    },
  });

  // The single sampling source: one unref'd interval, cleared by the disposer.
  ctx.effect(() => {
    if (settings.enabled) metrics.sample();
    const timer = setInterval(() => {
      try {
        metrics.sample();
      } catch (error) {
        ctx.logger?.warn?.(`[dsh-system-bar] sample failed: ${error?.message ?? error}`);
      }
    }, settings.sampleIntervalMs);
    timer.unref?.();
    return () => {
      clearInterval(timer);
      metrics.dispose();
    };
  }, 'dsh-system-bar: sampler');

  ctx.inject(['webServer'], (webCtx) => {
    const isAuthenticated = (req) => webCtx.get?.('connection')?.isAuthenticated?.(req);
    webCtx.effect(
      () => webCtx.webServer.register({ kind: 'exact', path: ROUTE_PATH, handler: createRouteHandler(metrics, token) }),
      'dsh-system-bar: route',
    );
    webCtx.effect(
      () => webCtx.webServer.register({ kind: 'exact', path: TOKEN_PATH, handler: createTokenHandler(token, isAuthenticated) }),
      'dsh-system-bar: token route',
    );
    webCtx.on?.('webserver/index-inject', (table) => {
      table.push(bootstrapRow({ path: ROUTE_PATH, token }));
    });
  });

  ctx.logger?.info?.(`[dsh-system-bar] active (sample ${settings.sampleIntervalMs}ms, network ${settings.network.enabled ? `${settings.network.intervalSeconds}s` : 'off'})`);
  return { settings, token };
}

import assert from 'node:assert/strict';
import { createSampler, analyzeTrend, appendLog, apply } from './index.js';
const results = [];
const test = (name, fn) => results.push({ name, fn });
test('sampler snapshots memory and CPU deltas while attribution remains null', () => {
  let n = 0; const s = createSampler({ memoryUsage: () => ({ rss: 100 + n * 10, heapUsed: 40, external: 5, arrayBuffers: 2 }), cpuUsage: () => ({ user: ++n * 100, system: n * 50 }), now: () => n * 5000 });
  s.sample(); const row = s.sample();
  for (let i = 0; i < 121; i++) s.sample();
  assert.equal(row.memory.rss, 110); assert.equal(row.cpu.userDelta, 100); assert.equal(row.plugins, null); assert.equal(s.samples.length, 120);
});
test('trend is capped and flags only above 20 MiB per minute over 60 seconds', () => {
  const samples = Array.from({ length: 121 }, (_, i) => ({ at: i * 5000, rss: i * 2_000_000 }));
  const trend = analyzeTrend(samples);
  assert.equal(trend.samples.length, 120); assert.equal(trend.anomaly, true);
  assert.equal(analyzeTrend([{ at: 0, rss: 10 }, { at: 5000, rss: 20 }]).anomaly, false);
});
test('optimization log remains capped at 60 entries', () => {
  assert.equal(appendLog(Array.from({ length: 60 }, (_, i) => i), { at: 1 }).length, 60);
});
test('routes authenticate; host sampler starts immediately, ticks every five seconds, updates trend, and stops on dispose', async () => {
  const rows = [], effects = [], listeners = {};
  let authenticated = true, timer, cleared = false, now = 1000, sampleCount = 0;
  const timers = { setInterval(fn, ms) { timer = { fn, ms, unref() { this.unrefed = true; } }; return timer; }, clearInterval(value) { cleared = value === timer; } };
  const ctx = { inject: (_services, cb) => cb({ webServer: { register: (route) => { rows.push(route); return () => {}; } }, on: (name, fn) => { listeners[name] = fn; }, get: () => ({ isAuthenticated: () => authenticated }) }), effect: (fn) => effects.push(fn) };
  const samplerSource = { now: () => now, memoryUsage: () => ({ rss: 100 + sampleCount++, heapUsed: 40, external: 5, arrayBuffers: 2 }), cpuUsage: () => ({ user: sampleCount * 100, system: sampleCount * 50 }), totalmem: () => 1000, freemem: () => 500 };
  apply(ctx, { token: 'test-token' }, { timers, samplerSource });
  assert.equal(rows.length, 2);
  assert.equal(timer.ms, 5000); assert.equal(timer.unrefed, true); assert.equal(sampleCount, 1, 'initial sample is taken immediately');
  const req = { method: 'GET', headers: { 'x-dsh-resource-manager-token': 'test-token' } };
  const response = (status, body) => ({ status, body });
  const first = await rows[0].handler(req, response); assert.equal(first.status, 200); assert.equal(first.body.data.trend.samples.length, 1);
  now += 5000; timer.fn(); assert.equal(sampleCount, 2, 'five-second callback takes a sample');
  const second = await rows[0].handler(req, response); assert.equal(second.body.data.trend.samples.length, 2); assert.equal(second.body.data.process.memory.rss, 101);
  assert.equal((await rows[0].handler({ ...req, method: 'POST' }, response)).status, 405);
  assert.equal((await rows[0].handler({ method: 'GET', headers: {} }, response)).status, 403);
  assert.equal((await rows[0].handler({ ...req, body: '{bad' }, response)).status, 400);
  assert.equal((await rows[1].handler({ method: 'GET', headers: {} }, response)).status, 200);
  authenticated = false; assert.equal((await rows[1].handler({ method: 'GET', headers: {} }, response)).status, 401);
  authenticated = true; assert.equal((await rows[1].handler({ method: 'POST', headers: {} }, response)).status, 405);
  assert.equal((await rows[1].handler({ method: 'GET', headers: { 'sec-fetch-site': 'cross-site' } }, response)).status, 403);
  const table = []; listeners['webserver/index-inject'](table); assert.equal(table[0].name, '__DSH_RESOURCE_MANAGER__');
  const dispose = effects[0](); assert.equal(typeof dispose, 'function'); dispose(); assert.equal(cleared, true);
});
let failed = 0;
for (const { name, fn } of results) { try { await fn(); console.log(`ok ${name}`); } catch (e) { failed++; console.error(`FAIL ${name}\n${e.stack}`); } }
console.log(`${results.length - failed}/${results.length} checks passed`); if (failed) process.exitCode = 1;

window.__ModuleLoader__.load({
  id: '@local/dsh-resource-manager',
  factory: () => {
    const ID = '@local/dsh-resource-manager';
    const BOOTSTRAP_KEY = '__DSH_RESOURCE_MANAGER__';
    const TOKEN_PATH = '/local/resource-manager-token';
    const TOKEN_HEADER = 'x-dsh-resource-manager-token';
    const TICK_MS = 60_000;
    const PERIODIC_CLEANUP_MS = 30 * 60_000;
    const COOLDOWN_MS = 15 * 60_000;
    const MAX_CACHES = 100;
    const MAX_LOG = 60;
    const MAX_CALLBACK_MS = 2_000;

    function installResourceManager() {
      const prior = window[BOOTSTRAP_KEY];
      const api = prior && typeof prior === 'object' ? prior : {};
      const originalDescriptors = Object.getOwnPropertyDescriptors(api);
      const originalGlobalDescriptor = Object.getOwnPropertyDescriptor(window, BOOTSTRAP_KEY);
      const priorRegisterCache = api.registerCache;
      const registry = new Map();
      const log = Array.isArray(api.optimizationLog) ? api.optimizationLog.slice(-MAX_LOG) : [];
      let timer = null;
      let disposed = false;
      let running = false;
      let endpointRequest = null;
      let lastCleanupAt = -Infinity;
      let lastPeriodicAt = Date.now();

      const visible = () => !disposed && document.visibilityState !== 'hidden';
      const record = (entry) => {
        log.push({ at: Date.now(), ...entry });
        if (log.length > MAX_LOG) log.splice(0, log.length - MAX_LOG);
        api.optimizationLog = log;
        api.lastOptimization = log.at(-1);
      };

      async function runCleanup(reason, now) {
        if (now - lastCleanupAt < COOLDOWN_MS || registry.size === 0) return false;
        lastCleanupAt = now;
        let freedBytes = 0;
        let errors = 0;
        const entries = [...registry.entries()];
        for (const [id, clear] of entries) {
          if (disposed) break;
          let timeout;
          try {
            const result = await Promise.race([
              Promise.resolve().then(() => clear()),
              new Promise((_, reject) => {
                timeout = setTimeout(() => reject(new Error('cache cleanup timed out')), MAX_CALLBACK_MS);
              }),
            ]);
            if (typeof result === 'number' && Number.isFinite(result) && result >= 0) freedBytes += result;
          } catch {
            errors++;
          } finally {
            clearTimeout(timeout);
            if (registry.get(id) !== clear) continue;
          }
        }
        record({ reason, caches: entries.length, freedBytes, errors });
        return true;
      }

      async function optimizerTick(now = Date.now()) {
        if (!visible() || running || registry.size === 0) return;
        running = true;
        try {
          if (now - lastPeriodicAt >= PERIODIC_CLEANUP_MS) {
            const cleaned = await runCleanup('periodic', now);
            if (cleaned) lastPeriodicAt = now;
            return;
          }
          if (typeof fetch !== 'function') return;
          try {
            const endpoint = await resolveEndpoint();
            if (!endpoint) return;
            const response = await fetch(api.path, {
              method: 'GET',
              credentials: 'same-origin',
              cache: 'no-store',
              headers: { [TOKEN_HEADER]: api.token },
            });
            if (!response?.ok) return;
            const payload = await response.json();
            if (payload?.ok === true && payload?.data?.trend?.anomaly === true) {
              await runCleanup('memory-anomaly', now);
            }
          } catch {
            // Monitoring is best-effort. A host route outage must not affect the UI.
          }
        } finally {
          running = false;
        }
      }

      async function resolveEndpoint() {
        if (typeof api.path === 'string' && typeof api.token === 'string') return api;
        if (endpointRequest) return endpointRequest;
        endpointRequest = (async () => {
          const response = await fetch(TOKEN_PATH, { method: 'GET', credentials: 'same-origin', cache: 'no-store' });
          if (!response?.ok) return null;
          const payload = await response.json();
          const data = payload?.data;
          if (payload?.ok !== true || typeof data?.path !== 'string' || typeof data?.token !== 'string') return null;
          api.path = data.path;
          api.token = data.token;
          return api;
        })().catch(() => null).finally(() => { endpointRequest = null; });
        return endpointRequest;
      }

      function stopTimer() {
        if (timer !== null) clearInterval(timer);
        timer = null;
      }
      function syncTimer() {
        if (!visible() || registry.size === 0) {
          stopTimer();
          return;
        }
        if (timer === null) timer = setInterval(() => { void optimizerTick(); }, TICK_MS);
      }
      function registerCache({ id, clear } = {}) {
        if (disposed || typeof id !== 'string' || id.length === 0 || id.length > 128 || typeof clear !== 'function') return () => {};
        if (!registry.has(id) && registry.size >= MAX_CACHES) return () => {};
        registry.set(id, clear);
        syncTimer();
        let active = true;
        return () => {
          if (!active) return;
          active = false;
          if (registry.get(id) === clear) registry.delete(id);
          syncTimer();
        };
      }

      api.version = 1;
      api.registerCache = registerCache;
      api.optimizationLog = log;
      window[BOOTSTRAP_KEY] = api;
      const onVisibilityChange = () => syncTimer();
      document.addEventListener?.('visibilitychange', onVisibilityChange);

      function dispose() {
        if (disposed) return;
        disposed = true;
        stopTimer();
        document.removeEventListener?.('visibilitychange', onVisibilityChange);
        registry.clear();
        for (const key of Reflect.ownKeys(api)) {
          if (!Object.hasOwn(originalDescriptors, key)) {
            try { delete api[key]; } catch { /* preserve a host-owned non-configurable field */ }
          }
        }
        for (const [key, descriptor] of Object.entries(originalDescriptors)) {
          try { Object.defineProperty(api, key, descriptor); } catch { /* keep the runtime stable during teardown */ }
        }
        if (originalGlobalDescriptor) {
          try { Object.defineProperty(window, BOOTSTRAP_KEY, originalGlobalDescriptor); } catch { /* keep the host bootstrap intact */ }
        } else {
          try { delete window[BOOTSTRAP_KEY]; } catch { /* keep the host bootstrap intact */ }
        }
      }

      return { dispose, optimizerTick, resolveEndpoint, registry };
    }

    let runtime;
    return {
      name: ID,
      inject: [],
      apply(ctx) {
        runtime = installResourceManager();
        ctx.effect?.(() => () => runtime?.dispose(), 'dsh-resource-manager.client');
      },
      __test: {
        ID,
        TICK_MS,
        PERIODIC_CLEANUP_MS,
        COOLDOWN_MS,
        installResourceManager,
        resolveEndpoint: () => runtime?.resolveEndpoint(),
        optimizerTick: (...args) => runtime?.optimizerTick(...args),
        getRuntime: () => runtime,
      },
    };
  },
});

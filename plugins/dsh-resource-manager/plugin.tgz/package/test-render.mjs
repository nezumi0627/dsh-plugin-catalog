import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('./client.js', import.meta.url), 'utf8');
assert.doesNotMatch(source, /className:\s*['"]rm-chip['"]/, 'the MEM chip must be absent from the client source');
assert.doesNotMatch(source, /className:\s*['"]rm-panel['"]/, 'the detached manager panel must be absent from the client source');
assert.doesNotMatch(source, /conversation\.composer\.dock|shell\.overlay/, 'resource manager must not register a visible slot');
console.log('no memory chip or resource manager UI remains in the client source');

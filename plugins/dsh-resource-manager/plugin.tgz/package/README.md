# DSH Resource Manager

`@local/dsh-resource-manager` provides five-second snapshots of the host Node process (`rss`, V8 heap, external memory, array buffers), OS total/free memory, CPU-time deltas, a capped ten-minute trend, and a transparent growth threshold (>20 MiB/min over at least one minute). It does **not** attribute memory to individual plugins: those values remain unavailable.

The visible MEM chip and detail panel remain removed from the client UI. The host keeps bounded five-second sampling for authorized route consumers. The client optimizer starts only while at least one cache owner has registered a cleanup callback, polls the authenticated trend once per minute, pauses while the document is hidden, runs owner cleanup on an abnormal-growth report, and performs periodic cleanup every 30 minutes with a 15-minute cooldown. In the desktop renderer, it obtains the route token through the authenticated token endpoint if index-injection bootstrap is unavailable.

## Responsible cleanup

The manager never sweeps another plugin's state. A cache owner may opt in by registering a clear callback through `window.__DSH_RESOURCE_MANAGER__.registerCache({ id, clear })`; `clear` can return freed bytes or `null`. A disposer returned from registration unregisters it. The optimizer invokes only these explicit callbacks, isolates thrown errors, and caps registry and history size. It never clears browser data, settings, authentication, or another plugin's state. Current source audit found no plugin cache owners, so the mechanism is ready but there is no cache it can currently reclaim. This plugin does not force garbage collection and owns no object URLs or external caches to clear.

No per-plugin host memory accounting or idle web-panel suspension is claimed: the available APIs do not expose trustworthy per-plugin memory or a consented panel pause contract. No hard CPU/RAM ceiling is enforced.

## Tests

```powershell
node --check index.js
node --check client.js
node test-host.mjs
node test-client.mjs
node test-render.mjs
```

import assert from 'node:assert/strict';

const specs = [];
const registered = [];
const effects = [];
const documentListeners = new Map();
let now = 1_000_000;
let intervalHandler = null;
let intervalMs = null;
let clearedTimer = false;
let hostSnapshot = { trend: { anomaly: false } };
let fetchCalls = 0;
const fetchUrls = [];
const oldNow = Date.now;
const oldSetInterval = globalThis.setInterval;
const oldClearInterval = globalThis.clearInterval;
const oldFetch = globalThis.fetch;
Date.now = () => now;
globalThis.setInterval = (fn, ms) => { intervalHandler = fn; intervalMs = ms; return 41; };
globalThis.clearInterval = (id) => { clearedTimer = id === 41; };
globalThis.fetch = async (url) => {
  fetchCalls++;
  fetchUrls.push(url);
  if (url === '/local/resource-manager-token') return { ok: true, json: async () => ({ ok: true, data: { path: '/local/resource-manager', token: 'desktop-token' } }) };
  return { ok: true, json: async () => ({ ok: true, data: hostSnapshot }) };
};
const previous = { path: '/local/resource-manager', token: 'host-token' };
globalThis.window = {
  __DSH_RESOURCE_MANAGER__: previous,
  __ModuleLoader__: { load: (spec) => specs.push(spec) },
};
globalThis.document = { visibilityState: 'visible', createElement: () => ({ setAttribute() {}, remove() {} }), head: { append() {} }, addEventListener: (name, fn) => documentListeners.set(name, fn), removeEventListener: (name) => documentListeners.delete(name) };
await import('./client.js?no-memory-chip');

const mod = specs[0].factory(() => { throw new Error('resource manager UI dependencies should be removed'); });
const disposers = [];
mod.apply({
  slots: {
    inject: (_name, register) => register(),
    register: (options) => { registered.push(options); return () => {}; },
  },
  effect: (fn) => { const cleanup = fn(); if (cleanup) disposers.push(cleanup); },
});
assert.deepEqual(registered, [], 'resource manager must not add the MEM chip or panel');
assert.equal(window.__DSH_RESOURCE_MANAGER__, previous, 'the shared host credentials remain intact');
assert.equal(typeof previous.registerCache, 'function');
let cleared = 0;
const unregister = previous.registerCache({ id: 'cache.test', clear: () => { cleared++; return 2048; } });
const unregisterBroken = previous.registerCache({ id: 'cache.broken', clear: () => { throw new Error('isolated cache failure'); } });
assert.equal(intervalMs, 60_000, 'owner cache registration starts a low-frequency optimizer');
assert.equal(typeof intervalHandler, 'function');
await mod.__test.optimizerTick(now);
assert.equal(fetchCalls, 1, 'memory trend is read from the authenticated host route');
assert.equal(cleared, 0, 'normal memory growth does not clear owner caches');
hostSnapshot = { trend: { anomaly: true } };
now += 60_000;
await mod.__test.optimizerTick(now);
assert.equal(cleared, 1, 'a sustained memory anomaly runs registered cleanup');
assert.equal(previous.lastOptimization.reason, 'memory-anomaly');
assert.equal(previous.lastOptimization.freedBytes, 2048);
assert.equal(previous.lastOptimization.errors, 1, 'one failing cache does not stop other cleanup callbacks');
const callsAfterAnomaly = fetchCalls;
now += 30_000;
await mod.__test.optimizerTick(now);
assert.equal(cleared, 1, 'cooldown prevents repeated cleanup while anomaly remains');
hostSnapshot = { trend: { anomaly: false } };
now += 30 * 60_000;
await mod.__test.optimizerTick(now);
assert.equal(cleared, 2, 'a periodic cleanup runs even without an active anomaly');
assert.ok(fetchCalls > callsAfterAnomaly);
document.visibilityState = 'hidden';
documentListeners.get('visibilitychange')?.();
assert.equal(clearedTimer, true, 'hidden documents stop optimizer polling');
unregister();
unregisterBroken();
for (const dispose of disposers.reverse()) dispose();
assert.equal(window.__DSH_RESOURCE_MANAGER__, previous, 'teardown preserves host bootstrap state');
assert.equal(documentListeners.has('visibilitychange'), false, 'teardown removes visibility listener');
window.__DSH_RESOURCE_MANAGER__ = {};
document.visibilityState = 'visible';
const desktopMod = specs[0].factory(() => { throw new Error('resource manager UI dependencies should be removed'); });
const desktopDisposers = [];
desktopMod.apply({ slots: {}, effect: (fn) => { const cleanup = fn(); if (cleanup) desktopDisposers.push(cleanup); } });
let desktopClears = 0;
window.__DSH_RESOURCE_MANAGER__.registerCache({ id: 'cache.desktop', clear: () => { desktopClears++; } });
now += 60_000;
await desktopMod.__test.optimizerTick(now);
assert.deepEqual(fetchUrls.slice(-2), ['/local/resource-manager-token', '/local/resource-manager'], 'desktop resolves the authenticated route token when index-inject bootstrap is unavailable');
assert.equal(window.__DSH_RESOURCE_MANAGER__.token, 'desktop-token');
assert.equal(desktopClears, 0, 'desktop host snapshot without an anomaly leaves caches untouched');
for (const dispose of desktopDisposers.reverse()) dispose();
assert.deepEqual(window.__DSH_RESOURCE_MANAGER__, {}, 'desktop bootstrap fields are restored on teardown');
Date.now = oldNow;
globalThis.setInterval = oldSetInterval;
globalThis.clearInterval = oldClearInterval;
globalThis.fetch = oldFetch;
console.log('resource manager owner caches optimize on growth/interval; cooldown, error isolation and cleanup verified');

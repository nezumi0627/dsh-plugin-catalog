import { randomBytes, timingSafeEqual } from 'node:crypto';
import os from 'node:os';

export const name = 'dsh-resource-manager';
export const ROUTE_PATH = '/local/resource-manager';
export const TOKEN_PATH = '/local/resource-manager-token';
export const BOOTSTRAP_KEY = '__DSH_RESOURCE_MANAGER__';
export const TOKEN_HEADER = 'x-dsh-resource-manager-token';
export const SAMPLE_MS = 5000;
export const TREND_CAP = 120;
export const LOG_CAP = 60;
export const ANOMALY_THRESHOLD_BYTES_PER_MIN = 20 * 1024 * 1024;

export function createSampler(source = {}) {
  const memoryUsage = source.memoryUsage ?? (() => process.memoryUsage());
  const cpuUsage = source.cpuUsage ?? (() => process.cpuUsage());
  const now = source.now ?? Date.now;
  let previousCpu = null;
  const samples = [];
  return {
    samples,
    sample() {
      const memory = memoryUsage();
      const cpu = cpuUsage();
      const row = { at: now(), memory: { rss: memory.rss, heapUsed: memory.heapUsed, external: memory.external, arrayBuffers: memory.arrayBuffers }, systemMemory: source.totalmem && source.freemem ? { total: source.totalmem(), free: source.freemem() } : { total: os.totalmem(), free: os.freemem() }, cpu: previousCpu ? { userDelta: cpu.user - previousCpu.user, systemDelta: cpu.system - previousCpu.system } : null, plugins: null };
      previousCpu = cpu;
      samples.push(row);
      if (samples.length > TREND_CAP) samples.shift();
      return row;
    },
  };
}

export function analyzeTrend(samples) {
  const bounded = samples.slice(-TREND_CAP);
  const first = bounded[0], last = bounded.at(-1);
  const minutes = first && last ? (last.at - first.at) / 60000 : 0;
  const slopeBytesPerMinute = minutes > 0 ? (last.memory?.rss ?? last.rss) - (first.memory?.rss ?? first.rss) : 0;
  const rate = minutes > 0 ? slopeBytesPerMinute / minutes : 0;
  return { samples: bounded, slopeBytesPerMinute: rate, windowMs: minutes * 60000, thresholdBytesPerMinute: ANOMALY_THRESHOLD_BYTES_PER_MIN, anomaly: bounded.length >= 12 && minutes >= 1 && rate > ANOMALY_THRESHOLD_BYTES_PER_MIN };
}

export function appendLog(log, entry) { return [...log, entry].slice(-LOG_CAP); }

export function authorized(req, token) {
  if (req?.headers?.['sec-fetch-site'] === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
}

function send(res, status, value) {
  if (typeof res === 'function') return res(status, value);
  res.statusCode = status;
  res.setHeader?.('content-type', 'application/json; charset=utf-8');
  res.setHeader?.('cache-control', 'no-store');
  res.end?.(JSON.stringify(value));
  return { status, body: value };
}

export function apply(ctx, config = {}, runtime = {}) {
  if (config.enabled === false) return;
  const token = typeof config.token === 'string' ? config.token : randomBytes(24).toString('hex');
  const timers = runtime.timers ?? globalThis;
  const sampler = createSampler(runtime.samplerSource);
  const snapshot = () => ({ version: 1, at: Date.now(), process: { pid: process.pid, platform: process.platform, memory: sampler.samples.at(-1)?.memory ?? null, systemMemory: sampler.samples.at(-1)?.systemMemory ?? null, cpu: sampler.samples.at(-1)?.cpu ?? null }, trend: analyzeTrend(sampler.samples), plugins: null, pluginAttribution: '未取得: this process API cannot attribute renderer or plugin memory' });
  ctx.inject(['webServer'], (webCtx) => {
    const disposers = [];
    const register = (path, handler) => disposers.push(webCtx.webServer.register({ kind: 'exact', path, handler }));
    register(ROUTE_PATH, (req, res) => {
      if (!authorized(req, token)) return send(res, 403, { ok: false, error: 'forbidden' });
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { ok: false, error: 'method-not-allowed' });
      if (req.body !== undefined && req.body !== null && req.body !== '') return send(res, 400, { ok: false, error: 'unexpected-body' });
      return send(res, 200, { ok: true, data: snapshot() });
    });
    register(TOKEN_PATH, (req, res) => {
      if (req?.headers?.['sec-fetch-site'] === 'cross-site') return send(res, 403, { ok: false, error: 'forbidden' });
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, { ok: false, error: 'method-not-allowed' });
      if (!webCtx.get?.('connection')?.isAuthenticated?.(req)) return send(res, 401, { ok: false, error: 'unauthorized' });
      return send(res, 200, { ok: true, data: { path: ROUTE_PATH, token } });
    });
    webCtx.on?.('webserver/index-inject', (table) => table.push({ kind: 'global', name: BOOTSTRAP_KEY, value: { path: ROUTE_PATH, token } }));
    // Seed the first snapshot before any request, then maintain a fixed 5 s trend independent of panel views.
    sampler.sample();
    const timer = timers.setInterval(() => sampler.sample(), SAMPLE_MS);
    timer.unref?.();
    const dispose = () => { timers.clearInterval(timer); for (const stop of disposers.reverse()) stop?.(); };
    ctx.effect?.(() => dispose, 'dsh-resource-manager.host');
  });
  ctx.logger?.info?.('[resource-manager] active; process snapshots every 5s');
}

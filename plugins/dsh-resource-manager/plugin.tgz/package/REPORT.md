# dsh-resource-manager verification report

Date: 2026-10-12. Scope: `dsh-resource-manager` only; no profile edits or dependency changes.

## Automatic cache optimization continuation

Restored the missing `client.js` implementation. With registered owner caches, it reads the authenticated host trend once per minute while the renderer is visible, runs owner callbacks for a reported memory anomaly, and performs cooldown-limited periodic cleanup every 30 minutes. The desktop renderer obtains its token via `/local/resource-manager-token` when no index-injection bootstrap exists. Teardown restores prior bootstrap properties, removes its visibility listener, and stops the timer. No chip or panel is added. Current source audit found no cache owners registered, so no actual cache is currently reclaimed; that limit is deliberate and reported rather than sweeping arbitrary state.

Focused checks after the change:

```text
node --check dsh-resource-manager/client.js — passed
node dsh-resource-manager/test-client.mjs — passed (anomaly, interval, cooldown, callback failure isolation, visibility teardown, desktop token fallback)
node dsh-resource-manager/test-host.mjs — 4/4 passed
node dsh-resource-manager/test-render.mjs — passed; no UI remains
```

## Host sampling

Host sampler is independent of route requests: it immediately takes an initial snapshot, then ticks at exactly 5,000 ms. The timer is `unref()`'d and stopped by the host effect disposer. Trend is a capped 120 samples (up to ten minutes). CPU values are `process.cpuUsage()` deltas for the host process, not a system CPU percentage. Plugin/renderer attribution remains unavailable (`plugins: null`); no per-plugin figures are fabricated.

For deterministic lifecycle verification, `apply(ctx, config, runtime)` accepts internal test-only injected timer and sampler sources; production uses `globalThis` timers and the real process/os sources.

## Commands and actual output

Executed from `dsh-resource-manager`:

```powershell
node --check index.js
node --check client.js
node test-host.mjs
node test-client.mjs
node test-render.mjs
```

Both syntax checks exited 0 with no output. Tests:

```text
ok sampler snapshots memory and CPU deltas while attribution remains null
ok trend is capped and flags only above 20 MiB per minute over 60 seconds
ok optimization log remains capped at 60 entries
ok routes authenticate; host sampler starts immediately, ticks every five seconds, updates trend, and stops on dispose
4/4 checks passed
ok bundle registers the order-160 overlay and persists with the namespaced log key
ok closed or hidden panel performs no fetch and starts no interval
ok visible open panel polls at five seconds and teardown clears timer/listener
ok cleanup calls only explicitly registered safe caches and unregisters them
4/4 checks passed
ok compact chip and portal panel render; unavailable plugin metrics are not zero
ok trend, optimization log, and settings are present in the detail panel
ok panel polling interval is five seconds and disposal stops its timer and listener
3/3 checks passed
```

The host test injects a fake timer and verifies the 5,000 ms interval, `unref()`, an immediate sample before any HTTP request, a sample when the timer callback runs, updated snapshot/trend, and `clearInterval` on effect disposal. Client panel polling is also 5 seconds, only while open and visible.

## Available live measurement (single bounded snapshot)

A bounded PowerShell point-in-time sample of the `DeepSeek Harness` process family returned:

```text
Processes=7 WorkingSetMiB=1203.2 AggregateCpuSeconds=2703.34 Sample=single-point; plugin attribution unavailable
```

This is not an interval CPU measurement, not an incremental memory measurement, and not attributable to this plugin. `AggregateCpuSeconds` is cumulative process CPU time, not a usage percentage. Therefore **current integrated sampler CPU/RSS cost was not measured**; no external CPU cost is claimed. The earlier standalone 61-second sampler run recorded in prior report history is not repeated as evidence for current integrated overhead.

`docs/design/RECON-C.md` §8 gives a historical 7-process working-set upper bound of about 1111.5 MiB. Current point snapshot is approximately 91.7 MiB higher; differing time/workload/process details prevent causal comparison. Summed working set may include shared pages.

## Attribution and cleanup limits

- Measured host Node process: RSS, V8 heap, external memory, array buffers, OS total/free memory, and host CPU-time delta between samples.
- Not measured/available: per-plugin or renderer memory/CPU attribution and system CPU percentage.
- Cleanup only invokes cache-owner callbacks explicitly registered through `window.__DSH_RESOURCE_MANAGER__.registerCache`, and only after the user presses the cleanup action. No arbitrary sweep, plugin/job/process termination, forced GC, or hard CPU/RAM limit.

## Files changed in this correction

- `index.js`: injectable runtime seam; explicit immediate sample + 5-second unref'ed host interval with disposer cleanup.
- `test-host.mjs`: injected-timer cadence, initial snapshot, trend update, unref, and disposal assertions.
- `REPORT.md`: this report with current command output and measurement caveats.

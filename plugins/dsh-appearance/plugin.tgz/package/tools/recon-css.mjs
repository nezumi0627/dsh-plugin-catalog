/**
 * recon-css.mjs — print the surrounding CSS for a literal, from the shipped
 * DSH client bundles. Used to prove which selector declares/consumes a token.
 *
 *   node tools/recon-css.mjs "<literal>" [contextChars] [asarPath]
 */
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const DEFAULT_ASAR = join(HERE, '..', '..', '_asar_full', 'dsh', 'node_modules', '@deepseek-ai');

const literal = process.argv[2];
const context = Number(process.argv[3] ?? 260);
const ASAR = process.argv[4] ?? DEFAULT_ASAR;
if (!literal) {
  console.error('usage: node tools/recon-css.mjs "<literal>" [context] [asar]');
  process.exit(1);
}

function collect(root) {
  const out = [];
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    if (!entry.isDirectory()) {
      // A plain directory of sources rather than a directory of packages.
      if (/\.(js|mjs|md)$/.test(entry.name)) out.push([entry.name, readFileSync(join(root, entry.name), 'utf8')]);
      continue;
    }
    for (const rel of [join('lib', 'client.js'), join('lib', 'index.js'), join('lib', 'invariant.js'), 'README.md']) {
      const file = join(root, entry.name, rel);
      if (existsSync(file)) out.push([`${entry.name}/${rel}`, readFileSync(file, 'utf8')]);
    }
  }
  return out;
}

let total = 0;
for (const [label, text] of collect(ASAR)) {
  let index = text.indexOf(literal);
  while (index !== -1) {
    total += 1;
    const start = Math.max(0, index - context);
    const end = Math.min(text.length, index + literal.length + context);
    const window = text.slice(start, end).replace(/\s+/g, ' ');
    console.log(`\n--- ${label} @${index}\n…${window}…`);
    index = text.indexOf(literal, index + literal.length);
  }
}
console.log(`\n# ${total} occurrence(s)`);

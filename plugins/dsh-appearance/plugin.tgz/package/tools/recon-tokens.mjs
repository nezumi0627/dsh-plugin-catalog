/**
 * recon-tokens.mjs — evidence gatherer for the token overrides in `client.js`.
 *
 * Reads the shipped DSH client bundles (read-only) and answers two questions:
 *   1. what is the *declared* value of each token this plugin overrides, and
 *   2. which selectors *consume* it, so the README can name the real surfaces.
 *
 * Nothing here is loaded by the plugin; it exists so the override list in
 * README.md and the assertion in test-appearance.mjs can be re-derived.
 *
 *   node tools/recon-tokens.mjs [--asar <path to _asar_full\dsh\node_modules\@deepseek-ai>]
 */
import { readFileSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const DEFAULT_ASAR = join(HERE, '..', '..', '_asar_full', 'dsh', 'node_modules', '@deepseek-ai');

const TOKENS = [
  '--dsw-alias-bg-base',
  '--dsw-specific-sidebar-fill',
  '--dsw-alias-bg-layer-1',
  '--dsw-alias-bg-layer-2',
  '--dsw-specific-input-major',
  '--dsw-radius-lg',
  '--dsw-radius-xl',
  '--dsw-radius-panel',
  '--dsw-alias-border-l1',
  '--dsw-alias-border-l2',
  '--dsw-alias-border-l3',
  '--dsw-alias-border-l4',
  '--dsw-menu-backdrop-filter',
];

const asarIndex = process.argv.indexOf('--asar');
const ASAR = asarIndex === -1 ? DEFAULT_ASAR : process.argv[asarIndex + 1];

if (!existsSync(ASAR)) {
  console.error(`not found: ${ASAR}`);
  process.exit(1);
}

/** Every `@deepseek-ai/*` package's client bundle, as [packageName, text]. */
function bundles(root) {
  const out = [];
  for (const entry of readdirSync(root, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const file = join(root, entry.name, 'lib', 'client.js');
    if (!existsSync(file)) continue;
    out.push([entry.name, readFileSync(file, 'utf8')]);
  }
  return out;
}

const all = bundles(ASAR);

console.log(`# bundles scanned: ${all.length}\n`);

console.log('## declared values');
for (const token of TOKENS) {
  const values = [];
  for (const [pkg, text] of all) {
    // `token:value;` — the theme package declares these twice (light, then dark).
    const re = new RegExp(`${token.replace(/[-]/g, '\\-')}\\s*:\\s*([^;}"']+)`, 'g');
    for (const match of text.matchAll(re)) values.push(`${pkg}: ${match[1].trim()}`);
  }
  console.log(`${token}`);
  for (const value of values.length ? values : ['(not declared anywhere)']) console.log(`    ${value}`);
}

console.log('\n## consumers (selector fragment before each use)');
for (const token of TOKENS) {
  const rows = [];
  for (const [pkg, text] of all) {
    let index = text.indexOf(token);
    while (index !== -1) {
      // Walk back to the start of the declaration block so the selector is visible.
      const start = Math.max(0, index - 220);
      const fragment = text.slice(start, index + token.length).replace(/\s+/g, ' ');
      rows.push(`${pkg}: …${fragment.slice(-180)}`);
      index = text.indexOf(token, index + token.length);
    }
  }
  console.log(`\n${token} — ${rows.length} use(s)`);
  for (const row of rows.slice(0, 12)) console.log(`    ${row}`);
  if (rows.length > 12) console.log(`    … ${rows.length - 12} more`);
}

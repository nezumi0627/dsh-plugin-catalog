# dsh-appearance verification report

Executed from `dsh-appearance` with Node.js v24.14.0.

## Commands and actual output

`node test-appearance.mjs`

```text
42/42 checks passed
```

`node test-client.mjs`

```text
ok   client registration, defaults, and style teardown
1/1 checks passed
```

`node test-render.mjs`

```text
ok   one looping video portal targets document.body
1/1 checks passed
```

`node --check client.js; node --check index.js; node --check test-appearance.mjs; node --check test-client.mjs; node --check test-render.mjs; node --check test-helpers.mjs; node --check tools/recon-css.mjs; node --check tools/recon-tokens.mjs`

```text
(no output; exit code 0)
```

## Scope and limitations

- The shipped default remains `C:\Users\ren11\Downloads\infinite-space-moewalls-com.mp4`; the source file is not copied or modified.
- Host media delivery is local-file streaming with byte-range support and does not buffer the full 86 MB video. No live DSH server request was exercised.
- The render harness verifies one looping/muted video portal to `document.body`. It does not exercise a real browser decoder, three stateful resize rerenders, or GPU load.
- Historical note: the portal-rendering lifecycle component was moved to `shell.leading`; this was superseded by the 2026-10-12 slot-collision fix below.
- Latest rerun: pure suite 42/42; client 1/1; render 1/1; `node --check client.js` and `index.js` exit 0. Added a regression assertion that plugin CSS contains no hex color literals; the dim layer now uses `rgb(0 0 0)`.
- Transparency/revert logic covers the five listed surface tokens; it is not a proven audit of every app canvas background. The render harness does not exercise a real browser decoder, multiple stateful resize rerenders, or GPU load.
- No third-party dependencies were added.

## 2026-10-12 — shell slot collision

The DSH sync error showed `shell.leading` already occupied at priority `0` by the main frame (`mf`). `shell.leading` is a singleton, so `dsh-appearance` could not register at its default priority. The lifecycle component now mounts through the `shell.overlay` list slot; its wallpaper DOM still portals to the first child of `document.body` at z-index `0`, so it does not render in the overlay layer. The existing client contract assertion and README now reflect this registration. Syntax was checked; the test suite was not run.

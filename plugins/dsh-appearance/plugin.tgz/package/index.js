/**
 * Host half of `@local/dsh-appearance`.
 *
 * The wallpaper lives entirely in the Client half, but the *file* it plays is on
 * the user's disk and the GUI is served over `http://127.0.0.1:<port>`. Chromium
 * refuses to load a `file://` subresource from an `http://` document ("Not
 * allowed to load local resource"), so this row is the only way to reach the
 * file: two loopback-only routes that stream a local media file and report
 * whether a path exists.
 *
 *   GET /local/dsh-appearance/probe?path=<absolute path>   -> JSON, no body read
 *   GET /local/dsh-appearance/media?path=<absolute path>   -> the file, with Range
 *
 * Both are guarded by a per-process token (`x-dsh-appearance-token`, or `?token=`
 * because a `<video src>` cannot send a header) that is injected only into the
 * page DSH itself serves. Media elements issue their own requests, so a
 * cross-site page cannot borrow the capability: `sec-fetch-site: cross-site` is
 * refused outright.
 *
 * Known limit, documented rather than hidden: any local page that learns the
 * token could read any file whose extension is on the whitelist. That is the
 * cost of playing a user-chosen file from a browser context, and it is why the
 * whitelist is media-only and the server is loopback-only.
 *
 * Streaming, never slurping: the route answers `Range` with a 206 and pipes a
 * read stream, so an 86 MB video is never held in memory.
 */
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { createReadStream, promises as fsp } from 'node:fs';
import { basename, extname, resolve } from 'node:path';

export const name = 'dsh-appearance';

/** Route base; the two exact routes below must beat the SPA fallback. */
export const ROUTE_BASE = '/local/dsh-appearance';
export const PROBE_PATH = `${ROUTE_BASE}/probe`;
export const MEDIA_PATH = `${ROUTE_BASE}/media`;
/** Page global carrying the route base and this process's token. */
export const BOOTSTRAP_KEY = '__DSH_APPEARANCE__';
/** Header that proves the caller is the served page. */
export const TOKEN_HEADER = 'x-dsh-appearance-token';
/** Requirement §12's default file, echoed to the GUI for "reset to default". */
export const DEFAULT_MEDIA_PATH = 'C:\\Users\\ren11\\Downloads\\infinite-space-moewalls-com.mp4';

/** The media whitelist. Deliberately narrow: this route reads local files. */
const VIDEO_TYPES = Object.freeze({
  mp4: 'video/mp4',
  m4v: 'video/x-m4v',
  webm: 'video/webm',
  ogv: 'video/ogg',
  ogg: 'video/ogg',
});
const IMAGE_TYPES = Object.freeze({
  gif: 'image/gif',
  png: 'image/png',
  jpg: 'image/jpeg',
  jpeg: 'image/jpeg',
  webp: 'image/webp',
  avif: 'image/avif',
  bmp: 'image/bmp',
  apng: 'image/apng',
  svg: 'image/svg+xml',
});

/** Which of the three render kinds an extension belongs to, or `none`. */
export function kindOf(path) {
  const extension = extname(String(path ?? '')).slice(1).toLowerCase();
  if (Object.prototype.hasOwnProperty.call(VIDEO_TYPES, extension)) return 'video';
  if (extension === 'gif') return 'gif';
  if (Object.prototype.hasOwnProperty.call(IMAGE_TYPES, extension)) return 'image';
  return 'none';
}

/** The `Content-Type` an extension is served with, or `application/octet-stream`. */
export function contentTypeOf(path) {
  const extension = extname(String(path ?? '')).slice(1).toLowerCase();
  return VIDEO_TYPES[extension] ?? IMAGE_TYPES[extension] ?? 'application/octet-stream';
}

/**
 * Normalise and validate a requested path without touching the disk.
 * `resolve` collapses `..`, mixes separators and keeps spaces intact, which is
 * why a path such as `C:\Users\ren 11\my video.mp4` needs no escaping here.
 */
export function describePath(rawPath) {
  const requested = typeof rawPath === 'string' ? rawPath.trim() : '';
  if (requested === '') return { ok: false, reason: 'empty' };
  if (requested.includes('\u0000')) return { ok: false, reason: 'invalid' };
  const absolute = resolve(requested);
  const kind = kindOf(absolute);
  const extension = extname(absolute).slice(1).toLowerCase();
  if (extension === '') return { ok: false, reason: 'no-extension', path: absolute };
  if (kind === 'none') return { ok: false, reason: 'unsupported-extension', path: absolute, extension };
  return { ok: true, reason: 'ok', path: absolute, kind, extension, type: contentTypeOf(absolute) };
}

/**
 * `bytes=a-b` against a known size.
 * @returns `null` when the header is absent, `{ invalid: true }` when it cannot
 * be satisfied, and `{ start, end }` (inclusive) otherwise.
 */
export function parseRange(header, size) {
  if (typeof header !== 'string' || header.trim() === '') return null;
  const match = /^bytes=(\d*)-(\d*)$/.exec(header.trim());
  if (!match) return { invalid: true };
  const [, rawStart, rawEnd] = match;
  if (rawStart === '' && rawEnd === '') return { invalid: true };
  let start;
  let end;
  if (rawStart === '') {
    // A suffix range: the last N bytes.
    const length = Number.parseInt(rawEnd, 10);
    if (!Number.isFinite(length) || length <= 0) return { invalid: true };
    start = Math.max(0, size - length);
    end = size - 1;
  } else {
    start = Number.parseInt(rawStart, 10);
    end = rawEnd === '' ? size - 1 : Number.parseInt(rawEnd, 10);
    if (!Number.isFinite(start) || !Number.isFinite(end)) return { invalid: true };
    end = Math.min(end, size - 1);
  }
  if (size === 0 || start > end || start >= size) return { invalid: true };
  return { start, end };
}

/** A stable, cheap validator for `If-None-Match`. */
export function etagFor(stat) {
  return `"${stat.size.toString(16)}-${Math.round(stat.mtimeMs).toString(16)}"`;
}

/** Constant-time token check that also refuses a cross-site caller. */
export function authorized(req, token) {
  const site = req?.headers?.['sec-fetch-site'];
  if (typeof site === 'string' && site === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  try {
    return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
  } catch {
    return false;
  }
}

/** The `?token=` fallback, for requests a media element makes on its own. */
export function authorizedQuery(url, token) {
  const supplied = url.searchParams.get('token');
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  try {
    return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
  } catch {
    return false;
  }
}

function sendJson(req, res, status, payload, extraHeaders = {}) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'content-length': Buffer.byteLength(body),
    ...extraHeaders,
  });
  res.end(req.method === 'HEAD' ? undefined : body);
}

/** Where a request may carry the token: the header, or the media URL's query. */
function requestAllowed(req, url, token) {
  if (req?.headers?.['sec-fetch-site'] === 'cross-site') return false;
  return authorized(req, token) || authorizedQuery(url, token);
}

/**
 * `GET|HEAD /local/dsh-appearance/probe` — existence, size and kind for one path.
 * No file contents are read; this is what lets the settings row refuse a path
 * *before* it replaces a working wallpaper.
 */
export function createProbeHandler(options) {
  const { token } = options;
  return async function appearanceProbeRoute(req, res) {
    const url = new URL(req.url ?? '/', 'http://127.0.0.1');
    if (!requestAllowed(req, url, token)) {
      sendJson(req, res, 403, { ok: false, reason: 'forbidden' });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(req, res, 405, { ok: false, reason: 'method-not-allowed' });
      return;
    }
    const described = describePath(url.searchParams.get('path'));
    if (!described.ok) {
      sendJson(req, res, 200, { ok: false, reason: described.reason, extension: described.extension ?? null });
      return;
    }
    try {
      const stat = await fsp.stat(described.path);
      sendJson(req, res, 200, {
        ok: true,
        exists: true,
        isFile: stat.isFile(),
        reason: stat.isFile() ? 'ok' : 'not-file',
        size: stat.size,
        mtimeMs: stat.mtimeMs,
        kind: described.kind,
        type: described.type,
        name: basename(described.path),
      });
    } catch (error) {
      sendJson(req, res, 200, {
        ok: false,
        exists: false,
        reason: error?.code === 'ENOENT' ? 'missing' : 'unreachable',
        kind: described.kind,
        type: described.type,
      });
    }
  };
}

/**
 * `GET|HEAD /local/dsh-appearance/media` — the file itself, Range-aware and
 * streamed. One read stream per request; nothing is buffered whole.
 */
export function createMediaHandler(options) {
  const { token } = options;
  return async function appearanceMediaRoute(req, res) {
    const url = new URL(req.url ?? '/', 'http://127.0.0.1');
    if (!requestAllowed(req, url, token)) {
      sendJson(req, res, 403, { ok: false, reason: 'forbidden' });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(req, res, 405, { ok: false, reason: 'method-not-allowed' }, { allow: 'GET, HEAD' });
      return;
    }
    const described = describePath(url.searchParams.get('path'));
    if (!described.ok) {
      sendJson(req, res, 404, { ok: false, reason: described.reason });
      return;
    }
    let stat;
    try {
      stat = await fsp.stat(described.path);
    } catch {
      sendJson(req, res, 404, { ok: false, reason: 'missing' });
      return;
    }
    if (!stat.isFile()) {
      sendJson(req, res, 404, { ok: false, reason: 'not-file' });
      return;
    }

    const etag = etagFor(stat);
    const range = parseRange(req.headers?.range, stat.size);

    if (range === null && req.headers?.['if-none-match'] === etag) {
      res.writeHead(304, { etag, 'cache-control': 'no-cache' });
      res.end();
      return;
    }
    if (range && range.invalid) {
      res.writeHead(416, {
        'content-type': 'application/json; charset=utf-8',
        'content-range': `bytes */${stat.size}`,
        'accept-ranges': 'bytes',
        'cache-control': 'no-store',
      });
      res.end(JSON.stringify({ ok: false, reason: 'range-not-satisfiable' }));
      return;
    }

    const start = range ? range.start : 0;
    const end = range ? range.end : stat.size - 1;
    const headers = {
      'content-type': described.type,
      'accept-ranges': 'bytes',
      'cache-control': 'no-cache',
      etag,
      // The GUI reloads the same URL after a path change; this keeps the media
      // cache honest without re-downloading on every seek.
      'last-modified': new Date(stat.mtimeMs).toUTCString(),
    };
    if (range) headers['content-range'] = `bytes ${start}-${end}/${stat.size}`;
    headers['content-length'] = String(Math.max(0, end - start + 1));

    res.writeHead(range ? 206 : 200, headers);
    if (req.method === 'HEAD' || stat.size === 0) {
      res.end();
      return;
    }

    const stream = createReadStream(described.path, { start, end });
    // A seek, a reload or a closed tab must not leave a read stream open.
    const stop = () => stream.destroy();
    res.on('close', stop);
    res.on('error', stop);
    stream.on('error', () => {
      try {
        res.destroy();
      } catch {
        /* the socket is already gone */
      }
    });
    stream.pipe(res);
  };
}

/** Inject the route base and token into the served index, so only the GUI knows them. */
export function injectBootstrap(html, { token, defaultPath = DEFAULT_MEDIA_PATH } = {}) {
  if (typeof html !== 'string') return html;
  const payload = JSON.stringify({
    path: ROUTE_BASE,
    probe: PROBE_PATH,
    media: MEDIA_PATH,
    header: TOKEN_HEADER,
    token,
    defaultPath,
  }).replace(/</g, '\\u003c');
  const script = `<script>window.${BOOTSTRAP_KEY}=${payload};</script>`;
  const headEnd = html.search(/<\/head>/i);
  if (headEnd === -1) return `${html}${script}`;
  return `${html.slice(0, headEnd)}${script}${html.slice(headEnd)}`;
}

/**
 * Register the two routes. The Client half degrades to a plain `file://` URL when
 * this row is absent (a CLI run with no web server), so nothing here is load
 * bearing for DSH itself.
 */
export function apply(ctx, config) {
  const options = { ...(config ?? {}) };
  ctx.logger?.info?.('[dsh-appearance] Host half active — loopback media route for the wallpaper');

  ctx.inject(['webServer'], (web) => {
    const token = randomBytes(32).toString('hex');
    web.effect(
      () => web.webServer.register({ kind: 'exact', path: PROBE_PATH, handler: createProbeHandler({ ...options, token }) }),
      'dsh-appearance: probe route',
    );
    web.effect(
      () => web.webServer.register({ kind: 'exact', path: MEDIA_PATH, handler: createMediaHandler({ ...options, token }) }),
      'dsh-appearance: media route',
    );
    web.effect(
      () => web.webServer.tapIndex((html) => injectBootstrap(html, { token, defaultPath: options.defaultPath })),
      'dsh-appearance: page bootstrap',
    );
  });
}

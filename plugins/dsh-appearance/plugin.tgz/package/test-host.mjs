import assert from 'node:assert/strict';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createProbeHandler } from './index.js';

const directory = await mkdtemp(join(tmpdir(), 'dsh-appearance-'));
try {
  const mediaPath = join(directory, 'wallpaper.mp4');
  await writeFile(mediaPath, 'video');
  const handler = createProbeHandler({ token: 'test-token' });
  async function request(method, path) {
    const response = { headers: null, body: null, writeHead(status, headers) { this.status = status; this.headers = headers; }, end(body) { this.body = body ?? null; } };
    await handler({ method, url: `/local/dsh-appearance/probe?path=${encodeURIComponent(path)}`, headers: { 'x-dsh-appearance-token': 'test-token' } }, response);
    return response;
  }

  const get = await request('GET', mediaPath);
  assert.equal(get.status, 200);
  assert.equal(JSON.parse(get.body).exists, true);

  const head = await request('HEAD', mediaPath);
  assert.equal(head.status, 200);
  assert.equal(head.headers['content-length'], Buffer.byteLength(get.body));
  assert.equal(head.body, null, 'HEAD probe must not return a response body');

  const invalidHead = await request('HEAD', join(directory, 'unsupported.txt'));
  assert.equal(invalidHead.status, 200);
  assert.equal(invalidHead.body, null, 'HEAD error responses must not return a response body');
} finally {
  await rm(directory, { recursive: true, force: true });
}

console.log('ok HEAD probe returns GET headers without a response body');

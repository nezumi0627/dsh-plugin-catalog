/**
 * Shared headless harness for the `@local/dsh-appearance` tests.
 *
 * It provides exactly what the Client half touches and nothing more:
 *
 *  - a fake DOM with a real cascade *shape* (an inline value beats the
 *    "stylesheet" value), because the override/revert proof depends on it;
 *  - a miniature React with one persistent hook frame per component function,
 *    so a nested component (`GifStill`) cannot corrupt its parent's hook order,
 *    available in two modes: render to the fake DOM (lifecycle tests) or expand
 *    to a descriptor tree (render tests);
 *  - a bundle loader that captures `window.__ModuleLoader__.load`;
 *  - a materializer that runs `apply(ctx)` against a stub Cordis context and
 *    hands back the registered slot cells and effects.
 *
 * Nothing about the plugin is re-implemented here.
 */
import assert from 'node:assert/strict';

// ---------------------------------------------------------------------------
// Fake CSSStyleDeclaration
// ---------------------------------------------------------------------------

/** Insertion-ordered property bag with the methods the plugin uses. */
export function createStyle() {
  const values = new Map();
  const priorities = new Map();
  const style = {
    setProperty(name, value, priority = '') {
      values.set(String(name), String(value));
      priorities.set(String(name), String(priority ?? ''));
    },
    getPropertyValue(name) {
      return values.has(String(name)) ? values.get(String(name)) : '';
    },
    getPropertyPriority(name) {
      return priorities.get(String(name)) ?? '';
    },
    removeProperty(name) {
      const previous = style.getPropertyValue(name);
      values.delete(String(name));
      priorities.delete(String(name));
      return previous;
    },
    get cssText() {
      return [...values]
        .map(([name, value]) => `${name}: ${value}${priorities.get(name) ? ' !important' : ''};`)
        .join(' ');
    },
    get entries() {
      return [...values];
    },
  };
  return style;
}

// ---------------------------------------------------------------------------
// Fake DOM
// ---------------------------------------------------------------------------

function createElement(tagName, owner) {
  const attributes = new Map();
  const listeners = new Map();
  const children = [];
  const element = {
    tagName: String(tagName).toUpperCase(),
    ownerDocument: owner,
    className: '',
    style: createStyle(),
    /** Stands in for the stylesheet-declared custom properties on this element. */
    declared: new Map(),
    children,
    parentNode: null,
    props: {},
    // Media surface touched by the Client half.
    paused: true,
    readyState: 4,
    muted: false,
    volume: 1,
    currentTime: 0,
    calls: { pause: 0, play: 0, load: 0, drawImage: 0 },
    get firstChild() {
      return children[0] ?? null;
    },
    get textContent() {
      return children.filter((child) => typeof child === 'string').join('');
    },
    set textContent(value) {
      children.length = 0;
      if (value !== '') children.push(String(value));
    },
    append(...nodes) {
      for (const node of nodes) element.appendChild(node);
    },
    appendChild(node) {
      if (node === null || node === undefined) return node;
      if (typeof node === 'string') {
        children.push(node);
        return node;
      }
      node.parentNode?.removeChild?.(node);
      node.parentNode = element;
      children.push(node);
      return node;
    },
    insertBefore(node, reference) {
      const at = reference === null || reference === undefined ? children.length : Math.max(0, children.indexOf(reference));
      node.parentNode?.removeChild?.(node);
      node.parentNode = element;
      children.splice(at === -1 ? children.length : at, 0, node);
      return node;
    },
    removeChild(node) {
      const index = children.indexOf(node);
      if (index !== -1) children.splice(index, 1);
      node.parentNode = null;
      return node;
    },
    remove() {
      element.parentNode?.removeChild(element);
    },
    setAttribute(name, value) {
      attributes.set(String(name), String(value));
      if (name === 'src') element.src = String(value);
      if (name === 'class') element.className = String(value);
    },
    getAttribute(name) {
      if (name === 'src') return element.src === undefined ? null : element.src;
      return attributes.has(String(name)) ? attributes.get(String(name)) : null;
    },
    removeAttribute(name) {
      attributes.delete(String(name));
      if (name === 'src') element.src = undefined;
    },
    hasAttribute(name) {
      return attributes.has(String(name));
    },
    addEventListener(type, handler) {
      if (!listeners.has(type)) listeners.set(type, new Set());
      listeners.get(type).add(handler);
    },
    removeEventListener(type, handler) {
      listeners.get(type)?.delete(handler);
    },
    listenerCount(type) {
      return listeners.get(type)?.size ?? 0;
    },
    dispatch(type, event = {}) {
      for (const handler of [...(listeners.get(type) ?? [])]) handler({ type, target: element, ...event });
    },
    getContext() {
      return {
        drawImage() {
          element.calls.drawImage += 1;
        },
      };
    },
    pause() {
      element.calls.pause += 1;
      element.paused = true;
    },
    play() {
      element.calls.play += 1;
      element.paused = false;
      return Promise.resolve();
    },
    load() {
      element.calls.load += 1;
      element.paused = true;
      element.readyState = 0;
    },
    /** Depth-first search over the attached subtree, by class fragment. */
    find(className) {
      const found = [];
      const walk = (node) => {
        for (const child of node.children) {
          if (typeof child === 'string') continue;
          if (String(child.className ?? '').includes(className)) found.push(child);
          walk(child);
        }
      };
      walk(element);
      return found;
    },
  };
  return element;
}

/**
 * Install a DOM whose computed value for a custom property is the inline value
 * when there is one and the element's declared (stylesheet) value otherwise —
 * the cascade shape this plugin's overrides depend on.
 */
export function installDom({ theme = 'dark', bootstrap } = {}) {
  const documentElement = createElement('html', null);
  const body = createElement('body', null);
  const head = createElement('head', null);
  const rootElement = createElement('div', null);
  rootElement.setAttribute('id', 'root');
  const overlayHost = createElement('div', null);
  overlayHost.className = 'overlayHost';

  const declarations = new Map([
    // The real theme declares statics and aliases on `body`
    // (dsh-client-ui-theme/lib/client.js:1148) and only radii on `:root` (:1142).
    ['--dsw-static-neutral-bluish-00', '#ffffff'],
    ['--dsw-static-neutral-bluish-950', '#0f1115'],
    ['--dsw-static-neutral-bluish-900', '#15171c'],
    ['--dsw-static-neutral-bluish-875', '#1b1e24'],
    ['--dsw-static-neutral-bluish-850', '#22252c'],
    ['--dsw-alias-bg-base', 'var(--dsw-static-neutral-bluish-950)'],
    ['--dsw-specific-sidebar-fill', 'var(--dsw-static-neutral-bluish-900)'],
    ['--dsw-alias-bg-layer-1', 'var(--dsw-static-neutral-bluish-875)'],
    ['--dsw-alias-bg-layer-2', 'var(--dsw-static-neutral-bluish-850)'],
    ['--dsw-specific-input-major', 'var(--dsw-static-neutral-bluish-850)'],
    ['--dsw-alias-border-l1', '#ffffff0f'],
    ['--dsw-alias-border-l2', '#ffffff1f'],
    ['--dsw-alias-border-l3', '#ffffff29'],
    ['--dsw-alias-border-l4', '#ffffff33'],
    ['--dsw-menu-backdrop-filter', 'blur(40px) saturate(150%)'],
  ]);
  const rootDeclarations = new Map([
    ['--dsw-radius-lg', '16px'],
    ['--dsw-radius-xl', '20px'],
    ['--dsw-radius-panel', '28px'],
  ]);
  if (theme === 'light') {
    declarations.set('--dsw-alias-bg-base', 'var(--dsw-static-neutral-bluish-00)');
    declarations.set('--dsw-alias-border-l1', '#0000000a');
  }
  for (const [name, value] of declarations) body.declared.set(name, value);
  for (const [name, value] of rootDeclarations) documentElement.declared.set(name, value);

  body.append(rootElement);
  rootElement.append(overlayHost);

  const documentListeners = new Map();
  const document = {
    documentElement,
    body,
    head,
    visibilityState: 'visible',
    createElement: (tag) => createElement(tag, document),
    querySelector: (selector) => (selector === '#root' ? rootElement : null),
    addEventListener(type, handler) {
      if (!documentListeners.has(type)) documentListeners.set(type, new Set());
      documentListeners.get(type).add(handler);
    },
    removeEventListener(type, handler) {
      documentListeners.get(type)?.delete(handler);
    },
    listenerCount(type) {
      return documentListeners.get(type)?.size ?? 0;
    },
    dispatch(type, event = {}) {
      for (const handler of [...(documentListeners.get(type) ?? [])]) handler({ type, target: document, ...event });
    },
  };
  for (const element of [documentElement, body, head, rootElement, overlayHost]) element.ownerDocument = document;

  const stored = new Map();
  const localStorage = {
    getItem: (key) => (stored.has(String(key)) ? stored.get(String(key)) : null),
    setItem: (key, value) => stored.set(String(key), String(value)),
    removeItem: (key) => stored.delete(String(key)),
  };

  function computedStyleOf(element) {
    return {
      getPropertyValue(name) {
        const inline = element?.style?.getPropertyValue(name);
        if (inline) return inline;
        const own = element?.declared?.get(name);
        if (own !== undefined) return own;
        return body.declared.get(name) ?? documentElement.declared.get(name) ?? '';
      },
    };
  }

  let reducedMotion = false;
  const mediaQueries = new Set();
  const window = {
    __ModuleLoader__: { load: () => {} },
    localStorage,
    innerWidth: 1600,
    innerHeight: 900,
    devicePixelRatio: 1,
    addEventListener() {},
    removeEventListener() {},
    matchMedia: (query) => {
      const list = {
        media: query,
        matches: query.includes('prefers-reduced-motion') ? reducedMotion : false,
        addEventListener(type, handler) {
          if (type === 'change') mediaQueries.add(handler);
        },
        removeEventListener(type, handler) {
          if (type === 'change') mediaQueries.delete(handler);
        },
      };
      return list;
    },
  };
  if (bootstrap) window.__DSH_APPEARANCE__ = bootstrap;

  globalThis.document = document;
  globalThis.window = window;
  globalThis.getComputedStyle = computedStyleOf;
  globalThis.Image = class FakeImage {
    constructor() {
      this.naturalWidth = 64;
      this.naturalHeight = 32;
      this.onload = null;
      this.onerror = null;
      this.decoding = 'auto';
    }

    set src(value) {
      this._src = value;
      if (value === '' || value === undefined || value === null) return;
      queueMicrotask(() => this.onload?.());
    }

    get src() {
      return this._src;
    }
  };

  return {
    document,
    window,
    body,
    head,
    root: rootElement,
    overlayHost,
    localStorage,
    setReducedMotion(value) {
      reducedMotion = value;
      for (const handler of [...mediaQueries]) handler({ matches: value });
    },
  };
}

// ---------------------------------------------------------------------------
// Miniature React
// ---------------------------------------------------------------------------

function depsEqual(a, b) {
  if (a === undefined || b === undefined) return false;
  if (a.length !== b.length) return false;
  return a.every((value, index) => Object.is(value, b[index]));
}

export const Fragment = Symbol('Fragment');

export const ReactShim = {
  Fragment,
  createElement(type, props, ...children) {
    const full = { ...(props ?? {}), children: children.length <= 1 ? children[0] : children };
    return { type, props: full };
  },
  useState: (initial) => activeHooks.useState(initial),
  useRef: (initial) => activeHooks.useRef(initial),
  useMemo: (fn, deps) => activeHooks.useMemo(fn, deps),
  useCallback: (fn, deps) => activeHooks.useCallback(fn, deps),
  useEffect: (fn, deps) => activeHooks.useEffect(fn, deps),
};

let activeHooks = null;
const NOTHING = (node) => node === null || node === undefined || typeof node === 'boolean';

/**
 * A renderer with one persistent hook frame per component function.
 * @param dom - `null` for descriptor mode (returns an expanded tree), or the
 * object `installDom` returned for fake-DOM mode.
 */
export function createRenderer(dom = null) {
  const frames = new Map();
  let pending = [];
  let active = null;

  function frameFor(type) {
    let frame = frames.get(type);
    if (!frame) {
      frame = { slots: [], effects: [], cursor: 0 };
      frames.set(type, frame);
    }
    return frame;
  }

  const hooks = {
    useState(initial) {
      const frame = active;
      const index = frame.cursor++;
      if (!(index in frame.slots)) frame.slots[index] = typeof initial === 'function' ? initial() : initial;
      return [frame.slots[index], (next) => {
        frame.slots[index] = typeof next === 'function' ? next(frame.slots[index]) : next;
      }];
    },
    useRef(initial) {
      const frame = active;
      const index = frame.cursor++;
      if (!(index in frame.slots)) frame.slots[index] = { current: initial };
      return frame.slots[index];
    },
    useMemo(fn, deps) {
      const frame = active;
      const index = frame.cursor++;
      const previous = frame.slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      const value = fn();
      frame.slots[index] = { deps, value };
      return value;
    },
    useCallback(fn, deps) {
      const frame = active;
      const index = frame.cursor++;
      const previous = frame.slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      frame.slots[index] = { deps, value: fn };
      return fn;
    },
    useEffect(fn, deps) {
      const frame = active;
      const index = frame.cursor++;
      const previous = frame.effects[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return;
      pending.push({ frame, index, deps, fn, cleanup: previous?.cleanup });
    },
  };

  /** Run a component function inside its own hook frame. */
  function callComponent(type, props) {
    const frame = frameFor(type);
    const outer = active;
    const outerCursor = outer ? outer.cursor : 0;
    active = frame;
    frame.cursor = 0;
    try {
      return type(props ?? {});
    } finally {
      active = outer;
      if (outer) outer.cursor = outerCursor;
    }
  }

  function mountDom(node, container) {
    if (NOTHING(node)) return;
    if (Array.isArray(node)) {
      for (const child of node) mountDom(child, container);
      return;
    }
    if (typeof node === 'string' || typeof node === 'number') {
      container.append(String(node));
      return;
    }
    if (node.__portal) {
      mountDom(node.children, node.container);
      return;
    }
    if (typeof node.type === 'function') {
      mountDom(callComponent(node.type, node.props), container);
      return;
    }
    if (node.type === Fragment) {
      mountDom(node.props?.children, container);
      return;
    }
    const element = dom.document.createElement(node.type);
    for (const [key, value] of Object.entries(node.props ?? {})) {
      if (key === 'children' || key === 'ref' || key === 'key') continue;
      if (value === false || value === null || value === undefined) continue;
      if (key === 'style') {
        for (const [name, styleValue] of Object.entries(value)) element.style.setProperty(name, String(styleValue));
        continue;
      }
      if (key === 'className') {
        element.className = String(value);
        element.setAttribute('class', String(value));
        continue;
      }
      if (key.startsWith('on') && typeof value === 'function') {
        element.addEventListener(key.slice(2).toLowerCase(), value);
        continue;
      }
      element.setAttribute(key, value === true ? '' : String(value));
    }
    container.append(element);
    mountDom(node.props?.children, element);
    if (node.props?.ref) node.props.ref.current = element;
  }

  function expand(node) {
    if (NOTHING(node)) return null;
    if (Array.isArray(node)) return node.map(expand).filter((child) => child !== null);
    if (typeof node === 'string' || typeof node === 'number') return String(node);
    if (node.__portal) return { __portal: true, container: node.container, children: expand(node.children) };
    if (typeof node.type === 'function') return expand(callComponent(node.type, node.props));
    if (node.type === Fragment) return expand(node.props?.children);
    return { type: node.type, props: { ...node.props, children: expand(node.props?.children) } };
  }

  function flush() {
    const run = pending;
    pending = [];
    for (const effect of run) {
      effect.cleanup?.();
      const cleanup = effect.fn();
      effect.frame.effects[effect.index] = {
        deps: effect.deps,
        fn: effect.fn,
        cleanup: typeof cleanup === 'function' ? cleanup : undefined,
      };
    }
  }

  function startRender() {
    activeHooks = hooks;
  }

  return {
    /** Render a component with the given props; returns the tree in descriptor mode. */
    renderComponent(type, props, container) {
      let tree = null;
      startRender();
      try {
        if (dom === null) tree = expand({ type, props: props ?? {} });
        else mountDom({ type, props: props ?? {} }, container);
      } finally {
        activeHooks = null;
      }
      flush();
      return tree;
    },
    /** Render an already-built descriptor tree. */
    render(node, container) {
      let tree = null;
      startRender();
      try {
        if (dom === null) tree = expand(node);
        else mountDom(node, container);
      } finally {
        activeHooks = null;
      }
      flush();
      return tree;
    },
    /** Run every pending cleanup, newest first: what a real unmount does. */
    unmount() {
      for (const frame of [...frames.values()].reverse()) {
        for (let index = frame.effects.length - 1; index >= 0; index -= 1) {
          const effect = frame.effects[index];
          if (!effect) continue;
          effect.cleanup?.();
          frame.effects[index] = undefined;
        }
      }
    },
  };
}

// ---------------------------------------------------------------------------
// Descriptor tree helpers
// ---------------------------------------------------------------------------

export function text(node) {
  if (NOTHING(node)) return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(text).filter(Boolean).join(' ');
  if (node.__portal) return text(node.children);
  return text(node.props?.children);
}

export function findAll(node, predicate, found = []) {
  if (NOTHING(node) || typeof node !== 'object') return found;
  if (Array.isArray(node)) {
    for (const child of node) findAll(child, predicate, found);
    return found;
  }
  if (node.__portal) return findAll(node.children, predicate, found);
  if (predicate(node)) found.push(node);
  findAll(node.props?.children, predicate, found);
  return found;
}

export const byClass = (name) => (node) => typeof node.props?.className === 'string' && node.props.className.includes(name);
export const byTag = (name) => (node) => node.type === name;

// ---------------------------------------------------------------------------
// Bundle loading
// ---------------------------------------------------------------------------

/**
 * Import a fresh copy of `client.js` and return the spec it registered. Node's
 * ESM cache keys by URL, so the query string gives one module instance — and one
 * module-level store — per call.
 */
export async function loadBundle(tag) {
  const specs = [];
  globalThis.window.__ModuleLoader__.load = (spec) => specs.push(spec);
  const url = new URL(`./client.js?case=${tag}`, import.meta.url).href;
  await import(url);
  assert.equal(specs.length, 1, 'the bundle registered exactly one module');
  return specs[0];
}

/**
 * Materialize a captured bundle against the miniature React and a stub Cordis
 * context.
 */
export function materialize(spec, { activeLocale = 'ja' } = {}) {
  const cells = new Map();
  const registrations = [];
  const effects = [];
  const instance = spec.factory((name) => {
    if (name === 'react') return ReactShim;
    if (name === 'react-dom') {
      return { createPortal: (children, container) => ({ __portal: true, children, container }) };
    }
    throw new Error(`unexpected require: ${name}`);
  });
  const ctx = {
    locale: {
      register: () => () => {},
      getLocale: () => ({ active: activeLocale }),
    },
    slots: {
      inject: (slotName, callback) => {
        callback({ slotName });
        return () => {};
      },
      register: (options, cell) => {
        cells.set(options.id, cell);
        registrations.push(options);
        return () => cells.delete(options.id);
      },
    },
    effect: (fn, label) => {
      const dispose = fn();
      effects.push({ label, dispose: typeof dispose === 'function' ? dispose : () => {} });
    },
  };
  instance.apply(ctx);
  return {
    instance,
    ctx,
    cells,
    registrations,
    /** Run every disposer `apply` registered, newest first. */
    dispose() {
      for (let index = effects.length - 1; index >= 0; index -= 1) effects[index].dispose();
    },
  };
}

/** A translator stub resolving against the bundle's own dictionary. */
export function makeT(instance, activeLocale = 'ja') {
  const dictionary = instance.__test.dictionaries[activeLocale] ?? instance.__test.dictionaries.en;
  return (key, params) => {
    const template = dictionary[key] ?? instance.__test.dictionaries.en[key] ?? key;
    if (!params) return template;
    return template.replace(/\{(\w+)\}/g, (whole, name) => (params[name] === undefined ? whole : String(params[name])));
  };
}

/**
 * Pure-logic tests for `@local/dsh-appearance` — no React, no lifecycle.
 *
 * Covers the path/type validation, the settings normalisation (including corrupt
 * and missing storage), the `var()` chain resolver, the colour maths, the token
 * diff itself, and the apply → revert proof that the document is restored
 * byte-for-byte.
 *
 *   node test-appearance.mjs
 */
import assert from 'node:assert/strict';
import { installDom, loadBundle } from './test-helpers.mjs';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// The bundle touches `document` and `window` at import time, so the fake page
// has to exist first. The shared materializer supplies React and react-dom.
const dom = installDom();
const spec = await loadBundle('appearance-pure');
const { materialize } = await import('./test-helpers.mjs');
const bundle = materialize(spec, { activeLocale: 'ja' });
const __ = bundle.instance.__test;
const lookup = __.createLookup(dom.document);

/** The tokens the README documents, in order. This list is the contract. */
const DOCUMENTED_SURFACE_TOKENS = [
  '--dsw-alias-bg-base',
  '--dsw-specific-sidebar-fill',
  '--dsw-alias-bg-layer-1',
  '--dsw-alias-bg-layer-2',
  '--dsw-specific-input-major',
];

// ---------------------------------------------------------------------------
// path / type validation
// ---------------------------------------------------------------------------

test('classifyPath: the three renderable kinds', () => {
  assert.deepEqual(__.classifyPath('C:\\a\\clip.mp4'), { ok: true, reason: 'ok', kind: 'video', extension: 'mp4' });
  assert.deepEqual(__.classifyPath('/home/me/loop.WEBM'), { ok: true, reason: 'ok', kind: 'video', extension: 'webm' });
  assert.deepEqual(__.classifyPath('C:\\a\\anim.gif'), { ok: true, reason: 'ok', kind: 'gif', extension: 'gif' });
  assert.deepEqual(__.classifyPath('C:\\a\\still.PNG'), { ok: true, reason: 'ok', kind: 'image', extension: 'png' });
  assert.equal(__.classifyPath('shot.jpeg').kind, 'image');
  assert.equal(__.classifyPath('shot.webp').kind, 'image');
  assert.equal(__.classifyPath('shot.avif').kind, 'image');
  assert.equal(__.classifyPath('shot.bmp').kind, 'image');
  assert.equal(__.classifyPath('icon.svg').kind, 'image');
});

test('classifyPath: a path with spaces is ordinary', () => {
  const path = 'C:\\Users\\ren 11\\My Videos\\infinite space 01.mp4';
  assert.equal(__.classifyPath(path).ok, true);
  assert.equal(__.classifyPath(path).kind, 'video');
});

test('classifyPath: refusals, each with its own reason', () => {
  assert.equal(__.classifyPath('').reason, 'empty');
  assert.equal(__.classifyPath('   ').reason, 'empty');
  assert.equal(__.classifyPath(null).reason, 'empty');
  assert.equal(__.classifyPath(42).reason, 'empty');
  assert.equal(__.classifyPath('C:\\a\\bad\u0000name.mp4').reason, 'invalid');
  assert.equal(__.classifyPath('C:\\a\\README').reason, 'no-extension');
  assert.equal(__.classifyPath('.mp4').reason, 'no-extension');
  assert.equal(__.classifyPath('C:\\a\\notes.txt').reason, 'unsupported-extension');
  assert.equal(__.classifyPath('C:\\a\\setup.exe').reason, 'unsupported-extension');
  assert.equal(__.classifyPath('C:\\a\\clip.mp4.txt').reason, 'unsupported-extension');
  assert.equal(__.classifyPath('C:\\a\\notes.txt').extension, 'txt');
});

test('classifyPath: a trailing query or fragment is not part of the extension', () => {
  assert.equal(__.classifyPath('clip.mp4?t=1').extension, 'mp4');
  assert.equal(__.classifyPath('clip.mp4#frag').extension, 'mp4');
});

// ---------------------------------------------------------------------------
// settings normalisation
// ---------------------------------------------------------------------------

test('normalizeSettings: the defaults are the requirement defaults', () => {
  const settings = __.normalizeSettings(null);
  assert.equal(settings.enabled, true);
  assert.equal(settings.path, 'C:\\Users\\ren11\\Downloads\\infinite-space-moewalls-com.mp4');
  assert.equal(settings.lastGoodPath, settings.path);
  assert.equal(settings.surface, 0.78);
  assert.equal(settings.dim, 0.3);
  assert.equal(settings.pauseWhenHidden, true);
  assert.equal(settings.reduceMotion, 'still');
  assert.deepEqual(settings.polish, { radius: 'keep', border: 'keep', backdrop: 'keep' });
});

test('normalizeSettings: corrupt input never throws and never leaks through', () => {
  for (const junk of ['nope', 7, [], { path: 123, polish: 'x' }, { polish: [] }, { surface: 'abc' }]) {
    const settings = __.normalizeSettings(junk);
    assert.equal(typeof settings.path, 'string');
    assert.equal(typeof settings.surface, 'number');
    assert.equal(typeof settings.polish.radius, 'string');
  }
});

test('normalizeSettings: numbers clamp and enums fall back', () => {
  const settings = __.normalizeSettings({
    enabled: false,
    surface: 9,
    dim: -4,
    reduceMotion: 'nonsense',
    pauseWhenHidden: 0,
    polish: { radius: 'huge', border: 'faint', backdrop: 'heavy' },
  });
  assert.equal(settings.enabled, false);
  assert.equal(settings.surface, 1);
  assert.equal(settings.dim, 0);
  assert.equal(settings.reduceMotion, 'still');
  assert.equal(settings.pauseWhenHidden, false);
  assert.deepEqual(settings.polish, { radius: 'keep', border: 'faint', backdrop: 'heavy' });
});

test('normalizeSettings: a blank path falls back to the default file', () => {
  assert.equal(__.normalizeSettings({ path: '   ' }).path, __.defaultPath);
  assert.equal(__.normalizeSettings({ path: ' D:\\x.mp4 ' }).path, 'D:\\x.mp4');
});

// ---------------------------------------------------------------------------
// var() chain resolution and colour maths
// ---------------------------------------------------------------------------

test('resolveChain: follows references to a concrete colour', () => {
  const table = { '--a': 'var(--b)', '--b': 'var(--c)', '--c': '#123456' };
  assert.equal(__.resolveChain('--a', (name) => table[name] ?? ''), '#123456');
});

test('resolveChain: uses the fallback when the reference is missing', () => {
  assert.equal(__.resolveChain('--a', () => 'var(--missing, #abcdef)'), '#abcdef');
  assert.equal(__.resolveChain('--a', () => 'var(--missing)'), 'var(--missing)');
});

test('resolveChain: a reference cycle terminates', () => {
  const table = { '--a': 'var(--b)', '--b': 'var(--a)' };
  const value = __.resolveChain('--a', (name) => table[name] ?? '');
  assert.equal(typeof value, 'string');
});

test('parseColor: hex, rgb(), rgba() and transparent', () => {
  assert.deepEqual(__.parseColor('#0f1115'), [15, 17, 21, 1]);
  assert.deepEqual(__.parseColor('#fff'), [255, 255, 255, 1]);
  assert.deepEqual(__.parseColor('#ffffff0f'), [255, 255, 255, 15 / 255]);
  assert.deepEqual(__.parseColor('rgba(1, 2, 3, 0.5)'), [1, 2, 3, 0.5]);
  assert.deepEqual(__.parseColor('rgb(1 2 3 / 40%)'), [1, 2, 3, 0.4]);
  assert.deepEqual(__.parseColor('transparent'), [0, 0, 0, 0]);
  assert.equal(__.parseColor('color-mix(in srgb, red, blue)'), null);
  assert.equal(__.parseColor(''), null);
});

test('withAlpha: opaque colours become rgba, translucent ones keep their alpha', () => {
  assert.equal(__.withAlpha('#0f1115', 0.78), 'rgba(15, 17, 21, 0.78)');
  assert.equal(__.withAlpha('#ffffff0f', 0.5), `rgba(255, 255, 255, ${Number((0.5 * (15 / 255)).toFixed(4))})`);
  assert.equal(__.withAlpha('#fff', 1), 'rgba(255, 255, 255, 1)');
});

test('withAlpha: an unparsable colour degrades to color-mix, not to nothing', () => {
  assert.equal(__.withAlpha('oklch(0.5 0.1 200)', 0.5), 'color-mix(in srgb, oklch(0.5 0.1 200) 50%, transparent)');
});

// ---------------------------------------------------------------------------
// the token diff
// ---------------------------------------------------------------------------

test('entriesFor: the documented token list is exactly what is written', () => {
  const entries = __.entriesFor(__.defaults, lookup);
  assert.deepEqual(entries.map((entry) => entry.token), DOCUMENTED_SURFACE_TOKENS);
  assert.deepEqual(entries.map((entry) => entry.owner), ['body', 'body', 'body', 'body', 'body']);
  assert.deepEqual(
    entries.map((entry) => entry.value),
    [
      'rgba(15, 17, 21, 0.78)',
      'rgba(21, 23, 28, 0.86)',
      'rgba(27, 30, 36, 0.92)',
      'rgba(34, 37, 44, 0.98)',
      'rgba(34, 37, 44, 0.94)',
    ],
  );
});

test('entriesFor: the bottom of the slider is still a usable surface', () => {
  const entries = __.entriesFor({ ...__.defaults, surface: 0.3 }, lookup);
  assert.equal(entries[0].value, 'rgba(15, 17, 21, 0.3)');
  assert.equal(entries[4].value, 'rgba(34, 37, 44, 0.46)');
});

test('entriesFor: the light palette resolves to light colours', () => {
  const light = installDom({ theme: 'light' });
  const lightLookup = __.createLookup(light.document);
  const entries = __.entriesFor(__.defaults, lightLookup);
  assert.equal(entries[0].value, 'rgba(255, 255, 255, 0.78)');
});

test('entriesFor: disabled drops the surfaces but keeps the polish toggles', () => {
  const entries = __.entriesFor({ ...__.defaults, enabled: false, polish: { radius: 'lg', border: 'keep', backdrop: 'keep' } }, lookup);
  assert.deepEqual(entries.map((entry) => entry.token), ['--dsw-radius-lg', '--dsw-radius-xl', '--dsw-radius-panel']);
  assert.deepEqual(entries.map((entry) => entry.owner), ['root', 'root', 'root']);
  assert.deepEqual(entries.map((entry) => entry.value), ['16px', '16px', '16px']);
});

test('entriesFor: the polish defaults add nothing at all', () => {
  const entries = __.entriesFor({ ...__.defaults, enabled: false }, lookup);
  assert.deepEqual(entries, []);
});

test('entriesFor: border and backdrop overrides target the declaring element', () => {
  const entries = __.polishEntries({ radius: 'keep', border: 'soft', backdrop: 'medium' }, lookup);
  assert.deepEqual(entries.map((entry) => entry.token), [
    '--dsw-alias-border-l1',
    '--dsw-alias-border-l2',
    '--dsw-alias-border-l3',
    '--dsw-alias-border-l4',
    '--dsw-menu-backdrop-filter',
  ]);
  assert.equal(entries[0].value, `rgba(255, 255, 255, ${Number((0.55 * (15 / 255)).toFixed(4))})`);
  assert.equal(entries[4].value, 'blur(28px) saturate(150%)');
  assert.ok(entries.every((entry) => entry.owner === 'body'));
});

// ---------------------------------------------------------------------------
// apply / revert — the exact-restore proof
// ---------------------------------------------------------------------------

test('applyOverrides reverts the document element style exactly', () => {
  const element = dom.document.documentElement;
  const before = element.style.cssText;
  const entries = __.polishEntries({ radius: 'xl', border: 'keep', backdrop: 'keep' }, lookup);
  const revert = __.applyOverrides(dom.document, entries);

  assert.equal(element.style.getPropertyValue('--dsw-radius-panel'), '20px');
  assert.equal(element.style.getPropertyPriority('--dsw-radius-panel'), 'important');
  assert.notEqual(element.style.cssText, before);

  revert();
  assert.equal(element.style.cssText, before, 'the root style is byte-for-byte what it was');
  assert.equal(element.style.getPropertyValue('--dsw-radius-panel'), '');
});

test('applyOverrides reverts the body style exactly', () => {
  const body = dom.document.body;
  const before = body.style.cssText;
  const revert = __.applyOverrides(dom.document, __.entriesFor(__.defaults, lookup));
  assert.equal(body.style.getPropertyValue('--dsw-alias-bg-base'), 'rgba(15, 17, 21, 0.78)');
  revert();
  assert.equal(body.style.cssText, before);
});

test('applyOverrides restores an inline value a custom theme had already written', () => {
  const body = dom.document.body;
  const snapshot = body.style.cssText;
  body.style.setProperty('--dsw-alias-bg-base', 'var(--my-theme-canvas)', 'important');
  const themed = body.style.cssText;

  const revert = __.applyOverrides(dom.document, __.entriesFor(__.defaults, lookup));
  assert.equal(body.style.getPropertyValue('--dsw-alias-bg-base'), 'rgba(15, 17, 21, 0.78)');
  revert();

  assert.equal(body.style.cssText, themed, 'the theme value and its priority come back');
  assert.equal(body.style.getPropertyValue('--dsw-alias-bg-base'), 'var(--my-theme-canvas)');
  body.style.removeProperty('--dsw-alias-bg-base');
  assert.equal(body.style.cssText, snapshot);
});

test('apply → revert → apply does not compound the alpha', () => {
  const body = dom.document.body;
  const seen = [];
  for (let pass = 0; pass < 3; pass += 1) {
    const revert = __.applyOverrides(dom.document, __.entriesFor({ ...__.defaults, surface: 0.5 }, __.createLookup(dom.document)));
    seen.push(body.style.getPropertyValue('--dsw-alias-bg-base'));
    revert();
  }
  assert.deepEqual(seen, ['rgba(15, 17, 21, 0.5)', 'rgba(15, 17, 21, 0.5)', 'rgba(15, 17, 21, 0.5)']);
  assert.equal(body.style.cssText, '', 'nothing is left behind between passes');
});

test('applyOverrides is idempotent and survives a target without the property API', () => {
  const revert = __.applyOverrides(dom.document, __.entriesFor(__.defaults, lookup));
  revert();
  revert();
  assert.equal(dom.document.body.style.cssText, '');
  assert.doesNotThrow(() => __.applyOverrides({ documentElement: {}, body: {} }, __.entriesFor(__.defaults, lookup)));
  assert.doesNotThrow(() => __.applyOverrides({}, __.entriesFor(__.defaults, lookup)));
});

// ---------------------------------------------------------------------------
// media URL building
// ---------------------------------------------------------------------------

test('encodeFilePath: drive letter kept, spaces and separators encoded', () => {
  assert.equal(__.encodeFilePath('C:\\Users\\ren 11\\clip one.mp4'), 'C:/Users/ren%2011/clip%20one.mp4');
  assert.equal(__.encodeFilePath('C:\\a\\b#c?d.mp4'), 'C:/a/b%23c%3Fd.mp4');
  assert.equal(__.encodeFilePath('C:\\a\\日本語.mp4'), `C:/a/${encodeURIComponent('日本語')}.mp4`);
  assert.equal(__.encodeFilePath('C:\\a\\b.mp4'), 'C:/a/b.mp4');
});

test('buildMediaUrl: on a file:// page it is a plain file URL', () => {
  assert.equal(__.buildMediaUrl('C:\\Users\\ren 11\\clip one.mp4', undefined), 'file:///C:/Users/ren%2011/clip%20one.mp4');
});

test('buildMediaUrl: on a served page it is the Host route, token included', () => {
  const url = __.buildMediaUrl('C:\\Users\\ren 11\\clip one.mp4', { path: '/local/dsh-appearance', token: 'abc123' });
  assert.match(url, /^\/local\/dsh-appearance\/media\?/);
  assert.ok(url.includes('path=C%3A%5CUsers%5Cren%2011%5Cclip%20one.mp4'), url);
  assert.ok(url.includes('kind=video'));
  assert.ok(url.includes('token=abc123'));
});

test('buildMediaUrl: an unsupported path yields no URL at all', () => {
  assert.equal(__.buildMediaUrl('C:\\a\\notes.txt', { path: '/x', token: 't' }), '');
  assert.equal(__.buildMediaUrl('', { path: '/x', token: 't' }), '');
});

// ---------------------------------------------------------------------------
// probe verdicts
// ---------------------------------------------------------------------------

test('judgePath: refuses an unsupported extension before any probe', () => {
  assert.deepEqual(__.judgePath('C:\\a\\x.txt', { ok: true, exists: true }).accept, false);
  assert.equal(__.judgePath('C:\\a\\x.txt', null).reason, 'unsupported-extension');
});

test('judgePath: a missing file is refused and keeps the caller on the old path', () => {
  assert.equal(__.judgePath('C:\\a\\x.mp4', { ok: false, exists: false, reason: 'missing' }).accept, false);
  assert.equal(__.judgePath('C:\\a\\x.mp4', { ok: false, exists: false, reason: 'missing' }).reason, 'missing');
  assert.equal(__.judgePath('C:\\a\\x.mp4', { ok: true, exists: true, isFile: false }).reason, 'not-file');
});

test('judgePath: accepts an existing file and a path we cannot verify', () => {
  const accepted = __.judgePath('C:\\a\\x.mp4', { ok: true, exists: true, isFile: true, size: 86931069 });
  assert.equal(accepted.accept, true);
  assert.equal(accepted.size, 86931069);
  assert.equal(__.judgePath('C:\\a\\x.mp4', { ok: true, unverified: true }).accept, true);
  assert.equal(__.judgePath('C:\\a\\x.mp4', null).accept, true);
});

// ---------------------------------------------------------------------------
// the store
// ---------------------------------------------------------------------------

function memoryStorage(initial) {
  const map = new Map(initial ? Object.entries(initial) : []);
  return {
    getItem: (key) => (map.has(key) ? map.get(key) : null),
    setItem: (key, value) => map.set(key, value),
    map,
  };
}

test('store: defaults when storage is missing entirely', () => {
  const store = __.createAppearanceStore(undefined);
  assert.equal(store.get().path, __.defaultPath);
  assert.doesNotThrow(() => store.update({ surface: 0.4 }));
  assert.equal(store.get().surface, 0.4);
});

test('store: a storage whose every call throws is survivable', () => {
  const hostile = {
    getItem() {
      throw new Error('blocked');
    },
    setItem() {
      throw new Error('quota');
    },
  };
  const store = __.createAppearanceStore(hostile);
  assert.equal(store.get().surface, 0.78);
  assert.doesNotThrow(() => store.update({ surface: 0.5 }));
  assert.equal(store.get().surface, 0.5);
});

test('store: a corrupt blob falls back to the defaults', () => {
  const store = __.createAppearanceStore(memoryStorage({ 'dsh-appearance:settings:v1': '{not json' }));
  assert.equal(store.get().enabled, true);
  assert.equal(store.get().path, __.defaultPath);
});

test('store: a valid blob is loaded, persisted and clamped', () => {
  const storage = memoryStorage();
  const store = __.createAppearanceStore(storage);
  store.update({ path: 'D:\\wall\\loop.mp4', surface: 0.44, polish: { radius: 'lg' } });
  assert.equal(store.get().polish.radius, 'lg');
  const reloaded = __.createAppearanceStore(storage);
  assert.equal(reloaded.get().path, 'D:\\wall\\loop.mp4');
  assert.equal(reloaded.get().surface, 0.44);
  assert.equal(reloaded.get().polish.radius, 'lg');
  assert.deepEqual(reloaded.get().polish.border, 'keep', 'a partial polish patch keeps the other choices');
});

test('store: the snapshot reference only changes when something changed', () => {
  const store = __.createAppearanceStore(memoryStorage());
  const first = store.snapshot();
  assert.equal(store.snapshot(), first);
  let notified = 0;
  const unsubscribe = store.subscribe(() => {
    notified += 1;
  });
  store.update({ dim: 0.5 });
  assert.notEqual(store.snapshot(), first);
  assert.equal(notified, 1);
  store.report('ready', store.get().path);
  assert.equal(notified, 2);
  store.report('ready', store.get().path);
  assert.equal(notified, 2, 'a repeated report does not churn subscribers');
  unsubscribe();
  store.update({ dim: 0.6 });
  assert.equal(notified, 2);
});

test('store: replace() takes the defaults back', () => {
  const store = __.createAppearanceStore(memoryStorage());
  store.update({ enabled: false, surface: 0.4, polish: { border: 'faint' } });
  store.replace(null);
  assert.equal(store.get().enabled, true);
  assert.equal(store.get().surface, 0.78);
  assert.equal(store.get().polish.border, 'keep');
});

// ---------------------------------------------------------------------------
// small helpers
// ---------------------------------------------------------------------------

test('baseName and formatSize', () => {
  assert.equal(__.baseName('C:\\a b\\clip one.mp4'), 'clip one.mp4');
  assert.equal(__.baseName('/home/me/clip.mp4'), 'clip.mp4');
  assert.equal(__.formatSize(86931069), '83 MB');
  assert.equal(__.formatSize(0), '—');
  assert.equal(__.formatSize(undefined), '—');
});

test('prefersReducedMotion reads matchMedia and never throws without it', () => {
  assert.equal(__.prefersReducedMotion({ matchMedia: () => ({ matches: true }) }), true);
  assert.equal(__.prefersReducedMotion({ matchMedia: () => ({ matches: false }) }), false);
  assert.equal(__.prefersReducedMotion(undefined), false);
  assert.equal(__.prefersReducedMotion({ matchMedia: () => { throw new Error('nope'); } }), false);
});

test('releaseMedia clears the source and releases the decoder', () => {
  const element = dom.document.createElement('video');
  element.setAttribute('src', 'http://127.0.0.1/x');
  __.releaseMedia(element);
  assert.equal(element.getAttribute('src'), null);
  assert.equal(element.calls.pause, 1);
  assert.equal(element.calls.load, 1);
  assert.doesNotThrow(() => __.releaseMedia(null));
  assert.doesNotThrow(() => __.releaseMedia({}));
});

test('clamp keeps a NaN from reaching a token value', () => {
  assert.equal(__.clamp(Number.NaN, 0.3, 1, 0.78), 0.78);
  assert.equal(__.clamp('0.9', 0.3, 1, 0.78), 0.9);
  assert.equal(__.clamp(5, 0.3, 1, 0.78), 1);
});

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

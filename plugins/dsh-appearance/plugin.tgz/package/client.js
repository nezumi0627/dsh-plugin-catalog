/**
 * Client half of `@local/dsh-appearance` — the live wallpaper and the reversible
 * design-polish toggles.
 *
 * ## Why the background itself is portalled to `document.body`
 * `shell.overlay` is `.BynINW_overlayLayer{z-index:20;pointer-events:none}` with
 * `>*{pointer-events:auto}` — it is *above* the content columns, so a wallpaper
 * placed there would paint over the conversation. The wallpaper therefore
 * portals straight into `document.body` as
 * `position:fixed; inset:0; z-index:0; pointer-events:none`, and the app's own
 * surfaces are made translucent so it shows through.
 *
 * Painting order matters: `.BynINW_frame` is `position:relative; z-index:auto`,
 * and a `z-index:0` positioned element is painted in the same step of the root
 * stacking context (CSS 2.1 appendix E, step 8), ordered by tree order. The
 * layer is therefore moved to be `document.body`'s *first* child, so `#root`
 * (and the frame inside it) paints after — and above — the wallpaper. Appending
 * the portal last, which is what React does by default, would cover the UI.
 *
 * ## Why the token overrides are inline on `<body>`
 * `dsh-client-ui-theme` declares `--dsw-alias-*` on **`body`** (`lib/client.js:1148`),
 * not on `:root`, so a rule or inline value on `documentElement` would lose the
 * cascade for `body` and every descendant. The theme's own token applier
 * (`dsh-client-ui-layout/lib/client.js:539-545`) writes its custom palette the
 * same way, which is also why these writes carry `!important`: a custom theme's
 * inline palette must not be able to silently swallow the wallpaper override.
 * `documentElement` carries only `:root`-declared properties (`--dsw-radius-*`,
 * declared at `lib/client.js:1142`).
 *
 * ## Cost
 * One element, one decoder. No `resize` listener (the element is never recreated,
 * `object-fit:cover` does the work), no re-render per frame, no timers. The
 * `<video>` is paused while `document.visibilityState === "hidden"`, its `src` is
 * cleared on dispose, and `prefers-reduced-motion: reduce` renders a still frame
 * instead of a moving one.
 */

window.__ModuleLoader__.load({
  id: '@local/dsh-appearance',
  factory(require) {
    const React = require('react');
    const ReactDOM = require('react-dom');
    const h = React.createElement;
    const { useCallback, useEffect, useMemo, useRef, useState } = React;

    const ID = '@local/dsh-appearance';
    /** Locale namespace owning the settings-row copy. */
    const NS = 'dshAppearance';
    /** `window.localStorage` key holding the persisted preferences. */
    const STORAGE_KEY = 'dsh-appearance:settings:v1';
    /** Page global the Host half injects: route base, probe/media paths, token. */
    const BOOTSTRAP_KEY = '__DSH_APPEARANCE__';
    /** Requirement §12's default: the file this bundle ships pre-selected. */
    const DEFAULT_PATH = 'C:\\Users\\ren11\\Downloads\\infinite-space-moewalls-com.mp4';

    // ---------------------------------------------------------------------
    // Dictionaries. The object form of `ctx.locale.register` requires both
    // shipped locales (en, zh); Japanese is registered per-locale so this
    // bundle works with dsh-locale-ja and without it.
    // ---------------------------------------------------------------------
    const zh = {
      'wallpaper.title': '壁纸与外观',
      'wallpaper.description': '在应用背景中循环播放图片 / GIF / MP4。关闭后原样恢复原来的背景。',
      'wallpaper.on': '开',
      'wallpaper.off': '关',
      'wallpaper.details': '详细设置',
      'wallpaper.close': '收起',
      'wallpaper.reset': '恢复默认',
      'path.label': '文件路径',
      'path.hint': '支持：图片（png / jpg / webp / avif / bmp / svg）、GIF、视频（mp4 / webm / m4v / ogv）',
      'path.apply': '应用',
      'path.checking': '检查中…',
      'surface.label': '壁纸的可见度（面板不透明度）',
      'dim.label': '壁纸的暗度',
      'radius.label': '圆角',
      'border.label': '边框',
      'backdrop.label': '面板背景模糊',
      'pauseHidden.label': '窗口隐藏时停止播放',
      'reduceMotion.label': '减少动效时',
      'keep': '保持原样',
      'motion.still': '显示静止画面',
      'motion.off': '不显示壁纸',
      'light': '弱',
      'medium': '中',
      'heavy': '强',
      'soft': '较弱',
      'faint': '极淡',
      'status.off': '已关闭 — 使用原来的背景',
      'status.loading': '正在载入…',
      'status.ready': '正在显示：{name}',
      'notice.title': '无法载入壁纸',
      'notice.hint': '请在 设置 → 通用 → 壁纸与外观 中检查文件路径。原来的背景已保留。',
      'reason.empty': '路径为空。',
      'reason.invalid': '路径包含无效字符。',
      'reason.no-extension': '路径没有扩展名。',
      'reason.unsupported-extension': '不支持的文件格式。',
      'reason.missing': '找不到文件。',
      'reason.unreachable': '无法访问本地媒体接口。',
      'reason.not-file': '指定的路径不是文件。',
      'reason.decode': '文件无法播放。',
    };
    const en = {
      'wallpaper.title': 'Wallpaper & appearance',
      'wallpaper.description': 'Loops an image / GIF / MP4 behind the app. Turning it off restores the original background exactly.',
      'wallpaper.on': 'On',
      'wallpaper.off': 'Off',
      'wallpaper.details': 'Details',
      'wallpaper.close': 'Hide',
      'wallpaper.reset': 'Reset to defaults',
      'path.label': 'File path',
      'path.hint': 'Supported: images (png / jpg / webp / avif / bmp / svg), GIF, video (mp4 / webm / m4v / ogv)',
      'path.apply': 'Apply',
      'path.checking': 'Checking…',
      'surface.label': 'Wallpaper visibility (surface opacity)',
      'dim.label': 'Wallpaper dimming',
      'radius.label': 'Corner radius',
      'border.label': 'Borders',
      'backdrop.label': 'Panel backdrop blur',
      'pauseHidden.label': 'Pause while the window is hidden',
      'reduceMotion.label': 'When reduced motion is requested',
      'keep': 'Leave unchanged',
      'motion.still': 'Show a still frame',
      'motion.off': 'No wallpaper',
      'light': 'Light',
      'medium': 'Medium',
      'heavy': 'Heavy',
      'soft': 'Softer',
      'faint': 'Faintest',
      'status.off': 'Off — the original background is in use',
      'status.loading': 'Loading…',
      'status.ready': 'Showing {name}',
      'notice.title': 'The wallpaper could not be loaded',
      'notice.hint': 'Check the path in Settings → General → Wallpaper & appearance. The previous background was kept.',
      'reason.empty': 'The path is empty.',
      'reason.invalid': 'The path contains an invalid character.',
      'reason.no-extension': 'The path has no file extension.',
      'reason.unsupported-extension': 'Unsupported file type.',
      'reason.missing': 'The file was not found.',
      'reason.unreachable': 'The local media route is unreachable.',
      'reason.not-file': 'That path is not a file.',
      'reason.decode': 'The file cannot be played.',
    };
    const ja = {
      'wallpaper.title': '壁紙と外観',
      'wallpaper.description': 'アプリの背景で画像 / GIF / MP4 をループ再生します。オフにすると元の背景へ完全に戻ります。',
      'wallpaper.on': 'オン',
      'wallpaper.off': 'オフ',
      'wallpaper.details': '詳細設定',
      'wallpaper.close': '閉じる',
      'wallpaper.reset': '初期値に戻す',
      'path.label': 'ファイルのパス',
      'path.hint': '対応形式: 画像（png / jpg / webp / avif / bmp / svg）、GIF、動画（mp4 / webm / m4v / ogv）',
      'path.apply': '適用',
      'path.checking': '確認中…',
      'surface.label': '壁紙の見え方（サーフェスの不透明度）',
      'dim.label': '壁紙の暗さ',
      'radius.label': '角丸',
      'border.label': '境界線',
      'backdrop.label': 'パネル背景のぼかし',
      'pauseHidden.label': 'ウィンドウが非表示のとき停止する',
      'reduceMotion.label': '視差効果を減らす設定のとき',
      'keep': 'そのまま',
      'motion.still': '静止画を表示',
      'motion.off': '壁紙を表示しない',
      'light': '弱',
      'medium': '中',
      'heavy': '強',
      'soft': '控えめ',
      'faint': 'ごく薄く',
      'status.off': 'オフ — 元の背景を使用中',
      'status.loading': '読み込み中…',
      'status.ready': '{name} を表示中',
      'notice.title': '壁紙を読み込めません',
      'notice.hint': '設定 → 一般 → 壁紙と外観 でパスを確認してください。元の背景はそのまま残しています。',
      'reason.empty': 'パスが空です。',
      'reason.invalid': 'パスに使用できない文字が含まれています。',
      'reason.no-extension': '拡張子がありません。',
      'reason.unsupported-extension': '対応していない形式です。',
      'reason.missing': 'ファイルが見つかりません。',
      'reason.unreachable': 'ローカル配信ルートに到達できません。',
      'reason.not-file': '指定されたパスはファイルではありません。',
      'reason.decode': 'ファイルを再生できません。',
    };

    // ---------------------------------------------------------------------
    // Recognised media. Kept in one place so the Host half's whitelist and this
    // one can be compared by eye (index.js re-declares it: the two halves share
    // no module system).
    // ---------------------------------------------------------------------
    const VIDEO_EXTENSIONS = new Set(['mp4', 'webm', 'm4v', 'ogv', 'ogg']);
    const GIF_EXTENSIONS = new Set(['gif']);
    const IMAGE_EXTENSIONS = new Set(['png', 'jpg', 'jpeg', 'webp', 'avif', 'bmp', 'apng', 'svg']);

    /**
     * The complete override list. Every entry names the element that *declares*
     * the token, because a custom property only cascades from the element whose
     * declaration would otherwise win.
     */
    const SURFACE_TOKENS = Object.freeze([
      Object.freeze({ owner: 'body', token: '--dsw-alias-bg-base', lift: 0 }),
      Object.freeze({ owner: 'body', token: '--dsw-specific-sidebar-fill', lift: 0.08 }),
      Object.freeze({ owner: 'body', token: '--dsw-alias-bg-layer-1', lift: 0.14 }),
      Object.freeze({ owner: 'body', token: '--dsw-alias-bg-layer-2', lift: 0.2 }),
      Object.freeze({ owner: 'body', token: '--dsw-specific-input-major', lift: 0.16 }),
    ]);
    const RADIUS_TOKENS = Object.freeze(['--dsw-radius-lg', '--dsw-radius-xl', '--dsw-radius-panel']);
    const BORDER_TOKENS = Object.freeze([
      '--dsw-alias-border-l1',
      '--dsw-alias-border-l2',
      '--dsw-alias-border-l3',
      '--dsw-alias-border-l4',
    ]);

    /** Choice tables. `keep` is the only value that emits no override at all. */
    const RADIUS_CHOICES = Object.freeze({ keep: null, sm: '8px', md: '12px', lg: '16px', xl: '20px' });
    const BORDER_CHOICES = Object.freeze({ keep: null, soft: 0.55, faint: 0.3 });
    const BACKDROP_CHOICES = Object.freeze({
      keep: null,
      light: 'blur(18px) saturate(140%)',
      medium: 'blur(28px) saturate(150%)',
      heavy: 'blur(48px) saturate(160%)',
    });

    /** Current appearance. Every polish value defaults to "no override". */
    const DEFAULTS = Object.freeze({
      version: 1,
      enabled: true,
      path: DEFAULT_PATH,
      lastGoodPath: DEFAULT_PATH,
      surface: 0.78,
      dim: 0.3,
      pauseWhenHidden: true,
      reduceMotion: 'still',
      polish: Object.freeze({ radius: 'keep', border: 'keep', backdrop: 'keep' }),
    });

    const hasOwn = (object, key) => Object.prototype.hasOwnProperty.call(object, key);

    // ---------------------------------------------------------------------
    // Pure helpers — everything below up to `createAppearanceStore` is
    // side-effect free and is exercised directly by `test-appearance.mjs`.
    // ---------------------------------------------------------------------

    /** Lower-cased extension without the dot; `''` for a dotfile or no suffix. */
    function extensionOf(path) {
      if (typeof path !== 'string') return '';
      const clean = path.trim().replace(/[?#].*$/, '');
      const slash = Math.max(clean.lastIndexOf('/'), clean.lastIndexOf('\\'));
      const tail = clean.slice(slash + 1);
      const dot = tail.lastIndexOf('.');
      if (dot <= 0) return '';
      return tail.slice(dot + 1).toLowerCase();
    }

    /**
     * Decide whether a path is something this plugin can render.
     * @returns `{ ok, reason, kind, extension }` — never throws.
     */
    function classifyPath(path) {
      const raw = typeof path === 'string' ? path.trim() : '';
      if (raw === '') return { ok: false, reason: 'empty', kind: 'none', extension: '' };
      if (raw.includes('\u0000')) return { ok: false, reason: 'invalid', kind: 'none', extension: '' };
      const extension = extensionOf(raw);
      if (extension === '') return { ok: false, reason: 'no-extension', kind: 'none', extension: '' };
      if (VIDEO_EXTENSIONS.has(extension)) return { ok: true, reason: 'ok', kind: 'video', extension };
      if (GIF_EXTENSIONS.has(extension)) return { ok: true, reason: 'ok', kind: 'gif', extension };
      if (IMAGE_EXTENSIONS.has(extension)) return { ok: true, reason: 'ok', kind: 'image', extension };
      return { ok: false, reason: 'unsupported-extension', kind: 'none', extension };
    }

    /** `Number` clamp with a fallback for `NaN`/`undefined` input. */
    function clamp(value, min, max, fallback) {
      const number = typeof value === 'number' ? value : Number(value);
      if (!Number.isFinite(number)) return fallback;
      return Math.min(max, Math.max(min, number));
    }

    /**
     * Coerce anything (a corrupt JSON blob, an old revision, `undefined`) into a
     * complete, in-range settings object. Unknown keys are dropped, never thrown.
     */
    function normalizeSettings(raw) {
      const source = raw && typeof raw === 'object' && !Array.isArray(raw) ? raw : {};
      const polish = source.polish && typeof source.polish === 'object' && !Array.isArray(source.polish) ? source.polish : {};
      const text = (value, fallback) => (typeof value === 'string' && value.trim() !== '' ? value.trim() : fallback);
      const path = text(source.path, DEFAULT_PATH);
      const pick = (table, value, fallback) => (typeof value === 'string' && hasOwn(table, value) ? value : fallback);
      return {
        version: 1,
        enabled: source.enabled !== false,
        path,
        lastGoodPath: text(source.lastGoodPath, path),
        surface: clamp(source.surface, 0.3, 1, DEFAULTS.surface),
        dim: clamp(source.dim, 0, 0.8, DEFAULTS.dim),
        pauseWhenHidden: source.pauseWhenHidden !== false && source.pauseWhenHidden !== 0,
        reduceMotion: source.reduceMotion === 'off' ? 'off' : 'still',
        polish: {
          radius: pick(RADIUS_CHOICES, polish.radius, 'keep'),
          border: pick(BORDER_CHOICES, polish.border, 'keep'),
          backdrop: pick(BACKDROP_CHOICES, polish.backdrop, 'keep'),
        },
      };
    }

    /**
     * Follow `var()` references until a concrete value remains. Reading the
     * computed value of a custom property may already have substituted the
     * chain, in which case one pass is enough; the loop covers both.
     */
    function resolveChain(name, lookup, depth = 12) {
      const seen = new Set();
      let value = String(lookup(name) ?? '').trim();
      for (let step = 0; step < depth && value !== '' && value.includes('var('); step += 1) {
        let changed = false;
        value = value.replace(
          /var\(\s*(--[A-Za-z0-9_-]+)\s*(?:,\s*([^()]*(?:\([^()]*\)[^()]*)*))?\)/g,
          (whole, reference, fallback) => {
            if (seen.has(reference)) return whole;
            seen.add(reference);
            const resolved = String(lookup(reference) ?? '').trim();
            if (resolved !== '' && !resolved.includes(`var(${reference}`)) {
              changed = true;
              return resolved;
            }
            return fallback === undefined ? whole : String(fallback).trim();
          },
        );
        if (!changed) break;
      }
      return value;
    }

    /** `[r, g, b, a]` for a plain CSS colour, or `null` for anything else. */
    function parseColor(input) {
      const value = String(input ?? '').trim().toLowerCase();
      if (value === '') return null;
      if (value === 'transparent') return [0, 0, 0, 0];
      const hex = /^#([0-9a-f]{3,8})$/.exec(value);
      if (hex) {
        const digits = hex[1];
        const pair = (text) => Number.parseInt(text, 16);
        if (digits.length === 3 || digits.length === 4) {
          return [
            pair(digits[0] + digits[0]),
            pair(digits[1] + digits[1]),
            pair(digits[2] + digits[2]),
            digits.length === 4 ? pair(digits[3] + digits[3]) / 255 : 1,
          ];
        }
        if (digits.length === 6 || digits.length === 8) {
          return [
            pair(digits.slice(0, 2)),
            pair(digits.slice(2, 4)),
            pair(digits.slice(4, 6)),
            digits.length === 8 ? pair(digits.slice(6, 8)) / 255 : 1,
          ];
        }
        return null;
      }
      const rgb = /^rgba?\(([^)]+)\)$/.exec(value);
      if (rgb) {
        const parts = rgb[1].split(/[\s,/]+/).filter((part) => part !== '');
        if (parts.length < 3) return null;
        const channel = (part) => {
          const number = part.endsWith('%') ? (Number.parseFloat(part) / 100) * 255 : Number.parseFloat(part);
          return Number.isFinite(number) ? Math.round(number) : null;
        };
        const red = channel(parts[0]);
        const green = channel(parts[1]);
        const blue = channel(parts[2]);
        if (red === null || green === null || blue === null) return null;
        let alpha = 1;
        if (parts[3] !== undefined) {
          const raw = parts[3].endsWith('%') ? Number.parseFloat(parts[3]) / 100 : Number.parseFloat(parts[3]);
          alpha = Number.isFinite(raw) ? raw : 1;
        }
        return [red, green, blue, alpha];
      }
      return null;
    }

    /**
     * The colour scaled by `factor`, keeping its own alpha: opaque surfaces get
     * `rgba(r,g,b,factor)`, and a translucent hairline such as `#ffffff0f` keeps
     * its 6% alpha *times* the factor. Anything unparsable degrades to a
     * `color-mix`, which every Chromium this app ships on supports.
     */
    function withAlpha(color, factor) {
      const amount = clamp(factor, 0, 1, 1);
      const parsed = parseColor(color);
      if (!parsed) return `color-mix(in srgb, ${color} ${Math.round(amount * 100)}%, transparent)`;
      const [red, green, blue, base] = parsed;
      const alpha = Number((amount * base).toFixed(4));
      return `rgba(${red}, ${green}, ${blue}, ${alpha})`;
    }

    /** The five surface overrides for one `surface` alpha. */
    function surfaceEntries(settings, lookup) {
      const alpha = clamp(settings.surface, 0.3, 1, DEFAULTS.surface);
      return SURFACE_TOKENS.map(({ owner, token, lift }) => ({
        owner,
        token,
        role: 'surface',
        value: withAlpha(resolveChain(token, lookup), Math.min(1, alpha + lift)),
      }));
    }

    /** The polish overrides; empty when every choice is `keep`. */
    function polishEntries(polish, lookup) {
      const entries = [];
      if (polish.radius !== 'keep') {
        for (const token of RADIUS_TOKENS) entries.push({ owner: 'root', token, role: 'radius', value: RADIUS_CHOICES[polish.radius] });
      }
      if (polish.border !== 'keep') {
        for (const token of BORDER_TOKENS) {
          entries.push({
            owner: 'body',
            token,
            role: 'border',
            value: withAlpha(resolveChain(token, lookup), BORDER_CHOICES[polish.border]),
          });
        }
      }
      if (polish.backdrop !== 'keep') {
        entries.push({ owner: 'body', token: '--dsw-menu-backdrop-filter', role: 'backdrop', value: BACKDROP_CHOICES[polish.backdrop] });
      }
      return entries;
    }

    /**
     * Every override this plugin would write for a snapshot. `enabled` gates the
     * surface set only: the polish toggles are independent of the wallpaper.
     */
    function entriesFor(settings, lookup) {
      const normalized = normalizeSettings(settings);
      const entries = normalized.enabled ? surfaceEntries(normalized, lookup) : [];
      return entries.concat(polishEntries(normalized.polish, lookup));
    }

    /**
     * Write overrides as inline custom properties on the element that declares
     * them, remembering whatever inline value was there before.
     * @returns an idempotent revert that restores the document *exactly*: a
     * token that had no inline value is removed, and one that had a value (a
     * custom theme's palette, for instance) gets that value and priority back.
     */
    function applyOverrides(doc, entries) {
      const applied = [];
      for (const entry of entries) {
        const element = entry.owner === 'root' ? doc.documentElement : doc.body;
        if (!element || !element.style || typeof element.style.setProperty !== 'function') continue;
        const previous = element.style.getPropertyValue(entry.token) || '';
        const priority = typeof element.style.getPropertyPriority === 'function' ? element.style.getPropertyPriority(entry.token) || '' : '';
        element.style.setProperty(entry.token, entry.value, 'important');
        applied.push({ element, token: entry.token, previous, priority });
      }
      let done = false;
      return function revert() {
        if (done) return;
        done = true;
        for (let index = applied.length - 1; index >= 0; index -= 1) {
          const { element, token, previous, priority } = applied[index];
          if (previous !== '') element.style.setProperty(token, previous, priority);
          else element.style.removeProperty(token);
        }
        applied.length = 0;
      };
    }

    /**
     * A cached reader for computed custom properties. `getComputedStyle` is the
     * expensive call here, so each name is read at most once per pass; the cache
     * must not outlive a pass, because a pass's own writes change the answers.
     */
    function createLookup(doc) {
      const cache = new Map();
      return function lookup(name) {
        if (cache.has(name)) return cache.get(name);
        let value = '';
        try {
          if (typeof getComputedStyle === 'function' && doc && doc.body) {
            value = String(getComputedStyle(doc.body).getPropertyValue(name) || '').trim();
            if (value === '' && doc.documentElement) {
              value = String(getComputedStyle(doc.documentElement).getPropertyValue(name) || '').trim();
            }
          }
        } catch {
          value = '';
        }
        cache.set(name, value);
        return value;
      };
    }

    /** A Windows/posix path as a `file:///` URL: drive letter kept, the rest %-encoded. */
    function encodeFilePath(raw) {
      const slashed = String(raw ?? '').replace(/\\/g, '/').replace(/^\/+/, '');
      return slashed
        .split('/')
        .map((segment, index) => (index === 0 && /^[A-Za-z]:$/.test(segment) ? segment : encodeURIComponent(segment)))
        .join('/');
    }

    /** The Host-injected bootstrap, when this page was served by DSH's web server. */
    function readBootstrap() {
      if (typeof window === 'undefined') return undefined;
      const boot = window[BOOTSTRAP_KEY];
      if (!boot || typeof boot !== 'object' || typeof boot.path !== 'string' || boot.path === '') return undefined;
      return boot;
    }

    /**
     * The URL the `<video>`/`<img>` should load. Over HTTP a `file://`
     * subresource is blocked by Chromium, so the Host route is the only way to
     * reach the user's disk. A plain file URL is valid only when the document
     * itself is file-backed; DSH's `dsh-app:` shell must never receive one.
     */
    function buildMediaUrl(path, boot = readBootstrap()) {
      const info = classifyPath(path);
      if (!info.ok) return '';
      if (boot) {
        const query = `path=${encodeURIComponent(path)}&kind=${info.kind}`;
        return `${boot.path}/media?${query}&token=${encodeURIComponent(boot.token ?? '')}`;
      }
      if (typeof window !== 'undefined' && window.location?.protocol !== 'file:') return '';
      return `file:///${encodeFilePath(path)}`;
    }

    /**
     * Turn a probe answer into accept/refuse. Kept separate from the fetch so the
     * decision is testable and so a refusal can never reach the store.
     */
    function judgePath(path, probe) {
      const info = classifyPath(path);
      if (!info.ok) return { accept: false, reason: info.reason, info };
      if (probe && probe.ok === false) return { accept: false, reason: probe.reason || 'missing', info };
      if (probe && probe.exists === false) return { accept: false, reason: probe.reason || 'missing', info };
      if (probe && probe.isFile === false) return { accept: false, reason: 'not-file', info };
      return { accept: true, info, size: typeof probe?.size === 'number' ? probe.size : undefined };
    }

    /** Ask the Host half whether a path exists and how big it is. Never throws. */
    async function probePath(path, boot = readBootstrap()) {
      if (!boot || typeof fetch !== 'function') return { ok: true, unverified: true };
      try {
        const response = await fetch(`${boot.path}/probe?path=${encodeURIComponent(path)}`, {
          cache: 'no-store',
          headers: boot.header ? { [boot.header]: boot.token ?? '' } : {},
        });
        const payload = await response.json();
        if (!payload || typeof payload !== 'object') return { ok: false, reason: 'unreachable' };
        return payload;
      } catch {
        return { ok: false, reason: 'unreachable' };
      }
    }

    /** File name for display, tolerating both separators. */
    function baseName(path) {
      const parts = String(path ?? '').split(/[/\\]/);
      return parts[parts.length - 1] || String(path ?? '');
    }

    /** `1.2 GB` / `843 MB` — display only. */
    function formatSize(bytes) {
      if (!Number.isFinite(bytes) || bytes <= 0) return '—';
      const units = ['B', 'KB', 'MB', 'GB', 'TB'];
      let value = bytes;
      let unit = 0;
      while (value >= 1024 && unit < units.length - 1) {
        value /= 1024;
        unit += 1;
      }
      return `${value >= 10 || unit === 0 ? Math.round(value) : value.toFixed(1)} ${units[unit]}`;
    }

    /** True when the user asked the OS to reduce motion. */
    function prefersReducedMotion(target = typeof window === 'undefined' ? undefined : window) {
      try {
        if (!target || typeof target.matchMedia !== 'function') return false;
        return target.matchMedia('(prefers-reduced-motion: reduce)').matches === true;
      } catch {
        return false;
      }
    }

    // ---------------------------------------------------------------------
    // Render helpers
    // ---------------------------------------------------------------------

    /**
     * Stop decoding this media element and let go of its source. Called from the
     * capturing effect's cleanup, so the node is passed in rather than read from
     * the ref (React detaches refs before passive cleanups).
     */
    function releaseMedia(element) {
      if (!element) return;
      try {
        element.pause?.();
      } catch {
        /* a detached or already-finished element */
      }
      try {
        element.removeAttribute?.('src');
        element.load?.();
      } catch {
        /* nothing else to release */
      }
    }

    // ---------------------------------------------------------------------
    // Store: one module-level singleton shared by the wallpaper layer, the
    // overlay notice and the settings row, so none of them needs a service.
    // ---------------------------------------------------------------------

    /**
     * @param storage - a `localStorage`-shaped object, or `undefined` when the
     * page has none. Every access is guarded: a corrupt blob, a full quota or a
     * blocked origin must degrade to the defaults, never throw.
     */
    function createAppearanceStore(storage) {
      let state = load();
      let runtime = { status: 'idle', path: state.path, reason: '' };
      let cache = null;
      const listeners = new Set();

      function load() {
        try {
          const raw = storage && typeof storage.getItem === 'function' ? storage.getItem(STORAGE_KEY) : null;
          if (typeof raw !== 'string' || raw === '') return normalizeSettings(null);
          return normalizeSettings(JSON.parse(raw));
        } catch {
          return normalizeSettings(null);
        }
      }

      function persist() {
        try {
          storage?.setItem?.(STORAGE_KEY, JSON.stringify(state));
        } catch {
          /* a private-mode or full-quota storage only costs persistence */
        }
      }

      function emit() {
        cache = null;
        for (const listener of [...listeners]) {
          try {
            listener();
          } catch {
            /* one bad subscriber must not stop the others */
          }
        }
      }

      return {
        get: () => state,
        runtime: () => runtime,
        /** A stable snapshot object, so `useState` sees a new reference only on change. */
        snapshot() {
          if (cache === null) cache = { settings: state, runtime };
          return cache;
        },
        /** Merge a patch; `polish` merges one level deep. */
        update(patch) {
          const next = { ...state, ...(patch ?? {}) };
          if (patch && typeof patch.polish === 'object' && patch.polish !== null) next.polish = { ...state.polish, ...patch.polish };
          state = normalizeSettings(next);
          persist();
          emit();
        },
        replace(next) {
          state = normalizeSettings(next);
          persist();
          emit();
        },
        /** Report what the media element is doing; not persisted. */
        report(status, path, reason = '') {
          if (runtime.status === status && runtime.path === path && runtime.reason === reason) return;
          runtime = { status, path, reason };
          emit();
        },
        subscribe(listener) {
          listeners.add(listener);
          return () => listeners.delete(listener);
        },
      };
    }

    const defaultStorage = (() => {
      try {
        return typeof window === 'undefined' ? undefined : window.localStorage;
      } catch {
        return undefined;
      }
    })();
    const store = createAppearanceStore(defaultStorage);

    /**
     * Exactly one revert is live at a time. Kept at module scope so the plugin's
     * own disposer can undo the overrides even if a React unmount never ran.
     */
    let activeRevert = null;
    function releaseOverrides() {
      const revert = activeRevert;
      activeRevert = null;
      try {
        revert?.();
      } catch {
        /* already reverted */
      }
    }

    /** Subscribe a component to the singleton. */
    function useAppearance() {
      const [snapshot, setSnapshot] = useState(() => store.snapshot());
      useEffect(() => store.subscribe(() => setSnapshot(store.snapshot())), []);
      return snapshot;
    }

    // ---------------------------------------------------------------------
    // Styles: one `<style data-plugin-css>` element, injected once and removed
    // by the plugin's disposer (the module system also claims untagged tags).
    // ---------------------------------------------------------------------

    const css = `
      .dsha-layer{position:fixed;inset:0;z-index:0;pointer-events:none;overflow:hidden;background:transparent;contain:layout paint style}
      .dsha-media{position:absolute;inset:0;width:100%;height:100%;display:block;object-fit:cover;object-position:center;pointer-events:none;border:0;background:transparent}
      .dsha-dim{position:absolute;inset:0;background:rgb(0 0 0);pointer-events:none;transition:opacity .18s var(--ds-ease-in-out,ease)}
      @media (prefers-reduced-motion:reduce){.dsha-dim{transition:none}}
      .dsha-row{display:flex;flex-direction:column;gap:10px;padding:12px 0;border-bottom:.5px solid var(--dsw-alias-border-l1);box-sizing:border-box;min-width:0}
      .dsha-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px}
      .dsha-text{min-width:0}
      .dsha-title{color:var(--dsw-alias-label-primary);font:var(--dsw-font-s-strong-14,500 14px/22px var(--dsw-font-family,system-ui,sans-serif))}
      .dsha-desc{color:var(--dsw-alias-label-tertiary);font:var(--dsw-font-xxs-12,12px/18px var(--dsw-font-family,system-ui,sans-serif));margin-top:2px;overflow-wrap:anywhere}
      .dsha-controls{display:flex;align-items:center;gap:8px;flex:none}
      .dsha-panel{display:flex;flex-direction:column;gap:12px;box-sizing:border-box;padding:12px;border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-md);background:var(--dsw-alias-bg-layer-1)}
      .dsha-field{display:flex;flex-direction:column;gap:4px;min-width:0}
      .dsha-label{color:var(--dsw-alias-label-secondary);font:var(--dsw-font-xxs-12,12px/18px var(--dsw-font-family,system-ui,sans-serif))}
      .dsha-value{color:var(--dsw-alias-label-tertiary);font:var(--dsw-font-xxxs-11,11px/14px var(--dsw-font-family,system-ui,sans-serif));font-variant-numeric:tabular-nums}
      .dsha-inline{display:flex;align-items:center;gap:8px}
      .dsha-inline>.dsha-input,.dsha-inline>.dsha-select{flex:1 1 auto;min-width:0}
      .dsha-input,.dsha-select{box-sizing:border-box;width:100%;height:30px;padding:0 8px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-bg-base);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px}
      .dsha-input:focus-visible,.dsha-select:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:1px}
      .dsha-range{width:100%;accent-color:var(--dsw-alias-state-business-primary);margin:0}
      .dsha-button{box-sizing:border-box;height:26px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary);font:inherit;font-size:12px;cursor:pointer}
      .dsha-button:hover{background:var(--dsw-alias-interactive-bg-active)}
      .dsha-button:disabled{opacity:.55;cursor:default}
      .dsha-button[data-variant=primary]{background:var(--dsw-alias-state-business-primary);color:var(--dsw-alias-label-primary-foreground);border-color:transparent}
      .dsha-switch{box-sizing:border-box;height:26px;min-width:56px;padding:0 10px;border:.5px solid var(--dsw-alias-border-l3);border-radius:999px;corner-shape:round;background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary);font:inherit;font-size:12px;cursor:pointer}
      .dsha-switch[aria-checked=true]{background:var(--dsw-alias-state-business-primary);border-color:transparent;color:var(--dsw-alias-label-primary-foreground)}
      .dsha-error{color:var(--dsw-alias-state-error-primary);font:var(--dsw-font-xxs-12,12px/18px var(--dsw-font-family,system-ui,sans-serif))}
      .dsha-hint{color:var(--dsw-alias-label-caption);font:var(--dsw-font-xxxs-11,11px/14px var(--dsw-font-family,system-ui,sans-serif))}
      .dsha-foot{display:flex;justify-content:flex-end}
      .dsha-noticeHost{position:absolute;left:0;right:0;top:var(--dsh-frame-overlay-top,24px);display:flex;justify-content:center;padding:0 16px;pointer-events:none;box-sizing:border-box}
      .dsha-notice{pointer-events:auto;box-sizing:border-box;display:flex;align-items:center;gap:10px;max-width:min(560px,100%);padding:8px 10px 8px 12px;--dsw-elevation-stroke-color:var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg);background:var(--dsw-specific-menu);backdrop-filter:var(--dsw-menu-backdrop-filter);-webkit-backdrop-filter:var(--dsw-menu-backdrop-filter);box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-secondary);font:var(--dsw-font-xxs-12,12px/18px var(--dsw-font-family,system-ui,sans-serif))}
      .dsha-noticeBody{min-width:0}
      .dsha-noticeTitle{color:var(--dsw-alias-label-primary);font-weight:500}
      .dsha-noticePath{color:var(--dsw-alias-label-caption);overflow-wrap:anywhere}
    `;

    // The Client module system claims the untagged tags a factory created during
    // materialization and removes them on teardown, so no non-baseline module
    // such as `styles` is requested: only platform seed words may be required.
    const styleElement = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = css;
      document.head.append(element);
      return element;
    })();

    // ---------------------------------------------------------------------
    // The wallpaper itself.
    // ---------------------------------------------------------------------

    /**
     * A single still frame for an animated GIF under `prefers-reduced-motion`.
     * A GIF cannot be paused by CSS, so the first frame is decoded once into a
     * canvas sized to the viewport (not to the image), drawn, and the decoder is
     * released immediately afterwards.
     */
    function GifStill({ src, onReady, onError }) {
      const canvasRef = useRef(null);
      useEffect(() => {
        let cancelled = false;
        let image = null;
        try {
          image = new Image();
        } catch {
          onError();
          return undefined;
        }
        image.decoding = 'async';
        image.onload = () => {
          if (cancelled) return;
          const canvas = canvasRef.current;
          try {
            const naturalWidth = image.naturalWidth || 1;
            const naturalHeight = image.naturalHeight || 1;
            const scale = Math.min(1, 1920 / naturalWidth);
            canvas.width = Math.max(1, Math.round(naturalWidth * scale));
            canvas.height = Math.max(1, Math.round(naturalHeight * scale));
            const context = typeof canvas.getContext === 'function' ? canvas.getContext('2d') : null;
            if (!context) throw new Error('no 2d context');
            context.drawImage(image, 0, 0, canvas.width, canvas.height);
            onReady();
          } catch {
            onError();
          } finally {
            image.src = '';
          }
        };
        image.onerror = () => {
          if (!cancelled) onError();
        };
        image.src = src;
        return () => {
          cancelled = true;
          image.onload = null;
          image.onerror = null;
          try {
            image.src = '';
          } catch {
            /* nothing to release */
          }
        };
      }, [src]);
      return h('canvas', { ref: canvasRef, className: 'dsha-media', 'aria-hidden': 'true' });
    }

    /**
     * The overlay slot mounts this lifecycle component, but the wallpaper DOM
     * itself is portalled to `document.body` rather than painted in that layer.
     */
    function WallpaperLayer() {
      const { settings, runtime } = useAppearance();
      const mediaRef = useRef(null);
      const layerRef = useRef(null);
      const [reduced, setReduced] = useState(() => prefersReducedMotion());

      const info = classifyPath(settings.path);
      const still = reduced && settings.reduceMotion !== 'off';
      const blocked = reduced && settings.reduceMotion === 'off';
      const wanted = settings.enabled && info.ok && !blocked;
      const ready = runtime.status === 'ready' && runtime.path === settings.path;
      const url = useMemo(() => (wanted ? buildMediaUrl(settings.path) : ''), [wanted, settings.path]);

      // Watch the OS preference live: one listener, no polling.
      useEffect(() => {
        if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') return undefined;
        let query = null;
        try {
          query = window.matchMedia('(prefers-reduced-motion: reduce)');
        } catch {
          return undefined;
        }
        const onChange = () => setReduced(query.matches === true);
        setReduced(query.matches === true);
        query.addEventListener?.('change', onChange);
        return () => query.removeEventListener?.('change', onChange);
      }, []);

      /**
       * Painting order: see the file header. `#root` must paint after this layer,
       * and step 8 of the root stacking context is ordered by tree order.
       */
      useEffect(() => {
        const layer = layerRef.current;
        const parent = layer?.parentNode;
        if (!layer || !parent || parent.firstChild === layer) return;
        try {
          parent.insertBefore(layer, parent.firstChild);
        } catch {
          /* a detached container leaves the default order, which is still usable */
        }
      }, []);

      // Report the load outcome, and fall back to the last path that worked.
      const onReady = useCallback(() => {
        store.update({ lastGoodPath: settings.path });
        store.report('ready', settings.path);
      }, [settings.path]);

      const onError = useCallback(() => {
        const previous = store.get().lastGoodPath;
        if (previous && previous !== settings.path) {
          store.update({ path: previous });
          store.report('loading', previous);
          return;
        }
        store.report('error', settings.path, 'decode');
      }, [settings.path]);

      // Play/pause. The `<video>` is the only element with a transport, and it is
      // paused both while the window is hidden and whenever playback is unwanted.
      useEffect(() => {
        if (info.kind !== 'video' || url === '') return undefined;
        const element = mediaRef.current;
        if (!element) return undefined;
        // `muted` as a property as well as an attribute: a `<video>` that React
        // has just created has no autoplay permission until it is muted.
        element.muted = true;
        element.volume = 0;
        const sync = () => {
          const target = mediaRef.current;
          if (!target) return;
          const hidden = typeof document !== 'undefined' && document.visibilityState === 'hidden';
          if (still || (hidden && settings.pauseWhenHidden)) {
            try {
              target.pause?.();
            } catch {
              /* already paused */
            }
            return;
          }
          if (target.paused && target.readyState >= 2) {
            const playing = target.play?.();
            playing?.catch?.(() => {
              /* an autoplay policy refusal is not an error worth surfacing */
            });
          }
        };
        document.addEventListener('visibilitychange', sync);
        sync();
        return () => document.removeEventListener('visibilitychange', sync);
      }, [info.kind, url, still, settings.pauseWhenHidden]);

      // The token overrides follow the *showing* wallpaper only, so a failed load
      // never leaves the app transparent, and switching the wallpaper off
      // restores the original background exactly. The previous effect's cleanup
      // runs before this body, so the computed colours read here are pristine
      // (no compounding alpha across re-applies).
      useEffect(() => {
        if (!wanted || !ready) return undefined;
        const revert = applyOverrides(document, entriesFor(settings, createLookup(document)));
        activeRevert = revert;
        return () => {
          if (activeRevert === revert) activeRevert = null;
          revert();
        };
      }, [wanted, ready, settings.enabled, settings.surface, settings.polish.radius, settings.polish.border, settings.polish.backdrop]);

      // Release the decoder when the source changes or the layer goes away. The
      // node is captured here because React detaches `ref` before passive
      // cleanups run on unmount.
      useEffect(() => {
        const element = mediaRef.current;
        return () => releaseMedia(element);
      }, [url]);

      if (!wanted) return null;

      const media = info.kind === 'video'
        ? h('video', {
          ref: mediaRef,
          className: 'dsha-media',
          src: url,
          muted: true,
          loop: true,
          autoPlay: !still,
          playsInline: true,
          preload: 'auto',
          disablePictureInPicture: true,
          tabIndex: -1,
          'aria-hidden': 'true',
          onLoadedData: onReady,
          onError: onError,
        })
        : info.kind === 'gif' && still
          ? h(GifStill, { key: url, src: url, onReady: onReady, onError: onError })
          : h('img', {
            ref: mediaRef,
            className: 'dsha-media',
            src: url,
            alt: '',
            decoding: 'async',
            draggable: false,
            onLoad: onReady,
            onError: onError,
          });

      return ReactDOM.createPortal(
        h('div', {
          ref: layerRef,
          className: 'dsha-layer',
          'data-kind': info.kind,
          'aria-hidden': 'true',
        },
        media,
        h('div', { className: 'dsha-dim', style: { opacity: String(settings.dim) } })),
        document.body,
      );
    }

    /**
     * The friendly failure state. It lives in `shell.overlay` (above the content
     * columns) because a notice painted *behind* the app would be invisible —
     * and it is only shown while the background could not be loaded, which is
     * exactly when the original, opaque background is still in place.
     */
    function WallpaperNotice({ t }) {
      const { settings, runtime } = useAppearance();
      const [dismissed, setDismissed] = useState('');
      const translate = typeof t === 'function' ? t : tSafe;
      const token = `${runtime.path}|${runtime.reason}`;
      const visible = settings.enabled && runtime.status === 'error' && dismissed !== token;
      if (!visible) return null;
      return h('div', { className: 'dsha-noticeHost' },
        h('div', { className: 'dsha-notice', role: 'status' },
          h('div', { className: 'dsha-noticeBody' },
            h('div', { className: 'dsha-noticeTitle' }, 'dsh-appearance'),
            h('div', null, `${translate('notice.title')}（${baseName(runtime.path)}）`),
            h('div', { className: 'dsha-noticePath' }, translate('notice.hint')),
          ),
          h('button', {
            type: 'button',
            className: 'dsha-button',
            onClick: () => setDismissed(token),
          }, translate('wallpaper.close')),
        ),
      );
    }

    /**
     * The settings row. `settings.general.item` projects no label, so the row
     * draws its own; the whole surface is collapsed until the user opens it, and
     * every polish control starts at "leave unchanged".
     */
    function SettingsRow({ t }) {
      const { settings, runtime } = useAppearance();
      const [open, setOpen] = useState(false);
      const [draft, setDraft] = useState(settings.path);
      const [busy, setBusy] = useState(false);
      const [message, setMessage] = useState(null);
      const [probed, setProbed] = useState(null);
      const observed = useRef(settings.path);

      useEffect(() => {
        if (observed.current === settings.path) return;
        observed.current = settings.path;
        setDraft(settings.path);
      }, [settings.path]);

      const translate = typeof t === 'function' ? t : tSafe;

      /** A reason key plus the extension, so the message needs no placeholder machinery. */
      const reasonText = (reason, extension) => {
        const base = translate(`reason.${reason}`);
        return reason === 'unsupported-extension' && extension ? `${base} (.${extension})` : base;
      };

      const status = (() => {
        if (!settings.enabled) return translate('status.off');
        if (runtime.status === 'ready') return translate('status.ready', { name: baseName(runtime.path) });
        if (runtime.status === 'error') return translate('reason.decode');
        return translate('status.loading');
      })();

      const apply = useCallback(async () => {
        const candidate = draft.trim();
        const info = classifyPath(candidate);
        if (!info.ok) {
          setProbed(null);
          setMessage(reasonText(info.reason, info.extension));
          return;
        }
        setBusy(true);
        setMessage(null);
        const probe = await probePath(candidate);
        const verdict = judgePath(candidate, probe);
        setBusy(false);
        if (!verdict.accept) {
          setProbed(null);
          setMessage(reasonText(verdict.reason, info.extension));
          return;
        }
        setProbed(typeof verdict.size === 'number' ? formatSize(verdict.size) : null);
        store.update({ path: candidate });
      }, [draft]);

      const patchPolish = useCallback((patch) => store.update({ polish: patch }), []);

      return h('div', { className: 'dsha-row' },
        h('div', { className: 'dsha-head' },
          h('div', { className: 'dsha-text' },
            h('div', { className: 'dsha-title' }, translate('wallpaper.title')),
            h('div', { className: 'dsha-desc' }, translate('wallpaper.description')),
            h('div', { className: 'dsha-value' }, status),
          ),
          h('div', { className: 'dsha-controls' },
            h('button', {
              type: 'button',
              className: 'dsha-switch',
              role: 'switch',
              'aria-checked': settings.enabled,
              onClick: () => store.update({ enabled: !settings.enabled }),
            }, settings.enabled ? translate('wallpaper.on') : translate('wallpaper.off')),
            h('button', {
              type: 'button',
              className: 'dsha-button',
              'aria-expanded': open,
              onClick: () => setOpen((value) => !value),
            }, translate(open ? 'wallpaper.close' : 'wallpaper.details')),
          ),
        ),
        open
          ? h('div', { className: 'dsha-panel' },
            h('div', { className: 'dsha-field' },
              h('label', { className: 'dsha-label', htmlFor: 'dsha-path' }, translate('path.label')),
              h('div', { className: 'dsha-inline' },
                h('input', {
                  id: 'dsha-path',
                  className: 'dsha-input',
                  type: 'text',
                  spellCheck: false,
                  value: draft,
                  placeholder: DEFAULT_PATH,
                  onChange: (event) => setDraft(event.target.value),
                  onKeyDown: (event) => {
                    if (event.key === 'Enter') apply();
                  },
                }),
                h('button', { type: 'button', className: 'dsha-button', disabled: busy, onClick: apply }, busy ? translate('path.checking') : translate('path.apply')),
              ),
              h('div', { className: 'dsha-hint' }, translate('path.hint')),
              probed ? h('div', { className: 'dsha-hint' }, `${probed}`) : null,
              message ? h('div', { className: 'dsha-error' }, message) : null,
            ),
            h('div', { className: 'dsha-field' },
              h('label', { className: 'dsha-label', htmlFor: 'dsha-surface' }, `${translate('surface.label')} — ${Math.round(settings.surface * 100)}%`),
              h('input', {
                id: 'dsha-surface',
                className: 'dsha-range',
                type: 'range',
                min: 30,
                max: 100,
                step: 1,
                value: Math.round(settings.surface * 100),
                onChange: (event) => store.update({ surface: Number(event.target.value) / 100 }),
              }),
            ),
            h('div', { className: 'dsha-field' },
              h('label', { className: 'dsha-label', htmlFor: 'dsha-dim' }, `${translate('dim.label')} — ${Math.round(settings.dim * 100)}%`),
              h('input', {
                id: 'dsha-dim',
                className: 'dsha-range',
                type: 'range',
                min: 0,
                max: 80,
                step: 1,
                value: Math.round(settings.dim * 100),
                onChange: (event) => store.update({ dim: Number(event.target.value) / 100 }),
              }),
            ),
            h('div', { className: 'dsha-inline' },
              h('select', {
                className: 'dsha-select',
                'aria-label': translate('radius.label'),
                value: settings.polish.radius,
                onChange: (event) => patchPolish({ radius: event.target.value }),
              }, ...['keep', 'sm', 'md', 'lg', 'xl'].map((id) => h('option', { key: id, value: id }, id === 'keep' ? `${translate('radius.label')}: ${translate('keep')}` : `${translate('radius.label')}: ${RADIUS_CHOICES[id]}`))),
              h('select', {
                className: 'dsha-select',
                'aria-label': translate('border.label'),
                value: settings.polish.border,
                onChange: (event) => patchPolish({ border: event.target.value }),
              }, ...['keep', 'soft', 'faint'].map((id) => h('option', { key: id, value: id }, id === 'keep' ? `${translate('border.label')}: ${translate('keep')}` : `${translate('border.label')}: ${translate(id)}`))),
              h('select', {
                className: 'dsha-select',
                'aria-label': translate('backdrop.label'),
                value: settings.polish.backdrop,
                onChange: (event) => patchPolish({ backdrop: event.target.value }),
              }, ...['keep', 'light', 'medium', 'heavy'].map((id) => h('option', { key: id, value: id }, id === 'keep' ? `${translate('backdrop.label')}: ${translate('keep')}` : `${translate('backdrop.label')}: ${translate(id)}`))),
            ),
            h('div', { className: 'dsha-inline' },
              h('button', {
                type: 'button',
                className: 'dsha-switch',
                role: 'switch',
                'aria-checked': settings.pauseWhenHidden,
                onClick: () => store.update({ pauseWhenHidden: !settings.pauseWhenHidden }),
              }, translate('pauseHidden.label')),
              h('select', {
                className: 'dsha-select',
                'aria-label': translate('reduceMotion.label'),
                value: settings.reduceMotion,
                onChange: (event) => store.update({ reduceMotion: event.target.value }),
              },
              h('option', { value: 'still' }, `${translate('reduceMotion.label')}: ${translate('motion.still')}`),
              h('option', { value: 'off' }, `${translate('reduceMotion.label')}: ${translate('motion.off')}`)),
            ),
            h('div', { className: 'dsha-foot' },
              h('button', {
                type: 'button',
                className: 'dsha-button',
                onClick: () => {
                  releaseOverrides();
                  store.replace(null);
                  setMessage(null);
                  setProbed(null);
                },
              }, translate('wallpaper.reset')),
            ),
          )
          : null,
      );
    }

    /** Fallback translator for the overlay notice, which is registered without a locale seat. */
    function tSafe(key, params) {
      let table = en;
      try {
        const active = String(activeLocale() ?? '').slice(0, 2).toLowerCase();
        if (active === 'ja') table = ja;
        else if (active === 'zh') table = zh;
      } catch {
        table = en;
      }
      const template = table[key] ?? en[key] ?? key;
      if (!params) return template;
      return template.replace(/\{(\w+)\}/g, (whole, name) => (params[name] === undefined ? whole : String(params[name])));
    }

    /** Replaced by `apply` with the live locale reader. */
    let activeLocale = () => undefined;

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        activeLocale = () => {
          try {
            return ctx.locale.getLocale()?.active;
          } catch {
            return undefined;
          }
        };

        ctx.effect(() => () => styleElement?.remove(), 'dsh-appearance: styles');
        ctx.effect(() => ctx.locale.register(NS, { zh, en }), 'dsh-appearance: dictionaries');
        ctx.effect(() => {
          try {
            return ctx.locale.register(NS, 'ja', ja);
          } catch {
            // Without the `ja` language pack the English copy stands.
            return () => {};
          }
        }, 'dsh-appearance: japanese dictionary');

        ctx.effect(
          () => ctx.slots.inject('shell.overlay', () => ctx.slots.register({
            name: 'shell.overlay',
            id: 'appearance-wallpaper',
            order: 4,
          }, WallpaperLayer)),
          'dsh-appearance: wallpaper layer',
        );

        ctx.effect(
          () => ctx.slots.inject('settings.general.item', () => ctx.slots.register({
            name: 'settings.general.item',
            id: 'appearance-wallpaper',
            order: 40,
            locale: NS,
          }, SettingsRow)),
          'dsh-appearance: settings row',
        );

        // Belt and braces: whatever removed the slot cell (HMR, a profile
        // reload), the inline token overrides never outlive this row.
        ctx.effect(() => () => releaseOverrides(), 'dsh-appearance: token overrides');
      },
      /** Test seam: pure helpers, the store factory and the cells. */
      __test: {
        id: ID,
        ns: NS,
        storageKey: STORAGE_KEY,
        bootstrapKey: BOOTSTRAP_KEY,
        defaultPath: DEFAULT_PATH,
        defaults: DEFAULTS,
        dictionaries: { zh, en, ja },
        surfaceTokens: SURFACE_TOKENS.map((entry) => entry.token),
        radiusTokens: RADIUS_TOKENS,
        borderTokens: BORDER_TOKENS,
        radiusChoices: RADIUS_CHOICES,
        borderChoices: BORDER_CHOICES,
        backdropChoices: BACKDROP_CHOICES,
        extensionOf,
        classifyPath,
        clamp,
        normalizeSettings,
        resolveChain,
        parseColor,
        withAlpha,
        surfaceEntries,
        polishEntries,
        entriesFor,
        applyOverrides,
        createLookup,
        encodeFilePath,
        buildMediaUrl,
        judgePath,
        probePath,
        baseName,
        formatSize,
        prefersReducedMotion,
        releaseMedia,
        createAppearanceStore,
        store,
        useAppearance,
        WallpaperLayer,
        WallpaperNotice,
        SettingsRow,
        GifStill,
        releaseOverrides,
        activeRevertRef: () => activeRevert,
      },
    };
  },
});

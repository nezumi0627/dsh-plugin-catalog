# DSH Appearance

`dsh-appearance` owns its wallpaper settings and its controls only; it does not restyle classes owned by DSH or other plugins. Wallpaper state is persisted with the app client store. The bundled default path is `C:\Users\ren11\Downloads\infinite-space-moewalls-com.mp4`; the user's source is read in place, never copied or modified.

## Shared visual contract

Use the DSH design tokens rather than fixed colors: surfaces (`--dsw-alias-bg-base`, `--dsw-alias-bg-layer-1/2`, `--dsw-specific-sidebar-fill`, `--dsw-specific-input-major`), hairline borders (`--dsw-alias-border-l1/l2/l3`), text (`--dsw-alias-label-primary/secondary`), and radii (`--dsw-radius-sm/md/lg`). Interactive elements preserve native focus visibility, use `:hover`/`:active` tokens, and respect `prefers-reduced-motion`. New surfaces should remain token-based and avoid hex color literals.

The single wallpaper media element portals to `document.body` at `position:fixed; inset:0; z-index:0; pointer-events:none`; surface transparency is applied only while a valid wallpaper is ready and is restored by the disposer. Its lifecycle component mounts through the `shell.overlay` list slot, while the wallpaper DOM portals directly to the first child of `document.body`. It does not paint in the overlay layer. The `shell.leading` slot is a singleton owned by the main frame and is not used.

## Verification

Run `node --check index.js`, `node --check client.js`, `node test-appearance.mjs`, `node test-client.mjs`, and `node test-render.mjs`. `REPORT.md` records output and known live-renderer limits. The host serves the selected file with byte-range support; it does not buffer the full video. No dependencies are added.

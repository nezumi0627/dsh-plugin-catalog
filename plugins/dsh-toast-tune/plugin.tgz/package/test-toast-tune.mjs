// Offline verification of the Client bundle for @local/dsh-toast-tune.
//
// The bundle is a browser artifact, so this harness runs it in a stubbed
// ModuleLoader, window, document and React, then asserts the contract the app
// depends on:
//
//   * the bundle registers exactly its own id and injects `slots` + `locale`;
//   * apply() inserts one <style data-plugin-css> with both animations, sets the
//     document flags the stylesheet reads, patches window.setTimeout, and
//     registers the Plugins page entry keyed `<package>#<row>`;
//   * the dismiss-timer rewrite fires for a banner on screen, leaves every other
//     timer alone, follows the "owner's hold wins when it is longer" rule, and
//     stops entirely at `holdMs: 0`;
//   * stacking assigns the vertical offsets and is undone when it is switched
//     off;
//   * disposal restores window.setTimeout, removes the stylesheet, and clears
//     the document flags.
//
// Run: node dsh-toast-tune/test-toast-tune.mjs
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const PKG = '@local/dsh-toast-tune';
const ROW = 'toast-tune';
const MARK = 'data-dsh-toast-tune';
const SELECTOR = 'div[role="alert"][style*="--dsh-toast-hold"]';

const failures = [];
const ok = (condition, message) => {
  if (!condition) failures.push(message);
};
const eq = (actual, expected, message) => {
  if (actual !== expected) failures.push(`${message}: ${JSON.stringify(actual)} !== ${JSON.stringify(expected)}`);
};

// ── a DOM small enough to reason about ───────────────────────────────────────

class FakeStyle {
  constructor() {
    this.map = new Map();
  }
  getPropertyValue(name) {
    return this.map.has(name) ? this.map.get(name) : '';
  }
  setProperty(name, value) {
    this.map.set(name, String(value));
  }
  removeProperty(name) {
    this.map.delete(name);
  }
}

class FakeElement {
  constructor(tag) {
    this.nodeType = 1;
    this.tagName = String(tag).toUpperCase();
    this.attributes = new Map();
    this.style = new FakeStyle();
    this.children = [];
    this.height = 0;
    this.textContent = '';
  }
  setAttribute(name, value) {
    this.attributes.set(name, String(value));
  }
  getAttribute(name) {
    return this.attributes.has(name) ? this.attributes.get(name) : null;
  }
  hasAttribute(name) {
    return this.attributes.has(name);
  }
  removeAttribute(name) {
    this.attributes.delete(name);
  }
  matches(selector) {
    return selector === SELECTOR
      && this.getAttribute('role') === 'alert'
      && this.style.getPropertyValue('--dsh-toast-hold') !== '';
  }
  querySelector() {
    return null;
  }
  querySelectorAll() {
    return [];
  }
  getBoundingClientRect() {
    return { height: this.height };
  }
  append(child) {
    this.children.push(child);
    child.parent = this;
  }
  remove() {
    if (this.parent) {
      const index = this.parent.children.indexOf(this);
      if (index >= 0) this.parent.children.splice(index, 1);
    }
  }
}

/** The banners the stubbed document reports; the test owns this list. */
const toasts = [];
function addBanner(holdMs, height = 48) {
  const element = new FakeElement('div');
  element.setAttribute('role', 'alert');
  element.style.setProperty('--dsh-toast-hold', `${holdMs}ms`);
  element.height = height;
  toasts.push(element);
  return element;
}

const head = new FakeElement('head');
const body = new FakeElement('body');
const documentElement = new FakeElement('html');
const document = {
  head,
  body,
  documentElement,
  createElement: (tag) => new FakeElement(tag),
  querySelectorAll: (selector) => (String(selector).includes(':not([')
    ? toasts.filter((element) => !element.hasAttribute(MARK))
    : toasts.slice())
};

// ── the window ───────────────────────────────────────────────────────────────

const timers = [];
const storage = new Map();
let observerInstances = [];
class FakeMutationObserver {
  constructor(callback) {
    this.callback = callback;
    this.observed = null;
    this.disconnected = false;
    observerInstances.push(this);
  }
  observe(target, options) {
    this.observed = { target, options };
  }
  disconnect() {
    this.disconnected = true;
  }
}

const nativeSetTimeout = (handler, delay, ...rest) => {
  timers.push({ handler, delay, rest });
  return timers.length;
};
const listeners = new Map();
const window = {
  setTimeout: nativeSetTimeout,
  clearTimeout: () => {},
  requestAnimationFrame: (run) => {
    run();
    return 1;
  },
  addEventListener: (name, listener) => {
    listeners.set(name, listener);
  },
  removeEventListener: (name) => {
    listeners.delete(name);
  },
  MutationObserver: FakeMutationObserver,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value))
  },
  __ModuleLoader__: {
    load(entry) {
      window.__entry = entry;
    }
  }
};

const react = {
  createElement: (type, props, ...children) => ({ type, props, children }),
  useState: () => [undefined, () => {}],
  useEffect: () => {}
};

// ── run the bundle ───────────────────────────────────────────────────────────

const sandbox = { window, document, console };
vm.createContext(sandbox);
vm.runInContext(readFileSync(fileURLToPath(new URL('./client.js', import.meta.url)), 'utf8'), sandbox, {
  filename: 'client.js'
});

const entry = window.__entry;
ok(entry !== undefined, 'the bundle did not call window.__ModuleLoader__.load');
eq(entry?.id, PKG, 'registered module id');
ok(typeof entry?.factory === 'function', 'the factory is not a function');

const plugin = entry.factory((name) => {
  if (name === 'react') return react;
  throw new Error(`unexpected require(${JSON.stringify(name)})`);
});
ok(Array.isArray(plugin?.inject), 'the plugin declares no inject list');
ok(plugin.inject.includes('slots') && plugin.inject.includes('locale'), `inject list: ${JSON.stringify(plugin?.inject)}`);
ok(typeof plugin?.apply === 'function', 'the plugin has no apply()');

const effects = [];
const dictionaries = [];
const injections = [];
const registrations = [];
const ctx = {
  effect(fn, name) {
    const dispose = fn();
    effects.push({ name, dispose });
    return dispose;
  },
  locale: {
    register(ns, dicts) {
      dictionaries.push({ ns, dicts });
      return () => {};
    },
    bind: () => (key) => key
  },
  slots: {
    inject(name, callback) {
      injections.push(name);
      callback();
      return () => {};
    },
    register(options, component) {
      registrations.push({ options, component });
      return () => {};
    }
  }
};

try {
  plugin.apply(ctx);
} catch (error) {
  failures.push(`apply() threw: ${error.message}`);
}

const test = plugin.__test;

// ── registration contract ────────────────────────────────────────────────────

const styleElement = head.children.find((element) => element.getAttribute('data-plugin-css') === PKG);
ok(styleElement !== undefined, 'apply() did not insert a <style data-plugin-css>');
ok(styleElement?.textContent.includes('@keyframes dsh-tt-in'), 'the stylesheet has no enter animation');
ok(styleElement?.textContent.includes('@keyframes dsh-tt-out'), 'the stylesheet has no exit animation');
ok(styleElement?.textContent.includes('@keyframes dsh-tt-drain'), 'the stylesheet has no countdown animation');
ok(styleElement?.textContent.includes('[style*="--dsh-toast-hold"]'), 'the stylesheet does not target the shipped banner');
ok(styleElement?.textContent.includes('@media (prefers-reduced-motion: reduce)'), 'the stylesheet ignores reduced motion');

eq(dictionaries.length, 1, 'dictionary registrations');
eq(dictionaries[0]?.ns, test.namespace, 'dictionary namespace');
const shipped = dictionaries[0]?.dicts ?? {};
const keySets = ['en', 'ja', 'zh'].map((locale) => Object.keys(shipped[locale] ?? {}).sort().join(','));
ok(keySets.every((keys) => keys === keySets[0] && keys.length > 0), 'the en/ja/zh dictionaries do not cover the same keys');

// The stylesheet is a template literal, so nothing but balance can be checked here.
const braces = (test.css.match(/\{/g) ?? []).length - (test.css.match(/\}/g) ?? []).length;
const parens = (test.css.match(/\(/g) ?? []).length - (test.css.match(/\)/g) ?? []).length;
eq(braces, 0, 'unbalanced braces in the stylesheet');
eq(parens, 0, 'unbalanced parentheses in the stylesheet');
ok(!test.css.includes('${'), 'the stylesheet interpolated a JavaScript expression');

eq(injections.length, 1, 'slot injections');
eq(injections[0], 'plugins.row.config', 'injected slot');
eq(registrations.length, 1, 'slot registrations');
eq(registrations[0]?.options?.name, 'plugins.row.config', 'registered slot name');
eq(registrations[0]?.options?.key, `${PKG}#${ROW}`, 'registered row key');
eq(registrations[0]?.options?.locale, test.namespace, 'registered locale namespace');
eq(typeof registrations[0]?.component, 'function', 'the registered page is not a component');

eq(documentElement.getAttribute('data-dshtt-motion'), '1', 'motion flag');
eq(documentElement.getAttribute('data-dshtt-tint'), '1', 'tint flag');
eq(documentElement.style.getPropertyValue('--dshtt-countdown'), '1', 'countdown flag');
eq(observerInstances.length, 1, 'banner observers');
eq(observerInstances[0]?.observed?.options?.childList, true, 'the observer does not watch childList');
ok(typeof listeners.get('resize') === 'function', 'no resize listener');
ok(window.setTimeout !== nativeSetTimeout, 'window.setTimeout was not patched');

// ── preference rules ─────────────────────────────────────────────────────────

eq(test.clampHold(0), 0, 'clampHold(0)');
eq(test.clampHold(-5), 0, 'clampHold(-5)');
eq(test.clampHold(1200), test.holdMin, 'clampHold below the minimum');
eq(test.clampHold(999999), test.holdMax, 'clampHold above the maximum');
eq(test.clampHold(12345), 12500, 'clampHold rounds to the step');
eq(test.normalize(null).holdMs, 8000, 'the default hold');
eq(test.normalize({ holdMs: 0 }).countdown, true, 'an absent toggle defaults on');

// ── what this bundle schedules ───────────────────────────────────────────────
//
// The banner's dismiss timer belongs to the shipped Toast; this bundle only
// rewrites it. So a banner arriving or leaving must schedule nothing of its own,
// and a burst of mutations has to coalesce into a single frame's restack — a
// per-banner timer or observer here would be the one thing that grows with the
// number of banners on screen.

const frames = [];
window.requestAnimationFrame = (run) => {
  frames.push(run);
  return frames.length;
};

const entering = addBanner(6000);
observerInstances[0].callback([{ addedNodes: [entering], removedNodes: [] }]);
eq(frames.length, 1, 'a banner entering the document did not schedule exactly one restack');
observerInstances[0].callback([{ addedNodes: [addBanner(6000)], removedNodes: [] }]);
eq(frames.length, 1, 'a second mutation in the same frame scheduled another restack');
eq(observerInstances.length, 1, 'a second banner created a second observer');
for (const run of frames.splice(0)) run();
eq(timers.length, 0, 'restacking a banner scheduled a timer of this bundle\u2019s own');

const unrelated = new FakeElement('div');
observerInstances[0].callback([{ addedNodes: [unrelated], removedNodes: [] }]);
eq(frames.length, 0, 'a mutation that carries no banner scheduled a restack');

// The banners this section put on screen are not the ones the timer rewrite below
// is about (that section matches a banner by its hold).
toasts.length = 0;

// ── the dismiss timer rewrite ────────────────────────────────────────────────

const first = addBanner(6000);
timers.length = 0;
window.setTimeout(() => {}, 7000);
eq(timers.at(-1)?.delay, 9000, 'the configured 8s minimum did not extend a 6s banner');
eq(first.getAttribute(MARK), '1', 'the rewritten banner was not marked');
eq(first.style.getPropertyValue('--dsh-toast-hold'), '8000ms', 'the banner hold was not rewritten');

timers.length = 0;
window.setTimeout(() => {}, 7000);
eq(timers.at(-1)?.delay, 7000, 'a marked banner was claimed twice');

const second = addBanner(6000);
timers.length = 0;
window.setTimeout(() => {}, 15000);
eq(timers.at(-1)?.delay, 15000, 'an unrelated long timer was rewritten');
ok(second.getAttribute(MARK) === null, 'an unrelated timer marked a banner');

const shorter = addBanner(6000);
test.applyPreferences({ ...test.preferences(), holdMs: 4000 });
timers.length = 0;
window.setTimeout(() => {}, 7000);
eq(timers.at(-1)?.delay, 7000, "a shorter preference shrank the owner's longer hold");
eq(shorter.style.getPropertyValue('--dsh-toast-hold'), '6000ms', 'the longer owner hold was rewritten downwards');

const longer = addBanner(3000);
test.applyPreferences({ ...test.preferences(), holdMs: 20000 });
timers.length = 0;
window.setTimeout(() => {}, 4000);
eq(timers.at(-1)?.delay, 21000, 'the configured 20s minimum did not extend a 3s banner');
eq(longer.style.getPropertyValue('--dsh-toast-hold'), '20000ms', 'the extended hold was not written to the banner');

const untouched = addBanner(5000);
test.applyPreferences({ ...test.preferences(), holdMs: 0 });
timers.length = 0;
window.setTimeout(() => {}, 6000);
eq(timers.at(-1)?.delay, 6000, 'holdMs 0 still rewrote the dismiss timer');
ok(untouched.getAttribute(MARK) === null, 'holdMs 0 still marked the banner');

// ── preference persistence ───────────────────────────────────────────────────

eq(storage.get(test.storeKey), JSON.stringify(test.preferences()), 'the preferences were not stored');
test.applyPreferences({ ...test.preferences(), holdMs: 8000, countdown: false, motion: false, tint: false, stack: false });
eq(test.readPreferences().holdMs, 8000, 'a stored preference did not read back');
eq(documentElement.getAttribute('data-dshtt-motion'), '0', 'the motion flag ignores the preference');
eq(documentElement.getAttribute('data-dshtt-tint'), '0', 'the tint flag ignores the preference');
eq(documentElement.style.getPropertyValue('--dshtt-countdown'), '0', 'the countdown flag ignores the preference');

// ── stacking ─────────────────────────────────────────────────────────────────

toasts.length = 0;
const stacked = [addBanner(6000, 48), addBanner(6000, 52), addBanner(6000, 40)];
test.applyPreferences({ ...test.preferences(), stack: true });
test.restack();
eq(stacked[0]?.style.getPropertyValue('top'), '28px', 'the first banner offset');
eq(stacked[1]?.style.getPropertyValue('top'), '86px', 'the second banner offset');
eq(stacked[2]?.style.getPropertyValue('top'), '148px', 'the third banner offset');
test.applyPreferences({ ...test.preferences(), stack: false });
eq(stacked[0]?.style.getPropertyValue('top'), '', 'turning stacking off leaves an offset behind');
test.applyPreferences({ ...test.preferences(), stack: true });
test.restack();
eq(stacked[1]?.style.getPropertyValue('top'), '86px', 'stacking does not come back');

// ── disposal ─────────────────────────────────────────────────────────────────

eq(effects.length, 7, `named effects: ${effects.map((effect) => effect.name).join(' | ')}`);
for (const effect of effects) effect.dispose();
eq(window.setTimeout, nativeSetTimeout, 'disposal did not restore window.setTimeout');
ok(!head.children.includes(styleElement), 'disposal left the stylesheet in the document');
eq(observerInstances[0]?.disconnected, true, 'disposal did not disconnect the banner observer');
eq(documentElement.getAttribute('data-dshtt-motion'), null, 'disposal left the motion flag');
eq(documentElement.getAttribute('data-dshtt-tint'), null, 'disposal left the tint flag');
eq(documentElement.style.getPropertyValue('--dshtt-countdown'), '', 'disposal left the countdown flag');
eq(listeners.get('resize'), undefined, 'disposal left the resize listener');

// ── report ───────────────────────────────────────────────────────────────────

console.log(`bundle id      : ${entry?.id}`);
console.log(`row key        : ${registrations[0]?.options?.key}`);
console.log(`dictionaries   : ${Object.keys(shipped).join(', ')} (${keySets[0].split(',').length} keys each)`);
console.log(`stylesheet     : ${styleElement?.textContent.length ?? 0} bytes`);
console.log(`effects        : ${effects.length}`);
console.log(`assertions     : ${failures.length === 0 ? 'all passed' : `${failures.length} failed`}`);
if (failures.length > 0) {
  console.error('\nFAILURES:');
  for (const failure of failures) console.error(`  x ${failure}`);
  process.exitCode = 1;
} else {
  console.log('\nALL CHECKS PASSED');
}

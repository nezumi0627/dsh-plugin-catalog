# @local/dsh-toast-tune

DSH Web GUI の**トースト（画面上部に出る通知バナー）**の見た目・動き・表示時間を整えるプラグインです。
本体（`app.asar` 内の `dsh-web-frontend`）には一切手を入れません。

## 何をするか

| 項目 | 既定 | 内容 |
|---|---|---|
| 表示時間 | **8 秒**（従来は 3 秒 / アーカイブ通知は 6 秒） | 保持時間の「最短値」。これより長く出す通知はそのまま長く出ます |
| 入場 | 260ms | 上から `-34px` の位置から `cubic-bezier(.16,1,.3,1)` で「シュッ」と降りてくる |
| 退場 | 1000ms | 保持時間の経過後、上へ戻りながらフェードアウト（最初の 26% で移動を終える） |
| 見た目 | — | 角丸 14px・境界線・ブラー・多層の影・アイコンの淡い円形背景・アクションの押しやすさ |
| 残り時間バー | オン | 下端の細い線が保持時間ぶんだけ減っていく |
| 複数トースト | 積む | 同時に出ても重ならないよう縦に並べる |

すべて **Plugins ページ → このバンドル → Configure** から変更でき、変更は即時反映・ブラウザー単位で記憶されます
（`window.localStorage` の `dsh-toast-tune:settings`）。ホスト側の設定も再起動も不要です。

## なぜ CSS だけでは足りないか

トーストの表示時間は CSS ではありません。本体の `Toast` コンポーネントは

```
useEffect(() => setTimeout(onDone, holdMs + FADE_MS))   // FADE_MS = 1000
```

で自分の寿命を決め、`onDone` で親がアンマウントします。したがって `--dsh-toast-hold` を
CSS で上書きしても、**フェードが遅れるだけで保持の途中で唐突に消えます**。

そこでこのバンドルは 3 つの層で効いています。

1. **見た目とアニメーション** — `<style data-plugin-css>` を 1 枚挿入し、本体の
   `.toast`（詳細度 0-1-0）より強い
   `div[role="alert"][style*="--dsh-toast-hold"]`（0-2-1、＋動きのフラグ）で
   `animation` ごと差し替えます。CSS モジュールのハッシュ（`_toast_l6cvn_6` の
   `l6cvn` 部分）には依存しないので、本体が作り直されても効きます。
2. **表示時間** — `window.setTimeout` を薄く包み、**画面に出ているトーストに対して
   予約された消滅タイマー**（遅延がちょうど `そのトーストの hold + 1000ms`）だけを
   設定値まで延ばし、同時にその要素の `--dsh-toast-hold` も書き換えます。
   CSS のフェード開始と JS のアンマウントが同じ値で動くのはこのためです。
   無関係な `setTimeout` は、遅延が一致しない限りそのまま素通しします。
3. **積み重ね** — `MutationObserver` でバナーの出入りを見て `top` を割り当てます。

## 構成

| ファイル | 役割 |
|---|---|
| `client.js` | **正**。スタイル・タイマーフック・積み重ね・設定ページを 1 つに収めた Client バンドル（ビルド不要） |
| `index.js` | Host 側。行を解決させるためだけの存在で、ログ以外は何もしない |
| `cordis.patch.yml` | Loader 行 `toast-tune` を挿入するバンドルパッチ。**行 id は設定ページのキー**（`@local/dsh-toast-tune#toast-tune`） |
| `locale/ja.json` / `locale/en.json` | Plugin Manager のカード表示（タイトル・説明） |
| `test-toast-tune.mjs` | オフライン検証。偽 DOM / 偽 React / 偽 ModuleLoader で契約を機械検証 |
| `icon.svg` | プラグイン一覧のアイコン |

設定ページの文言は Client の locale サービスへ `en` / `ja` / `zh` の 3 辞書で登録しています
（`ja` は `@local/dsh-locale-ja` が定義する外部ロケール。未導入なら `en` に落ちます）。

## 検証

```powershell
node dsh-toast-tune/test-toast-tune.mjs
```

次のことを機械的に確かめます。

- バンドル id と `inject: ['slots', 'locale']`
- `<style data-plugin-css>` の挿入と、入場・退場・残り時間バーの各 `@keyframes`
- `en` / `ja` / `zh` の辞書が同一キー集合であること
- `plugins.row.config` へ `@local/dsh-toast-tune#toast-tune` を登録していること
- タイマー書き換え：6 秒のトーストが 8 秒へ延びる／同じトーストを二度取らない／
  無関係な長いタイマーは触らない／**呼び出し側が長いときはその値を尊重**／
  `holdMs: 0` なら何もしない
- 積み重ねの `top` 計算と、オフにしたときの解除
- 破棄で `window.setTimeout` が元に戻り、スタイル・フラグ・observer が片付くこと

見た目そのものはブラウザーでしか確認できないため、この検証は
「契約が満たされている」ことの証明であって「見た目が良い」ことの証明ではありません。

## インストール

プロファイル `desktop` にリンクインストールしています。

- `$DSH_PROFILE_DIR/package.json` の `dependencies` と `dsh.profile.bundles`
- `$DSH_PROFILE_DIR/node_modules/@local/dsh-toast-tune` → このディレクトリ

バンドル一覧の変更は DSH の起動時に読まれるため、**有効化には再起動が必要**です
（バンドルを外すときも同じ）。

## 既知の限界

- **本体のタイマーの作り方に依存します。** `Toast` が `setTimeout(fn, hold + 1000)` を
  やめた場合、延長は効かなくなります（見た目とアニメーションは効いたままです）。
  その場合は `client.js` の `bannerAwaiting` / `tunedSetTimeout` を本体の新しい形に合わせてください。
- React のアンマウント自体には触れていません。`removeChild` を妨害するような真似をすると
  「元に戻す」ボタンのイベントごと死ぬため、意図的に避けています。
- `prefers-reduced-motion: reduce` の環境ではスライドをやめ、フェードのみにします
  （アプリ本体も同じ扱いです）。
- 設定はブラウザー（`localStorage`）単位です。別のブラウザーは別の値を持ちます。

## ロールバック

1. `$DSH_PROFILE_DIR/package.json` の `dsh.profile.bundles` から
   `@local/dsh-toast-tune` を外す（`dependencies` の行も外してよい）。
2. DSH を再起動する。

本体には何も書き込んでいないので、これだけで元の見た目と表示時間に戻ります。

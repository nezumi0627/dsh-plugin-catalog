/**
 * Host half of `@local/dsh-toast-tune`.
 *
 * The banner is browser work — a stylesheet, a rewritten dismiss timer and a
 * settings page all live in the page — so this half registers no Host service
 * and holds no configuration.
 *
 * It exists because a profile bundle row must resolve a package root:
 * `dsh-client-modules` keys the browser boot graph by the package a row names,
 * and a row whose module cannot be imported would fail the whole composition.
 * Keeping the host half trivial (and side-effect free) is what lets the toast
 * work ship as its own bundle instead of being folded into another one.
 */
export const name = 'dsh-toast-tune';
export const VERSION = '1.0.0';

export function apply(ctx) {
  ctx.logger?.info?.('[toast-tune] active — toast banner restyled; display time from Plugins → Configure');
}

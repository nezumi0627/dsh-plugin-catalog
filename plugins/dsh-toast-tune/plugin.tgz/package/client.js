/**
 * Client half of `@local/dsh-toast-tune` — the look, the motion and the display
 * time of the shipped toast banner (`@deepseek-ai/dsh-client-ui-primitives`
 * Toast, rendered by `dsh-web-frontend`).
 *
 * ## Why this is not just a stylesheet
 *
 * The banner's display time is not CSS. The component schedules
 * `setTimeout(onDone, holdMs + FADE_MS)` and its owner unmounts it when that
 * fires, so re-pointing `--dsh-toast-hold` alone would only delay the fade while
 * the banner still vanished mid-hold. This bundle therefore does three things:
 *
 * 1. styles the banner and replaces both animations (slide down from the top,
 *    slide back up and out) through one injected `<style data-plugin-css>`;
 * 2. wraps `window.setTimeout` and, when the delay is exactly the one the Toast
 *    component scheduled for a banner on screen, rewrites it — and the banner's
 *    own `--dsh-toast-hold` — to the configured hold. The wrapper is the only
 *    seam a plugin has here: the component instance belongs to its owner, and
 *    the primitives module table is frozen.
 * 3. stacks concurrent banners vertically, because a longer hold makes two
 *    banners on top of each other far more likely.
 *
 * The banner is selected by its own stable shape — `role="alert"` plus the hold
 * the component writes into its inline style — never by a CSS-module hash, so a
 * rebuilt UI keeps working.
 *
 * ## Preferences
 *
 * Preferences are the browser's (`window.localStorage`), like the clock's
 * seconds toggle: they apply immediately and need no Host round trip. The
 * Plugins page renders them on this bundle's own row page through the
 * `plugins.row.config` slot, keyed `<package name>#<row id>`.
 */

window.__ModuleLoader__.load({
  id: '@local/dsh-toast-tune',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useEffect, useState } = React;

    /** Package name; the Client module system keys the boot graph by it. */
    const ID = '@local/dsh-toast-tune';
    /** Locale namespace owned by this bundle. */
    const NS = 'dshToastTune';
    /** Loader row id from cordis.patch.yml; the Plugins page keys this row's page by it. */
    const ROW_ID = 'toast-tune';
    /** `window.localStorage` key holding this browser's toast preferences. */
    const STORE_KEY = 'dsh-toast-tune:settings';
    /** Fade duration of the shipped Toast — its own FADE_MS. */
    const FADE_MS = 1000;
    /**
     * The shipped banner: `role="alert"` plus the hold the component writes into
     * its inline style. `:not([data-dsh-toast-tune])` below skips a banner whose
     * dismiss timer this bundle already rewrote.
     */
    const TOAST_SELECTOR = 'div[role="alert"][style*="--dsh-toast-hold"]';
    /** Marks a banner whose dismiss timer this bundle already rewrote. */
    const MARK = 'data-dsh-toast-tune';
    /** Distance from the window's top edge to the first banner, in pixels. */
    const BASE_TOP = 28;
    /** Vertical gap between stacked banners, in pixels. */
    const STACK_GAP = 10;
    const HOLD_MIN = 3000;
    const HOLD_MAX = 30000;
    const HOLD_STEP = 500;
    /** `holdMs: 0` means "leave the app's own timing alone". */
    const DEFAULTS = Object.freeze({ holdMs: 8000, countdown: true, motion: true, tint: true, stack: true });
    const PRESETS = [4000, 6000, 8000, 12000, 20000];

    // ── copy ────────────────────────────────────────────────────────────────
    //
    // Registered through the Client locale service. `ja` is an external language
    // the profile's language pack declares with `en` as its fallback, so the
    // lookup chain reaches these entries either way.
    const en = {
      title: 'Toast banners',
      summary: 'Stays for at least {seconds}, sliding in from the top.',
      summaryOff: 'Uses the app\u2019s own display time.',
      description:
        'Banners slide down from the top, hold, then slide back up as they fade. The time below is the shortest any banner stays; a banner that asks for a longer one keeps its own.',
      holdLabel: 'Minimum display time',
      holdHint: '3\u201330 seconds. Auto-dismiss and the countdown line both follow it.',
      holdOff: 'Do not extend (keep the app\u2019s timing)',
      presets: 'Presets',
      seconds: 's',
      countdown: 'Countdown line',
      countdownHint: 'A thin line along the bottom edge drains while the banner waits.',
      motion: 'Slide animation',
      motionHint: 'Off keeps a plain fade, for less movement.',
      tint: 'Tinted icon',
      tintHint: 'Puts a soft round background behind the leading icon.',
      stack: 'Stack several banners',
      stackHint: 'Keeps a second banner from covering the first.',
      reset: 'Reset to defaults',
      immediate: 'Changes apply at once and are remembered in this browser.'
    };
    const ja = {
      title: 'トースト表示',
      summary: '上から降りてきて、最低 {seconds} 表示します。',
      summaryOff: '本体の表示時間をそのまま使います。',
      description:
        'トーストは上から降りてきて、保持したあと上へ戻りながら消えます。下の時間は「最短」の保持時間で、それより長く出したい通知はそのまま長く出ます。',
      holdLabel: '最低表示時間',
      holdHint: '3〜30秒。自動で消えるまでと残り時間バーがこの値に従います。',
      holdOff: '延長しない（本体の既定のまま）',
      presets: 'プリセット',
      seconds: '秒',
      countdown: '残り時間バー',
      countdownHint: '下端の細いバーが、残り時間ぶんだけ減っていきます。',
      motion: 'スライドアニメーション',
      motionHint: 'オフにすると単純なフェードになります。',
      tint: 'アイコンの淡い背景',
      tintHint: '先頭のアイコンの後ろに丸い背景を敷きます。',
      stack: '複数トーストを積む',
      stackHint: '2つ同時に出ても重ならないようにします。',
      reset: '既定に戻す',
      immediate: '変更はすぐ反映され、このブラウザーに記憶されます。'
    };
    const zh = {
      title: '气泡提示',
      summary: '从顶部滑入，至少显示 {seconds}。',
      summaryOff: '沿用应用自身的显示时长。',
      description:
        '气泡从顶部滑入，停留后向上滑出并淡出。下面的时长是最短停留时间；需要更久的提示会保留自己的时长。',
      holdLabel: '最短显示时长',
      holdHint: '3〜30 秒。自动消失与剩余时间条都按此执行。',
      holdOff: '不延长（沿用应用自身节奏）',
      presets: '预设',
      seconds: '秒',
      countdown: '剩余时间条',
      countdownHint: '底部的细条会随剩余时间递减。',
      motion: '滑动动画',
      motionHint: '关闭后只保留淡入淡出。',
      tint: '图标底色',
      tintHint: '在首个图标后面铺一层柔和的圆形底色。',
      stack: '多个提示纵向排列',
      stackHint: '避免第二个提示盖住第一个。',
      reset: '恢复默认',
      immediate: '修改立即生效，并记录在本浏览器中。'
    };

    // ── preferences ─────────────────────────────────────────────────────────

    /** Clamp a hold to the offered range; `0` (and below) means "do not extend". */
    function clampHold(value) {
      const ms = Number(value);
      if (!Number.isFinite(ms) || ms <= 0) return 0;
      return Math.min(HOLD_MAX, Math.max(HOLD_MIN, Math.round(ms / HOLD_STEP) * HOLD_STEP));
    }

    /** Read any stored shape into the current preference shape. */
    function normalize(raw) {
      const source = raw !== null && typeof raw === 'object' ? raw : {};
      return {
        holdMs: source.holdMs === undefined ? DEFAULTS.holdMs : clampHold(source.holdMs),
        countdown: source.countdown !== false,
        motion: source.motion !== false,
        tint: source.tint !== false,
        stack: source.stack !== false
      };
    }

    function readPreferences() {
      try {
        const raw = window.localStorage.getItem(STORE_KEY);
        return normalize(raw === null ? null : JSON.parse(raw));
      } catch {
        return normalize(null);
      }
    }

    let preferences = readPreferences();
    /** React pages observing the preferences; module-local, one per mounted form. */
    const subscribers = new Set();

    /** The banner elements in the document, in DOM order. */
    function banners() {
      return Array.prototype.slice.call(document.querySelectorAll(TOAST_SELECTOR));
    }

    /** Reflect the boolean preferences the stylesheet reads as document state. */
    function applyDocumentFlags() {
      const root = document.documentElement;
      root.setAttribute('data-dshtt-motion', preferences.motion ? '1' : '0');
      root.setAttribute('data-dshtt-tint', preferences.tint ? '1' : '0');
      root.style.setProperty('--dshtt-countdown', preferences.countdown ? '1' : '0');
    }

    /** Apply (and remember) a preference change, then re-style the live banners. */
    function applyPreferences(next) {
      preferences = normalize(next);
      try {
        window.localStorage.setItem(STORE_KEY, JSON.stringify(preferences));
      } catch {
        /* storage may be unavailable; the change still applies to this page */
      }
      applyDocumentFlags();
      restack();
      for (const notify of subscribers) notify();
    }

    // ── the dismiss timer ───────────────────────────────────────────────────

    const nativeSetTimeout = window.setTimeout;

    /** The hold the component wrote into a banner's inline style, in ms. */
    function holdOf(element) {
      const raw = element.style.getPropertyValue('--dsh-toast-hold');
      const ms = Number.parseFloat(raw);
      return Number.isFinite(ms) && ms > 0 ? ms : null;
    }

    /**
     * The banner whose scheduled dismiss this delay is, or null.
     *
     * A banner's timeout is exactly `hold + FADE_MS`, and the banner is already
     * in the document by the time the effect runs, so the value in its inline
     * style identifies it without a timer registry. Marking the banner keeps a
     * later timer from claiming it twice.
     */
    function bannerAwaiting(delay) {
      const nodes = document.querySelectorAll(TOAST_SELECTOR + ':not([' + MARK + '])');
      for (let index = 0; index < nodes.length; index += 1) {
        const node = nodes[index];
        const hold = holdOf(node);
        if (hold !== null && Math.round(hold) + FADE_MS === delay) return node;
      }
      return null;
    }

    /**
     * `window.setTimeout`, with the one rewrite this bundle needs: a banner may
     * not disappear before the configured minimum. Anything the app schedules
     * for another reason passes through untouched — the delay has to match a
     * banner that is on screen right now.
     */
    function tunedSetTimeout(handler, delay, ...rest) {
      if (typeof delay === 'number' && delay >= FADE_MS + 1500 && preferences.holdMs > 0) {
        const node = bannerAwaiting(delay);
        if (node !== null) {
          const hold = Math.max(Math.round(delay) - FADE_MS, preferences.holdMs);
          node.setAttribute(MARK, '1');
          node.style.setProperty('--dsh-toast-hold', hold + 'ms');
          delay = hold + FADE_MS;
        }
      }
      return nativeSetTimeout.call(window, handler, delay, ...rest);
    }

    // ── stacking ────────────────────────────────────────────────────────────

    function restack() {
      const nodes = banners();
      if (!preferences.stack) {
        for (const node of nodes) node.style.removeProperty('top');
        return;
      }
      let top = BASE_TOP;
      for (const node of nodes) {
        node.style.setProperty('top', top + 'px');
        const height = node.getBoundingClientRect().height;
        top += (height > 0 ? height : 44) + STACK_GAP;
      }
    }

    let restackScheduled = false;
    /** Move the stacking pass out of the current mutation, once per frame. */
    function scheduleRestack() {
      if (restackScheduled) return;
      restackScheduled = true;
      const run = () => {
        restackScheduled = false;
        restack();
      };
      if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(run);
      else run();
    }

    /** Restack whenever a banner enters or leaves the document body. */
    function watchBanners() {
      const Observer = window.MutationObserver;
      if (typeof Observer !== 'function') return null;
      const holdsBanner = (nodes) => {
        for (const node of nodes) {
          if (node === null || typeof node !== 'object' || node.nodeType !== 1) continue;
          if (typeof node.matches === 'function' && node.matches(TOAST_SELECTOR)) return true;
          if (typeof node.querySelector === 'function' && node.querySelector(TOAST_SELECTOR) !== null) return true;
        }
        return false;
      };
      const instance = new Observer((records) => {
        for (const record of records) {
          if (holdsBanner(record.addedNodes) || holdsBanner(record.removedNodes)) {
            scheduleRestack();
            return;
          }
        }
      });
      instance.observe(document.body, { childList: true });
      return instance;
    }

    // ── the stylesheet ──────────────────────────────────────────────────────
    //
    // `div[role="alert"][style*="--dsh-toast-hold"]` (specificity 0-2-1, plus the
    // motion flag below) outranks the shipped `.toast` (0-1-0) and its
    // reduced-motion rule, so the shipped animations are replaced rather than
    // doubled. The fallback in `var(--dsh-toast-hold, 3000ms)` matches the
    // component's own default.
    const css = `
/* ── the banner surface ─────────────────────────────────────────────────── */
div[role="alert"][style*="--dsh-toast-hold"] {
  top: 28px;
  gap: 12px;
  padding: 13px 18px;
  border-radius: 14px;
  border: 1px solid color-mix(in srgb, #fff 12%, transparent);
  background: color-mix(in srgb, var(--dsw-alias-toast-bg, #22293a) 88%, transparent);
  -webkit-backdrop-filter: blur(16px) saturate(140%);
  backdrop-filter: blur(16px) saturate(140%);
  box-shadow:
    inset 0 1px 0 color-mix(in srgb, #fff 10%, transparent),
    0 16px 40px -16px rgb(0 0 0 / 62%),
    0 2px 10px -2px rgb(0 0 0 / 34%);
  font-size: 13.5px;
  line-height: 21px;
  letter-spacing: 0.005em;
  transform: translateX(-50%);
  will-change: transform, opacity;
}

html[data-dshtt-tint="1"] div[role="alert"][style*="--dsh-toast-hold"] > span[aria-hidden="true"]:first-child {
  width: 24px;
  height: 24px;
  border-radius: 999px;
  background: color-mix(in srgb, currentColor 16%, transparent);
  box-shadow: inset 0 0 0 1px color-mix(in srgb, currentColor 24%, transparent);
}

/* Inline action text keeps its seat in the sentence but gains a hit target. */
div[role="alert"][style*="--dsh-toast-hold"] button[type="button"] {
  margin-inline: 3px;
  padding: 2px 8px;
  border-radius: 8px;
  color: var(--dsw-static-deepseek-400, #7aafff);
  opacity: 1;
  transition: background-color 140ms ease, color 140ms ease;
}

div[role="alert"][style*="--dsh-toast-hold"] button[type="button"]:hover {
  background: color-mix(in srgb, currentColor 16%, transparent);
  opacity: 1;
}

div[role="alert"][style*="--dsh-toast-hold"] button[type="button"]:focus-visible {
  outline: 2px solid var(--dsw-focus-ring-color, var(--dsw-alias-state-business-primary, #4d93f8));
  outline-offset: 1px;
}

/* ── the countdown line ─────────────────────────────────────────────────── */
div[role="alert"][style*="--dsh-toast-hold"]::after {
  content: "";
  position: absolute;
  inset: auto 0 0 0;
  height: 2px;
  border-radius: 0 0 13px 13px;
  background: linear-gradient(
    90deg,
    color-mix(in srgb, var(--dsw-static-deepseek-400, #7aafff) 88%, transparent),
    color-mix(in srgb, var(--dsw-static-deepseek-400, #7aafff) 30%, transparent)
  );
  transform-origin: left center;
  opacity: var(--dshtt-countdown, 1);
  animation: dsh-tt-drain var(--dsh-toast-hold, 3000ms) linear both;
  pointer-events: none;
}

/* ── the motion ─────────────────────────────────────────────────────────── */
/* The exit travels up in its first quarter and then simply waits: the owner
   unmounts the banner exactly FADE_MS after the hold, so the animation's total
   duration still has to be FADE_MS. */
@keyframes dsh-tt-in {
  from { opacity: 0; transform: translate(-50%, -34px) scale(0.965); }
  to { opacity: 1; transform: translate(-50%, 0) scale(1); }
}

@keyframes dsh-tt-out {
  0% { opacity: 1; transform: translate(-50%, 0) scale(1); }
  26% { opacity: 0; transform: translate(-50%, -26px) scale(0.985); }
  100% { opacity: 0; transform: translate(-50%, -26px) scale(0.985); visibility: hidden; }
}

@keyframes dsh-tt-fade {
  to { opacity: 0; visibility: hidden; }
}

@keyframes dsh-tt-drain {
  from { transform: scaleX(1); }
  to { transform: scaleX(0); }
}

html[data-dshtt-motion="1"] div[role="alert"][style*="--dsh-toast-hold"] {
  animation:
    dsh-tt-in 260ms cubic-bezier(0.16, 1, 0.3, 1) both,
    dsh-tt-out 1000ms cubic-bezier(0.55, 0, 0.85, 0.35) var(--dsh-toast-hold, 3000ms) forwards;
}

html[data-dshtt-motion="0"] div[role="alert"][style*="--dsh-toast-hold"] {
  animation: dsh-tt-fade 1000ms linear var(--dsh-toast-hold, 3000ms) forwards;
}

@media (prefers-reduced-motion: reduce) {
  html[data-dshtt-motion="1"] div[role="alert"][style*="--dsh-toast-hold"] {
    animation: dsh-tt-fade 1000ms linear var(--dsh-toast-hold, 3000ms) forwards;
  }
}

/* ── the Plugins page form ──────────────────────────────────────────────── */
.dshtt { display: flex; flex-direction: column; gap: 12px; max-width: 560px; }
.dshtt-lead { margin: 0; color: var(--dsw-alias-label-secondary, currentColor); font-size: 13px; line-height: 20px; }
.dshtt-row { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
.dshtt-label { color: var(--dsw-alias-label-primary, currentColor); font-size: 13px; font-weight: 600; }
.dshtt-value { color: var(--dsw-alias-label-primary, currentColor); font-size: 13px; font-variant-numeric: tabular-nums; }
.dshtt-range { width: 100%; margin: 0; accent-color: var(--dsw-alias-state-business-primary, #4d93f8); }
.dshtt-hint { margin: 0; color: var(--dsw-alias-label-tertiary, currentColor); font-size: 12px; line-height: 18px; }
.dshtt-presets { display: flex; flex-wrap: wrap; gap: 6px; }
.dshtt-preset {
  padding: 3px 10px;
  border: 1px solid var(--dsw-alias-border-l1, rgb(127 127 127 / 28%));
  border-radius: 999px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, currentColor);
  font: inherit;
  font-size: 12px;
  cursor: pointer;
  transition: background-color 140ms ease, border-color 140ms ease, color 140ms ease;
}
.dshtt-preset:hover { background: var(--dsw-alias-interactive-bg-hover, rgb(127 127 127 / 16%)); color: var(--dsw-alias-label-primary, currentColor); }
.dshtt-preset-on {
  border-color: var(--dsw-alias-state-business-primary, #4d93f8);
  color: var(--dsw-alias-state-business-primary, #4d93f8);
}
.dshtt-toggle { display: flex; align-items: flex-start; gap: 10px; cursor: pointer; }
.dshtt-toggle input { margin: 3px 0 0; accent-color: var(--dsw-alias-state-business-primary, #4d93f8); }
.dshtt-toggle-label { display: block; color: var(--dsw-alias-label-primary, currentColor); font-size: 13px; }
.dshtt-toggle-hint { display: block; color: var(--dsw-alias-label-tertiary, currentColor); font-size: 12px; line-height: 18px; }
.dshtt-reset {
  align-self: flex-start;
  padding: 4px 12px;
  border: 1px solid var(--dsw-alias-border-l1, rgb(127 127 127 / 28%));
  border-radius: 8px;
  background: transparent;
  color: var(--dsw-alias-label-secondary, currentColor);
  font: inherit;
  font-size: 12px;
  cursor: pointer;
}
.dshtt-reset:hover { background: var(--dsw-alias-interactive-bg-hover, rgb(127 127 127 / 16%)); color: var(--dsw-alias-label-primary, currentColor); }
.dshtt-note { margin: 0; color: var(--dsw-alias-label-tertiary, currentColor); font-size: 12px; }
`;

    // ── the Plugins page form ───────────────────────────────────────────────

    /** Re-render a form when the preferences change anywhere. */
    function usePreferences() {
      const [, bump] = useState(0);
      useEffect(() => {
        const notify = () => bump((value) => value + 1);
        subscribers.add(notify);
        return () => {
          subscribers.delete(notify);
        };
      }, []);
      return preferences;
    }

    /** `8000` → `8秒` / `8s`: whole seconds stay whole. */
    function secondsText(t, ms) {
      const seconds = ms / 1000;
      return (Number.isInteger(seconds) ? String(seconds) : seconds.toFixed(1)) + t('seconds');
    }

    function toggleRow(t, id, label, hint, checked, onChange) {
      return h('label', { className: 'dshtt-toggle', htmlFor: id, key: id },
        h('input', { id, type: 'checkbox', checked, onChange: (event) => onChange(event.target.checked) }),
        h('span', null,
          h('span', { className: 'dshtt-toggle-label' }, label),
          h('span', { className: 'dshtt-toggle-hint' }, hint)));
    }

    /**
     * This bundle's row page on the Plugins page (`plugins.row.config`).
     * @param props - the page's view, its locale reader, and nothing else: the
     * form keeps its state in the browser, so no Host form is involved.
     */
    function ToastTunePage(props) {
      const t = props.t;
      const current = usePreferences();
      if (props.view === 'summary') {
        return h('span', null, current.holdMs > 0
          ? t('summary', { seconds: secondsText(t, current.holdMs) })
          : t('summaryOff'));
      }
      const patch = (changes) => applyPreferences({ ...preferences, ...changes });
      return h('div', { className: 'dshtt' },
        h('p', { className: 'dshtt-lead' }, t('description')),
        h('div', { className: 'dshtt-row' },
          h('label', { className: 'dshtt-label', htmlFor: 'dshtt-hold' }, t('holdLabel')),
          h('span', { className: 'dshtt-value' }, current.holdMs > 0 ? secondsText(t, current.holdMs) : t('holdOff'))),
        h('input', {
          id: 'dshtt-hold',
          className: 'dshtt-range',
          type: 'range',
          min: HOLD_MIN,
          max: HOLD_MAX,
          step: HOLD_STEP,
          value: current.holdMs > 0 ? current.holdMs : HOLD_MIN,
          'aria-label': t('holdLabel'),
          onChange: (event) => patch({ holdMs: Number(event.target.value) })
        }),
        h('p', { className: 'dshtt-hint' }, t('holdHint')),
        h('div', { className: 'dshtt-presets' },
          PRESETS.map((ms) => h('button', {
            key: String(ms),
            type: 'button',
            className: 'dshtt-preset' + (current.holdMs === ms ? ' dshtt-preset-on' : ''),
            'aria-pressed': current.holdMs === ms,
            onClick: () => patch({ holdMs: ms })
          }, secondsText(t, ms))),
          h('button', {
            key: 'off',
            type: 'button',
            className: 'dshtt-preset' + (current.holdMs === 0 ? ' dshtt-preset-on' : ''),
            'aria-pressed': current.holdMs === 0,
            onClick: () => patch({ holdMs: 0 })
          }, t('holdOff'))),
        toggleRow(t, 'dshtt-countdown', t('countdown'), t('countdownHint'), current.countdown, (value) => patch({ countdown: value })),
        toggleRow(t, 'dshtt-motion', t('motion'), t('motionHint'), current.motion, (value) => patch({ motion: value })),
        toggleRow(t, 'dshtt-tint', t('tint'), t('tintHint'), current.tint, (value) => patch({ tint: value })),
        toggleRow(t, 'dshtt-stack', t('stack'), t('stackHint'), current.stack, (value) => patch({ stack: value })),
        h('button', { type: 'button', className: 'dshtt-reset', onClick: () => applyPreferences({ ...DEFAULTS }) }, t('reset')),
        h('p', { className: 'dshtt-note' }, t('immediate')));
    }

    // ── the bundle ──────────────────────────────────────────────────────────

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        // The slot registration below carries `locale: NS`, so the page receives
        // its own `t` seat; the bundle itself never renders copy.
        ctx.effect(() => ctx.locale.register(NS, { en, ja, zh }), 'dsh-toast-tune: dictionaries');

        const styleElement = document.createElement('style');
        styleElement.setAttribute('data-plugin-css', ID);
        styleElement.textContent = css;
        document.head.append(styleElement);
        ctx.effect(() => () => styleElement.remove(), 'dsh-toast-tune: styles');

        applyDocumentFlags();
        ctx.effect(() => () => {
          const root = document.documentElement;
          root.removeAttribute('data-dshtt-motion');
          root.removeAttribute('data-dshtt-tint');
          root.style.removeProperty('--dshtt-countdown');
        }, 'dsh-toast-tune: document flags');

        window.setTimeout = tunedSetTimeout;
        ctx.effect(() => () => {
          window.setTimeout = nativeSetTimeout;
        }, 'dsh-toast-tune: dismiss timer');

        const observer = watchBanners();
        ctx.effect(() => () => observer?.disconnect(), 'dsh-toast-tune: banner watcher');

        window.addEventListener('resize', scheduleRestack);
        ctx.effect(() => () => window.removeEventListener('resize', scheduleRestack), 'dsh-toast-tune: restack on resize');

        ctx.effect(() => ctx.slots.inject('plugins.row.config', () => ctx.slots.register({
          name: 'plugins.row.config',
          key: `${ID}#${ROW_ID}`,
          locale: NS
        }, ToastTunePage)), 'dsh-toast-tune: settings page');
      },
      /** Test seam: the seams and pure helpers, so the bundle is verifiable offline. */
      __test: {
        id: ID,
        namespace: NS,
        rowId: ROW_ID,
        storeKey: STORE_KEY,
        toastSelector: TOAST_SELECTOR,
        mark: MARK,
        fadeMs: FADE_MS,
        holdMin: HOLD_MIN,
        holdMax: HOLD_MAX,
        holdStep: HOLD_STEP,
        defaults: DEFAULTS,
        presets: PRESETS,
        css,
        en,
        ja,
        zh,
        clampHold,
        normalize,
        readPreferences,
        preferences: () => preferences,
        applyPreferences,
        applyDocumentFlags,
        restack,
        scheduleRestack,
        holdOf,
        bannerAwaiting,
        tunedSetTimeout,
        toastTunePage: ToastTunePage
      }
    };
  }
});

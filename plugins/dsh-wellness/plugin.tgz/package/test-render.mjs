/**
 * Render test for the Client half of `@local/dsh-wellness`.
 *
 * A miniature React drives the two real slot components the bundle registers —
 * the notification cell and the settings row — through mount and interaction.
 * Nothing about either component is re-implemented here, and the copy asserted
 * below is the bundle's own Japanese dictionary, resolved through a faithful
 * `translate()` (placeholders, key as last resort).
 *
 *   node test-render.mjs
 */
import assert from 'node:assert/strict';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// --- browser surface --------------------------------------------------------

const appended = [];
const removed = [];
const listeners = new Map();
let timers = new Map();
let timerId = 0;
let fetchCalls = [];

globalThis.document = {
  createElement: () => ({
    attrs: {},
    textContent: '',
    setAttribute(key, value) {
      this.attrs[key] = value;
    },
    remove() {
      removed.push(this);
    },
  }),
  head: { append: (element) => appended.push(element) },
  documentElement: { hasAttribute: () => false },
  visibilityState: 'visible',
  addEventListener(event, callback) {
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(callback);
  },
  removeEventListener(event, callback) {
    listeners.get(event)?.delete(callback);
  },
};
globalThis.window = {
  setTimeout: (fn, ms) => {
    timerId += 1;
    timers.set(timerId, { fn, ms });
    return timerId;
  },
  clearTimeout: (id) => timers.delete(id),
  addEventListener: () => {},
  removeEventListener: () => {},
  localStorage: { getItem: () => null, setItem: () => {}, removeItem: () => {} },
};
// node 24 ships a getter-only `navigator`, so the stub is defined, not assigned.
Object.defineProperty(globalThis, 'navigator', { value: {}, configurable: true, writable: true });

const flush = async () => {
  for (let round = 0; round < 4; round += 1) await new Promise((resolve) => setImmediate(resolve));
};

const specs = [];
globalThis.window.__ModuleLoader__ = { load: (spec) => specs.push(spec) };

// --- miniature React (the contract the auto-kill/clock render tests use) -----

function depsEqual(a, b) {
  if (a === undefined || b === undefined) return false;
  if (a.length !== b.length) return false;
  return a.every((value, index) => Object.is(value, b[index]));
}

let activeHooks = null;

const ReactShim = {
  createElement(type, props, ...children) {
    const full = { ...(props ?? {}), children: children.length <= 1 ? children[0] : children };
    return typeof type === 'function' ? type(full) : { type, props: full };
  },
  useState: (initial) => activeHooks.useState(initial),
  useRef: (initial) => activeHooks.useRef(initial),
  useMemo: (fn, deps) => activeHooks.useMemo(fn, deps),
  useCallback: (fn, deps) => activeHooks.useCallback(fn, deps),
  useEffect: (fn, deps) => activeHooks.useEffect(fn, deps),
};

function createUi() {
  const slots = [];
  const effects = [];
  let cursor = 0;
  let pending = [];
  const hooks = {
    useState(initial) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = typeof initial === 'function' ? initial() : initial;
      return [slots[index], (next) => {
        slots[index] = typeof next === 'function' ? next(slots[index]) : next;
      }];
    },
    useRef(initial) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = { current: initial };
      return slots[index];
    },
    useMemo(fn, deps) {
      const index = cursor++;
      const previous = slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      const value = fn();
      slots[index] = { deps, value };
      return value;
    },
    useCallback(fn, deps) {
      const index = cursor++;
      const previous = slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      slots[index] = { deps, value: fn };
      return fn;
    },
    useEffect(fn, deps) {
      const index = cursor++;
      const previous = effects[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return;
      pending.push({ index, deps, fn, cleanup: previous?.cleanup });
    },
  };
  return {
    render(component, props) {
      cursor = 0;
      pending = [];
      activeHooks = hooks;
      let tree;
      try {
        tree = component(props);
      } finally {
        activeHooks = null;
      }
      const toRun = pending;
      pending = [];
      for (const effect of toRun) {
        effect.cleanup?.();
        effects[effect.index] = { deps: effect.deps, fn: effect.fn, cleanup: effect.fn() ?? undefined };
      }
      return tree;
    },
    unmount() {
      for (const effect of effects) effect?.cleanup?.();
    },
  };
}

function text(node) {
  if (node === null || node === undefined || typeof node === 'boolean') return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(text).join(' ');
  return text(node.props?.children);
}

function findAll(node, predicate, found = []) {
  if (node === null || node === undefined || typeof node !== 'object') return found;
  if (Array.isArray(node)) {
    for (const child of node) findAll(child, predicate, found);
    return found;
  }
  if (node.type !== undefined && predicate(node)) found.push(node);
  findAll(node.props?.children, predicate, found);
  return found;
}

const byType = (name) => (node) => node.type === name;

// --- the bundle under test --------------------------------------------------

const primitives = {
  Toast: (props) => ({ type: 'Toast', props }),
  Button: (props) => ({ type: 'Button', props }),
  Switch: (props) => ({ type: 'Switch', props }),
  SegmentedControl: (props) => ({ type: 'SegmentedControl', props }),
  Checkbox: (props) => ({ type: 'Checkbox', props }),
  IconClockOutlineRegular: (props) => ({ type: 'IconClockOutlineRegular', props }),
};

function createFakeStoreModule(seed) {
  const records = [];
  return {
    records,
    createSnapshotStore(init, opts) {
      const record = { key: opts?.persist?.name ?? null, writes: [] };
      records.push(record);
      let state = typeof seed === 'function' ? seed(init()) : init();
      const subscribers = new Set();
      return {
        getSnapshot: () => state,
        subscribe: (fn) => {
          subscribers.add(fn);
          return () => subscribers.delete(fn);
        },
        update: (mutator) => {
          mutator(state);
        },
        set: (next) => {
          state = next;
          record.writes.push(next);
          for (const fn of [...subscribers]) fn(state);
        },
      };
    },
  };
}

async function loadBundle(tag, seed) {
  const store = createFakeStoreModule(seed);
  const before = specs.length;
  await import(`./client.js?render=${tag}`);
  assert.equal(specs.length, before + 1, 'the bundle registered itself');
  const spec = specs[specs.length - 1];
  const mod = spec.factory((name) => {
    if (name === 'react') return ReactShim;
    if (name === '@deepseek-ai/dsh-client-ui-primitives') return primitives;
    if (name === '@deepseek-ai/dsh-client-store') return store;
    throw new Error(`unexpected require: ${name}`);
  });
  return { mod, store };
}

/**
 * Apply the bundle and hand back the two registered components, so the render
 * tests drive exactly what the app would mount — not a private entry point.
 */
async function mountPlugin(tag, options = {}) {
  const { mod, store } = await loadBundle(tag, options.seed);
  const registrations = [];
  mod.apply({
    logger: { info: () => {} },
    locale: { register: () => () => {}, bind: () => (key) => key, getLocale: () => ({ active: 'ja' }) },
    slots: {
      inject: (_name, callback) => callback(),
      register: (registration, component) => {
        registrations.push({ options: registration, component });
        return () => {};
      },
    },
    effect: (fn) => {
      const dispose = fn();
      return typeof dispose === 'function' ? dispose : () => {};
    },
  });
  const W = mod.__test;
  const dict = W.dictionaries.ja;
  const t = (key, params) => {
    const template = dict[key] ?? key;
    if (!params) return template;
    return template.replace(/\{(\w+)\}/g, (match, name) => (name in params ? String(params[name]) : match));
  };
  return {
    mod,
    W,
    store,
    t,
    cell: registrations.find((entry) => entry.options.name === 'shell.overlay').component,
    row: registrations.find((entry) => entry.options.name === 'settings.general.item').component,
  };
}

const uptimePayload = (uptimeMs) => ({ ok: true, status: 200, json: async () => ({ ok: true, data: { uptimeMs } }) });

function seedCapability() {
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 'z'.repeat(48) };
}

/** The `document`-level surface of a page with no caption strip and no globals. */
function resetPage() {
  timers = new Map();
  timerId = 0;
  listeners.clear();
  appended.length = 0;
  removed.length = 0;
  fetchCalls = [];
  globalThis.document.visibilityState = 'visible';
}

const TWO_HOURS = 2 * 60 * 60_000;

// ---------------------------------------------------------------------------

test('render: with nothing due the notification cell renders nothing at all', async () => {
  resetPage();
  seedCapability();
  const before = fetchCalls;
  globalThis.fetch = async (...args) => {
    before.push(args);
    return uptimePayload(20 * 60_000);
  };
  const { cell, W, t } = await mountPlugin('cell-quiet');
  await flush();
  assert.equal(W.pending(), null);
  const ui = createUi();
  assert.equal(ui.render(cell, { t }), null, 'no suggestion, no DOM');
  ui.unmount();
});

test('render: a due session shows the shipped Toast, never a modal and never focus', async () => {
  resetPage();
  seedCapability();
  globalThis.fetch = async () => uptimePayload(TWO_HOURS);
  const { cell, W, t } = await mountPlugin('cell-toast');
  await flush();
  const pending = W.pending();
  assert.equal(pending.id, 'coffee');
  assert.equal(pending.atMs > 0, true);

  const ui = createUi();
  const tree = ui.render(cell, { t });
  const toasts = findAll(tree, byType('Toast'));
  assert.equal(toasts.length, 1, 'exactly one banner');
  const props = toasts[0].props;

  assert.match(props.text, /2時間/, 'the banner names how long the session has run');
  assert.match(props.text, /コーヒー/);
  assert.equal(typeof props.holdMs, 'number');
  assert.ok(props.holdMs >= 6000, 'long enough to read, still an auto-expiring banner');
  assert.equal(props.key, `dsh-wellness-${String(pending.seq)}`, 'a per-show key restarts the cycle');
  assert.equal(props.actions.length, 2);
  assert.equal(props.actions[0].label, '閉じる');
  assert.equal(props.actions[1].prefix, 'または');
  assert.equal(props.actions[1].label, '30分スヌーズ', 'the N comes from the stored preference');
  assert.equal(typeof props.actions[0].onClick, 'function');
  assert.equal(typeof props.onDone, 'function');

  // Unobtrusive: nothing here is modal, nothing grabs focus, nothing is click-through-blocking.
  assert.equal('autoFocus' in props, false);
  assert.equal(findAll(tree, (node) => node.props?.autoFocus !== undefined || node.props?.autoFocus === true).length, 0);
  assert.equal(findAll(tree, (node) => node.type === 'Modal').length, 0);
  assert.equal(findAll(tree, (node) => node.type === 'Toast').length, 1, 'one banner, no stacking');

  // It auto-expires through the primitive's own onDone.
  props.onDone();
  assert.equal(ui.render(cell, { t }), null, 'onDone unmounts the banner');
  ui.unmount();
});

test('render: the banner can be dismissed, snoozed, or left to expire', async () => {
  resetPage();
  seedCapability();
  globalThis.fetch = async () => uptimePayload(TWO_HOURS);
  const { cell, W, t } = await mountPlugin('cell-actions');
  await flush();
  const ui = createUi();
  let tree = ui.render(cell, { t });
  tree = ui.render(cell, { t });
  const actions = findAll(tree, byType('Toast'))[0].props.actions;

  actions[0].onClick();
  assert.equal(W.pending(), null, 'dismiss closes the banner');
  assert.equal(W.readState().snoozeUntil, 0, 'dismiss is not a snooze');
  assert.equal(ui.render(cell, { t }), null);

  // The next due suggestion offers the configured snooze, and it persists.
  fetchCalls = [];
  W.writeState({ ...W.readState(), lastSuggestionAt: 0, suggestedCount: 0, snoozeUntil: 0 });
  await W.evaluateDue();
  const again = ui.render(cell, { t });
  const snooze = findAll(again, byType('Toast'))[0].props.actions[1];
  const before = Date.now();
  snooze.onClick();
  const snoozed = W.readState();
  assert.equal(W.pending(), null);
  assert.ok(snoozed.snoozeUntil >= before + 29 * 60_000, 'N minutes of quiet, remembered across a restart');
  assert.equal(snoozed.snoozeUntil <= before + 31 * 60_000, true);
  ui.unmount();
});

test('render: the settings row reads as a native general-settings row', async () => {
  resetPage();
  seedCapability();
  globalThis.fetch = async () => uptimePayload(3_723_000);
  const { row, W, t } = await mountPlugin('row-content');
  await flush();
  const ui = createUi();
  const tree = ui.render(row, { t });

  const switches = findAll(tree, byType('Switch'));
  assert.equal(switches.length, 2, 'enable + long-session suggestions');
  assert.equal(switches[0].props.checked, true);
  assert.equal(typeof switches[0].props.label, 'string');
  assert.equal(switches[0].props.label.length > 0, true);

  const segmented = findAll(tree, byType('SegmentedControl'));
  assert.equal(segmented.length, 2, 'interval + snooze length');
  assert.equal(segmented[0].props.value, 3_600_000);
  assert.deepEqual(segmented[0].props.options.map((option) => option.value), [1_800_000, 3_600_000, 7_200_000]);
  assert.deepEqual(segmented[0].props.options.map((option) => option.label), ['30分', '60分', '120分']);
  assert.equal(typeof segmented[0].props.label, 'string');
  assert.deepEqual(segmented[1].props.options.map((option) => option.value), [10, 30, 60]);

  // With a real reading the row shows it; the countdown comes from the seam.
  const body = text(tree);
  assert.match(body, /連続起動/);
  assert.match(body, /1時間2分/);
  assert.match(body, /次の提案/);
  assert.equal(body.includes('未取得'), false);

  ui.unmount();
});

test('render: no reading renders 未取得 and offers a real retry button', async () => {
  resetPage();
  seedCapability();
  globalThis.fetch = async () => {
    throw new Error('ECONNREFUSED');
  };
  const { row, W, t } = await mountPlugin('row-unavailable');
  await flush();
  assert.equal(W.session().uptimeMs, null);
  const ui = createUi();
  const tree = ui.render(row, { t });
  assert.match(text(tree), /未取得/);
  assert.equal(text(tree).includes('ECONNREFUSED'), false, 'never an internal error string in the UI');

  const retry = findAll(tree, byType('Button')).find((node) => node.props['aria-label'] === '再取得');
  assert.notEqual(retry, undefined, 'the retry is a real button with an accessible name');
  globalThis.fetch = async () => uptimePayload(60_000);
  retry.props.onClick();
  await flush();
  assert.equal(W.session().uptimeMs, 60_000, 'retrying re-reads the route');
  assert.match(text(ui.render(row, { t })), /連続起動/);
  ui.unmount();
});

test('render: the settings row writes every preference through to the store', async () => {
  resetPage();
  seedCapability();
  globalThis.fetch = async () => uptimePayload(60_000);
  const { row, W, store, t } = await mountPlugin('row-writes');
  await flush();
  const ui = createUi();
  let tree = ui.render(row, { t });

  findAll(tree, byType('Switch'))[0].props.onChange(false);
  assert.equal(W.readState().enabled, false);
  tree = ui.render(row, { t });
  assert.equal(findAll(tree, byType('Switch'))[0].props.checked, false, 'the row follows the store');

  findAll(tree, byType('SegmentedControl'))[0].props.onChange(1_800_000);
  assert.equal(W.readState().intervalMs, 1_800_000, 'the frequency is configurable');
  findAll(ui.render(row, { t }), byType('SegmentedControl'))[1].props.onChange(60);
  assert.equal(W.readState().snoozeMinutes, 60);
  findAll(ui.render(row, { t }), byType('Switch'))[1].props.onChange(false);
  assert.equal(W.readState().longSession, false, 'long-session suggestions can be turned off');

  assert.ok(store.records[0].writes.length >= 4, 'every change was persisted');
  assert.equal(store.records[0].key, 'dsh.wellness.state');

  // Reset restores the shipped defaults, corrupt-value recovery included.
  const reset = findAll(ui.render(row, { t }), byType('Button')).find((node) => node.props['aria-label'] === '設定を既定に戻す');
  reset.props.onClick();
  assert.deepEqual(W.readState(), W.defaults);
});

test('render: snooze can be lifted from the row, and the button reflects the state', async () => {
  resetPage();
  seedCapability();
  globalThis.fetch = async () => uptimePayload(60_000);
  const { row, W, t } = await mountPlugin('row-snooze');
  await flush();
  const ui = createUi();

  const findClear = (tree) => findAll(tree, byType('Button')).find((node) => node.props['aria-label'] === 'スヌーズを解除');
  assert.equal(findClear(ui.render(row, { t })).props.disabled, true, 'nothing to clear yet');

  W.writeState(W.snoozeFor(W.readState(), Date.now(), 30));
  const tree = ui.render(row, { t });
  assert.equal(findClear(tree).props.disabled, false);
  assert.match(text(tree), /スヌーズ中/);
  findClear(tree).props.onClick();
  assert.equal(W.readState().snoozeUntil, 0);
  assert.equal(findClear(ui.render(row, { t })).props.disabled, true);
  ui.unmount();
});

test('render: every clickable is a real primitive button with an accessible name', async () => {
  resetPage();
  seedCapability();
  globalThis.fetch = async () => uptimePayload(60_000);
  const { row, t } = await mountPlugin('row-a11y');
  await flush();
  const tree = createUi().render(row, { t });

  const buttons = findAll(tree, byType('Button'));
  assert.ok(buttons.length >= 3, 'retry, clear-snooze and reset');
  for (const button of buttons) {
    assert.equal(typeof button.props['aria-label'], 'string');
    assert.ok(button.props['aria-label'].length > 0);
    assert.equal(typeof button.props.onClick, 'function');
  }
  for (const node of findAll(tree, (candidate) => candidate.type === 'div' || candidate.type === 'span')) {
    assert.equal(typeof node.props?.onClick, 'undefined', 'no clickable div: only real buttons');
  }
});

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

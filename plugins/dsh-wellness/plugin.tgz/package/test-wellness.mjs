/**
 * Offline test for `@local/dsh-wellness`: the pure logic seams (which the whole
 * feature is decided by) and the Host half (the uptime route).
 *
 * The bundle is a `window.__ModuleLoader__.load({ id, factory })` call, so this
 * test fakes the module loader, React, the primitives and the client store, then
 * reads the shipped seams out of `mod.__test`. Nothing is re-implemented here.
 *
 *   node test-wellness.mjs
 */
import assert from 'node:assert/strict';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// --- the browser surface the bundle touches while materializing --------------

const appended = [];
globalThis.document = {
  createElement: () => ({
    attrs: {},
    textContent: '',
    setAttribute(key, value) {
      this.attrs[key] = value;
    },
    remove() {},
  }),
  head: { append: (element) => appended.push(element) },
  documentElement: { hasAttribute: () => false },
  visibilityState: 'visible',
  addEventListener: () => {},
  removeEventListener: () => {},
};
globalThis.window = {
  addEventListener: () => {},
  removeEventListener: () => {},
  setTimeout: () => 0,
  clearTimeout: () => {},
  localStorage: { getItem: () => null, setItem: () => {}, removeItem: () => {} },
};
// node 24 ships a getter-only `navigator`, so the stub is defined, not assigned.
Object.defineProperty(globalThis, 'navigator', { value: {}, configurable: true, writable: true });

const specs = [];
globalThis.window.__ModuleLoader__ = { load: (spec) => specs.push(spec) };

// --- the three platform seeds the bundle may ask for ------------------------

/** A faithful core of `createSnapshotStore`: get/subscribe/set/update + a write log. */
function createFakeClientStore() {
  const records = [];
  return {
    records,
    store: {
      createSnapshotStore(init, opts) {
        const record = { key: opts?.persist?.name ?? null, writes: [] };
        records.push(record);
        let state = init();
        const subscribers = new Set();
        return {
          getSnapshot: () => state,
          subscribe: (fn) => {
            subscribers.add(fn);
            return () => subscribers.delete(fn);
          },
          update: (mutator) => {
            mutator(state);
          },
          set: (next) => {
            state = next;
            record.writes.push(next);
            for (const fn of [...subscribers]) fn(state);
          },
        };
      },
    },
  };
}

const clientStore = createFakeClientStore();
const DICTS = {};
const React = {
  createElement: (type, props, ...children) => ({ type, props: { ...(props ?? {}), children } }),
  useState: () => [undefined, () => {}],
  useEffect: () => {},
  useRef: () => ({ current: null }),
  useCallback: (fn) => fn,
  useMemo: (fn) => fn(),
};
const primitives = {
  Toast: (props) => ({ type: 'Toast', props }),
  Button: (props) => ({ type: 'Button', props }),
  Switch: (props) => ({ type: 'Switch', props }),
  SegmentedControl: (props) => ({ type: 'SegmentedControl', props }),
  Checkbox: (props) => ({ type: 'Checkbox', props }),
  IconClockOutlineRegular: (props) => ({ type: 'IconClockOutlineRegular', props }),
};

await import('./client.js');
assert.equal(specs.length, 1, 'the bundle registers exactly one module');
const spec = specs[0];

const mod = spec.factory((name) => {
  if (name === 'react') return React;
  if (name === '@deepseek-ai/dsh-client-ui-primitives') return primitives;
  if (name === '@deepseek-ai/dsh-client-store') return clientStore.store;
  throw new Error(`unexpected require: ${name}`);
});

const W = mod.__test;
const { defaults: DEFAULTS } = W;

/** The shipped `translate()` contract: `{name}` placeholders, key as last resort. */
function binder(dict) {
  return (key, params) => {
    const template = dict[key] ?? key;
    if (!params) return template;
    return template.replace(/\{(\w+)\}/g, (match, name) => (name in params ? String(params[name]) : match));
  };
}

// ---------------------------------------------------------------------------
// pure logic: the stored shape

test('logic: a missing, corrupt or foreign stored value falls back to defaults', () => {
  const expected = { ...DEFAULTS };
  for (const raw of [undefined, null, '', 'nonsense', '{not json', 42, [], '[]', {}, { nothing: 'here' }, true]) {
    assert.deepEqual(W.normalizeState(raw), expected, `raw=${JSON.stringify(raw) ?? String(raw)}`);
  }
});

test('logic: a valid-JSON but partial/old value is completed, not trusted', () => {
  const state = W.normalizeState('{"enabled":false}');
  assert.equal(state.enabled, false, 'a stored boolean is honoured');
  assert.equal(state.intervalMs, DEFAULTS.intervalMs, 'the missing fields come back as defaults');
  assert.equal(state.longSession, DEFAULTS.longSession);
  assert.equal(state.version, 1, 'the current version is stamped on');
  assert.deepEqual(Object.keys(state).sort(), Object.keys(DEFAULTS).sort(), 'the shape is complete');
});

test('logic: garbage fields are clamped into range, never carried through', () => {
  const state = W.normalizeState({
    version: 'old',
    enabled: 'yes',
    intervalMs: -1,
    longSession: 'no',
    snoozeMinutes: 9999,
    snoozeUntil: 'soon',
    lastSuggestionAt: -5,
    suggestedCount: -3.7,
  });
  assert.equal(state.enabled, true, 'only an explicit false disables');
  assert.equal(state.longSession, true, 'only an explicit false turns the long-session tiers off');
  assert.ok(state.intervalMs >= W.minIntervalMs && state.intervalMs <= W.maxIntervalMs);
  assert.ok(state.snoozeMinutes >= 1 && state.snoozeMinutes <= W.maxSnoozeMinutes);
  assert.equal(state.snoozeUntil, 0);
  assert.equal(state.lastSuggestionAt, 0);
  assert.ok(Number.isInteger(state.suggestedCount) && state.suggestedCount >= 0);
});

test('logic: the suggestion counter stays bounded (no unbounded state)', () => {
  const state = W.normalizeState({ suggestedCount: 999_999 });
  assert.ok(state.suggestedCount < 1000, 'the rotation counter wraps instead of growing');
});

// ---------------------------------------------------------------------------
// pure logic: when a suggestion is due

const T = 1_700_000_000_000; // a fixed "now" so nothing depends on the wall clock

test('logic: nothing is due before one interval of continuous uptime', () => {
  assert.deepEqual(W.dueSuggestions(59 * 60_000, 0, DEFAULTS, T), []);
  assert.deepEqual(W.dueSuggestions(60 * 60_000 - 1, 0, DEFAULTS, T), []);
  assert.deepEqual(W.dueSuggestions(60 * 60_000, 0, DEFAULTS, T), ['coffee'], 'one hour is the first coffee break');
});

test('logic: the long-session tiers unlock with uptime, in order', () => {
  const at = (minutes) => W.dueSuggestions(minutes * 60_000, 0, DEFAULTS, T);
  assert.deepEqual(at(120), ['coffee', 'stretch']);
  assert.deepEqual(at(180), ['coffee', 'stretch', 'water']);
  assert.deepEqual(at(240), ['coffee', 'stretch', 'water', 'eyes']);
  assert.deepEqual(at(600), ['coffee', 'stretch', 'water', 'eyes'], 'the pool is capped: variety stays modest');
});

test('logic: long-session suggestions can be switched off', () => {
  const off = { ...DEFAULTS, longSession: false };
  assert.deepEqual(W.dueSuggestions(6 * 60 * 60_000, 0, off, T), ['coffee']);
});

test('logic: the interval restarts from the last suggestion, not from uptime', () => {
  const last = T;
  assert.deepEqual(W.dueSuggestions(90 * 60_000, last, DEFAULTS, T + 30 * 60_000), []);
  assert.deepEqual(W.dueSuggestions(90 * 60_000, last, DEFAULTS, T + 59 * 60_000), []);
  assert.deepEqual(W.dueSuggestions(120 * 60_000, last, DEFAULTS, T + 60 * 60_000), ['coffee', 'stretch']);
});

test('logic: disabled, snoozed and unknown-uptime sessions never fire', () => {
  assert.deepEqual(W.dueSuggestions(3 * 60 * 60_000, 0, { ...DEFAULTS, enabled: false }, T), []);
  const snoozed = W.snoozeFor(DEFAULTS, T, 30);
  assert.deepEqual(W.dueSuggestions(3 * 60 * 60_000, 0, snoozed, T + 10 * 60_000), [], 'snoozed: silent');
  assert.deepEqual(W.dueSuggestions(3 * 60 * 60_000, 0, snoozed, T + 30 * 60_000), ['coffee', 'stretch', 'water']);
  for (const uptime of [null, undefined, NaN, -1, 'x']) {
    assert.deepEqual(W.dueSuggestions(uptime, 0, DEFAULTS, T), [], `uptime=${String(uptime)} is not a number`);
  }
});

test('logic: successive suggestions rotate through the unlocked pool', () => {
  const pool = ['coffee', 'stretch', 'water', 'eyes'];
  assert.deepEqual(
    [0, 1, 2, 3, 4, 5].map((count) => W.selectSuggestion(pool, count)),
    ['coffee', 'stretch', 'water', 'eyes', 'coffee', 'stretch'],
  );
  assert.equal(W.selectSuggestion([], 3), null);
  assert.equal(W.selectSuggestion(['coffee'], 7), 'coffee');
});

test('logic: the next-due countdown is the later of the interval and the snooze', () => {
  assert.equal(W.nextDueInMs(30 * 60_000, 0, DEFAULTS, T), 30 * 60_000);
  assert.equal(W.nextDueInMs(null, 0, DEFAULTS, T), null, 'no uptime reading, no claim');
  assert.equal(W.nextDueInMs(null, T, DEFAULTS, T + 10 * 60_000), 50 * 60_000, 'the interval restarts from the last one');
  assert.equal(W.nextDueInMs(60 * 60_000, 0, { ...DEFAULTS, enabled: false }, T), null);
  const snoozed = W.snoozeFor(DEFAULTS, T, 30);
  assert.equal(W.nextDueInMs(30 * 60_000, 0, snoozed, T), 30 * 60_000, 'a fresh snooze is not shorter than the interval');
  assert.equal(W.nextDueInMs(120 * 60_000, 0, snoozed, T + 25 * 60_000), 5 * 60_000, 'the snooze tail wins while it lasts');
});

// ---------------------------------------------------------------------------
// pure logic: snooze

test('logic: snooze defers for N minutes and is part of the persisted state', () => {
  const snoozed = W.snoozeFor(DEFAULTS, T, 30);
  assert.equal(snoozed.snoozeUntil, T + 30 * 60_000);
  assert.equal(W.isSnoozed(snoozed, T), true);
  assert.equal(W.isSnoozed(snoozed, T + 29 * 60_000), true);
  assert.equal(W.isSnoozed(snoozed, T + 30 * 60_000), false, 'the snooze expires on its own');
  assert.equal(W.isSnoozed(DEFAULTS, T), false);
  assert.deepEqual(W.clearSnooze(snoozed).snoozeUntil, 0);
  assert.equal(W.isSnoozed(W.clearSnooze(snoozed), T), false);
  // A snooze is a whole-value state change: it survives normalize (a restart round trip).
  assert.equal(W.normalizeState(JSON.stringify(snoozed)).snoozeUntil, snoozed.snoozeUntil);
});

// ---------------------------------------------------------------------------
// pure logic: copy

test('logic: durations read as hours/minutes/seconds in the active locale', () => {
  assert.deepEqual(W.durationParts(0), { hours: 0, minutes: 0, seconds: 0 });
  assert.deepEqual(W.durationParts(90_000), { hours: 0, minutes: 1, seconds: 30 });
  assert.deepEqual(W.durationParts(3_723_000), { hours: 1, minutes: 2, seconds: 3 });
  assert.deepEqual(W.durationParts(90_061_000), { hours: 25, minutes: 1, seconds: 1 }, 'days fold into hours');
  assert.deepEqual(W.durationParts('x'), { hours: 0, minutes: 0, seconds: 0 });
  const ja = binder(W.dictionaries.ja);
  const en = binder(W.dictionaries.en);
  assert.equal(W.durationText(3_723_000, ja), '1時間2分');
  assert.equal(W.durationText(90_000, ja), '1分');
  assert.equal(W.durationText(5_000, ja), '5秒');
  assert.equal(W.durationText(3_723_000, en), '1h 2m');
  assert.equal(W.durationText(90_000, en), '1m');
});

test('logic: every tier has copy in both dictionaries, and the key sets match', () => {
  const ja = W.dictionaries.ja;
  const en = W.dictionaries.en;
  assert.deepEqual(Object.keys(ja).sort(), Object.keys(en).sort());
  for (const tier of W.tiers) {
    assert.equal(typeof ja[`suggest.${tier.id}`], 'string', `ja copy for ${tier.id}`);
    assert.equal(typeof en[`suggest.${tier.id}`], 'string', `en copy for ${tier.id}`);
  }
  const text = W.suggestionText('coffee', '1時間2分', binder(ja));
  assert.match(text, /1時間2分/);
  assert.equal(W.suggestionText('eyes', '3時間0分', binder(en)), W.dictionaries.en['suggest.eyes'].replace('{elapsed}', '3時間0分'));
});

test('logic: the missing-reading copy is exactly 未取得 in Japanese', () => {
  assert.equal(W.dictionaries.ja.statusUnknown, '未取得');
  assert.equal(W.dictionaries.ja.unavailable.includes('bootstrap'), false, 'no internal error string');
});

// ---------------------------------------------------------------------------
// host half: `./index.js`

const host = await import('./index.js');

test('host: the token fence refuses cross-site, missing, short and wrong tokens', () => {
  const token = 'a'.repeat(48);
  assert.equal(host.authorized({ headers: { [host.TOKEN_HEADER]: token } }, token), true);
  assert.equal(host.authorized({ headers: { [host.TOKEN_HEADER]: token, 'sec-fetch-site': 'cross-site' } }, token), false);
  assert.equal(host.authorized({ headers: {} }, token), false);
  assert.equal(host.authorized({ headers: { [host.TOKEN_HEADER]: 'short' } }, token), false);
  assert.equal(host.authorized({ headers: { [host.TOKEN_HEADER]: 'b'.repeat(48) } }, token), false);
  assert.equal(host.authorized(undefined, token), false);
});

test('host: the uptime route answers only the token holder', () => {
  const token = 'c'.repeat(48);
  const handler = host.createRouteHandler(() => host.uptimeSnapshot(1_700_000_000_000, () => 1234.5), token);
  const ok = reply();
  handler({ method: 'GET', headers: { [host.TOKEN_HEADER]: token } }, ok.res);
  assert.equal(ok.res.status, 200);
  assert.equal(ok.res.headers['cache-control'], 'no-store');
  assert.deepEqual(ok.body.data.uptimeMs, 1_234_500);
  assert.equal(ok.body.data.startedAt, 1_700_000_000_000 - 1_234_500);
  assert.equal(typeof ok.body.data.pid, 'number');

  const denied = reply();
  handler({ method: 'GET', headers: {} }, denied.res);
  assert.equal(denied.res.status, 403);
  assert.equal(denied.body.error, 'forbidden');

  const wrong = reply();
  handler({ method: 'POST', headers: { [host.TOKEN_HEADER]: token } }, wrong.res);
  assert.equal(wrong.res.status, 405);
  assert.equal(wrong.body.error, 'method-not-allowed');
});

test('host: the token route is guarded by the GUI cookie, not by a peer token', () => {
  const token = 'd'.repeat(48);
  const open = reply();
  host.createTokenHandler(token, () => true)({ method: 'GET', headers: {} }, open.res);
  assert.equal(open.res.status, 200);
  assert.deepEqual(open.body.data, { path: host.ROUTE_PATH, token });

  const denied = reply();
  host.createTokenHandler(token, () => false)({ method: 'GET', headers: {} }, denied.res);
  assert.equal(denied.res.status, 401);
  assert.equal(denied.body.error, 'unauthorized');

  const thrown = reply();
  host.createTokenHandler(token, () => {
    throw new Error('no connection service');
  })({ method: 'GET', headers: {} }, thrown.res);
  assert.equal(thrown.res.status, 401, 'a broken guard refuses instead of opening');

  const crossSite = reply();
  host.createTokenHandler(token, () => true)({ method: 'GET', headers: { 'sec-fetch-site': 'cross-site' } }, crossSite.res);
  assert.equal(crossSite.res.status, 403);

  const post = reply();
  host.createTokenHandler(token, () => true)({ method: 'POST', headers: {} }, post.res);
  assert.equal(post.res.status, 405);
});

test('host: uptime is the host process itself, and an unusable reading is null', () => {
  const snapshot = host.uptimeSnapshot();
  assert.ok(Number.isFinite(snapshot.uptimeMs) && snapshot.uptimeMs > 0, 'process.uptime() is a real number');
  assert.equal(snapshot.pid, process.pid);
  assert.ok(snapshot.startedAt < Date.now());
  assert.equal(host.uptimeSnapshot(1234, () => NaN).uptimeMs, null, 'never a fabricated number');
  assert.equal(host.uptimeSnapshot(1234, () => -1).uptimeMs, null);
  assert.equal(host.uptimeSnapshot(1234, () => 'x').uptimeMs, null);
  const later = host.uptimeSnapshot().uptimeMs;
  assert.ok(later >= snapshot.uptimeMs, 'uptime only grows');
});

test('host: apply registers both routes and the bootstrap row that carries the token', () => {
  const registered = [];
  const injections = [];
  const effects = [];
  const ctx = {
    logger: { info: () => {} },
    inject: (services, callback) => {
      assert.deepEqual(services, ['webServer']);
      callback({
        webServer: {
          register: (route) => {
            registered.push(route);
            return () => {};
          },
        },
        effect: (fn, label) => {
          effects.push(label);
          fn();
        },
        on: (event, handler) => injections.push({ event, handler }),
        get: () => undefined,
      });
    },
  };
  host.apply(ctx);

  assert.deepEqual(registered.map((route) => route.path), [host.ROUTE_PATH, host.TOKEN_PATH]);
  assert.equal(registered.every((route) => route.kind === 'exact'), true);
  assert.deepEqual(effects, ['dsh-wellness: route', 'dsh-wellness: token route']);

  assert.equal(injections.length, 1);
  assert.equal(injections[0].event, 'webserver/index-inject');
  const rows = [];
  injections[0].handler(rows);
  assert.deepEqual(rows, [{ kind: 'global', name: host.BOOTSTRAP_KEY, value: { path: host.ROUTE_PATH, token: rows[0].value.token } }]);
  assert.equal(rows[0].value.token.length, 48);

  // The row's token is the route's token: the handshake and the data route agree.
  const ok = reply();
  registered[0].handler({ method: 'GET', headers: { [host.TOKEN_HEADER]: rows[0].value.token } }, ok.res);
  assert.equal(ok.res.status, 200);
  assert.ok(ok.body.data.uptimeMs > 0);
});

// --- helpers ---------------------------------------------------------------

function reply() {
  const res = {
    status: 0,
    headers: null,
    raw: '',
    writeHead(status, headers) {
      this.status = status;
      this.headers = headers;
    },
    end(body) {
      this.raw = body ?? '';
    },
  };
  return {
    res,
    get body() {
      return JSON.parse(res.raw);
    },
  };
}

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

/**
 * Client half of `@local/dsh-wellness` — the relaxation feature.
 *
 * ## What it does, and when
 *
 * After an hour of continuous DSH uptime it suggests a coffee break; a longer
 * session also gets stretching, water and eye-rest suggestions. The suggestion
 * is the shipped `Toast` primitive — a top-centre banner that fades on its own —
 * so nothing here is modal, nothing takes keyboard focus, and the composer and a
 * running turn are untouched. Each banner can be dismissed, or snoozed for the
 * configured number of minutes.
 *
 * ## The seams (this file is written around them)
 *
 * 1. **`dueSuggestions(uptimeMs, lastSuggestionAt, settings, now)`** decides
 *    whether the moment has come, and returns the *unlocked pool* of tiers.
 *    `selectSuggestion(due, suggestedCount)` rotates through that pool, so
 *    suggestions get progressively (and modestly) more varied as a session runs.
 * 2. **Uptime is the Host's**, read from `/local/wellness` — never a number this
 *    page made up. A missing or failed route is `未取得`, and it is not a
 *    suggestion either.
 * 3. **Work time is a separate, honest source.** `createVisibleTimeSource()`
 *    reports how long *this page has been visible*; it is displayed as such and
 *    deliberately does **not** drive the schedule, so real activity tracking can
 *    replace it later without rewriting the decision.
 * 4. **`createScheduler(env)`** owns the only timer: one 60 s chain, suspended
 *    while `document.visibilityState === 'hidden'`, with both the timer and the
 *    visibility listener cleared by the disposer.
 * 5. **`normalizeState(raw)`** is the only place persisted values are trusted:
 *    missing, corrupt, partial or foreign state becomes complete defaults, and an
 *    unusable store degrades to in-memory state with the UI still working.
 *
 * Only platform seed words are required: `react`, the UI primitives (for the
 * banner, switch, segmented control and button the app already draws) and the
 * client store the workspace convention persists preferences with.
 */

window.__ModuleLoader__.load({
  id: '@local/dsh-wellness',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useCallback, useEffect, useState } = React;
    const { Toast, Button, Switch, SegmentedControl, IconClockOutlineRegular } = require('@deepseek-ai/dsh-client-ui-primitives');
    const { createSnapshotStore } = require('@deepseek-ai/dsh-client-store');

    /** Package name; the Client module system keys the boot graph by it. */
    const ID = '@local/dsh-wellness';
    /** Locale namespace owned by this bundle. */
    const NS = 'dshWellness';
    /** Loader row id from cordis.patch.yml; also this bundle's settings row id. */
    const ROW_ID = 'wellness';
    /** Persisted-state key (`PLUGIN_GUIDE.md` §7: `dsh.<plugin>.<key>`). */
    const STORE_KEY = 'dsh.wellness.state';
    /** Host capability global, filled by the Host half's index-injection row. */
    const BOOTSTRAP_KEY = '__DSH_WELLNESS__';
    /** Client-side fallback for the capability (the Host half serves it). */
    const TOKEN_PATH = '/local/wellness-token';
    /** Header the Host half checks. */
    const TOKEN_HEADER = 'x-dsh-wellness-token';

    const MINUTE = 60_000;
    /**
     * The one timer. Sixty seconds is plenty for a feature whose shortest
     * interval is half an hour, and it keeps DSH idle-cheap (`REQUIREMENTS.md` §15).
     */
    const TICK_MS = 60_000;
    const MIN_INTERVAL_MS = 5 * MINUTE;
    const MAX_INTERVAL_MS = 8 * 60 * MINUTE;
    const MAX_SNOOZE_MINUTES = 240;
    /** The rotation counter wraps instead of growing without bound. */
    const COUNT_WRAP = 1000;
    /** Full-opacity hold of the banner: long enough to read the sentence. */
    const HOLD_MS = 12_000;
    const INTERVAL_CHOICES = [30, 60, 120];
    const SNOOZE_CHOICES = [10, 30, 60];

    /** Shipped defaults: an hour of continuous uptime, coffee, once an hour. */
    const DEFAULTS = Object.freeze({
      version: 1,
      enabled: true,
      intervalMs: 60 * MINUTE,
      longSession: true,
      snoozeMinutes: 30,
      snoozeUntil: 0,
      lastSuggestionAt: 0,
      suggestedCount: 0,
    });

    /**
     * The suggestion ladder. A tier unlocks once the session has reached
     * `unlock` full intervals of uptime, so the pool broadens slowly: coffee at
     * the first interval, then stretching, water and eye rest — and the pool is
     * capped at four, because a nudge is not a lecture.
     */
    const TIERS = Object.freeze([
      Object.freeze({ id: 'coffee', unlock: 1 }),
      Object.freeze({ id: 'stretch', unlock: 2 }),
      Object.freeze({ id: 'water', unlock: 3 }),
      Object.freeze({ id: 'eyes', unlock: 4 }),
    ]);

    const CSS = `
      .dshw-row{display:flex;align-items:flex-start;justify-content:space-between;gap:24px;padding:16px 0;border-bottom:.5px solid var(--dsw-alias-border-l2)}
      .dshw-text{display:flex;flex:1;flex-direction:column;gap:4px;min-width:0;padding-right:48px}
      .dshw-title{color:var(--dsw-alias-label-primary);font-size:14px;line-height:22px}
      .dshw-desc{color:var(--dsw-alias-label-secondary);font-size:12px;line-height:18px}
      .dshw-status{display:flex;flex-wrap:wrap;gap:6px;color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));font-size:12px;line-height:18px}
      .dshw-status-value{color:var(--dsw-alias-label-secondary);font-variant-numeric:tabular-nums;transition:color var(--ds-transition-duration-fast,.1s) var(--ds-ease-in-out,ease)}
      .dshw-status[data-quiet='1'] .dshw-status-value{color:var(--dsw-alias-state-warn-primary)}
      .dshw-controls{display:flex;flex-direction:column;align-items:flex-end;gap:10px}
      .dshw-label{color:var(--dsw-alias-label-tertiary,var(--dsw-alias-label-secondary));font-size:12px;line-height:18px}
      .dshw-actions{display:flex;flex-wrap:wrap;gap:8px;justify-content:flex-end}
      @media (max-width:480px){
        .dshw-row{flex-direction:column;align-items:stretch}
        .dshw-controls{align-items:stretch}
        .dshw-actions{justify-content:flex-start}
      }
      @media (prefers-reduced-motion: reduce){.dshw-status-value{transition:none}}
    `;

    // ── copy ────────────────────────────────────────────────────────────────
    //
    // Registered through the Client locale service. `ja` is the external language
    // `@local/dsh-locale-ja` declares with `en` as its fallback, so the lookup
    // chain reaches the right entry either way.
    const ja = {
      title: 'リラックス機能',
      description: '長く続けて使っているときに、休憩・ストレッチ・水分補給を控えめに提案します。',
      enable: '休憩の提案',
      interval: '提案の間隔',
      intervalHint: '最初の提案までの時間と、提案どうしの最短間隔です。',
      snooze: 'スヌーズの長さ',
      snoozeHint: '「スヌーズ」を押したとき、この時間だけ提案を止めます。',
      longSession: '長時間セッションの提案',
      longSessionHint: 'ストレッチ・水分補給・目の休憩も加えます。',
      status: '{elapsed} 連続起動',
      statusWork: 'この画面では {elapsed}',
      statusUnknown: '未取得',
      unavailable: '連続起動時間を取得できませんでした。',
      retry: '再取得',
      next: '次の提案まで 約{remaining}',
      nextOff: '提案は停止中',
      snoozedNow: 'スヌーズ中（あと{remaining}）',
      clearSnooze: 'スヌーズを解除',
      reset: '設定を既定に戻す',
      'unit.minutes': '{minutes}分',
      'duration.hours': '{hours}時間{minutes}分',
      'duration.minutes': '{minutes}分',
      'duration.seconds': '{seconds}秒',
      'suggest.coffee': '{elapsed} 続けて起動しています。コーヒー休憩にしませんか？',
      'suggest.stretch': '{elapsed} 経過しました。肩と首を1〜2分ほぐしましょう。',
      'suggest.water': '{elapsed} 連続起動です。水分補給のタイミングです。',
      'suggest.eyes': '{elapsed} 経過しました。20秒ほど画面から目を離しましょう。',
      'toast.dismiss': '閉じる',
      'toast.snooze': '{minutes}分スヌーズ',
      'toast.or': 'または',
    };
    const en = {
      title: 'Relaxation',
      description: 'Gently suggests a break, a stretch or some water during long sessions.',
      enable: 'Break suggestions',
      interval: 'Suggestion interval',
      intervalHint: 'Time to the first suggestion, and the shortest gap between suggestions.',
      snooze: 'Snooze length',
      snoozeHint: 'How long Snooze silences suggestions.',
      longSession: 'Long-session suggestions',
      longSessionHint: 'Adds stretching, water and eye-rest suggestions.',
      status: 'up {elapsed}',
      statusWork: 'on screen {elapsed}',
      statusUnknown: 'unavailable',
      unavailable: 'The session length could not be read.',
      retry: 'Retry',
      next: 'next suggestion in ~{remaining}',
      nextOff: 'suggestions are off',
      snoozedNow: 'snoozed ({remaining} left)',
      clearSnooze: 'Clear snooze',
      reset: 'Reset to defaults',
      'unit.minutes': '{minutes}m',
      'duration.hours': '{hours}h {minutes}m',
      'duration.minutes': '{minutes}m',
      'duration.seconds': '{seconds}s',
      'suggest.coffee': "You've been at this for {elapsed}. How about a coffee break?",
      'suggest.stretch': '{elapsed} in — loosen your shoulders and neck for a minute or two.',
      'suggest.water': '{elapsed} of continuous use. Time for a glass of water.',
      'suggest.eyes': '{elapsed} in — look away from the screen for 20 seconds.',
      'toast.dismiss': 'Dismiss',
      'toast.snooze': 'Snooze {minutes}m',
      'toast.or': 'or',
    };

    // A factory-created untagged <style> is claimed by the module system and
    // removed on teardown; nothing but platform seed words is required.
    const styleElement = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = CSS;
      document.head.append(element);
      return element;
    })();

    // ── persistence ─────────────────────────────────────────────────────────

    /** Clamp a number into a closed range. */
    function clamp(value, min, max) {
      return Math.min(max, Math.max(min, value));
    }

    /**
     * The only place a persisted value is trusted.
     *
     * Accepts anything a store may rehydrate — a JSON string, a partial older
     * object, `null`, a number, an array — and always answers with a complete,
     * in-range state. A corrupt value therefore costs the user defaults, never a
     * broken page (`REQUIREMENTS.md:14`).
     *
     * @param raw - whatever storage or the store handed back.
     * @returns a complete state object.
     */
    function normalizeState(raw) {
      let source = raw;
      if (typeof source === 'string') {
        try {
          source = JSON.parse(source);
        } catch {
          source = null;
        }
      }
      if (source === null || typeof source !== 'object' || Array.isArray(source)) source = {};
      const intervalMs = Number(source.intervalMs);
      const snoozeMinutes = Number(source.snoozeMinutes);
      const snoozeUntil = Number(source.snoozeUntil);
      const lastSuggestionAt = Number(source.lastSuggestionAt);
      const suggestedCount = Number(source.suggestedCount);
      return {
        version: 1,
        enabled: source.enabled !== false,
        intervalMs: Number.isFinite(intervalMs)
          ? clamp(Math.round(intervalMs / MINUTE) * MINUTE, MIN_INTERVAL_MS, MAX_INTERVAL_MS)
          : DEFAULTS.intervalMs,
        longSession: source.longSession !== false,
        snoozeMinutes: Number.isFinite(snoozeMinutes)
          ? clamp(Math.round(snoozeMinutes), 1, MAX_SNOOZE_MINUTES)
          : DEFAULTS.snoozeMinutes,
        snoozeUntil: Number.isFinite(snoozeUntil) && snoozeUntil > 0 ? Math.round(snoozeUntil) : 0,
        lastSuggestionAt: Number.isFinite(lastSuggestionAt) && lastSuggestionAt > 0 ? Math.round(lastSuggestionAt) : 0,
        suggestedCount: Number.isFinite(suggestedCount) && suggestedCount > 0 ? Math.floor(suggestedCount) % COUNT_WRAP : 0,
      };
    }

    /**
     * The store seat. A missing or throwing store (an older shell, a private
     * window) must not take the feature down, so it degrades to memory.
     */
    function createStateStore() {
      try {
        return createSnapshotStore(() => ({ ...DEFAULTS }), { persist: { name: STORE_KEY } });
      } catch {
        return null;
      }
    }

    const store = createStateStore();
    /**
     * A store that rejects a write (a hostile environment, a broken shell) is
     * not asked again: the page keeps the value it already has in memory, so a
     * preference still applies even when it cannot be persisted.
     */
    let storeUsable = store !== null;
    let memory = { ...DEFAULTS };

    /** @returns the complete current state, whatever the store handed back. */
    function readState() {
      try {
        return normalizeState(storeUsable ? store.getSnapshot() : memory);
      } catch {
        return normalizeState(memory);
      }
    }

    /** Persist a state change; a rejected write only costs durability, not the session. */
    function writeState(next) {
      const value = normalizeState(next);
      memory = value;
      if (storeUsable) {
        try {
          store.set(value);
        } catch {
          /* Quota, private mode: the page keeps working from memory. */
          storeUsable = false;
        }
      }
      return value;
    }

    // ── schedule (pure) ─────────────────────────────────────────────────────

    /** Whether the user asked for quiet right now. */
    function isSnoozed(settings, now) {
      return Number(settings?.snoozeUntil) > now;
    }

    /** Defer every suggestion for `minutes` from `now`. */
    function snoozeFor(settings, now, minutes) {
      return normalizeState({ ...settings, snoozeUntil: now + clamp(Math.round(minutes), 1, MAX_SNOOZE_MINUTES) * MINUTE });
    }

    /** Lift the snooze. */
    function clearSnooze(settings) {
      return normalizeState({ ...settings, snoozeUntil: 0 });
    }

    /**
     * The tiers a session of this length has unlocked, in escalation order.
     * With long-session suggestions off, only the first tier is ever unlocked.
     */
    function unlockedTiers(uptimeMs, settings) {
      if (!Number.isFinite(uptimeMs) || uptimeMs < 0) return [];
      const interval = Number(settings?.intervalMs) > 0 ? settings.intervalMs : DEFAULTS.intervalMs;
      const tiers = settings?.longSession === false ? TIERS.slice(0, 1) : TIERS;
      return tiers.filter((tier) => uptimeMs >= tier.unlock * interval).map((tier) => tier.id);
    }

    /**
     * The pool of suggestions due at `now`: empty when the moment has not come,
     * otherwise every tier the session has unlocked. Only one is ever shown —
     * `selectSuggestion` picks from the pool — so the schedule stays quiet while
     * the variety grows.
     *
     * @param uptimeMs - the Host process's uptime, or anything unusable (→ none).
     * @param lastSuggestionAt - epoch ms of the last suggestion, 0 for "none yet".
     * @param settings - the normalized state.
     * @param now - wall clock, epoch ms.
     * @returns the due tier ids, in escalation order.
     */
    function dueSuggestions(uptimeMs, lastSuggestionAt, settings, now) {
      if (settings?.enabled === false) return [];
      if (!Number.isFinite(uptimeMs) || uptimeMs < 0) return [];
      if (isSnoozed(settings, now)) return [];
      const interval = Number(settings?.intervalMs) > 0 ? settings.intervalMs : DEFAULTS.intervalMs;
      const previous = Number.isFinite(lastSuggestionAt) && lastSuggestionAt > 0 ? lastSuggestionAt : null;
      const ready = previous === null ? uptimeMs >= interval : now - previous >= interval;
      if (!ready) return [];
      return unlockedTiers(uptimeMs, settings);
    }

    /** Rotate through the due pool, so consecutive suggestions differ. */
    function selectSuggestion(due, suggestedCount) {
      if (!Array.isArray(due) || due.length === 0) return null;
      const count = Number.isFinite(suggestedCount) && suggestedCount > 0 ? Math.floor(suggestedCount) : 0;
      return due[count % due.length];
    }

    /**
     * Milliseconds until the next suggestion, or `null` when there is nothing to
     * promise: switched off, or no uptime reading to measure the first interval
     * against. A snooze tail counts as a floor — the countdown is the later of
     * the two.
     */
    function nextDueInMs(uptimeMs, lastSuggestionAt, settings, now) {
      if (settings?.enabled === false) return null;
      const interval = Number(settings?.intervalMs) > 0 ? settings.intervalMs : DEFAULTS.intervalMs;
      const previous = Number.isFinite(lastSuggestionAt) && lastSuggestionAt > 0 ? lastSuggestionAt : null;
      if (previous === null && !Number.isFinite(uptimeMs)) return null;
      const candidates = [previous === null ? interval - uptimeMs : previous + interval - now];
      if (isSnoozed(settings, now)) candidates.push(settings.snoozeUntil - now);
      return Math.max(0, ...candidates);
    }

    // ── copy helpers (pure) ─────────────────────────────────────────────────

    /** Split a duration for the locale templates. Days fold into hours. */
    function durationParts(ms) {
      const total = Number.isFinite(ms) && ms > 0 ? Math.floor(ms / 1000) : 0;
      return {
        hours: Math.floor(total / 3600),
        minutes: Math.floor((total % 3600) / 60),
        seconds: total % 60,
      };
    }

    /** "1時間23分" / "1h 23m" — the largest two units that matter here. */
    function durationText(ms, t) {
      const parts = durationParts(ms);
      if (parts.hours > 0) return t('duration.hours', { hours: parts.hours, minutes: parts.minutes });
      if (parts.minutes > 0) return t('duration.minutes', { minutes: parts.minutes });
      return t('duration.seconds', { seconds: parts.seconds });
    }

    /** The suggestion sentence for one tier, with the session length folded in. */
    function suggestionText(id, elapsedText, t) {
      return t(`suggest.${id}`, { elapsed: elapsedText });
    }

    /** Never render a raw internal error string; the row shows its own sentence. */
    function bindText(props) {
      return typeof props?.t === 'function' ? props.t : (key) => key;
    }

    // ── the visible-time source (the activity seam) ──────────────────────────

    /**
     * The honest answer to "how much work time was that?": how long *this page
     * has been visible*. It observes only what it can — no input events are
     * invented — and it is reported, not scheduled on: the suggestion ladder keys
     * on the Host's uptime, so replacing this source with real activity tracking
     * later changes a figure on a settings row and nothing else.
     */
    function createVisibleTimeSource(hidden, now) {
      let visibleMs = 0;
      let since = hidden() ? null : now();
      return {
        /** Visible time observed so far, in ms. */
        activeMs(at = now()) {
          return since === null ? visibleMs : visibleMs + Math.max(0, at - since);
        },
        /** Fold the current visibility stretch in; call on every visibility change. */
        noteVisibility(at = now()) {
          if (hidden()) {
            if (since !== null) {
              visibleMs += Math.max(0, at - since);
              since = null;
            }
            return;
          }
          if (since === null) since = at;
        },
      };
    }

    function pageHidden() {
      return typeof document !== 'undefined' && document.visibilityState === 'hidden';
    }

    const activity = createVisibleTimeSource(pageHidden, () => Date.now());

    // ── the timer ───────────────────────────────────────────────────────────

    /**
     * The only timer in this bundle.
     *
     * `start()` subscribes to visibility and, when the page is visible, evaluates
     * once and then arms one 60 s chain. Becoming hidden cancels the timer *and*
     * the evaluation guards on visibility, so a stale callback cannot slip a
     * suggestion through a hidden page either. `stop()` clears both the timer and
     * the listener — the disposer a plugin unload relies on.
     *
     * @param env - `{ periodMs, now, setTimer, clearTimer, isHidden, onVisibility, evaluate, onError }`.
     * @returns `{ start, stop, tick, armed, running }`.
     */
    function createScheduler(env) {
      const periodMs = Number(env?.periodMs) > 0 ? env.periodMs : TICK_MS;
      let timer = null;
      let unsubscribe = null;
      let running = false;
      let inFlight = false;

      function arm() {
        if (!running || timer !== null || env.isHidden()) return;
        timer = env.setTimer(() => {
          timer = null;
          void pump();
        }, periodMs);
      }

      function cancel() {
        if (timer === null) return;
        const id = timer;
        timer = null;
        env.clearTimer(id);
      }

      async function pump() {
        if (!running || env.isHidden()) return;
        if (!inFlight) {
          inFlight = true;
          try {
            await env.evaluate();
          } catch (error) {
            env.onError?.(error);
          } finally {
            inFlight = false;
          }
        }
        arm();
      }

      function onVisibilityChange() {
        if (env.isHidden()) cancel();
        else void pump();
      }

      return {
        start() {
          if (running) return;
          running = true;
          unsubscribe = env.onVisibility(onVisibilityChange) ?? null;
          void pump();
        },
        stop() {
          running = false;
          cancel();
          try {
            unsubscribe?.();
          } catch {
            /* an already-torn-down document listener is not an error */
          }
          unsubscribe = null;
        },
        tick: () => pump(),
        armed: () => timer !== null,
        running: () => running,
      };
    }

    function timerEnv() {
      return {
        periodMs: TICK_MS,
        now: () => Date.now(),
        setTimer: (fn, ms) => (typeof window === 'undefined' ? 0 : window.setTimeout(fn, ms)),
        clearTimer: (id) => {
          if (typeof window !== 'undefined') window.clearTimeout(id);
        },
        isHidden: pageHidden,
        onVisibility: (callback) => {
          if (typeof document === 'undefined' || typeof document.addEventListener !== 'function') return () => {};
          const wrapped = () => {
            activity.noteVisibility();
            callback();
          };
          document.addEventListener('visibilitychange', wrapped);
          return () => document.removeEventListener('visibilitychange', wrapped);
        },
        evaluate: () => evaluateDue(),
        onError: (error) => {
          lastError = error?.message ?? String(error);
        },
      };
    }

    let scheduler = null;
    function ensureScheduler() {
      if (scheduler === null) scheduler = createScheduler(timerEnv());
      return scheduler;
    }

    // ── the Host route client ───────────────────────────────────────────────

    let lastError = null;
    /** The last Host reading, plus the visible-time figure. Never persisted. */
    let session = { uptimeMs: null, at: 0, workMs: 0, error: null };
    /** The banner on screen, if any: `{ seq, id, atMs, uptimeMs }`. */
    let pending = null;
    let seq = 0;
    const listeners = new Set();

    /** Tell every mounted consumer that the module state moved. */
    function notify() {
      for (const fn of [...listeners]) {
        try {
          fn();
        } catch {
          /* a broken subscriber must not stop the schedule */
        }
      }
    }

    /** Subscribe to the persisted state and to the per-session state at once. */
    function subscribeState(fn) {
      listeners.add(fn);
      let off = null;
      try {
        off = store?.subscribe?.(fn) ?? null;
      } catch {
        off = null;
      }
      return () => {
        listeners.delete(fn);
        try {
          off?.();
        } catch {
          /* ignore */
        }
      };
    }

    function readBootstrap() {
      try {
        if (typeof window === 'undefined') return null;
        const boot = window[BOOTSTRAP_KEY];
        if (boot === null || typeof boot !== 'object') return null;
        if (typeof boot.path !== 'string' || boot.path === '') return null;
        if (typeof boot.token !== 'string' || boot.token === '') return null;
        return { path: boot.path, token: boot.token };
      } catch {
        return null;
      }
    }

    function installBootstrap(value) {
      try {
        window[BOOTSTRAP_KEY] = value;
      } catch {
        /* ignore */
      }
    }

    /** Drop a capability the Host refused, so the next read re-handshakes. */
    function forgetBootstrap() {
      if (readBootstrap() === null) return false;
      try {
        delete window[BOOTSTRAP_KEY];
      } catch {
        installBootstrap(undefined);
      }
      return true;
    }

    async function requestJson(url, init) {
      const response = await fetch(url, init);
      const payload = await response.json().catch(() => null);
      if (response.ok !== true || payload === null || payload.ok !== true) {
        const error = new Error(payload?.error ?? `HTTP ${String(response.status)}`);
        error.status = response.status;
        throw error;
      }
      return payload.data;
    }

    /** The data route bound to the capability currently in the page. */
    function createApi() {
      const boot = readBootstrap();
      if (boot === null) return null;
      return {
        read: () => requestJson(boot.path, {
          method: 'GET',
          headers: { accept: 'application/json', [TOKEN_HEADER]: boot.token },
          credentials: 'same-origin',
          cache: 'no-store',
        }),
      };
    }

    /**
     * The capability, in the order the guide lays out: the injected global, then
     * the token route for a page that never saw one.
     */
    async function resolveApi() {
      const direct = createApi();
      if (direct !== null) return direct;
      if (typeof fetch !== 'function') throw new Error('bootstrap-missing: no fetch in this page');
      let data;
      try {
        data = await requestJson(TOKEN_PATH, {
          method: 'GET',
          headers: { accept: 'application/json' },
          credentials: 'same-origin',
          cache: 'no-store',
        });
      } catch (error) {
        throw new Error(`bootstrap-missing: ${error?.message ?? String(error)}`);
      }
      if (data === null || typeof data !== 'object' || typeof data.path !== 'string' || typeof data.token !== 'string') {
        throw new Error('bootstrap-missing: the token route returned no capability');
      }
      installBootstrap({ path: data.path, token: data.token });
      return createApi();
    }

    /**
     * Read the Host uptime, or answer `null`.
     *
     * `null` covers every failure — no route, a refused token, a refused payload,
     * a non-numeric field — and it is deliberately *not* a number: the feature
     * renders 未取得 rather than deriving a session length from the page clock.
     * A 403 means the Host re-minted its token, so the capability is re-obtained
     * exactly once before giving up.
     */
    async function readUptime() {
      try {
        const api = await resolveApi();
        if (api === null) {
          lastError = 'bootstrap-missing: no capability';
          return null;
        }
        const data = await api.read();
        const ms = Number(data?.uptimeMs);
        if (!Number.isFinite(ms) || ms < 0) {
          lastError = 'bootstrap-missing: the route reported no uptime';
          return null;
        }
        lastError = null;
        return { uptimeMs: ms, at: Date.now() };
      } catch (error) {
        if (error?.status === 403 && forgetBootstrap()) {
          try {
            const api = await resolveApi();
            const data = await api?.read();
            const ms = Number(data?.uptimeMs);
            if (Number.isFinite(ms) && ms >= 0) {
              lastError = null;
              return { uptimeMs: ms, at: Date.now() };
            }
            lastError = 'bootstrap-missing: the route reported no uptime';
            return null;
          } catch (retryError) {
            lastError = retryError?.message ?? String(retryError);
            return null;
          }
        }
        lastError = error?.message ?? String(error);
        return null;
      }
    }

    function recordSession(reading) {
      session = {
        uptimeMs: reading === null ? null : reading.uptimeMs,
        at: reading === null ? Date.now() : reading.at,
        workMs: activity.activeMs(),
        error: reading === null ? lastError : null,
      };
      return session;
    }

    /** Re-read the Host uptime without touching the schedule (the row's retry). */
    async function refreshSession() {
      const reading = await readUptime();
      recordSession(reading);
      notify();
      return reading;
    }

    /**
     * One decision tick: read the Host uptime, then ask the pure seams whether a
     * suggestion is due. Nothing fires while the page is hidden, while the
     * feature is off, while a snooze lasts, or when the route gave no reading.
     */
    async function evaluateDue() {
      const settings = readState();
      if (!settings.enabled) return;
      const at = Date.now();
      if (isSnoozed(settings, at)) return;
      const reading = await readUptime();
      recordSession(reading);
      if (reading === null || pending !== null) {
        notify();
        return;
      }
      const due = dueSuggestions(reading.uptimeMs, settings.lastSuggestionAt, settings, at);
      if (due.length === 0) {
        notify();
        return;
      }
      const id = selectSuggestion(due, settings.suggestedCount);
      if (id === null) {
        notify();
        return;
      }
      pending = { seq: seq + 1, id, atMs: at, uptimeMs: reading.uptimeMs };
      seq += 1;
      writeState({ ...settings, lastSuggestionAt: at, suggestedCount: settings.suggestedCount + 1 });
      notify();
    }

    /** The banner's own "close", and the primitive's `onDone`. */
    function dismissSuggestion() {
      if (pending === null) return;
      pending = null;
      notify();
    }

    /** "Don't suggest again for N minutes" — persisted, so a restart respects it. */
    function snoozeSuggestion() {
      const settings = readState();
      writeState(snoozeFor(settings, Date.now(), settings.snoozeMinutes));
      pending = null;
      notify();
    }

    function clearSnoozeState() {
      writeState(clearSnooze(readState()));
      notify();
    }

    function resetState() {
      writeState({ ...DEFAULTS });
      pending = null;
      notify();
    }

    // ── React ───────────────────────────────────────────────────────────────

    /** Read the module state through a subscription (no selector, no memo). */
    function useWellnessState() {
      const [, bump] = useState(0);
      useEffect(() => subscribeState(() => bump((value) => value + 1)), []);
      return { settings: readState(), session, pending };
    }

    /**
     * The notification cell: it draws nothing until a suggestion is due, and then
     * exactly one shipped `Toast`. The banner is top-centre, auto-expiring,
     * pointer-transparent outside its own surface and never focused, so a running
     * turn and the composer are untouched; `key` remounts it per suggestion so
     * the primitive's own hold cycle restarts.
     */
    function WellnessCell(props) {
      const t = bindText(props);
      const { pending: current, settings } = useWellnessState();
      if (current === null) return null;
      return h(Toast, {
        key: `dsh-wellness-${String(current.seq)}`,
        text: suggestionText(current.id, durationText(current.uptimeMs, t), t),
        icon: h(IconClockOutlineRegular, { size: 18 }),
        holdMs: HOLD_MS,
        actions: [
          { prefix: '', label: t('toast.dismiss'), onClick: dismissSuggestion },
          { prefix: t('toast.or'), label: t('toast.snooze', { minutes: settings.snoozeMinutes }), onClick: snoozeSuggestion },
        ],
        onDone: dismissSuggestion,
      });
    }

    /**
     * The settings row on the General page: the same primitives the app's own
     * rows use, so it looks native by construction. It can turn the feature off,
     * change the interval, change the snooze length, drop the long-session
     * suggestions, lift a snooze, reset the stored state, and re-read the Host
     * uptime when the route could not be reached.
     */
    function WellnessSettingsRow(props) {
      const t = bindText(props);
      const { settings, session: reading } = useWellnessState();
      const refresh = useCallback(() => {
        void refreshSession();
      }, []);
      const patch = useCallback((changes) => {
        writeState({ ...readState(), ...changes });
      }, []);

      const at = Date.now();
      const elapsed = reading.uptimeMs === null ? null : durationText(reading.uptimeMs, t);
      const remaining = nextDueInMs(reading.uptimeMs, settings.lastSuggestionAt, settings, at);
      const snoozed = isSnoozed(settings, at);
      const lines = [elapsed === null ? t('statusUnknown') : t('status', { elapsed })];
      lines.push(t('statusWork', { elapsed: durationText(reading.workMs, t) }));
      if (!settings.enabled) lines.push(t('nextOff'));
      else if (snoozed) lines.push(t('snoozedNow', { remaining: durationText(remaining, t) }));
      else if (remaining !== null) lines.push(t('next', { remaining: durationText(remaining, t) }));

      return h('div', { className: 'dshw-row' },
        h('div', { className: 'dshw-text' },
          h('span', { className: 'dshw-title' }, t('title')),
          h('span', { className: 'dshw-desc' }, elapsed === null ? t('unavailable') : t('description')),
          h('span', { className: 'dshw-status', 'data-quiet': snoozed ? '1' : '0' },
            lines.map((line, index) => h('span', { key: `line-${String(index)}`, className: 'dshw-status-value' }, line))),
        ),
        h('div', { className: 'dshw-controls' },
          h(Switch, {
            checked: settings.enabled,
            onChange: (value) => patch({ enabled: value }),
            label: t('enable'),
          }),
          h('span', { className: 'dshw-label' }, t('interval')),
          h(SegmentedControl, {
            id: 'dshw-interval',
            value: settings.intervalMs,
            label: t('interval'),
            options: INTERVAL_CHOICES.map((minutes) => ({ value: minutes * MINUTE, label: t('unit.minutes', { minutes }) })),
            onChange: (value) => patch({ intervalMs: value }),
          }),
          h('span', { className: 'dshw-label' }, t('snooze')),
          h(SegmentedControl, {
            id: 'dshw-snooze',
            value: settings.snoozeMinutes,
            label: t('snooze'),
            options: SNOOZE_CHOICES.map((minutes) => ({ value: minutes, label: t('unit.minutes', { minutes }) })),
            onChange: (value) => patch({ snoozeMinutes: value }),
          }),
          h(Switch, {
            checked: settings.longSession,
            onChange: (value) => patch({ longSession: value }),
            label: t('longSession'),
          }),
          h('div', { className: 'dshw-actions' },
            h(Button, { variant: 'outline', onClick: refresh, 'aria-label': t('retry') }, t('retry')),
            h(Button, {
              variant: 'outline',
              disabled: !snoozed,
              onClick: clearSnoozeState,
              'aria-label': t('clearSnooze'),
            }, t('clearSnooze')),
            h(Button, { variant: 'outline', onClick: resetState, 'aria-label': t('reset') }, t('reset')),
          ),
        ),
      );
    }

    // ── wiring ──────────────────────────────────────────────────────────────

    function apply(ctx) {
      ctx.effect(() => () => styleElement?.remove(), 'dsh-wellness: styles');
      ctx.effect(() => ctx.locale.register(NS, { ja, en }), 'dsh-wellness: copy');
      ctx.effect(() => {
        ensureScheduler().start();
        return () => ensureScheduler().stop();
      }, 'dsh-wellness: scheduler');
      ctx.effect(() => ctx.slots.inject('shell.overlay', () => ctx.slots.register({
        name: 'shell.overlay',
        id: ID,
        order: 200,
        locale: NS,
        inject: () => ({}),
      }, WellnessCell)), 'dsh-wellness: notification cell');
      ctx.effect(() => ctx.slots.inject('settings.general.item', () => ctx.slots.register({
        name: 'settings.general.item',
        id: ROW_ID,
        order: 30,
        locale: NS,
        inject: () => ({}),
      }, WellnessSettingsRow)), 'dsh-wellness: settings row');
      ctx.logger?.info?.('[wellness] active — coffee after 60 minutes of continuous uptime, one banner at a time');
    }

    return {
      inject: ['slots', 'locale'],
      apply,
      /** Test seam: the seams, the pure helpers and the cells, verifiable offline. */
      __test: {
        id: ID,
        namespace: NS,
        rowId: ROW_ID,
        storeKey: STORE_KEY,
        bootstrapKey: BOOTSTRAP_KEY,
        tokenPath: TOKEN_PATH,
        tokenHeader: TOKEN_HEADER,
        tickMs: TICK_MS,
        holdMs: HOLD_MS,
        minIntervalMs: MIN_INTERVAL_MS,
        maxIntervalMs: MAX_INTERVAL_MS,
        maxSnoozeMinutes: MAX_SNOOZE_MINUTES,
        intervalChoices: INTERVAL_CHOICES,
        snoozeChoices: SNOOZE_CHOICES,
        defaults: DEFAULTS,
        tiers: TIERS,
        dictionaries: { ja, en },
        css: CSS,
        normalizeState,
        readState,
        writeState,
        subscribeState,
        isSnoozed,
        snoozeFor,
        clearSnooze,
        unlockedTiers,
        dueSuggestions,
        selectSuggestion,
        nextDueInMs,
        durationParts,
        durationText,
        suggestionText,
        createVisibleTimeSource,
        createScheduler,
        readBootstrap,
        forgetBootstrap,
        createApi,
        resolveApi,
        readUptime,
        refreshSession,
        evaluateDue,
        session: () => ({ ...session }),
        pending: () => pending,
        setSession: (reading) => recordSession(reading),
        dismissSuggestion,
        snoozeSuggestion,
        clearSnoozeState,
        resetState,
        activeMs: () => activity.activeMs(),
        WellnessCell,
        WellnessSettingsRow,
      },
    };
  },
});

/**
 * Host half of `@local/dsh-wellness`.
 *
 * The relaxation feature itself is browser work — a timer, a banner and a
 * settings row all live in the page — but the one fact it must not invent is how
 * long DSH has been running: "after an hour of continuous use" has to mean the
 * Host process's own lifetime, not a number the page accumulated for itself.
 * This half therefore answers exactly that, on its own route:
 *
 *   GET /local/wellness        -> { uptimeMs, startedAt, at, pid, version }
 *   GET /local/wellness-token  -> { path, token }   (the GUI cookie is the guard)
 *
 * The token is the same-origin capability every local plugin uses
 * (`docs/design/PLUGIN_GUIDE.md` §2.1): minted per process, handed to the page
 * both as a bootstrap row over `webserver/index-inject` — the supported channel,
 * which also reaches the Desktop shell's boot payload — and over the token route
 * for a window that was already open. The data route refuses a cross-site
 * request and a wrong or absent token, answers JSON with `cache-control:
 * no-store`, and reports nothing but process facts.
 *
 * No configuration and no timers: the page polls this route once a minute.
 */
import { randomBytes, timingSafeEqual } from 'node:crypto';

export const name = 'dsh-wellness';
export const VERSION = '1.0.0';

/** Data route: this process's uptime. */
export const ROUTE_PATH = '/local/wellness';
/** Capability hand-out for a page whose boot payload predates this plugin. */
export const TOKEN_PATH = '/local/wellness-token';
/** Header carrying the per-process token. */
export const TOKEN_HEADER = 'x-dsh-wellness-token';
/** Global the served index (and the Desktop boot payload) carries into the page. */
export const BOOTSTRAP_KEY = '__DSH_WELLNESS__';

/** JSON reply with the one cache policy a live reading may have. */
function sendJson(res, status, payload) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
  });
  res.end(JSON.stringify(payload));
}

/**
 * The one measured fact this plugin ships: how long the Host process has run.
 *
 * `uptimeSeconds` is injectable so a test can drive it, and a value that is not
 * a usable number yields `null` — an unavailable metric is a state, never a zero
 * and never a guess (`REQUIREMENTS.md:12`, `PLUGIN_GUIDE.md:276`).
 *
 * @param now - wall clock for the reading, in ms.
 * @param uptimeSeconds - reader of the process uptime, in seconds.
 * @returns the snapshot the route serializes.
 */
export function uptimeSnapshot(now = Date.now(), uptimeSeconds = () => process.uptime()) {
  let seconds = Number.NaN;
  try {
    seconds = Number(uptimeSeconds());
  } catch {
    seconds = Number.NaN;
  }
  const uptimeMs = Number.isFinite(seconds) && seconds >= 0 ? Math.round(seconds * 1000) : null;
  return {
    version: VERSION,
    at: now,
    uptimeMs,
    startedAt: uptimeMs === null ? null : now - uptimeMs,
    pid: process.pid,
  };
}

/** The token is a same-origin capability: only the served index carries it. */
export function authorized(req, token) {
  if (req?.headers?.['sec-fetch-site'] === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
}

/** Exact-route handler: GET/HEAD reads the snapshot; anything else is a 405. */
export function createRouteHandler(snapshot, token) {
  return function wellnessRoute(req, res) {
    if (!authorized(req, token)) {
      sendJson(res, 403, { ok: false, error: 'forbidden' });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' });
      return;
    }
    try {
      sendJson(res, 200, { ok: true, data: snapshot() });
    } catch (error) {
      sendJson(res, 500, { ok: false, error: error instanceof Error ? error.message : String(error) });
    }
  };
}

/**
 * Hand the capability to a page that has no bootstrap global — an already-open
 * window, or a live install whose boot-injection table predates this plugin. The
 * guard is the index's own: the request must carry the GUI cookie, and a
 * cross-site sender is refused outright.
 */
export function createTokenHandler(token, isAuthenticated) {
  return function wellnessTokenRoute(req, res) {
    if (req?.headers?.['sec-fetch-site'] === 'cross-site') {
      sendJson(res, 403, { ok: false, error: 'forbidden' });
      return;
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      sendJson(res, 405, { ok: false, error: 'method-not-allowed' });
      return;
    }
    if (typeof isAuthenticated === 'function') {
      let authenticated = false;
      try {
        authenticated = isAuthenticated(req) === true;
      } catch {
        authenticated = false;
      }
      if (!authenticated) {
        sendJson(res, 401, { ok: false, error: 'unauthorized' });
        return;
      }
    }
    sendJson(res, 200, { ok: true, data: { path: ROUTE_PATH, token } });
  };
}

/** The index-injection row carrying `{ path, token }` into the page. */
export function bootstrapRow(value) {
  return { kind: 'global', name: BOOTSTRAP_KEY, value };
}

export function apply(ctx) {
  const token = randomBytes(24).toString('hex');
  const snapshot = () => uptimeSnapshot();

  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(
      () => webCtx.webServer.register({ kind: 'exact', path: ROUTE_PATH, handler: createRouteHandler(snapshot, token) }),
      'dsh-wellness: route',
    );
    webCtx.effect(
      () => webCtx.webServer.register({
        kind: 'exact',
        path: TOKEN_PATH,
        handler: createTokenHandler(token, (req) => webCtx.get?.('connection')?.isAuthenticated?.(req)),
      }),
      'dsh-wellness: token route',
    );
    // The supported page-side channel: rows reach both the served index and the
    // Desktop shell's boot payload, so a live install appears in the next load.
    webCtx.on?.('webserver/index-inject', (table) => {
      table.push(bootstrapRow({ path: ROUTE_PATH, token }));
    });
  });

  ctx.logger?.info?.('[wellness] active — break suggestions read the Host process uptime from /local/wellness');
}

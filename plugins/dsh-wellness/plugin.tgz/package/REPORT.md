# dsh-wellness — task-04 completion report

## Changes

- Toast remount keys now use the task brief's prescribed `dsh-wellness-${seq}` format. The module/loader/package identity remains `@local/dsh-wellness`, as required by `PLUGIN_GUIDE.md` §1–3; the Toast key is a separate per-show identifier, not a package ID.
- The client tests now dispose applied registrations after testing (preventing a scheduler from an earlier test leaking into later timer checks) and record fetches in the due-session timer assertion (which previously asserted on an untouched recorder). The scheduler itself already evaluated immediately, held a single 60-second timer, and generated the due coffee suggestion.

## Verification — actual outputs

Commands run from `dsh-wellness/`:

### Syntax

```text
node --check index.js; node --check client.js
```

Output: *(no output; exit code 0)*

### Host and pure-logic suite

```text
node test-wellness.mjs
```

Output:

```text
ok   logic: a missing, corrupt or foreign stored value falls back to defaults
ok   logic: a valid-JSON but partial/old value is completed, not trusted
ok   logic: garbage fields are clamped into range, never carried through
ok   logic: the suggestion counter stays bounded (no unbounded state)
ok   logic: nothing is due before one interval of continuous uptime
ok   logic: the long-session tiers unlock with uptime, in order
ok   logic: long-session suggestions can be switched off
ok   logic: the interval restarts from the last suggestion, not from uptime
ok   logic: disabled, snoozed and unknown-uptime sessions never fire
ok   logic: successive suggestions rotate through the unlocked pool
ok   logic: the next-due countdown is the later of the interval and the snooze
ok   logic: snooze defers for N minutes and is part of the persisted state
ok   logic: durations read as hours/minutes/seconds in the active locale
ok   logic: every tier has copy in both dictionaries, and the key sets match
ok   logic: the missing-reading copy is exactly 未取得
ok   host: the token fence refuses cross-site, missing, short and wrong tokens
ok   host: the uptime route answers only the token holder
ok   host: the token route is guarded by the GUI cookie, not by a peer token
ok   host: uptime is the host process itself, and an unusable reading is null
ok   host: apply registers both routes and the bootstrap row that carries the token

20/20 checks passed
```

### Client suite

```text
node test-client.mjs
```

Output:

```text
ok   bundle: registers the package id, its client services and its identity
ok   bundle: apply registers the notification cell, the settings row, copy and styles
ok   timer: apply arms exactly one 60 s timer while visible, and not before evaluation
ok   timer: nothing is armed or fetched while the document is hidden
ok   timer: the scheduler is a pure seam, gated on visibility
ok   disposer: unloading clears the timer, the listener and the stylesheet
ok   route: the token rides in the bootstrap global and every read is a GET
ok   route: no global means the token route hands the capability over
ok   route: a refused capability re-handshakes exactly once
ok   route: a missing or failed route is 未取得, never a fabricated number
ok   decision: a due session raises one suggestion and remembers it
ok   decision: dismissing closes the banner, snoozing mutes it for N minutes
ok   storage: an unusable store falls back to defaults and the UI keeps working
ok   storage: a rejected write (quota, private mode) still updates the session
ok   storage: a valid-JSON but partial stored value is completed by defaults

15/15 checks passed
```

### Render suite

```text
node test-render.mjs
```

Output:

```text
ok   render: with nothing due the notification cell renders nothing at all
ok   render: a due session shows the shipped Toast, never a modal and never focus
ok   render: the banner can be dismissed, snoozed, or left to expire
ok   render: the settings row reads as a native general-settings row
ok   render: no reading renders 未取得 and offers a real retry button
ok   render: the settings row writes every preference through to the store
ok   render: snooze can be lifted from the row, and the button reflects the state
ok   render: every clickable is a real primitive button with an accessible name

8/8 checks passed
```

### Non-blocking behavior scan

```text
grep focus\(|preventDefault|Modal dsh-wellness/client.js
```

Output: `No matches found` — no focus call, `preventDefault`, or modal surface is present.

The host test file in this checkout is `test-wellness.mjs` (20 checks); there is no separate `test-host.mjs`. No files outside `dsh-wellness/` were changed.

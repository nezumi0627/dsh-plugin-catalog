/**
 * Offline test for the Client half of `@local/dsh-wellness`: registration, the
 * single 60 s timer, its visibility gating, the route client, and the disposer.
 *
 * The bundle is materialized for real (only React, the primitives and the client
 * store are stubbed), so every behaviour below comes from `client.js` itself.
 *
 *   node test-client.mjs
 */
import assert from 'node:assert/strict';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// --- a recording browser surface -------------------------------------------

const appended = [];
const removed = [];

let timers = new Map();
let timerId = 0;
const cleared = [];
const listeners = new Map();
let fetchCalls = [];

function resetBrowser() {
  timers = new Map();
  timerId = 0;
  cleared.length = 0;
  listeners.clear();
  fetchCalls = [];
  appended.length = 0;
  removed.length = 0;
}

globalThis.document = {
  createElement: () => ({
    attrs: {},
    textContent: '',
    setAttribute(key, value) {
      this.attrs[key] = value;
    },
    remove() {
      removed.push(this);
    },
  }),
  head: { append: (element) => appended.push(element) },
  documentElement: { hasAttribute: () => false },
  visibilityState: 'visible',
  addEventListener(event, callback) {
    if (!listeners.has(event)) listeners.set(event, new Set());
    listeners.get(event).add(callback);
  },
  removeEventListener(event, callback) {
    listeners.get(event)?.delete(callback);
  },
};
globalThis.window = {
  setTimeout: (fn, ms) => {
    timerId += 1;
    timers.set(timerId, { fn, ms });
    return timerId;
  },
  clearTimeout: (id) => {
    cleared.push(id);
    timers.delete(id);
  },
  addEventListener: () => {},
  removeEventListener: () => {},
  localStorage: { getItem: () => null, setItem: () => {}, removeItem: () => {} },
};
// node 24 ships a getter-only `navigator`, so the stub is defined, not assigned.
Object.defineProperty(globalThis, 'navigator', { value: {}, configurable: true, writable: true });

/** Let every already-resolvable promise in the bundle settle. */
const flush = async () => {
  for (let round = 0; round < 4; round += 1) await new Promise((resolve) => setImmediate(resolve));
};
const onlyTimer = () => {
  assert.equal(timers.size, 1, 'exactly one timer is armed');
  return [...timers.entries()][0];
};
const fireTimer = () => {
  const [id, entry] = onlyTimer();
  timers.delete(id);
  entry.fn();
};

// --- the two platform seeds the bundle may ask for --------------------------

const React = {
  createElement: (type, props, ...children) => ({ type, props: { ...(props ?? {}), children } }),
  useState: () => [undefined, () => {}],
  useEffect: () => {},
  useRef: () => ({ current: null }),
  useCallback: (fn) => fn,
  useMemo: (fn) => fn(),
};
const primitives = {
  Toast: (props) => ({ type: 'Toast', props }),
  Button: (props) => ({ type: 'Button', props }),
  Switch: (props) => ({ type: 'Switch', props }),
  SegmentedControl: (props) => ({ type: 'SegmentedControl', props }),
  IconClockOutlineRegular: (props) => ({ type: 'IconClockOutlineRegular', props }),
};

/**
 * The parts of `createSnapshotStore` this bundle leans on. `seed` replaces what a
 * real rehydration would have installed; `broken`/`readOnly` emulate a store that
 * cannot be built and a storage write that throws (quota, private mode).
 */
function createFakeStoreModule(options = {}) {
  const records = [];
  const module = {
    records,
    createSnapshotStore(init, opts) {
      if (options.broken === true) throw new Error('snapshot store unavailable');
      const record = { key: opts?.persist?.name ?? null, writes: [] };
      records.push(record);
      let state = typeof options.seed === 'function' ? options.seed(init()) : init();
      const subscribers = new Set();
      return {
        getSnapshot: () => state,
        subscribe: (fn) => {
          subscribers.add(fn);
          return () => subscribers.delete(fn);
        },
        update: (mutator) => {
          mutator(state);
        },
        set: (next) => {
          if (options.readOnly === true) throw new Error('QuotaExceededError');
          state = next;
          record.writes.push(next);
          for (const fn of [...subscribers]) fn(state);
        },
      };
    },
  };
  return module;
}

const specs = [];
globalThis.window.__ModuleLoader__ = { load: (spec) => specs.push(spec) };

/** Import a fresh materialization: node keys ESM by URL, so the query is a new run. */
async function loadBundle(tag, storeOptions) {
  const store = createFakeStoreModule(storeOptions);
  const before = specs.length;
  await import(`./client.js?bundle=${tag}`);
  assert.equal(specs.length, before + 1, 'the bundle registered itself');
  const spec = specs[specs.length - 1];
  const mod = spec.factory((name) => {
    if (name === 'react') return React;
    if (name === '@deepseek-ai/dsh-client-ui-primitives') return primitives;
    if (name === '@deepseek-ai/dsh-client-store') return store;
    throw new Error(`unexpected require: ${name}`);
  });
  return { spec, mod, store };
}

/** A recording plugin context, in the shape the other local bundles see. */
function makeCtx() {
  const slotWaits = [];
  const registrations = [];
  const locales = [];
  const disposers = [];
  const ctx = {
    logger: { info: () => {} },
    locale: {
      register: (ns, dicts) => {
        locales.push({ ns, dicts });
        return () => {};
      },
      bind: (ns) => (key) => `${ns}:${key}`,
      getLocale: () => ({ active: 'ja' }),
    },
    slots: {
      inject(name, callback) {
        slotWaits.push(name);
        return callback();
      },
      register(options, component) {
        registrations.push({ options, component });
        return () => {};
      },
    },
    effect(fn) {
      const dispose = fn();
      const close = typeof dispose === 'function' ? dispose : () => {};
      disposers.push(close);
      return close;
    },
  };
  return { ctx, slotWaits, registrations, locales, disposers };
}

const uptimePayload = (uptimeMs) => ({
  ok: true,
  status: 200,
  json: async () => ({ ok: true, data: { uptimeMs, at: Date.now(), pid: 1 } }),
});

// ---------------------------------------------------------------------------

test('bundle: registers the package id, its client services and its identity', async () => {
  resetBrowser();
  const { spec, mod } = await loadBundle('identity', {});
  assert.equal(spec.id, '@local/dsh-wellness');
  assert.deepEqual(mod.inject, ['slots', 'locale']);
  assert.equal(mod.__test.id, '@local/dsh-wellness');
  assert.equal(mod.__test.namespace, 'dshWellness');
  assert.equal(mod.__test.rowId, 'wellness');
  assert.equal(mod.__test.storeKey, 'dsh.wellness.state');
  assert.equal(mod.__test.bootstrapKey, '__DSH_WELLNESS__');
  assert.equal(mod.__test.tokenPath, '/local/wellness-token');
  assert.equal(mod.__test.tokenHeader, 'x-dsh-wellness-token');
  assert.equal(mod.__test.tickMs, 60000, 'one timer, no faster than 1 Hz — 60 s is plenty');
  assert.ok(mod.__test.tickMs >= 1000);
  assert.equal(typeof mod.apply, 'function');
});

test('bundle: apply registers the notification cell, the settings row, copy and styles', async () => {
  resetBrowser();
  const { mod } = await loadBundle('registration', {});
  const { ctx, slotWaits, registrations, locales, disposers } = makeCtx();
  mod.apply(ctx);

  assert.deepEqual(slotWaits, ['shell.overlay', 'settings.general.item']);
  assert.equal(registrations.length, 2);

  const cell = registrations[0];
  assert.equal(cell.options.name, 'shell.overlay');
  assert.equal(cell.options.id, '@local/dsh-wellness');
  assert.equal(cell.options.locale, 'dshWellness');
  assert.equal(typeof cell.options.inject, 'function');
  assert.equal(typeof cell.component, 'function');

  const row = registrations[1];
  assert.equal(row.options.name, 'settings.general.item');
  assert.equal(row.options.id, 'wellness', 'the row id is the settings row key');
  assert.equal(row.options.locale, 'dshWellness');
  assert.equal(typeof row.component, 'function');

  assert.equal(locales.length, 1);
  assert.equal(locales[0].ns, 'dshWellness');
  assert.deepEqual(Object.keys(locales[0].dicts).sort(), ['en', 'ja']);
  assert.deepEqual(Object.keys(locales[0].dicts.ja).sort(), Object.keys(locales[0].dicts.en).sort());

  assert.equal(appended.length, 1);
  assert.equal(appended[0].attrs['data-plugin-css'], '@local/dsh-wellness');
  const css = appended[0].textContent;
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)/, 'reduced motion is mandatory');
  assert.match(css, /\.dshw-row\{/);
  assert.match(css, /var\(--dsw-alias-label-secondary\)/, 'design tokens only');
  assert.equal(/#[0-9a-f]{3,8}\b/i.test(css), false, 'no hardcoded colours');
  assert.equal(/rgba?\(|hsla?\(/i.test(css), false, 'no hardcoded colours');
  assert.equal(disposers.length >= 4, true, 'styles, copy, scheduler and both registrations are owned');
  for (const dispose of [...disposers].reverse()) dispose();
});

test('timer: apply arms exactly one 60 s timer while visible, and not before evaluation', async () => {
  resetBrowser();
  const { mod } = await loadBundle('timer-arm', {});
  const { ctx, disposers } = makeCtx();
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 't'.repeat(48) };
  globalThis.fetch = async (url, init) => {
    fetchCalls.push({ url, init });
    return uptimePayload(30 * 60_000);
  };
  mod.apply(ctx);
  await flush();

  assert.equal(fetchCalls.length, 1, 'the first evaluation happens at once, not after a minute');
  const [id, entry] = onlyTimer();
  assert.equal(entry.ms, 60000);
  assert.equal(mod.__test.session().uptimeMs, 30 * 60_000);

  // Firing the timer evaluates again and re-arms exactly one timer.
  fireTimer();
  await flush();
  assert.equal(fetchCalls.length, 2);
  assert.equal(timers.size, 1);
  assert.equal(cleared.includes(id), false, 'an expired timer is not the disposer clearing one');
  for (const dispose of [...disposers].reverse()) dispose();
});

test('timer: nothing is armed or fetched while the document is hidden', async () => {
  resetBrowser();
  const { mod } = await loadBundle('timer-hidden', {});
  const { ctx, disposers } = makeCtx();
  globalThis.document.visibilityState = 'hidden';
  globalThis.fetch = async (url, init) => {
    fetchCalls.push({ url, init });
    return uptimePayload(3 * 60 * 60_000);
  };
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 'h'.repeat(48) };

  mod.apply(ctx);
  await flush();
  assert.equal(timers.size, 0, 'a hidden page holds no timer');
  assert.equal(fetchCalls.length, 0, 'a hidden page does not even ask');
  assert.equal(mod.__test.pending(), null);
  assert.equal(typeof [...(listeners.get('visibilitychange') ?? [])][0], 'function', 'it waits for the change');

  // Becoming visible starts the loop again: one immediate evaluation, one timer.
  globalThis.document.visibilityState = 'visible';
  for (const callback of [...(listeners.get('visibilitychange') ?? [])]) callback();
  await flush();
  assert.equal(fetchCalls.length, 1);
  assert.equal(timers.size, 1);

  // Going hidden clears the pending timer, and a stale callback cannot fire it.
  const stale = [...timers.values()][0].fn;
  globalThis.document.visibilityState = 'hidden';
  for (const callback of [...(listeners.get('visibilitychange') ?? [])]) callback();
  assert.equal(timers.size, 0);
  assert.equal(cleared.length, 1, 'the pending timer was cleared, not leaked');
  stale();
  await flush();
  assert.equal(fetchCalls.length, 1, 'no evaluation escapes through a stale callback');
  assert.equal(timers.size, 0, 'and no timer is re-armed while hidden');
  globalThis.document.visibilityState = 'visible';
  for (const dispose of [...disposers].reverse()) dispose();
});

test('timer: the scheduler is a pure seam, gated on visibility', async () => {
  const { mod } = await loadBundle('scheduler-seam', {});
  const W = mod.__test;
  let hidden = true;
  let armed = null;
  const clearedIds = [];
  let visibility = null;
  let evaluated = 0;
  const scheduler = W.createScheduler({
    periodMs: 60000,
    now: () => 1_700_000_000_000,
    setTimer: (fn, ms) => {
      armed = { fn, ms };
      return 7;
    },
    clearTimer: (id) => {
      clearedIds.push(id);
      armed = null;
    },
    isHidden: () => hidden,
    onVisibility: (callback) => {
      visibility = callback;
      return () => {
        visibility = null;
      };
    },
    evaluate: () => {
      evaluated += 1;
    },
  });

  assert.equal(scheduler.running(), false);
  scheduler.start();
  assert.equal(scheduler.running(), true);
  await flush();
  assert.equal(evaluated, 0, 'hidden: never evaluated');
  assert.equal(armed, null, 'hidden: no timer');
  assert.equal(typeof visibility, 'function');

  hidden = false;
  visibility();
  await flush();
  assert.equal(evaluated, 1, 'becoming visible evaluates at once');
  assert.equal(armed.ms, 60000);
  assert.equal(scheduler.armed(), true);

  const pending = armed;
  pending.fn();
  await flush();
  assert.equal(evaluated, 2, 'the timer evaluates and re-arms');
  assert.equal(armed.ms, 60000);

  hidden = true;
  visibility();
  assert.equal(armed, null, 'hiding clears the timer');
  assert.deepEqual(clearedIds, [7]);
  const stale = { fn: pending.fn };
  stale.fn();
  await flush();
  assert.equal(evaluated, 2, 'a stale callback is refused by the hidden check');

  hidden = false;
  scheduler.stop();
  assert.equal(scheduler.running(), false);
  assert.equal(visibility, null, 'the visibility listener is removed');
  scheduler.stop();
  assert.equal(scheduler.running(), false, 'stop is idempotent');
});

test('disposer: unloading clears the timer, the listener and the stylesheet', async () => {
  resetBrowser();
  const { mod } = await loadBundle('disposer', {});
  const { ctx, disposers } = makeCtx();
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 'd'.repeat(48) };
  globalThis.fetch = async () => uptimePayload(10 * 60_000);
  mod.apply(ctx);
  await flush();

  const [id] = onlyTimer();
  assert.equal(listeners.get('visibilitychange').size, 1);
  assert.equal(removed.includes(appended[0]), false);

  for (const dispose of [...disposers].reverse()) dispose();

  assert.equal(timers.size, 0, 'the timer is gone');
  assert.ok(cleared.includes(id), 'the armed timer id was cleared');
  assert.equal(listeners.get('visibilitychange').size, 0, 'the visibility listener is gone');
  assert.ok(removed.includes(appended[0]), 'the stylesheet is gone');
});

test('route: the token rides in the bootstrap global and every read is a GET', async () => {
  resetBrowser();
  const { mod } = await loadBundle('route-global', {});
  const W = mod.__test;
  const token = 'r'.repeat(48);
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token };
  globalThis.fetch = async (url, init) => {
    fetchCalls.push({ url, init });
    return uptimePayload(90 * 60_000);
  };

  const reading = await W.readUptime();
  assert.deepEqual({ uptimeMs: reading.uptimeMs, at: typeof reading.at }, { uptimeMs: 90 * 60_000, at: 'number' });
  assert.equal(fetchCalls.length, 1);
  assert.equal(fetchCalls[0].url, '/local/wellness');
  assert.equal(fetchCalls[0].init.method, 'GET');
  assert.equal(fetchCalls[0].init.headers[W.tokenHeader], token);
  assert.equal(fetchCalls[0].init.cache, 'no-store');
  assert.equal(fetchCalls[0].init.credentials, 'same-origin');
});

test('route: no global means the token route hands the capability over', async () => {
  resetBrowser();
  const { mod } = await loadBundle('route-handshake', {});
  const W = mod.__test;
  delete globalThis.window.__DSH_WELLNESS__;
  globalThis.fetch = async (url, init) => {
    fetchCalls.push({ url, init });
    if (url === W.tokenPath) {
      return { ok: true, status: 200, json: async () => ({ ok: true, data: { path: '/local/wellness', token: 'n'.repeat(48) } }) };
    }
    return uptimePayload(12 * 60_000);
  };

  const reading = await W.readUptime();
  assert.equal(reading.uptimeMs, 12 * 60_000);
  assert.deepEqual(fetchCalls.map((call) => call.url), [W.tokenPath, '/local/wellness']);
  assert.equal(fetchCalls[0].init.credentials, 'same-origin');
  assert.deepEqual(globalThis.window.__DSH_WELLNESS__, { path: '/local/wellness', token: 'n'.repeat(48) });
});

test('route: a refused capability re-handshakes exactly once', async () => {
  resetBrowser();
  const { mod } = await loadBundle('route-403', {});
  const W = mod.__test;
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 's'.repeat(48) };
  globalThis.fetch = async (url, init) => {
    fetchCalls.push({ url, init });
    if (url === W.tokenPath) {
      return { ok: true, status: 200, json: async () => ({ ok: true, data: { path: '/local/wellness', token: 'f'.repeat(48) } }) };
    }
    if (init.headers[W.tokenHeader] === 's'.repeat(48)) {
      return { ok: false, status: 403, json: async () => ({ ok: false, error: 'forbidden' }) };
    }
    return uptimePayload(45 * 60_000);
  };

  const reading = await W.readUptime();
  assert.equal(reading.uptimeMs, 45 * 60_000);
  assert.deepEqual(fetchCalls.map((call) => call.url), ['/local/wellness', W.tokenPath, '/local/wellness']);
  assert.equal(fetchCalls[2].init.headers[W.tokenHeader], 'f'.repeat(48));

  // A second 403 is not retried forever: the read just reports "no reading".
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 's'.repeat(48) };
  fetchCalls = [];
  globalThis.fetch = async (url, init) => {
    fetchCalls.push({ url, init });
    if (url === W.tokenPath) return { ok: false, status: 401, json: async () => ({ ok: false, error: 'unauthorized' }) };
    return { ok: false, status: 403, json: async () => ({ ok: false, error: 'forbidden' }) };
  };
  assert.equal(await W.readUptime(), null);
  assert.deepEqual(fetchCalls.map((call) => call.url), ['/local/wellness', W.tokenPath]);
});

test('route: a missing or failed route is 未取得, never a fabricated number', async () => {
  resetBrowser();
  const { mod } = await loadBundle('route-fail', {});
  const W = mod.__test;
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 'x'.repeat(48) };

  globalThis.fetch = async () => {
    throw new Error('ECONNREFUSED');
  };
  assert.equal(await W.refreshSession(), null);
  assert.equal(W.session().uptimeMs, null, 'no reading is no reading');
  assert.match(W.session().error, /ECONNREFUSED/);

  globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: false, error: 'nope' }) });
  assert.equal(await W.refreshSession(), null);

  globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: true, data: { uptimeMs: 'soon' } }) });
  assert.equal(await W.refreshSession(), null, 'a non-numeric uptime is refused');

  globalThis.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: true, data: { uptimeMs: 5000 } }) });
  assert.equal((await W.refreshSession()).uptimeMs, 5000);
  assert.equal(W.session().error, null);
});

test('decision: a due session raises one suggestion and remembers it', async () => {
  resetBrowser();
  const { mod, store } = await loadBundle('decision-fire', {});
  const W = mod.__test;
  const { ctx, disposers } = makeCtx();
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 'f'.repeat(48) };
  globalThis.fetch = async (...args) => {
    fetchCalls.push(args);
    return uptimePayload(2 * 60 * 60_000);
  };

  mod.apply(ctx);
  await flush();

  const pending = W.pending();
  assert.notEqual(pending, null, 'two hours of uptime is due');
  assert.equal(pending.id, 'coffee', 'the first suggestion of a long session is the coffee break');
  assert.equal(typeof pending.seq, 'number');

  const state = W.readState();
  assert.equal(state.suggestedCount, 1, 'the rotation counter moved');
  assert.ok(state.lastSuggestionAt > 0, 'the interval restarts from now');
  assert.equal(state.snoozeUntil, 0);
  assert.equal(store.records[0].key, 'dsh.wellness.state', 'the store persists under the documented key');
  assert.equal(store.records[0].writes.length, 1, 'the decision was written through');
  assert.equal(store.records[0].writes[0].lastSuggestionAt, state.lastSuggestionAt);

  // A second tick inside the same interval must not fire twice.
  fetchCalls = [];
  fireTimer();
  await flush();
  assert.equal(fetchCalls.length, 1);
  assert.equal(W.readState().suggestedCount, 1);
  for (const dispose of [...disposers].reverse()) dispose();
});

test('decision: dismissing closes the banner, snoozing mutes it for N minutes', async () => {
  resetBrowser();
  const { mod } = await loadBundle('decision-actions', {});
  const W = mod.__test;
  const { ctx } = makeCtx();
  globalThis.window.__DSH_WELLNESS__ = { path: '/local/wellness', token: 'a'.repeat(48) };
  globalThis.fetch = async () => uptimePayload(2 * 60 * 60_000);
  mod.apply(ctx);
  await flush();
  assert.notEqual(W.pending(), null);

  const before = Date.now();
  W.snoozeSuggestion();
  const snoozed = W.readState();
  assert.equal(W.pending(), null, 'snoozing closes the banner');
  const expected = before + snoozed.snoozeMinutes * 60_000;
  assert.ok(Math.abs(snoozed.snoozeUntil - expected) <= 2000, `snoozed for the configured N (${String(snoozed.snoozeUntil - before)})`);
  assert.equal(W.isSnoozed(snoozed, before), true);

  // While snoozed a due session stays quiet, even when the timer fires.
  fetchCalls = [];
  fireTimer();
  await flush();
  assert.equal(W.pending(), null, 'a snoozed session is not suggested at again');
  assert.equal(W.readState().suggestedCount, 1, 'the counter did not move');

  W.clearSnoozeState();
  assert.equal(W.readState().snoozeUntil, 0);
  assert.equal(W.isSnoozed(W.readState(), Date.now()), false);
});

test('storage: an unusable store falls back to defaults and the UI keeps working', async () => {
  resetBrowser();
  const { mod } = await loadBundle('storage-broken', { broken: true });
  const W = mod.__test;

  assert.deepEqual(W.readState(), W.defaults, 'no store, shipped defaults');
  const next = { ...W.defaults, enabled: false, intervalMs: 30 * 60_000 };
  assert.doesNotThrow(() => W.writeState(next), 'a write never throws at the caller');
  assert.equal(W.readState().enabled, false, 'the session keeps its own state in memory');
  assert.equal(W.readState().intervalMs, 30 * 60_000);
});

test('storage: a rejected write (quota, private mode) still updates the session', async () => {
  resetBrowser();
  const { mod } = await loadBundle('storage-readonly', { readOnly: true });
  const W = mod.__test;
  assert.deepEqual(W.readState(), W.defaults);
  assert.doesNotThrow(() => W.writeState({ ...W.defaults, longSession: false }));
  assert.equal(W.readState().longSession, false);
});

test('storage: a valid-JSON but partial stored value is completed by defaults', async () => {
  resetBrowser();
  const { mod } = await loadBundle('storage-partial', { seed: () => ({ enabled: false, intervalMs: 'soon' }) });
  const W = mod.__test;
  const state = W.readState();
  assert.equal(state.enabled, false);
  assert.equal(state.intervalMs, W.defaults.intervalMs, 'a garbage field never reaches the schedule');
  assert.deepEqual(Object.keys(state).sort(), Object.keys(W.defaults).sort());
});

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

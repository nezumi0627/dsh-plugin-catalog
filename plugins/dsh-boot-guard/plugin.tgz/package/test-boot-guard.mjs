/**
 * Host-half test for `@local/dsh-boot-guard`.
 *
 * Pure functions are driven directly; the file-touching paths run against a
 * throwaway fixture under the OS temp directory (never the real profile, never
 * another plugin's directory).
 *
 *   node test-boot-guard.mjs
 */
import assert from 'node:assert/strict';
import { existsSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, utimesSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

import {
  CLIENT_SEEDS,
  CRASH_LOG_BYTES,
  DEFAULT_CONFIG,
  HOST_REQUIRED_IDS,
  MARKER_PREFIX,
  PACKAGE,
  analyzePatch,
  appendAudit,
  applyProfileEdit,
  authorized,
  bootGuardPaths,
  checkJavaScriptSyntax,
  collectRegistry,
  decideCrashQuarantines,
  decidePreflight,
  deriveRowIdCandidate,
  findLastOverride,
  listCrashLogs,
  parseCrashLog,
  parseJsonObject,
  patchOverrideDisabled,
  planPatchEdit,
  readState,
  reconcileState,
  reenablePackage,
  resolveConfig,
  resolveCrashLogsDir,
  resolveHomeDir,
  resolveProfileDir,
  rowIdsFromPatch,
  runBootGuard,
  validatePatchStructure,
  validateRegistry,
  verifyPatchOutcome,
  writeState,
  createNodeIo,
} from './index.js';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

const io = createNodeIo();
const ROOT = mkdtempSync(join(tmpdir(), 'dsh-boot-guard-test-'));
let fixtureCounter = 0;

/** A disposable profile: `home/profiles/desktop/`, one dir per plugin, logs, state. */
function makeFixture({ dependencies = {}, bundles = [], plugins = [], patch = '', crashLogs = [] } = {}) {
  fixtureCounter += 1;
  const root = join(ROOT, `fx-${fixtureCounter}`);
  const homeDir = join(root, 'home');
  const profileDir = join(homeDir, 'profiles', 'desktop');
  const logsDir = join(root, 'logs');
  mkdirSync(profileDir, { recursive: true });
  mkdirSync(logsDir, { recursive: true });
  writeFileSync(
    join(profileDir, 'package.json'),
    `${JSON.stringify({ name: 'dsh-profile-test', private: true, dependencies, dsh: { profile: { bundles } } }, null, 2)}\n`,
    'utf8',
  );
  writeFileSync(join(profileDir, 'cordis.patch.yml'), patch, 'utf8');
  for (const plugin of plugins) {
    const dir = join(profileDir, plugin.dir ?? localBasename(plugin.name));
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'package.json'), `${JSON.stringify(plugin.manifest, null, 2)}\n`, 'utf8');
    if (plugin.patch !== undefined) writeFileSync(join(dir, 'cordis.patch.yml'), plugin.patch, 'utf8');
    if (plugin.client !== undefined) writeFileSync(join(dir, 'client.js'), plugin.client, 'utf8');
  }
  for (const log of crashLogs) writeFileSync(join(logsDir, log.name), log.text, 'utf8');
  return { root, profileDir, homeDir, logsDir };
}

/** `@local/dsh-auto-kill` → `dsh-auto-kill`, the directory the link: spec names. */
function localBasename(packageName) {
  return packageName.startsWith('@') ? packageName.slice(packageName.indexOf('/') + 1) : packageName;
}

function pluginFixture({ name, dir = null, inject = [], platform = 'web', clientExport = true, withClientManifest = true, rowId = null, client = 'window.__ModuleLoader__.load({ id: 1, factory() { return {}; } });\n', withPatch = true, manifest: extra = {} } = {}) {
  const id = rowId ?? deriveRowIdCandidate(name);
  const manifest = {
    name,
    version: '1.0.0',
    type: 'module',
    exports: { '.': './index.js', ...(clientExport ? { './client': './client.js' } : {}) },
    ...(withClientManifest ? { dsh: { client: { ...(platform === null ? {} : { platform }), inject } } } : { dsh: {} }),
    ...extra,
  };
  return {
    name,
    dir: dir ?? localBasename(name),
    manifest,
    patch: withPatch ? `- insert:\n    - id: ${id}\n      name: '${name}'\n` : undefined,
    client: clientExport ? client : undefined,
  };
}

function registryFor(fixture) {
  return collectRegistry({ io, profileDir: fixture.profileDir });
}

function verdictFor(registry, packageName) {
  const { verdicts } = validateRegistry(registry);
  return verdicts.find((verdict) => verdict.packageName === packageName);
}

function signalsOf(verdict) {
  return verdict.signals.map((signal) => signal.code);
}

// ---------------------------------------------------------------------------
// the incident's real log, verbatim (also re-read from disk when present)

const INCIDENT_LOG = `time: 2026-10-11T16:50:18.321Z
source: web-boot
phase: running
app: @deepseek-ai/dsh-desktop 0.2.0-rc.2
platform: win32 x64
electron: 44.0.0
node: 24.18.1
locale: ja
shell pid: 16572

--- error ---
Error: web boot: 1 entry did not activate
@local/dsh-auto-kill: pending (waiting for service: @deepseek-ai/dsh-client-ui-primitives)
    at file:///C:/Users/ren11/AppData/Local/Programs/DeepSeek%20Harness/resources/app.asar/lib/main.js:11740:15
    at Session.<anonymous> (node:electron/js2c/browser_init:2:122853)
    at Session.emit (node:events:509:28)

--- renderer console (error level, oldest first) ---
dsh-app://app/assets/index-5SrrfWpU.js:126 Error: web boot: 1 entry did not activate
@local/dsh-auto-kill: pending (waiting for service: @deepseek-ai/dsh-client-ui-primitives)
`;

const REAL_CRASH_LOG = 'C:\\Users\\ren11\\AppData\\Roaming\\@deepseek-ai\\dsh-desktop\\logs\\crash-2026-10-11T16-50-18-321Z-web-boot.log';

/** The incident reproduced end to end: one bad plugin = one quarantine. */
function incidentFixture() {
  return makeFixture({
    dependencies: {
      '@local/dsh-auto-kill': 'link:./dsh-auto-kill',
      '@local/dsh-clock': 'link:./dsh-clock',
    },
    bundles: ['@deepseek-ai/dsh-base', '@local/dsh-clock', '@local/dsh-auto-kill'],
    plugins: [
      pluginFixture({ name: '@local/dsh-clock', inject: ['@deepseek-ai/dsh-client-ui-layout'] }),
      pluginFixture({ name: '@local/dsh-auto-kill', inject: ['@deepseek-ai/dsh-client-ui-primitives'] }),
    ],
    patch: '# user patch\n- id: ui-theme\n  name: "@deepseek-ai/dsh-client-ui-theme"\n  config:\n    preference: dark\n',
    crashLogs: [{ name: 'crash-2026-10-11T16-50-18-321Z-web-boot.log', text: INCIDENT_LOG }],
  });
}

// ---------------------------------------------------------------------------
// pure helpers

test('config: defaults, clamping, and the disabled switch', () => {
  assert.deepEqual(resolveConfig(), { ...DEFAULT_CONFIG });
  assert.equal(resolveConfig({ disabled: true }).disabled, true);
  assert.equal(resolveConfig({ enabled: false }).enabled, false);
  assert.equal(resolveConfig({ dryRun: 'yes' }).dryRun, false, 'only a real boolean turns dryRun on');
  assert.equal(resolveConfig({ dryRun: true }).dryRun, true);
  assert.equal(resolveConfig({ autoQuarantine: false }).autoQuarantine, false);
  assert.equal(resolveConfig({ maxCrashLogs: 999 }).maxCrashLogs, 20);
  assert.equal(resolveConfig({ maxCrashLogs: -4 }).maxCrashLogs, 0);
  assert.equal(resolveConfig({ crashLogBytes: 1 }).crashLogBytes, 4096);
});

test('home/profile resolution: $DSH_HOME, then ~/.dsh; argv finds the profiles tree', () => {
  assert.equal(resolveHomeDir({ env: { DSH_HOME: 'C:\\custom\\dsh' } }), 'C:\\custom\\dsh');
  assert.equal(resolveHomeDir({ env: {}, home: 'C:\\Users\\x' }), join('C:\\Users\\x', '.dsh'));
  const fixture = incidentFixture();
  const found = resolveProfileDir({
    io,
    homeDir: join(fixture.root, 'home'),
    env: {},
    argv: ['node', 'dsh-desktop-host', join(fixture.root, 'dsh'), fixture.profileDir, 'C:\\elsewhere'],
  });
  assert.equal(found, fixture.profileDir);
  assert.equal(resolveProfileDir({ io, homeDir: join(fixture.root, 'nope'), env: {}, argv: [] }), null);
});

test('crash-log dir: APPDATA is honoured, absence is not guessed', () => {
  assert.equal(
    resolveCrashLogsDir({ env: { APPDATA: 'C:\\Users\\x\\AppData\\Roaming' } }),
    join('C:\\Users\\x\\AppData\\Roaming', '@deepseek-ai', 'dsh-desktop', 'logs'),
  );
  assert.equal(resolveCrashLogsDir({ env: {} }), null);
});

// ---------------------------------------------------------------------------
// the real crash log

test('crash log: the real incident text parses to one pending @local/dsh-auto-kill entry', () => {
  const parsed = parseCrashLog(INCIDENT_LOG, { file: REAL_CRASH_LOG });
  assert.equal(parsed.entries.length, 1, 'the renderer-console duplicate is deduped');
  const entry = parsed.entries[0];
  assert.equal(entry.packageName, '@local/dsh-auto-kill');
  assert.equal(entry.kind, 'pending');
  assert.deepEqual(entry.missing, ['@deepseek-ai/dsh-client-ui-primitives']);
  assert.equal(entry.line, 13, 'the first occurrence names the evidence line');
  assert.equal(entry.file, REAL_CRASH_LOG);
});

test('crash log: the file on disk (when present) parses identically', () => {
  if (!existsSync(REAL_CRASH_LOG)) {
    console.log('     (real crash log absent — fixture string only)');
    return;
  }
  const text = readFileSync(REAL_CRASH_LOG, 'utf8');
  const parsed = parseCrashLog(text, { file: REAL_CRASH_LOG });
  assert.equal(parsed.entries.length, 1);
  assert.equal(parsed.entries[0].packageName, '@local/dsh-auto-kill');
  assert.equal(parsed.entries[0].kind, 'pending');
});

test('crash log: host form, failed form, import failure and the grouped Package: form', () => {
  const text = [
    'dsh: startup failed: 1 required plugin did not activate',
    '',
    'Failed plugins (2):',
    '  dsh-broken (required)',
    '    Package: @local/dsh-broken',
    '    activate: Error: boom',
    '  dsh-warn',
    '    Package: @local/dsh-warn',
    '    activate: Error: nope',
    '',
    'Plugins waiting for services (1):',
    '  dsh-pending     missing-service',
    '    Package: @local/dsh-pending',
    '@local/dsh-import: import failed: SyntaxError: Unexpected token',
  ].join('\n');
  const packages = parseCrashLog(text, { file: 'x.log' }).entries.map((entry) => `${entry.packageName}:${entry.kind}`);
  assert.deepEqual(packages, ['@local/dsh-broken:failed', '@local/dsh-warn:failed', '@local/dsh-pending:pending', '@local/dsh-import:import-failed']);
});

test('host crash log: only an explicit out-of-tree plugin script failure is attributed', () => {
  const pluginFailure = [
    'source: host',
    '--- renderer console (error level, oldest first) ---',
    'dsh-app://app/plugins/??@local/dsh-broken/client.js&rev=abc:42 Uncaught SyntaxError: Unexpected token',
    '--- error ---',
    'Error: dsh desktop host exited with 4294967295: (node:4) [DEP0180] DeprecationWarning: fs.Stats constructor is deprecated.',
  ].join('\n');
  const parsed = parseCrashLog(pluginFailure, { file: 'crash-test-host.log' });
  assert.deepEqual(parsed.entries.map(({ packageName, kind }) => ({ packageName, kind })), [
    { packageName: '@local/dsh-broken', kind: 'failed' },
  ]);

  const warningOnly = parseCrashLog(
    'source: host\nError: dsh desktop host exited with 4294967295: [DEP0180] DeprecationWarning: fs.Stats constructor is deprecated.\n',
    { file: 'crash-warning-host.log' },
  );
  assert.deepEqual(warningOnly.entries, [], 'a generic host exit and Node deprecation warning must not disable a plugin');
});

test('host exit trace: attributes only the registered plugin whose real file is on the exit stack', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-exit-source': 'link:./dsh-exit-source' },
    bundles: ['@local/dsh-exit-source'],
    plugins: [pluginFixture({ name: '@local/dsh-exit-source' })],
  });
  const registry = registryFor(fixture);
  const source = pathToFileURL(join(fixture.profileDir, 'dsh-exit-source', 'index.js')).href;
  const text = [
    'source: host',
    'Error: dsh desktop host exited with 4294967295; stderr tail (cause not established):',
    '[dsh-host-exit-trace] process.exit(-1)',
    'Error',
    '    at process.exit (data:text/javascript,trace)',
    `    at stopHost (${source}:19:7)`,
    '    at async runPlugin (file:///C:/app/core/host.js:1:1)',
  ].join('\n');
  const parsed = parseCrashLog(text, { file: 'crash-test-host.log', registry });
  assert.deepEqual(parsed.entries.map(({ packageName, kind }) => ({ packageName, kind })), [
    { packageName: '@local/dsh-exit-source', kind: 'host-exit' },
  ]);
  const decisions = decideCrashQuarantines({ entries: parsed.entries, registry }).decisions;
  assert.equal(decisions.length, 1);
  assert.equal(decisions[0].packageName, '@local/dsh-exit-source');

  const [staleEntry] = parsed.entries;
  const registered = registry.pluginByPackage.get('@local/dsh-exit-source');
  registered._io = { ...io, mtimeMs: (path) => (path === staleEntry.sourcePath ? 2_001 : 999) };
  assert.deepEqual(
    decideCrashQuarantines({ entries: [{ ...staleEntry, mtimeMs: 2_000 }], registry }).decisions,
    [],
    'a traced source edited after the crash is stale evidence',
  );

  const wrapperOnly = parseCrashLog([
    '[dsh-host-exit-trace] process.exit(-1)',
    'Error',
    '    at process.exit (data:text/javascript,trace)',
    '    at runHost (file:///C:/app/core/host.js:1:1)',
  ].join('\n'), { file: 'crash-test-host.log', registry });
  assert.deepEqual(wrapperOnly.entries, [], 'a trace with no registered plugin frame is not blamed on a plugin');
});

test('host uncaught trace: attributes only a registered plugin named by the exception stack', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-uncaught-source': 'link:./dsh-uncaught-source' },
    bundles: ['@local/dsh-uncaught-source'],
    plugins: [pluginFixture({ name: '@local/dsh-uncaught-source' })],
  });
  const registry = registryFor(fixture);
  const source = pathToFileURL(join(fixture.profileDir, 'dsh-uncaught-source', 'index.js')).href;
  const text = [
    'source: host',
    '[dsh-host-uncaught] origin=uncaughtException',
    'Error: plugin exploded',
    `    at apply (${source}:24:3)`,
    '    at runHost (file:///C:/app/core/host.js:1:1)',
  ].join('\n');
  const parsed = parseCrashLog(text, { file: 'crash-test-host.log', registry });
  assert.deepEqual(parsed.entries.map(({ packageName, kind }) => ({ packageName, kind })), [
    { packageName: '@local/dsh-uncaught-source', kind: 'host-uncaught' },
  ]);
  assert.equal(decideCrashQuarantines({ entries: parsed.entries, registry }).decisions[0]?.packageName, '@local/dsh-uncaught-source');

  const coreOnly = parseCrashLog([
    '[dsh-host-uncaught] origin=uncaughtException',
    'Error: core failed',
    '    at runHost (file:///C:/app/core/host.js:1:1)',
  ].join('\n'), { file: 'crash-test-host.log', registry });
  assert.deepEqual(coreOnly.entries, [], 'a core-only stack is not blamed on a plugin');
});

test('crash log: bounded — entries are capped and pending lists are truncated', () => {
  const many = Array.from({ length: 40 }, (_, index) => `@local/p${index}: pending (waiting for service: a, b, c, d, e, f, g, h, i)`).join('\n');
  const parsed = parseCrashLog(many, { file: 'x.log' });
  assert.equal(parsed.entries.length, 24);
  assert.equal(parsed.truncated, true);
  assert.equal(parsed.entries[0].missing.length, 8);
});

test('crash decision: the incident yields exactly ONE decision, for @local/dsh-auto-kill', () => {
  const fixture = incidentFixture();
  const registry = registryFor(fixture);
  const parsed = parseCrashLog(INCIDENT_LOG, { file: REAL_CRASH_LOG });
  const { decisions } = decideCrashQuarantines({ entries: parsed.entries, registry });
  assert.equal(decisions.length, 1);
  assert.equal(decisions[0].packageName, '@local/dsh-auto-kill');
  assert.equal(decisions[0].rowId, 'dsh-auto-kill');
  assert.equal(decisions[0].reason, 'crash-log:pending');
  assert.equal(decisions[0].evidence[0].file, REAL_CRASH_LOG);
  assert.equal(decisions[0].evidence[0].line, 13);
});

test('crash decision: core ids, @deepseek-ai/* bundles, required ids and self are never quarantined', () => {
  const fixture = incidentFixture();
  const registry = registryFor(fixture);
  const core = [
    { packageName: '@deepseek-ai/dsh-client-ui-layout', rowId: 'ui-layout', kind: 'pending', missing: [], file: 'x.log', line: 1 },
    { packageName: '@deepseek-ai/dsh-base', rowId: 'base', kind: 'failed', missing: [], file: 'x.log', line: 2 },
    { packageName: PACKAGE, rowId: 'dsh-boot-guard', kind: 'failed', missing: [], file: 'x.log', line: 3 },
  ];
  const { decisions } = decideCrashQuarantines({ entries: core, registry });
  assert.deepEqual(decisions, []);
  // A required host id is protected even when an out-of-tree package claims it.
  const viaRegistry = {
    pluginByPackage: new Map([
      ['@local/dsh-evil', { packageName: '@local/dsh-evil', rowId: 'webserver', rowIds: ['webserver'], outOfTree: true }],
    ]),
  };
  const required = decideCrashQuarantines({
    entries: [{ packageName: '@local/dsh-evil', rowId: 'webserver', kind: 'failed', missing: [], file: 'x.log', line: 4 }],
    registry: viaRegistry,
  });
  assert.deepEqual(required.decisions, []);
  assert.equal(HOST_REQUIRED_IDS.includes('webserver'), true);
});

test('crash decision: an unregistered third-party package is not our business', () => {
  const fixture = incidentFixture();
  const registry = registryFor(fixture);
  const { decisions } = decideCrashQuarantines({
    entries: [{ packageName: '@evil/not-linked', rowId: 'evil', kind: 'failed', missing: [], file: 'x.log', line: 9 }],
    registry,
  });
  assert.deepEqual(decisions, []);
});

test('crash decision: newer plugin/profile edits make old crash evidence stale', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-fixed': 'link:./dsh-fixed' },
    bundles: ['@local/dsh-fixed'],
    plugins: [pluginFixture({ name: '@local/dsh-fixed' })],
    crashLogs: [{ name: 'crash-old-web-boot.log', text: '@local/dsh-fixed: failed: Error: old source failed\n' }],
  });
  const registry = registryFor(fixture);
  const log = join(fixture.logsDir, 'crash-old-web-boot.log');
  const evidenceTime = statSync(log).mtimeMs;
  const edited = join(fixture.profileDir, 'dsh-fixed', 'client.js');
  const future = new Date(evidenceTime + 5000);
  writeFileSync(edited, 'window.__ModuleLoader__.load({ id: "@local/dsh-fixed" });\n', 'utf8');
  utimesSync(edited, future, future);
  const parsed = parseCrashLog('@local/dsh-fixed: failed: Error: old source failed\n', { file: log, mtimeMs: evidenceTime });
  assert.deepEqual(decideCrashQuarantines({ entries: parsed.entries, registry }).decisions, []);
});

// ---------------------------------------------------------------------------
// pre-flight signals

test('pre-flight: every one of the 9 module seeds in inject is a guaranteed hang', () => {
  const dependencies = {};
  const bundles = [];
  const plugins = [];
  for (const [index, seed] of CLIENT_SEEDS.entries()) {
    const name = `@local/dsh-seed${index}`;
    dependencies[name] = `link:./dsh-seed${index}`;
    bundles.push(name);
    plugins.push(pluginFixture({ name, inject: [seed] }));
  }
  const fixture = makeFixture({ dependencies, bundles, plugins });
  const registry = registryFor(fixture);
  assert.equal(registry.ok, true);
  for (const [index] of CLIENT_SEEDS.entries()) {
    const verdict = verdictFor(registry, `@local/dsh-seed${index}`);
    assert.equal(verdict.level, 'quarantine', CLIENT_SEEDS[index]);
    assert.equal(signalsOf(verdict).includes('seed-in-inject'), true);
    assert.equal(verdict.reason, 'seed-in-inject');
  }
  const { decisions } = decidePreflight(validateRegistry(registry).verdicts);
  assert.equal(decisions.length, 9, 'every seed-inject plugin is quarantined');
});

test('pre-flight: a legitimate shipped provider is accepted, an unknown core name only warns', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-a': 'link:./dsh-a', '@local/dsh-b': 'link:./dsh-b' },
    bundles: ['@local/dsh-a', '@local/dsh-b'],
    plugins: [
      pluginFixture({ name: '@local/dsh-a', inject: ['@deepseek-ai/dsh-client-ui-layout', '@deepseek-ai/dsh-client-locale'] }),
      pluginFixture({ name: '@local/dsh-b', inject: ['@deepseek-ai/dsh-client-ui-chat'] }),
    ],
  });
  const registry = registryFor(fixture);
  const accepted = verdictFor(registry, '@local/dsh-a');
  assert.equal(accepted.level, 'ok');
  assert.deepEqual(accepted.signals, []);
  const warned = verdictFor(registry, '@local/dsh-b');
  assert.equal(warned.level, 'warn', 'a core name we cannot verify is never quarantined');
  assert.equal(signalsOf(warned).includes('inject-provider-core-unverified'), true);
});

test('pre-flight: unknown, disabled, client-less and broken inject providers are quarantines', () => {
  const fixture = makeFixture({
    dependencies: {
      '@local/dsh-consumer': 'link:./dsh-consumer',
      '@local/dsh-off': 'link:./dsh-off',
      '@local/dsh-noclient': 'link:./dsh-noclient',
      '@local/dsh-broken': 'link:./dsh-broken',
      '@local/dsh-provider': 'link:./dsh-provider',
    },
    // `@local/dsh-off` is a dependency but NOT a bundle → disabled.
    bundles: ['@local/dsh-consumer', '@local/dsh-noclient', '@local/dsh-broken', '@local/dsh-provider'],
    plugins: [
      pluginFixture({ name: '@local/dsh-off' }),
      pluginFixture({ name: '@local/dsh-noclient', withClientManifest: false, clientExport: false }),
      pluginFixture({ name: '@local/dsh-broken', clientExport: false }),
      pluginFixture({ name: '@local/dsh-provider', inject: ['@deepseek-ai/dsh-client-ui-layout'] }),
      pluginFixture({ name: '@local/dsh-consumer', inject: ['@local/dsh-nonexistent'] }),
    ],
  });
  const registry = registryFor(fixture);
  const byPackage = new Map(registry.plugins.map((plugin) => [plugin.packageName, plugin]));
  const consumer = byPackage.get('@local/dsh-consumer');
  const variants = [
    ['@local/dsh-nonexistent', 'inject-provider-unknown'],
    ['@local/dsh-off', 'inject-provider-disabled'],
    ['@local/dsh-noclient', 'inject-provider-no-client'],
    ['@local/dsh-broken', 'inject-provider-broken'],
    ['@deepseek-ai/dsh-client-ui-layout', null],
  ];
  for (const [target, expected] of variants) {
    consumer.client.inject = [target];
    const verdict = verdictFor(registry, '@local/dsh-consumer');
    if (expected === null) {
      assert.equal(verdict.level, 'ok', `${target} is a known provider`);
    } else {
      assert.equal(verdict.level, 'quarantine', `${target} must quarantine`);
      assert.equal(signalsOf(verdict).includes(expected), true, `${target} → ${expected}`);
    }
  }
  assert.equal(byPackage.get('@local/dsh-noclient').client.declared, false, 'that plugin declares no dsh.client');
  assert.equal(byPackage.get('@local/dsh-noclient').inBundles, true);
  assert.equal(byPackage.get('@local/dsh-off').inBundles, false, 'not in dsh.profile.bundles');
  assert.equal(verdictFor(registry, '@local/dsh-off').level, 'warn', 'a listed dependency that never loads is a warning');
});

test('pre-flight: platform, missing client export, and a syntax error are quarantines', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-p': 'link:./dsh-p', '@local/dsh-e': 'link:./dsh-e', '@local/dsh-s': 'link:./dsh-s' },
    bundles: ['@local/dsh-p', '@local/dsh-e', '@local/dsh-s'],
    plugins: [
      pluginFixture({ name: '@local/dsh-p', platform: null, inject: [] }),
      pluginFixture({ name: '@local/dsh-e', clientExport: false, inject: [] }),
      pluginFixture({ name: '@local/dsh-s', inject: [], client: 'window.__ModuleLoader__.load({ id: 1, factory( { return {}; });\n' }),
    ],
  });
  const registry = registryFor(fixture);
  const platform = verdictFor(registry, '@local/dsh-p');
  assert.equal(platform.level, 'quarantine');
  assert.equal(signalsOf(platform).includes('client-platform-missing'), true);
  const missingExport = verdictFor(registry, '@local/dsh-e');
  assert.equal(missingExport.level, 'quarantine');
  assert.equal(signalsOf(missingExport).includes('client-export-missing'), true);
  const syntax = verdictFor(registry, '@local/dsh-s');
  assert.equal(syntax.level, 'quarantine');
  assert.equal(signalsOf(syntax).includes('client-syntax'), true);
});

test('resolution: a bundle named in dsh.profile.bundles that is not on disk is flagged', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-real': 'link:./dsh-real' },
    bundles: ['@deepseek-ai/dsh-base', '@local/dsh-real', '@local/dsh-ghost'],
    plugins: [pluginFixture({ name: '@local/dsh-real' })],
  });
  const registry = registryFor(fixture);
  const ghost = verdictFor(registry, '@local/dsh-ghost');
  assert.equal(ghost.level, 'quarantine');
  assert.equal(signalsOf(ghost).includes('bundle-unresolved'), true);
  assert.equal(ghost.rowId, 'dsh-ghost');
  assert.equal(ghost.rowIdSource, 'convention', 'the row id is derived, and the override asserts name:');
  assert.equal(verdictFor(registry, '@local/dsh-real').level, 'ok');
  // A stale `link:` target (dependency declared, directory gone) is flagged too.
  const stale = makeFixture({
    dependencies: { '@local/dsh-gone': 'link:./dsh-gone' },
    bundles: ['@local/dsh-gone'],
  });
  const staleRegistry = registryFor(stale);
  const gone = verdictFor(staleRegistry, '@local/dsh-gone');
  assert.equal(gone.level, 'quarantine');
  assert.equal(signalsOf(gone).includes('manifest-unreadable'), true);
  assert.equal(gone.rowId, 'dsh-gone');
});

test('resolution: core bundles are never judged (their tree is not the profile)', () => {
  const fixture = makeFixture({ dependencies: {}, bundles: ['@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app'] });
  const registry = registryFor(fixture);
  const { verdicts } = validateRegistry(registry);
  assert.deepEqual(verdicts, []);
});

test('resolution: an unreadable profile manifest is a safe no-op, not a crash', () => {
  const fixture = makeFixture({ dependencies: {}, bundles: [] });
  writeFileSync(join(fixture.profileDir, 'package.json'), '{ not json', 'utf8');
  const registry = registryFor(fixture);
  assert.equal(registry.ok, false);
  assert.match(registry.error, /profile manifest unreadable/);
  const report = runBootGuard({
    io,
    config: {},
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    crashLogsDir: fixture.logsDir,
    now: Date.now(),
  });
  assert.equal(report.actions.length, 0);
  assert.equal(report.profile.ok, false);
  assert.match(report.profile.error, /unreadable/);
});

// ---------------------------------------------------------------------------
// the patch editor (pure over a given text)

const USER_PATCH = [
  '# Your patch layer for this dsh profile.',
  '- id: ui-theme',
  '  name: "@deepseek-ai/dsh-client-ui-theme"',
  '  config:',
  '    preference: dark',
  '',
  '- id: dsh-clock',
  '  name: "@local/dsh-clock"',
  '  config:',
  '    seconds: true',
  '',
].join('\n');

test('patch: structure validation accepts a real profile patch and rejects what we must not edit', () => {
  assert.equal(validatePatchStructure(USER_PATCH).ok, true);
  assert.equal(validatePatchStructure('[]\n').ok, true);
  assert.equal(validatePatchStructure('').ok, true);
  assert.equal(validatePatchStructure('- id: x\n\tconfig: y\n').ok, false, 'tabs are refused');
  assert.equal(validatePatchStructure('id: x\n').ok, false, 'a top-level mapping is refused');
  assert.equal(validatePatchStructure('- id: "unbalanced\n').ok, false);
  const nestedSequence = '- id: provider\n  name: "@local/provider"\n  config:\n    defaultInput:\n      - text\n      - image\n';
  assert.equal(validatePatchStructure(nestedSequence).ok, true, 'valid nested scalar sequences in real profile configuration are accepted');
  const quarantine = planPatchEdit(nestedSequence, { rowId: 'dsh-fullscreen', packageName: '@local/dsh-fullscreen', enabled: false });
  assert.equal(quarantine.ok, true, 'a valid profile using nested sequence values remains quarantinable');
  assert.equal(patchOverrideDisabled(quarantine.text, 'dsh-fullscreen', '@local/dsh-fullscreen'), true);
});

test('patch: row ids come from the bundle own insert list', () => {
  const patch = '# c\n- insert:\n    - id: dsh-auto-kill\n      name: "@local/dsh-auto-kill"\n      config:\n        dryRun: false\n';
  assert.deepEqual(rowIdsFromPatch(patch, '@local/dsh-auto-kill'), [{ id: 'dsh-auto-kill', name: '@local/dsh-auto-kill' }]);
  assert.deepEqual(rowIdsFromPatch(patch, '@local/dsh-other'), []);
  const analysis = analyzePatch(USER_PATCH);
  assert.equal(analysis.items.length, 2);
  assert.equal(findLastOverride(analysis, 'dsh-clock', '@local/dsh-clock').fields.config !== undefined, true);
  assert.equal(patchOverrideDisabled(USER_PATCH, 'dsh-clock', '@local/dsh-clock'), undefined);
});

test('patch: quarantine APPENDS a minimal override that asserts the package name', () => {
  const plan = planPatchEdit(USER_PATCH, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: false });
  assert.equal(plan.ok, true);
  assert.equal(plan.changed, true);
  assert.equal(plan.edit.kind, 'append');
  assert.equal(USER_PATCH.includes('dsh-auto-kill'), false, 'the input text is never mutated');
  const lines = plan.text.split('\n');
  assert.equal(lines.at(-1), '', 'the file still ends with a newline');
  assert.equal(plan.text.includes(`${MARKER_PREFIX} quarantined @local/dsh-auto-kill`), true);
  assert.equal(plan.text.includes('- id: dsh-auto-kill\n  name: "@local/dsh-auto-kill"\n  disabled: true\n'), true);
  assert.equal(plan.text.includes('preference: dark'), true, 'every existing line survives verbatim');
  assert.equal(plan.text.startsWith(USER_PATCH), true, 'appending never rewrites earlier content');
  assert.equal(verifyPatchOutcome(plan.text, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: false }), true);
  assert.equal(patchOverrideDisabled(plan.text, 'dsh-auto-kill', '@local/dsh-auto-kill'), true);
});

test('patch: quarantine UPDATES the last matching override instead of appending', () => {
  const text = `${USER_PATCH}\n- id: dsh-auto-kill\n  name: "@local/dsh-auto-kill"\n  config:\n    enabled: true\n`;
  const plan = planPatchEdit(text, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: false });
  assert.equal(plan.edit.kind, 'in-place-insert');
  assert.equal(plan.text.includes('  disabled: true\n  config:\n    enabled: true\n'), true);
  assert.equal(plan.text.split('\n').length, text.split('\n').length + 1);
  // With an override that already names `disabled`, the value is replaced.
  const explicit = `${text}  disabled: false\n`;
  const second = planPatchEdit(explicit, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: false });
  assert.equal(second.edit.kind, 'in-place-set');
  assert.equal(second.text.includes('disabled: true'), true);
  assert.equal(second.text.includes('disabled: false'), false);
  assert.equal(second.text.split('\n').length, explicit.split('\n').length, 'a value edit does not change the line count');
  assert.equal(patchOverrideDisabled(second.text, 'dsh-auto-kill', '@local/dsh-auto-kill'), true);
});

test('patch: a second edit is a no-op (idempotence at the text level)', () => {
  const first = planPatchEdit(USER_PATCH, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: false });
  const second = planPatchEdit(first.text, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: false });
  assert.equal(second.changed, false);
  assert.equal(second.edit.reason, 'already-disabled');
  assert.equal(second.text, first.text);
});

test('patch: a wrong row id is fenced by the name assertion and never touches another row', () => {
  const text = '- id: dsh-clock\n  name: "@local/dsh-clock"\n  disabled: false\n';
  const plan = planPatchEdit(text, { rowId: 'dsh-clock', packageName: '@local/dsh-auto-kill', enabled: false });
  assert.equal(plan.edit.kind, 'append', 'the name mismatch means the existing row is not ours to edit');
  const analysis = analyzePatch(plan.text);
  const clock = findLastOverride(analysis, 'dsh-clock', '@local/dsh-clock');
  assert.equal(clock.fields.disabled.value, 'false');
  assert.equal(patchOverrideDisabled(plan.text, 'dsh-clock', '@local/dsh-clock'), false);
});

test('patch: re-enable removes the block we wrote, and only that block', () => {
  const quarantined = planPatchEdit(USER_PATCH, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: false }).text;
  const back = planPatchEdit(quarantined, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: true });
  assert.equal(back.changed, true);
  assert.equal(back.edit.kind, 'remove-block');
  assert.equal(back.text, USER_PATCH, 'the file is byte-identical to the pre-quarantine text');
  assert.equal(back.text.includes('dsh-boot-guard'), false);
  const again = planPatchEdit(back.text, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: true });
  assert.equal(again.changed, false, 'nothing left to re-enable');
});

test('patch: re-enable of a user-authored disable flips the value instead of deleting content', () => {
  const text = '- id: dsh-clock\n  name: "@local/dsh-clock"\n  config:\n    seconds: true\n  disabled: true\n';
  const plan = planPatchEdit(text, { rowId: 'dsh-clock', packageName: '@local/dsh-clock', enabled: true });
  assert.equal(plan.edit.kind, 'in-place-set');
  assert.equal(plan.text.includes('seconds: true'), true, 'the user config survives');
  assert.equal(patchOverrideDisabled(plan.text, 'dsh-clock', '@local/dsh-clock'), false);
});

test('patch: an empty (or flow-empty) patch file is written correctly', () => {
  const empty = planPatchEdit('', { rowId: 'dsh-x', packageName: '@local/dsh-x', enabled: false });
  assert.equal(empty.text, `${MARKER_PREFIX} quarantined @local/dsh-x — disable override, safe to delete\n- id: dsh-x\n  name: "@local/dsh-x"\n  disabled: true\n`);
  const flow = planPatchEdit('[]\n', { rowId: 'dsh-x', packageName: '@local/dsh-x', enabled: false });
  assert.equal(flow.edit.replacedEmptySequence, true);
  assert.equal(flow.text.startsWith('[]'), false, 'the empty flow sequence is replaced, not appended to');
  assert.equal(validatePatchStructure(flow.text).ok, true);
});

test('patch: a corrupt patch refuses every edit (safe no-op)', () => {
  const corrupt = 'id: not-a-sequence\n  bad indent\ttab\n';
  const plan = planPatchEdit(corrupt, { rowId: 'dsh-x', packageName: '@local/dsh-x', enabled: false });
  assert.equal(plan.ok, false);
  assert.equal(plan.changed, false);
  assert.equal(plan.error, 'patch-not-parseable');
  assert.equal(plan.text, corrupt, 'the refused plan returns the input untouched');
});

// ---------------------------------------------------------------------------
// the file-touching paths

test('apply: quarantine backs the file up, writes atomically, and verifies the result', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const before = readFileSync(file, 'utf8');
  const result = applyProfileEdit({
    io,
    profileDir: fixture.profileDir,
    decision: { packageName: '@local/dsh-auto-kill', rowId: 'dsh-auto-kill', enabled: false },
    now: new Date('2026-10-12T01:35:00Z'),
  });
  assert.equal(result.ok, true);
  assert.equal(result.action, 'written');
  assert.equal(result.edit.kind, 'append');
  const after = readFileSync(file, 'utf8');
  assert.equal(after.startsWith(before), true);
  assert.equal(patchOverrideDisabled(after, 'dsh-auto-kill', '@local/dsh-auto-kill'), true);
  assert.equal(existsSync(result.backup), true, 'the backup exists before the write');
  assert.equal(readFileSync(result.backup, 'utf8'), before, 'the backup is the pre-edit text');
  assert.match(result.backup, /cordis\.patch\.yml\.bak-bootguard-\d{8}-\d{6}$/);
  const leftovers = readdirSync(fixture.profileDir).filter((name) => name.includes('.tmp'));
  assert.deepEqual(leftovers, [], 'no temp file is left behind');
  // No other entry was disturbed.
  assert.equal(after.includes('preference: dark'), true);
  assert.equal(after.includes('ui-theme'), true);
});

test('apply: dryRun plans the edit and writes nothing (no backup, no mtime change)', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const before = readFileSync(file, 'utf8');
  const beforeStat = statSync(file).mtimeMs;
  const result = applyProfileEdit({
    io,
    profileDir: fixture.profileDir,
    decision: { packageName: '@local/dsh-auto-kill', rowId: 'dsh-auto-kill', enabled: false },
    dryRun: true,
  });
  assert.equal(result.action, 'dry-run');
  assert.equal(result.edit.kind, 'append');
  assert.equal(readFileSync(file, 'utf8'), before);
  assert.equal(statSync(file).mtimeMs, beforeStat);
  assert.deepEqual(
    readdirSync(fixture.profileDir).filter((name) => name.includes('bak-bootguard')),
    [],
    'dryRun leaves no backup',
  );
});

test('apply: an unreadable profile patch is a safe no-op that says so', () => {
  const fixture = incidentFixture();
  rmSync(join(fixture.profileDir, 'cordis.patch.yml'));
  const result = applyProfileEdit({
    io,
    profileDir: fixture.profileDir,
    decision: { packageName: '@local/dsh-auto-kill', rowId: 'dsh-auto-kill', enabled: false },
  });
  assert.equal(result.ok, false);
  assert.equal(result.action, 'refused');
  assert.match(result.error, /unreadable/);
  assert.equal(existsSync(join(fixture.profileDir, 'cordis.patch.yml')), false, 'nothing is created');
});

test('apply: a corrupt profile patch is a safe no-op that says so', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  writeFileSync(file, 'id: broken\n\t- id: nested\n', 'utf8');
  const result = applyProfileEdit({
    io,
    profileDir: fixture.profileDir,
    decision: { packageName: '@local/dsh-auto-kill', rowId: 'dsh-auto-kill', enabled: false },
  });
  assert.equal(result.ok, false);
  assert.equal(result.error, 'patch-not-parseable');
  assert.equal(readFileSync(file, 'utf8'), 'id: broken\n\t- id: nested\n');
  assert.deepEqual(
    readdirSync(fixture.profileDir).filter((name) => name.includes('bak-bootguard')),
    [],
    'a refused edit never even backs up',
  );
});

// ---------------------------------------------------------------------------
// the whole run

test('run: the incident produces exactly one quarantine, and a second run changes nothing', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const first = runBootGuard({
    io,
    config: {},
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    crashLogsDir: fixture.logsDir,
    now: Date.parse('2026-10-12T01:35:00Z'),
  });
  assert.equal(first.actions.length, 1, 'the crash log names one plugin');
  assert.equal(first.actions[0].packageName, '@local/dsh-auto-kill');
  assert.equal(first.actions[0].action, 'written');
  assert.equal(first.quarantines.length, 1);
  assert.equal(first.quarantines[0].reason, 'crash-log:pending');
  assert.equal(first.quarantines[0].rowId, 'dsh-auto-kill');
  assert.equal(first.verdicts.find((verdict) => verdict.packageName === '@local/dsh-auto-kill').level, 'quarantine');
  assert.equal(first.verdicts.find((verdict) => verdict.packageName === '@local/dsh-clock').level, 'ok');
  const written = readFileSync(file, 'utf8');
  const writtenStat = statSync(file).mtimeMs;
  const backups = readdirSync(fixture.profileDir).filter((name) => name.includes('bak-bootguard'));
  assert.equal(backups.length, 1);

  const second = runBootGuard({
    io,
    config: {},
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    crashLogsDir: fixture.logsDir,
    now: Date.parse('2026-10-12T01:40:00Z'),
  });
  assert.equal(second.actions[0].action, 'no-change');
  assert.equal(second.actions[0].idempotent, true);
  assert.equal(readFileSync(file, 'utf8'), written, 'the patch text is unchanged');
  assert.equal(statSync(file).mtimeMs, writtenStat, 'and the file was not rewritten');
  assert.equal(readdirSync(fixture.profileDir).filter((name) => name.includes('bak-bootguard')).length, 1, 'no second backup');
  assert.equal(second.quarantines.length, 1);

  const state = readState({ io, paths: bootGuardPaths(fixture.homeDir) });
  assert.equal(state.quarantines['@local/dsh-auto-kill'].applied, true);
  assert.equal(state.quarantines['@local/dsh-auto-kill'].evidence.find((item) => item.kind === 'crash-log')?.line, 13);
  const audit = readFileSync(join(fixture.homeDir, 'boot-guard', 'audit.log'), 'utf8').trim().split('\n').map((line) => JSON.parse(line));
  assert.equal(audit[0].kind, 'quarantine');
  assert.equal(audit[0].packageName, '@local/dsh-auto-kill');
  assert.equal(audit[0].edit.kind, 'append');
  assert.match(audit[0].evidence.find((item) => item.kind === 'crash-log')?.file ?? '', /crash-2026-10-11T16-50-18-321Z-web-boot\.log$/);
});

test('run: a live renderer activation failure quarantines only the registered third-party plugin', () => {
  const plugin = pluginFixture({ name: '@local/dsh-fullscreen', rowId: 'dsh-fullscreen' });
  const fixture = makeFixture({
    dependencies: { '@local/dsh-fullscreen': 'link:./dsh-fullscreen' },
    bundles: ['@local/dsh-fullscreen'],
    plugins: [plugin],
    patch: '',
  });
  const report = runBootGuard({
    io,
    config: {},
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    crashLogsDir: fixture.logsDir,
    runtimeFailures: [{ packageName: '@local/dsh-fullscreen' }],
    now: Date.parse('2026-10-12T09:00:00Z'),
  });
  assert.equal(report.quarantines.length, 1);
  assert.equal(report.quarantines[0].packageName, '@local/dsh-fullscreen');
  assert.equal(report.quarantines[0].applied, true);
  assert.match(readFileSync(join(fixture.profileDir, 'cordis.patch.yml'), 'utf8'), /disabled: true/u);
  assert.equal(readdirSync(fixture.profileDir).filter((name) => name.includes('bak-bootguard')).length, 1);
});

test('run: dryRun decides but performs no write at all', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const before = readFileSync(file, 'utf8');
  const report = runBootGuard({
    io,
    config: { dryRun: true },
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    crashLogsDir: fixture.logsDir,
  });
  assert.equal(report.dryRun, true);
  assert.equal(report.actions.length, 1);
  assert.equal(report.actions[0].action, 'dry-run');
  assert.equal(readFileSync(file, 'utf8'), before, 'the profile patch is byte-identical');
  assert.equal(report.quarantines.length, 0, 'nothing is recorded as applied');
  assert.deepEqual(readdirSync(fixture.profileDir).filter((name) => name.includes('bak-bootguard')), []);
});

test('run: autoQuarantine=false observes only', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const before = readFileSync(file, 'utf8');
  const report = runBootGuard({
    io,
    config: { autoQuarantine: false },
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    crashLogsDir: fixture.logsDir,
  });
  assert.equal(report.actions[0].action, 'observed');
  assert.equal(readFileSync(file, 'utf8'), before);
  const audit = readFileSync(join(fixture.homeDir, 'boot-guard', 'audit.log'), 'utf8');
  assert.match(audit, /"kind":"observed"/);
});

test('run: disabled=true does nothing at all', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const before = readFileSync(file, 'utf8');
  const report = runBootGuard({
    io,
    config: { disabled: true },
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    crashLogsDir: fixture.logsDir,
  });
  assert.equal(report.disabled, true);
  assert.equal(report.actions.length, 0);
  assert.equal(readFileSync(file, 'utf8'), before);
  assert.equal(existsSync(join(fixture.homeDir, 'boot-guard', 'state.json')), false, 'a disabled plugin writes no state');
});

test('run: a log that names several plugins quarantines each named one once', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-a': 'link:./dsh-a', '@local/dsh-b': 'link:./dsh-b' },
    bundles: ['@local/dsh-a', '@local/dsh-b'],
    plugins: [pluginFixture({ name: '@local/dsh-a' }), pluginFixture({ name: '@local/dsh-b' })],
    crashLogs: [
      {
        name: 'crash-2026-10-12T00-00-00-000Z-web-boot.log',
        text: 'Error: web boot: 2 entries did not activate\n@local/dsh-a: pending (waiting for service: x)\n@local/dsh-b: failed: Error: boom\n',
      },
    ],
  });
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  writeFileSync(file, '[]\n', 'utf8');
  const report = runBootGuard({ io, config: {}, profileDir: fixture.profileDir, homeDir: fixture.homeDir, crashLogsDir: fixture.logsDir });
  assert.equal(report.actions.length, 2);
  assert.deepEqual(report.actions.map((action) => action.packageName).sort(), ['@local/dsh-a', '@local/dsh-b']);
  assert.equal(report.quarantines.length, 2);
  const text = readFileSync(file, 'utf8');
  assert.equal(text.includes('- id: dsh-a\n  name: "@local/dsh-a"\n  disabled: true\n'), true);
  assert.equal(text.includes('- id: dsh-b\n  name: "@local/dsh-b"\n  disabled: true\n'), true);
});

test('crash scan: only the newest few host/web-boot logs are read', () => {
  const fixture = makeFixture({
    dependencies: { '@local/dsh-a': 'link:./dsh-a', '@local/dsh-b': 'link:./dsh-b' },
    bundles: ['@local/dsh-a', '@local/dsh-b'],
    plugins: [pluginFixture({ name: '@local/dsh-a' }), pluginFixture({ name: '@local/dsh-b' })],
    crashLogs: [
      { name: 'crash-2026-10-11T16-00-00-000Z-web-boot.log', text: '@local/dsh-a: failed: Error: old\n' },
      { name: 'crash-2026-10-11T17-00-00-000Z-web-boot.log', text: '@local/dsh-b: failed: Error: new\n' },
      { name: 'crash-2026-10-11T18-00-00-000Z-host.log', text: 'source: host\n@local/dsh-a: failed: Error: host startup failed\n' },
      { name: 'not-a-crash.log', text: '@local/dsh-a: failed: Error: ignore\n' },
      { name: 'crash-other-kind.log', text: '@local/dsh-a: failed: Error: ignore\n' },
    ],
  });
  const logs = listCrashLogs({ io, logsDir: fixture.logsDir });
  assert.deepEqual(logs.map((log) => log.name).sort(), ['crash-2026-10-11T16-00-00-000Z-web-boot.log', 'crash-2026-10-11T17-00-00-000Z-web-boot.log', 'crash-2026-10-11T18-00-00-000Z-host.log']);
  const limited = listCrashLogs({ io, logsDir: fixture.logsDir, limit: 1 });
  assert.equal(limited.length, 1);
  const report = runBootGuard({ io, config: { maxCrashLogs: 1 }, profileDir: fixture.profileDir, homeDir: fixture.homeDir, crashLogsDir: fixture.logsDir });
  assert.deepEqual(report.crash.entries.map((entry) => entry.packageName), ['@local/dsh-a'], 'only the newest host log is read');
  assert.equal(report.crash.files[0].read, true);
  assert.equal(CRASH_LOG_BYTES >= 65536, true);
});

test('state: a user re-enable is noticed, moved to history, and not re-disabled blind', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const paths = bootGuardPaths(fixture.homeDir);
  runBootGuard({ io, config: {}, profileDir: fixture.profileDir, homeDir: fixture.homeDir, crashLogsDir: fixture.logsDir });
  // The user edits the profile patch and takes our block out again.
  const quarantined = readFileSync(file, 'utf8');
  const reenabled = planPatchEdit(quarantined, { rowId: 'dsh-auto-kill', packageName: '@local/dsh-auto-kill', enabled: true });
  writeFileSync(file, reenabled.text, 'utf8');
  const state = readState({ io, paths });
  const reconciled = reconcileState(state, reenabled.text, Date.now());
  assert.deepEqual(Object.keys(reconciled.quarantines), []);
  assert.equal(reconciled.history[0].enabledByUser, true);
  writeState({ io, paths, state: reconciled });
  const report = runBootGuard({ io, config: {}, profileDir: fixture.profileDir, homeDir: fixture.homeDir, crashLogsDir: fixture.logsDir });
  assert.equal(report.quarantines.length, 0, 'the state no longer claims a disable we do not own');
  assert.equal(report.enabledByUser.length >= 1, true);
});

test('reenable: removes our override, clears the record, and audits the change', () => {
  const fixture = incidentFixture();
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const before = readFileSync(file, 'utf8');
  const paths = bootGuardPaths(fixture.homeDir);
  runBootGuard({ io, config: {}, profileDir: fixture.profileDir, homeDir: fixture.homeDir, crashLogsDir: fixture.logsDir });
  const result = reenablePackage({
    io,
    config: {},
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    packageName: '@local/dsh-auto-kill',
  });
  assert.equal(result.ok, true);
  assert.equal(result.action, 'written');
  assert.equal(result.edit.kind, 'remove-block');
  assert.equal(readFileSync(file, 'utf8'), before, 'the patch is exactly the pre-quarantine text');
  assert.deepEqual(Object.keys(readState({ io, paths }).quarantines), []);
  const audit = readFileSync(paths.auditFile, 'utf8');
  assert.match(audit, /"kind":"reenable"/);
  // Unknown / protected / dry-run re-enables refuse instead of writing.
  assert.equal(reenablePackage({ io, config: {}, profileDir: fixture.profileDir, homeDir: fixture.homeDir, packageName: '@local/dsh-clock' }).error, 'not-quarantined');
});

test('reenable: dryRun refuses with a reason instead of writing', () => {
  const fixture = incidentFixture();
  runBootGuard({ io, config: {}, profileDir: fixture.profileDir, homeDir: fixture.homeDir, crashLogsDir: fixture.logsDir });
  const file = join(fixture.profileDir, 'cordis.patch.yml');
  const written = readFileSync(file, 'utf8');
  const result = reenablePackage({
    io,
    config: { dryRun: true },
    profileDir: fixture.profileDir,
    homeDir: fixture.homeDir,
    packageName: '@local/dsh-auto-kill',
  });
  assert.equal(result.ok, false);
  assert.equal(result.error, 'dry-run');
  assert.equal(readFileSync(file, 'utf8'), written);
});

test('audit: the log is bounded and rotated instead of growing forever', () => {
  const fixture = incidentFixture();
  const paths = bootGuardPaths(fixture.homeDir);
  mkdirSync(paths.stateDir, { recursive: true });
  writeFileSync(join(paths.stateDir, 'audit.log'), 'x'.repeat(512 * 1024 + 10), { encoding: 'utf8', flag: 'w' });
  appendAudit({ io, paths, record: { kind: 'test' } });
  const text = readFileSync(paths.auditFile, 'utf8');
  assert.equal(text.includes('"rotated":true'), true);
  assert.equal(text.length < 1000, true);
});

// ---------------------------------------------------------------------------
// syntax check + route guard

test('syntax: compile-only check catches a broken client half and accepts a real one', () => {
  assert.equal(checkJavaScriptSyntax('var a = 1;\n').ok, true);
  assert.equal(checkJavaScriptSyntax('function ( { \n').ok, false);
  assert.match(checkJavaScriptSyntax('function ( { \n').error, /function name|Unexpected|SyntaxError/i);
  const real = readFileSync(join(import.meta.dirname, 'client.js'), 'utf8');
  const measured = process.hrtime.bigint();
  const verdict = checkJavaScriptSyntax(real, 'client.js');
  const micros = Number(process.hrtime.bigint() - measured) / 1000;
  assert.equal(verdict.ok, true, 'our own client half parses');
  assert.equal(micros < 500000, true, `compile stays far under 0.5s (measured ${Math.round(micros)}µs)`);
  console.log(`     compile: our client.js (${real.length} bytes) checked in ${Math.round(micros)}µs`);
});

test('route: the token contract — cross-site, wrong token, wrong method, timing-safe compare', () => {
  const token = 'ab'.repeat(24);
  assert.equal(authorized({ headers: { 'x-dsh-boot-guard-token': token } }, token), true);
  assert.equal(authorized({ headers: { 'x-dsh-boot-guard-token': token, 'sec-fetch-site': 'cross-site' } }, token), false);
  assert.equal(authorized({ headers: { 'x-dsh-boot-guard-token': 'ab' } }, token), false);
  assert.equal(authorized({ headers: {} }, token), false);
  assert.equal(authorized(undefined, token), false);
});

test('fixture hygiene: fixtures stay inside the temp root and are cleaned afterward', () => {
  assert.equal(ROOT.includes('dsh-boot-guard-test-'), true);
  assert.equal(existsSync(join(ROOT, 'fx-1', 'home', 'profiles', 'desktop', 'package.json')), true);
  assert.equal(existsSync(join(ROOT, 'fx-1', 'logs')), true);
});

// ---------------------------------------------------------------------------



let failed = 0;
for (const { name: testName, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${testName}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${testName}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
rmSync(ROOT, { recursive: true, force: true });
if (failed > 0) process.exitCode = 1;

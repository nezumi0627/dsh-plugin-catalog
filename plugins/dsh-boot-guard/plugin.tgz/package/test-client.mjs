import assert from 'node:assert/strict';

const loaded = [], registrations = [], effects = [];
globalThis.window = { __ModuleLoader__: { load: (spec) => loaded.push(spec) } };
globalThis.document = { createElement: () => ({ setAttribute() {}, remove() {} }), head: { append() {} } };
await import('./client.js');
assert.equal(loaded.length, 1);
const React = {
  createElement: (type, props, ...children) => ({ type, props: { ...props, children } }),
  useState: (initial) => [typeof initial === 'function' ? initial() : initial, () => {}],
  useEffect: (effect) => effects.push(effect),
};
const plugin = loaded[0].factory((name) => {
  if (name === 'react') return React;
  throw new Error(`unexpected require: ${name}`);
});
plugin.apply({
  slots: { inject: (_name, callback) => callback(), register: (options, component) => { registrations.push({ options, component }); return () => {}; } },
  locale: { register: () => () => {}, getLocale: () => ({ active: 'en' }) },
  effect: (effect) => { const cleanup = effect(); if (cleanup) effects.push(() => cleanup()); },
});
assert.ok(registrations.some(({ options }) => options.name === 'settings.general.item' && options.id === '@local/dsh-boot-guard'));
assert.equal(typeof plugin.__test.request, 'function');
let calls = [];
globalThis.fetch = async (url, options = {}) => {
  calls.push({ url, options });
  return url === '/local/boot-guard-token'
    ? { ok: true, json: async () => ({ data: { path: '/local/boot-guard', token: 'test-token' } }) }
    : { ok: true, json: async () => ({ ok: true, data: { status: 'ok' } }) };
};
await plugin.__test.request('POST', { action: 'recheck' });
assert.deepEqual(calls.map(({ url }) => url), ['/local/boot-guard-token', '/local/boot-guard']);
assert.equal(calls[1].options.headers['x-dsh-boot-guard-token'], 'test-token');
assert.equal(JSON.parse(calls[1].options.body).action, 'recheck');
for (const dispose of effects.reverse()) dispose();
console.log('ok   settings registration and authenticated host request');
console.log('1/1 checks passed');

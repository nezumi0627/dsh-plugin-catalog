import assert from 'node:assert/strict';
import { transformCoreWidgets } from './desktop/core-widgets.js';

const chatManifest = JSON.stringify({ name: '@deepseek-ai/dsh-client-ui-chat', dsh: { client: { platform: 'web', inject: ['@deepseek-ai/dsh-client-ui-layout'] } } });
const conversationManifest = JSON.stringify({ name: '@deepseek-ai/dsh-client-ui-conversation', dsh: { client: { platform: 'web', inject: ['@deepseek-ai/dsh-client-ui-layout'] } } });
const chatClient = `const inject = [\n\t\t\t"sidebarRight"\n\t\t];\nfunction apply(ctx) {\n\t\t\tctx.slots.inject("conversation.composer.dock", () => ctx.slots.register({\n\t\t\t\tname: "conversation.composer.dock",\n\t\t\t\tid: "stats",\n\t\t\t\torder: 0,\n\t\t\t\tlocale: NS,\n\t\t\t\tinject: () => ({ hooks: { performanceUsage } })\n\t\t\t}, StatsPills));\n}`;
const conversationClient = `const inject = [\n\t\t\t"configForms"\n\t\t];\n\t\t/** Validated Conversation runtime configuration. */\n\t\tconst Config = schema;\n\t\tfunction apply(ctx, config = Config({})) {\n\t\t\tconst t = ctx.locale.bind(NS);\n\t\t}\n\t\tconst InputBar = (0, react.memo)(function InputBar({ useProjection, renderSlot, t, activity, variant, input, sessionId }) {\n\t\t\treturn jsx("div", {\n\t\t\t\tchildren: [variant === "composer" && input !== void 0 && sessionId !== void 0 ? renderSlot("conversation.composer.dock", {}) : null, activity ? null : (0, react_jsx_runtime.jsx)(ContextMeter, {\n\t\t\t\t\tuseProjection,\n\t\t\t\t\tt\n\t\t\t\t})]\n\t\t\t});\n\t\t});\n\t\t"conversation.composer.dock": {\n\t\t\tkind: "list",\n\t\t\tscope: "session"\n\t\t}`;

const before = { chatManifest, chatClient, conversationManifest, conversationClient };
const first = transformCoreWidgets(before);
assert.equal(first.status, 'applied');
assert.match(first.files.chatManifest, /@local\/dsh-status-widgets/);
assert.match(first.files.chatClient, /ctx\.get\("statusWidgets"\)/);
assert.match(first.files.chatClient, /conversation\.composer\.stats/);
assert.doesNotMatch(first.files.chatClient, /slots\.inject\("conversation\.composer\.dock"[^]*?StatsPills/);
assert.match(first.files.conversationManifest, /@local\/dsh-status-widgets/);
assert.match(first.files.conversationClient, /subscribePortalTarget\("dsh\.core\.context-meter"/);
assert.match(first.files.conversationClient, /subscribePortalTarget\("dsh\.core\.chat-stats"/);
assert.match(first.files.conversationClient, /createPortal\)\(renderSlot\("conversation\.composer\.stats"/);
assert.match(first.files.conversationClient, /createPortal\)\(\(0, react_jsx_runtime\.jsx\)\(ContextMeter/);
assert.match(first.files.conversationClient, /"conversation\.composer\.stats": \{/);
const second = transformCoreWidgets(first.files);
assert.equal(second.status, 'already-applied', 'the core patch is idempotent');
const statsRegistration = chatClient.slice(chatClient.indexOf('ctx.slots.inject('), chatClient.indexOf(';', chatClient.indexOf('ctx.slots.inject(')) + 1);
assert.throws(() => transformCoreWidgets({ ...before, chatClient: chatClient.replace(statsRegistration, `${statsRegistration}\n${statsRegistration}`) }), /expected exactly one/);
console.log('core composer widgets attach to persistent movable portal targets; transform is idempotent and rejects ambiguous anchors');

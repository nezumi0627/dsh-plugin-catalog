import assert from 'node:assert/strict';
import { mkdtempSync, readSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { runInNewContext } from 'node:vm';
import { closeArchive, findEntry, openArchive, readEntryBuffer, snapshotEntries } from './desktop/asar.js';
import { ensureClientBootIsolation } from './desktop/archive.js';
import { CLIENT_BOOT_DIAGNOSTIC_MARKER, CLIENT_BOOT_MARKER, transformClientBoot } from './desktop/client-boot.js';

const original = 'function eM(e,n){for(const s of e.loader.entries()){}const o=[];if(o.length>0)throw new Error(`web boot: ${String(o.length)} entries did not activate\n${o.join(`\n`)}`)}function yn(e,n){}';
const transformed = transformClientBoot(original);
assert.equal(transformed.status, 'applied');
assert.equal(transformClientBoot(transformed.source).status, 'already-applied');
assert.ok(transformed.source.includes(CLIENT_BOOT_MARKER));
assert.ok(transformed.source.includes(CLIENT_BOOT_DIAGNOSTIC_MARKER));
const legacy = 'function eM(e,n){const o=[];for(const s of e.loader.entries()){};console.error("[dsh-boot-guard] optional client plugin failed");if(o.length)throw new Error("web boot: did not activate")}function yn(e,n){}';
const upgraded = transformClientBoot(legacy);
assert.equal(upgraded.status, 'upgraded');
assert.ok(upgraded.source.includes(CLIENT_BOOT_DIAGNOSTIC_MARKER));

const calls = [];
const sandbox = {
  A7: { active: 'active', pending: 'pending', failed: 'failed' },
  console: { error: (...args) => calls.push(['error', ...args]), warn: (...args) => calls.push(['warn', ...args]) },
  fetch: async (url, options) => {
    calls.push([url, options]);
    if (url === '/local/boot-guard-token') return { ok: true, json: async () => ({ data: { path: '/local/boot-guard', token: 'test-token' } }) };
    return { ok: true };
  },
  Promise,
  Set,
  JSON,
};
runInNewContext(`${transformed.source};globalThis.bootSummary=eM`, sandbox);
const failedPlugin = { options: { name: '@local/dsh-fullscreen' }, fiber: { state: 'failed', inject: {} } };
assert.doesNotThrow(() => sandbox.bootSummary({ loader: { entries: () => [failedPlugin] }, get: () => undefined }, { importError: () => undefined }));
await new Promise((resolve) => setTimeout(resolve, 0));
assert.ok(calls.some(([url]) => url === '/local/boot-guard-token'));
const quarantine = calls.find(([url]) => url === '/local/boot-guard');
assert.ok(quarantine);
assert.equal(JSON.parse(quarantine[1].body).package, '@local/dsh-fullscreen');
assert.equal(quarantine[1].headers['x-dsh-boot-guard-token'], 'test-token');
assert.throws(
  () => sandbox.bootSummary({ loader: { entries: () => [{ options: { name: '@deepseek-ai/dsh-client-store' }, fiber: { state: 'failed', inject: {}, _error: new Error('sidebar failure synthetic') } }] }, get: () => undefined }, { importError: () => undefined }),
  (error) => /required client entries did not activate/u.test(error.message) && /sidebar failure synthetic/u.test(error.message),
  'required core startup failures include the original activation error in the boot report',
);

function writeFixtureArchive(path, { minimalHeader = false, trailer = Buffer.alloc(0) } = {}) {
  const manifest = Buffer.from(JSON.stringify({ name: '@deepseek-ai/dsh-desktop' }));
  const js = Buffer.from(original);
  const payload = Buffer.concat([manifest, js]);
  const entry = (size, offset) => ({ size, offset: String(offset) });
  const header = {
    files: {
      'package.json': entry(manifest.length, 0),
      dsh: { files: {
        node_modules: { files: {
          '@deepseek-ai': { files: {
            'dsh-web-frontend': { files: {
              dist: { files: {
                assets: { files: { 'index-test.js': entry(js.length, manifest.length) } },
              } },
            } },
          } },
        } },
      } },
    },
  };
  const json = Buffer.from(JSON.stringify(header));
  const headerSize = minimalHeader ? Math.ceil(json.length / 4) * 4 : 16_384;
  const prefix = Buffer.alloc(16);
  prefix.writeUInt32LE(4, 0);
  prefix.writeUInt32LE(headerSize + 8, 4);
  prefix.writeUInt32LE(headerSize + 4, 8);
  prefix.writeUInt32LE(headerSize, 12);
  const padded = Buffer.alloc(headerSize, 0x20);
  json.copy(padded);
  writeFileSync(path, Buffer.concat([prefix, padded, payload, trailer]));
}

const temp = mkdtempSync(join(tmpdir(), 'dsh-boot-guard-client-'));
try {
  const archivePath = join(temp, 'app.asar');
  const orphanTail = Buffer.from('preserve-unreferenced-tail');
  writeFixtureArchive(archivePath, { minimalHeader: true, trailer: orphanTail });
  const before = openArchive(archivePath);
  const beforeEntries = snapshotEntries(before.header);
  const beforeHeaderSize = before.headerSize;
  closeArchive(before);
  const applied = ensureClientBootIsolation(archivePath);
  assert.equal(applied.status, 'staged');
  const source = openArchive(archivePath);
  assert.equal(source.headerSize, beforeHeaderSize, 'staging leaves the live archive untouched');
  assert.deepEqual(snapshotEntries(source.header), beforeEntries);
  closeArchive(source);
  const after = openArchive(applied.stagedPath);
  const afterEntries = snapshotEntries(after.header);
  const assetEntry = findEntry(after.header, ['dsh', 'node_modules', '@deepseek-ai', 'dsh-web-frontend', 'dist', 'assets', 'index-test.js']);
  const asset = readEntryBuffer(after, assetEntry).toString();
  const tail = Buffer.alloc(orphanTail.length);
  const originalPayloadLength = Buffer.byteLength(JSON.stringify({ name: '@deepseek-ai/dsh-desktop' })) + Buffer.byteLength(original);
  readSync(after.fd, tail, 0, tail.length, after.dataOffset + originalPayloadLength);
  closeArchive(after);
  assert.deepEqual([...afterEntries.keys()].filter((key) => beforeEntries.get(key) !== afterEntries.get(key)), ['dsh/node_modules/@deepseek-ai/dsh-web-frontend/dist/assets/index-test.js']);
  assert.ok(asset.includes(CLIENT_BOOT_MARKER));
  assert.deepEqual(tail, orphanTail, 'repacking preserves an unreferenced trailer');
  assert.equal(ensureClientBootIsolation(archivePath).status, 'staged');
} finally {
  rmSync(temp, { recursive: true, force: true });
}

console.log('boot isolation allows app boot after optional failure, quarantines only named profile plugins, preserves core failure, and patches only the frontend archive entry');

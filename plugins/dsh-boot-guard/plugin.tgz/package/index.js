/**
 * Host half of `@local/dsh-boot-guard` — boot survivability for DSH.
 *
 * The incident this exists for (2026-10-12): `@local/dsh-auto-kill` listed a
 * *module seed* (`@deepseek-ai/dsh-client-ui-primitives`) in
 * `dsh.client.inject`. In the **client boot graph** that list means "these
 * client entries must be active before me"; a seed is a pure `require()`-able
 * module and provides no client service, so the entry stayed
 * `pending (waiting for service: …)`, the client boot aborted, and the whole
 * app came up without a composer. The host loader is lenient (only 7 entry ids
 * are required) — the strict path is the web boot.
 *
 * Two defences, both here:
 *   1. **Early pre-flight** — every registered out-of-tree plugin is validated
 *      in `apply`, synchronously, before the window's client boot fetches its
 *      graph. Definitive defects quarantine the plugin (one atomic edit of the
 *      profile's `cordis.patch.yml`).
 *   2. **Crash-log recovery** — the newest `crash-*-web-boot.log` and
 *      `crash-*-host.log` files are parsed; explicit plugin activation failures,
 *      renderer errors naming one plugin, and traced `process.exit()` calls from
 *      a registered plugin's own files are quarantined, so the NEXT start can
 *      boot. Generic host exits and Node warnings are not attribution.
 *
 * This module is node-builtins only (a profile-local bundle cannot resolve
 * `@deepseek-ai/*`), has no side effects at import time, and keeps every piece
 * of decision logic in exported pure functions so it is testable without a
 * running app. See README.md for the decision table and the safety rules.
 */
import { randomBytes, timingSafeEqual } from 'node:crypto';
import {
  appendFileSync,
  closeSync,
  copyFileSync,
  existsSync,
  mkdirSync,
  openSync,
  readFileSync,
  readSync,
  readdirSync,
  realpathSync,
  renameSync,
  statSync,
  unlinkSync,
  writeFileSync,
} from 'node:fs';
import { homedir } from 'node:os';
import { basename, dirname, isAbsolute, join, posix, resolve, win32 } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Script } from 'node:vm';
import { applyClientBootIsolation } from './desktop/archive.js';

export const name = 'dsh-boot-guard';
export const VERSION = '1.0.0';
export const PACKAGE = '@local/dsh-boot-guard';
export const ROUTE_PATH = '/local/boot-guard';
export const TOKEN_PATH = '/local/boot-guard-token';
export const BOOTSTRAP_KEY = '__DSH_BOOT_GUARD__';
export const TOKEN_HEADER = 'x-dsh-boot-guard-token';
export const STATE_VERSION = 1;

/**
 * The 9 module seeds of the client graph. They resolve as bare `require()`
 * specifiers, provide no client service, and therefore may NEVER appear in a
 * `dsh.client.inject` list: the entry would wait forever and abort the boot.
 */
export const CLIENT_SEEDS = Object.freeze([
  'react',
  'react/jsx-runtime',
  'react-dom',
  'react-dom/client',
  '@deepseek-ai/cordis',
  '@deepseek-ai/dsh-client-store',
  '@deepseek-ai/dsh-client-ui-slots',
  '@deepseek-ai/dsh-client-ui-primitives',
  '@deepseek-ai/dsh-client-ui-dockkit',
]);

/**
 * Shipped client entries that really do provide a service and are the only
 * values observed in a working `dsh.client.inject` (the 5 the Lead verified).
 * They are not profile dependencies, so they must be allow-listed explicitly.
 */
export const KNOWN_CLIENT_INJECT_PROVIDERS = Object.freeze([
  '@deepseek-ai/dsh-client-locale',
  '@deepseek-ai/dsh-client-ui-layout',
  '@deepseek-ai/dsh-client-ui-conversation',
  '@deepseek-ai/dsh-client-shortcuts',
  '@deepseek-ai/dsh-client-ui-sidebar-right',
]);

/**
 * Host entry ids that reject startup when inactive (mirrors
 * `requiredStartupEntryIds` in `@deepseek-ai/dsh-app-boot`). Never touched.
 */
export const HOST_REQUIRED_IDS = Object.freeze([
  'agent-loop',
  'webserver',
  'modules',
  'connection',
  'headless-runner',
  'acp',
  'sdk-jsonrpc-server',
]);

/** Namespace of the shipped app: never examined strictly, never quarantined. */
export const CORE_SCOPE = '@deepseek-ai/';

/** Marker line that makes an override block provably ours (so it can be removed). */
export const MARKER_PREFIX = '# dsh-boot-guard:';
/** Cap on a client half we are willing to compile for the syntax check. */
export const MAX_CLIENT_SOURCE_BYTES = 2 * 1024 * 1024;
/** Crash-log scan bounds: never read an unbounded directory or file. */
export const CRASH_LOG_LIMIT = 5;
export const CRASH_LOG_BYTES = 256 * 1024;
/** Cap on parsed evidence entries (keeps one huge log from filling state). */
export const MAX_CRASH_ENTRIES = 24;

export const DEFAULT_CONFIG = Object.freeze({
  /** Master switch for the whole feature (pre-flight + recovery). */
  enabled: true,
  /** `true` switches this plugin itself off: `apply` does nothing at all. */
  disabled: false,
  /** Observe only: decide and log, write nothing. */
  dryRun: false,
  /** Gates step 1–3 (pre-flight quarantine, crash-log quarantine, re-enable writes). */
  autoQuarantine: true,
  /** Run the early pre-flight validator. */
  preflight: true,
  /** Parse crash logs and quarantine the plugin they name. */
  crashLogRecovery: true,
  /** How many of the newest `crash-*-web-boot.log` / `crash-*-host.log` files to read. */
  maxCrashLogs: CRASH_LOG_LIMIT,
  /** Byte cap per crash log. */
  crashLogBytes: CRASH_LOG_BYTES,
  /** Compile out-of-tree client halves to catch a syntax error before the page does. */
  syntaxCheck: true,
  /** Compile a client half at most this large (bytes). */
  maxClientSourceBytes: MAX_CLIENT_SOURCE_BYTES,
});

export function resolveConfig(config = {}) {
  const merged = { ...DEFAULT_CONFIG, ...(config && typeof config === 'object' ? config : {}) };
  const int = (value, fallback, min, max) => {
    const number = Number(value);
    if (!Number.isFinite(number)) return fallback;
    return Math.min(max, Math.max(min, Math.round(number)));
  };
  return {
    ...merged,
    enabled: merged.enabled !== false,
    disabled: merged.disabled === true,
    dryRun: merged.dryRun === true,
    autoQuarantine: merged.autoQuarantine !== false,
    preflight: merged.preflight !== false,
    crashLogRecovery: merged.crashLogRecovery !== false,
    syntaxCheck: merged.syntaxCheck !== false,
    maxCrashLogs: int(merged.maxCrashLogs, CRASH_LOG_LIMIT, 0, 20),
    crashLogBytes: int(merged.crashLogBytes, CRASH_LOG_BYTES, 4096, 8 * 1024 * 1024),
    maxClientSourceBytes: int(merged.maxClientSourceBytes, MAX_CLIENT_SOURCE_BYTES, 4096, 16 * 1024 * 1024),
  };
}

export function isCorePackage(packageName) {
  return typeof packageName === 'string' && packageName.startsWith(CORE_SCOPE);
}

/** A plugin we may never quarantine, whatever the evidence says. */
export function isProtectedTarget({ packageName, rowId }) {
  if (typeof packageName !== 'string' || packageName === '') return true;
  if (isCorePackage(packageName)) return true;
  if (packageName === PACKAGE) return true;
  if (typeof rowId === 'string' && HOST_REQUIRED_IDS.includes(rowId)) return true;
  return false;
}

// ---------------------------------------------------------------------------
// tiny structural YAML helpers (line-oriented, bounded, never a full parser)

/** Split into lines *with* their terminators, so joining restores the bytes. */
export function splitLines(text) {
  if (typeof text !== 'string' || text === '') return [];
  return text.match(/[^\n]*\n|[^\n]+$/g) ?? [];
}

export function lineBody(line) {
  return line.replace(/\r?\n$/, '');
}

function detectEol(text) {
  const match = /\r?\n/.exec(text ?? '');
  return match === null ? '\n' : match[0];
}

const TOP_ITEM = /^-(\s|$)/;
const FIELD = /^(\s*)(?:-\s+)?([A-Za-z_][\w.-]*)\s*:\s*(.*)$/;
const BLANK_OR_COMMENT = /^\s*(#.*)?$/;

/**
 * Structural check of a profile patch. This is deliberately strict and
 * deliberately not a YAML parser: we refuse to edit a document we cannot read
 * line-by-line, because the profile patch is the one file whose corruption
 * makes DSH unbootable. Documented limits: flow style (`{a: b}`), anchors,
 * block scalars and tabs are rejected.
 */
export function validatePatchStructure(text) {
  const errors = [];
  if (typeof text !== 'string') return { ok: false, errors: ['patch is not text'] };
  const lines = splitLines(text);
  let sawContent = false;
  for (let index = 0; index < lines.length; index += 1) {
    const body = lineBody(lines[index]);
    if (body.includes('\t')) errors.push(`line ${index + 1}: tab character (YAML forbids tabs in indentation)`);
    if (BLANK_OR_COMMENT.test(body)) continue;
    const trimmed = body.trim();
    if (trimmed === '[]' || trimmed === '---' || trimmed === '...') continue;
    if (/^\s/.test(body) && /^\s*-\s*$/.test(body) === false && /^\s+-\s+\S/.test(body) === false && FIELD.test(body) === false) {
      errors.push(`line ${index + 1}: unreadable indented line`);
      continue;
    }
    if (/^\s/.test(body)) continue;
    sawContent = true;
    if (!TOP_ITEM.test(body)) {
      errors.push(`line ${index + 1}: top-level content must be a sequence item ("- …")`);
      continue;
    }
    if ((body.match(/"/g) ?? []).length % 2 !== 0) errors.push(`line ${index + 1}: unbalanced double quote`);
    if (FIELD.test(body) === false && /^-\s*$/.test(body) === false && /^\-\s*$/.test(body) === false) {
      // `- { id: x }` and `- ""` are the shapes we refuse to reason about.
      errors.push(`line ${index + 1}: unreadable sequence item`);
    }
  }
  if (!sawContent && lines.every((line) => BLANK_OR_COMMENT.test(lineBody(line)))) return { ok: true, errors: [] };
  return { ok: errors.length === 0, errors };
}

function unquote(value) {
  const trimmed = String(value ?? '').trim();
  if (trimmed.length >= 2 && ((trimmed.startsWith('"') && trimmed.endsWith('"')) || (trimmed.startsWith("'") && trimmed.endsWith("'")))) {
    return trimmed.slice(1, -1);
  }
  return trimmed;
}

/**
 * Every top-level sequence item with the fields it declares at any depth.
 * `fields` keeps the first occurrence of each key; `lines` is `[start, end]`
 * inclusive in the `splitLines` array.
 */
export function analyzePatch(text) {
  const lines = splitLines(text);
  const items = [];
  for (let index = 0; index < lines.length; index += 1) {
    const body = lineBody(lines[index]);
    if (!TOP_ITEM.test(body)) continue;
    let end = index + 1;
    while (end < lines.length && !TOP_ITEM.test(lineBody(lines[end]))) end += 1;
    const fields = {};
    const keys = new Set();
    for (let cursor = index; cursor < end; cursor += 1) {
      const match = FIELD.exec(lineBody(lines[cursor]));
      if (match === null) continue;
      const key = match[2];
      keys.add(key);
      if (fields[key] === undefined) {
        // Sequence item fields are indented by two spaces relative to the
        // top-level dash, but FIELD captures the dash's indentation as well.
        // Keep the true value-column indent so in-place writes preserve YAML.
        const sequenceField = /^\s*-\s+/.test(lineBody(lines[cursor]));
        fields[key] = { line: cursor, indent: match[1].length + (sequenceField ? 2 : 0), raw: match[3].trim(), value: unquote(match[3]) };
      }
    }
    items.push({ start: index, end: end - 1, keys, fields, isOverride: keys.has('insert') === false });
  }
  return { lines, items, eol: detectEol(text) };
}

/** The plugin-manager rule: last override with this id, no `insert`, name absent or equal. */
export function findLastOverride(analysis, rowId, packageName) {
  let found = null;
  for (const item of analysis.items) {
    if (!item.isOverride || item.fields.id?.value !== rowId) continue;
    const declared = item.fields.name?.value;
    if (declared !== undefined && declared !== '' && declared !== packageName) continue;
    found = item;
  }
  return found;
}

/** Whether the override for `rowId` currently disables it (`true`/`false`/undefined). */
export function patchOverrideDisabled(text, rowId, packageName) {
  const analysis = analyzePatch(text);
  const target = findLastOverride(analysis, rowId, packageName);
  if (target === null) return undefined;
  const field = target.fields.disabled;
  if (field === undefined) return undefined;
  if (field.value === 'true') return true;
  if (field.value === 'false') return false;
  return 'expression';
}

/** Row ids a bundle's own patch inserts for `packageName` (block `insert:` form). */
export function rowIdsFromPatch(text, packageName) {
  const lines = splitLines(text);
  const rows = [];
  for (let index = 0; index < lines.length; index += 1) {
    const body = lineBody(lines[index]);
    const open = /^\s*(?:-\s+)?insert\s*:\s*$/.exec(body);
    if (open === null) continue;
    const parentIndent = body.length - body.trimStart().length;
    let cursor = index + 1;
    while (cursor < lines.length) {
      const child = lineBody(lines[cursor]);
      if (BLANK_OR_COMMENT.test(child)) {
        cursor += 1;
        continue;
      }
      const indent = child.length - child.trimStart().length;
      if (indent <= parentIndent) break;
      if (!/^\s*-\s/.test(child)) {
        cursor += 1;
        continue;
      }
      const childIndent = indent;
      let end = cursor + 1;
      while (end < lines.length) {
        const next = lineBody(lines[end]);
        if (BLANK_OR_COMMENT.test(next)) {
          end += 1;
          continue;
        }
        const nextIndent = next.length - next.trimStart().length;
        if (nextIndent <= childIndent || /^\s*-\s/.test(next)) break;
        end += 1;
      }
      const fields = {};
      for (let fieldIndex = cursor; fieldIndex < end; fieldIndex += 1) {
        const match = FIELD.exec(lineBody(lines[fieldIndex]));
        if (match === null) continue;
        if (fields[match[2]] === undefined) fields[match[2]] = unquote(match[3]);
      }
      if (fields.id !== undefined) rows.push({ id: fields.id, name: fields.name });
      cursor = end;
    }
    index = cursor - 1;
  }
  if (rows.length > 0) return rows.filter((row) => row.name === undefined || row.name === '' || row.name === packageName);
  return [];
}

// ---------------------------------------------------------------------------
// crash-log parsing

const CRASH_LINE = /^(?<indent>\s*)(?<id>[^\s():]+)(?:\s+\((?<name>[^()]+)\))?:\s*(?<detail>.+)$/;
const PENDING_LINE = /^pending \(waiting for service(?:s)?:\s*(?<missing>[^)]*)\)/;
const FAILED_LINE = /^([A-Za-z][\w -]*:\s*)?(failed|error|Error)\b/;
const IMPORT_FAILED_LINE = /^import failed\b/;
const CLIENT_SCRIPT_FAILURE = /^dsh-app:\/\/app\/plugins\/\?\?(?<package>@[^/\s]+\/[^/\s]+)\/client\.js[^\s]*\s+(?:Uncaught\s+)?(?:SyntaxError|TypeError|ReferenceError)\b/i;
const HOST_EXIT_TRACE = /^\[dsh-host-exit-trace\] process\.exit\((?<code>[^)]*)\)/;
const HOST_UNCAUGHT_TRACE = /^\[dsh-host-uncaught\] origin=(?<origin>\S+)/;

function stackFramePath(line) {
  if (!/^\s*at\s/.test(line)) return null;
  const match = /(?:file:\/\/\/[^\s)]+|[A-Za-z]:[\\/][^\s)]+)\)?$/.exec(line);
  if (match === null) return null;
  let value = match[0].replace(/\)?$/, '').replace(/:\d+:\d+$/, '');
  if (value.startsWith('file:///')) {
    try {
      value = fileURLToPath(value);
    } catch {
      return null;
    }
  }
  return value;
}

function pluginRoots(registry) {
  return (registry?.plugins ?? []).filter((plugin) => plugin.outOfTree === true).map((plugin) => {
    const roots = [plugin.dir];
    if (typeof plugin.dir === 'string') {
      try {
        roots.push(realpathSync(plugin.dir));
      } catch {
        // A removed link is already rejected by registry validation; retain the lexical path as a fallback.
      }
    }
    return { plugin, roots: [...new Set(roots.filter((root) => typeof root === 'string' && root !== ''))] };
  });
}

function isWithinPluginDirectory(file, candidates) {
  for (const { plugin, roots } of candidates) {
    for (const root of roots) {
      const paths = /^[A-Za-z]:[\\/]/.test(root) || /^[A-Za-z]:[\\/]/.test(file) ? win32 : posix;
      const relative = paths.relative(paths.resolve(root), paths.resolve(file));
      if (relative === '' || (relative !== '..' && !relative.startsWith(`..${paths.sep}`) && !paths.isAbsolute(relative))) return plugin;
    }
  }
  return null;
}

function tracedHostFailureEntries(lines, { registry, file, mtimeMs, maxEntries }) {
  if (!registry || maxEntries <= 0) return [];
  const entries = [];
  const candidates = pluginRoots(registry);
  for (let index = 0; index < lines.length && entries.length < maxEntries; index += 1) {
    const text = lineBody(lines[index]).trim();
    const exitMarker = HOST_EXIT_TRACE.exec(text);
    const uncaughtMarker = HOST_UNCAUGHT_TRACE.exec(text);
    if (exitMarker === null && uncaughtMarker === null) continue;
    if (exitMarker !== null && Number(exitMarker.groups.code) === 0) continue;
    let match = null;
    for (let cursor = index + 1; cursor < lines.length && cursor <= index + 48; cursor += 1) {
      const body = lineBody(lines[cursor]);
      if (body.trim() === '' || (!/^\s*at\s/.test(body) && cursor > index + 1)) break;
      const sourcePath = stackFramePath(body);
      if (sourcePath === null) continue;
      const plugin = isWithinPluginDirectory(sourcePath, candidates);
      if (plugin !== null) {
        match = { plugin, sourcePath, line: cursor + 1 };
        break;
      }
    }
    if (match === null) continue;
    entries.push({
      packageName: match.plugin.packageName,
      rowId: match.plugin.rowId ?? null,
      kind: uncaughtMarker === null ? 'host-exit' : 'host-uncaught',
      missing: [],
      file,
      mtimeMs,
      line: index + 1,
      sourceLine: match.line,
      sourcePath: match.sourcePath,
      text: uncaughtMarker === null
        ? `[dsh-host-exit-trace] process.exit(${exitMarker.groups.code})`
        : `[dsh-host-uncaught] origin=${uncaughtMarker.groups.origin}`,
    });
  }
  return entries;
}

/** `@local/x: pending (…)` → one bounded evidence entry. Both boot formats. */
export function parseCrashLog(text, { file = '', mtimeMs = null, maxEntries = MAX_CRASH_ENTRIES, registry = null } = {}) {
  const entries = [];
  const seen = new Set();
  if (typeof text !== 'string') return { entries, truncated: false };
  const lines = splitLines(text);
  for (const entry of tracedHostFailureEntries(lines, { registry, file, mtimeMs, maxEntries })) {
    const key = `${entry.packageName}|${entry.rowId ?? ''}|${entry.kind}`;
    if (seen.has(key)) continue;
    seen.add(key);
    entries.push(entry);
  }
  let pendingPackage = null;
  let pendingTable = false;
  for (let index = 0; index < lines.length; index += 1) {
    const body = lineBody(lines[index]).trim();
    if (body === '') {
      pendingTable = false;
      continue;
    }
    // Electron host crash reports can include renderer console errors. An
    // explicit plugin client-script failure is actionable evidence; a generic
    // host exit or Node warning (including DEP0180) is deliberately not.
    const clientFailure = CLIENT_SCRIPT_FAILURE.exec(body);
    if (clientFailure !== null) {
      const packageName = clientFailure.groups.package;
      const key = `${packageName}||failed|`;
      if (!seen.has(key)) {
        seen.add(key);
        entries.push({ packageName, rowId: null, kind: 'failed', missing: [], file, mtimeMs, line: index + 1, text: body.slice(0, 400) });
        if (entries.length >= maxEntries) return { entries, truncated: true };
      }
      continue;
    }
    if (/^Plugins waiting for services \(\d+\):$/.test(body)) {
      pendingTable = true;
      continue;
    }
    if (pendingTable && /^Package:\s*(\S+)\s*$/.test(body)) {
      const previous = entries.at(-1);
      if (previous?.kind === 'pending' && previous.packageName === null) previous.packageName = /^Package:\s*(\S+)\s*$/.exec(body)[1];
      continue;
    }
    if (pendingTable) {
      // The host's required-entry table: `<rowId>  <services>` — the package
      // name is absent, so the row id is the only handle and is resolved later.
      const row = /^(?<id>\S+?)(?: \(required\))?\s\s+(?<missing>.+)$/.exec(body);
      if (row !== null && row.groups.missing !== 'Missing services') {
        const missing = row.groups.missing.split(',').map((value) => value.trim()).filter((value) => value !== '').slice(0, 8);
        const key = `|${row.groups.id}|pending|${missing.join(',')}`;
        if (!seen.has(key)) {
          seen.add(key);
          entries.push({ packageName: null, rowId: row.groups.id, kind: 'pending', missing, file, line: index + 1, text: body.slice(0, 400) });
          if (entries.length >= maxEntries) return { entries, truncated: true };
        }
        continue;
      }
      // The grouped table ends at its first non-row. Do not swallow the next
      // ordinary diagnostic (often the import error that explains the row).
      pendingTable = false;
      index -= 1;
      continue;
    }
    const label = /^Package:\s*(\S+)\s*$/.exec(body);
    if (label !== null) {
      const previous = entries.at(-1);
      if (previous?.kind === 'pending' && previous.packageName === null && index > 0 && /Package:\s*\S+/.test(body)) previous.packageName = label[1];
      else pendingPackage = label[1];
      continue;
    }
    const match = CRASH_LINE.exec(body);
    if (match === null) continue;
    const detail = match.groups.detail;
    const pending = PENDING_LINE.exec(detail);
    let kind = null;
    let missing = [];
    if (pending !== null) {
      kind = 'pending';
      missing = pending.groups.missing
        .split(',')
        .map((value) => value.trim())
        .filter((value) => value !== '')
        .slice(0, 8);
    } else if (IMPORT_FAILED_LINE.test(detail)) {
      kind = 'import-failed';
    } else if (/^activate:\s*(?:Error|SyntaxError|TypeError)\b/i.test(detail) || FAILED_LINE.test(detail)) {
      kind = 'failed';
    }
    if (kind === null) continue;
    // Host form: `<rowId> (<package>): detail`. Web-boot form: `<package>: detail`
    // — there the id *is* the package name. Grouped form: a `Package:` line
    // already carried the package for this entry.
    const explicitName = match.groups.name;
    const rowId = explicitName === undefined ? null : match.groups.id;
    const named = explicitName ?? (match.groups.id.includes('/') ? match.groups.id : pendingPackage);
    pendingPackage = null;
    const packageName = typeof named === 'string' && named.includes('/') ? named : null;
    if (packageName === null) continue;
    const key = `${packageName}|${rowId ?? ''}|${kind}|${missing.join(',')}`;
    if (seen.has(key)) continue;
    seen.add(key);
    entries.push({ packageName, rowId, kind, missing, file, mtimeMs, line: index + 1, text: body.slice(0, 400) });
    if (entries.length >= maxEntries) return { entries, truncated: true };
  }
  return { entries, truncated: false };
}

/**
 * Which out-of-tree plugins the log evidence blames. The rule the spec demands:
 * at most one plugin per evidence line, but every plugin the log names when a
 * line names several; core, required and self are never candidates.
 * `dismissed` carries the evidence the user has already answered by pressing
 * 再有効化 — a stale log must not switch the same plugin off again on the next
 * start, or the button would be meaningless.
 */
export function decideCrashQuarantines({ entries, registry, dismissed = [] }) {
  const decisions = [];
  const byPackage = new Map();
  const dismissedKeys = new Set(dismissed);
  for (const entry of entries) {
    const plugin =
      registry?.pluginByPackage?.get?.(entry.packageName) ?? registry?.pluginByRowId?.get?.(entry.rowId) ?? null;
    if (plugin === null) continue; // not one of our registered out-of-tree plugins
    if (plugin.outOfTree !== true) continue;
    // A crash report stops describing the current plugin after its source or
    // profile configuration changes. Ignore that stale evidence; the next
    // launch will generate a fresh report if the revised plugin still fails.
    if (Number.isFinite(entry.mtimeMs)) {
      const io = plugin._io;
      const relevantFiles = [
        entry.sourcePath,
        plugin.client?.exportPath,
        plugin.manifestPath,
        join(plugin.dir, 'cordis.patch.yml'),
        registry.manifestPath,
      ].filter((path) => typeof path === 'string');
      if (relevantFiles.some((path) => Number(io?.mtimeMs?.(path)) > entry.mtimeMs)) continue;
    }
    const rowId = entry.rowId ?? plugin.rowId ?? plugin.rowIds?.[0] ?? null;
    if (isProtectedTarget({ packageName: plugin.packageName, rowId })) continue;
    const evidenceKey = `${basename(entry.file ?? '')}|${plugin.packageName}|${entry.kind}`;
    if (dismissedKeys.has(evidenceKey)) continue;
    const reason = `crash-log:${entry.kind}`;
    // A concrete crash-log row is stronger than a static suspicion (for
    // example, an earlier client entry never settled before the recorded
    // failure). Promote this to the decision; orchestration dedupes evidence.
    const existing = byPackage.get(plugin.packageName);
    const evidence = {
      kind: 'crash-log',
      key: evidenceKey,
      file: entry.file,
      line: entry.line,
      detail: `${plugin.packageName}: ${entry.kind}${entry.missing.length > 0 ? ` (waiting for service: ${entry.missing.join(', ')})` : ''}`,
    };
    if (existing !== undefined) {
      existing.evidence.push(evidence);
      continue;
    }
    const decision = {
      packageName: plugin.packageName,
      rowId,
      rowIdSource: 'patch',
      source: 'crash-log',
      reason,
      signal: entry.kind,
      detail: evidence.detail,
      evidence: [evidence],
    };
    byPackage.set(plugin.packageName, decision);
    decisions.push(decision);
  }
  return { decisions };
}

// ---------------------------------------------------------------------------
// registry collection (IO) + pre-flight validation (pure)

function linkTarget(spec) {
  if (typeof spec !== 'string') return null;
  const match = /^(link|file):(.+)$/.exec(spec.trim());
  if (match === null) return null;
  // `file:` may name a packed npm archive, not a directory. Resolve that
  // package through the installed node_modules entry just like registry specs;
  // joining `package.json` to the archive filename causes a false quarantine.
  if (match[1] === 'file' && /\.(?:tgz|tar(?:\.gz)?)$/iu.test(match[2])) return null;
  return { kind: match[1], path: match[2] };
}

/**
 * Compile only — never run. This is the in-process equivalent of
 * `node --check` for the *classic script* the client module system executes,
 * so it is bounded (one compile per client half per start, size-capped) and
 * never shells out per file.
 */
export function checkJavaScriptSyntax(source, filename = 'client.js') {
  try {
    // eslint-disable-next-line no-new
    new Script(source, { filename, displayErrors: false });
    return { ok: true };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

export function parseJsonObject(text) {
  if (typeof text !== 'string' || text.trim() === '') return { ok: false, error: 'empty' };
  try {
    const value = JSON.parse(text);
    if (value === null || typeof value !== 'object' || Array.isArray(value)) return { ok: false, error: 'not an object' };
    return { ok: true, value };
  } catch (error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
}

function readCapped(io, file, maxBytes) {
  try {
    if (typeof io.size === 'function') {
      const size = io.size(file);
      if (size === null) return null;
      if (size <= maxBytes) return readFileSync(file, 'utf8');
    }
  } catch {
    return null;
  }
  try {
    const handle = openSync(file, 'r');
    try {
      const buffer = Buffer.alloc(maxBytes);
      const read = readSync(handle, buffer, 0, maxBytes, 0);
      return buffer.subarray(0, read).toString('utf8');
    } finally {
      closeSync(handle);
    }
  } catch {
    return null;
  }
}

/**
 * Everything the validators need, read once: the profile manifest, the profile
 * patch, and each registered out-of-tree plugin (its own manifest, its own
 * patch, its client half, its row ids). IO only — no decisions here.
 */
export function collectRegistry({ io, profileDir }) {
  const manifestPath = join(profileDir, 'package.json');
  const manifestText = io.readText(manifestPath);
  const manifest = parseJsonObject(manifestText);
  if (!manifest.ok) {
    return {
      ok: false,
      profileDir,
      error: `profile manifest unreadable at ${manifestPath}: ${manifest.error}`,
      plugins: [],
      pluginByPackage: new Map(),
      bundles: [],
      patchText: '',
      patchOk: false,
      patchErrors: [],
    };
  }
  const profileJson = manifest.value;
  const dependencies = profileJson.dependencies && typeof profileJson.dependencies === 'object' ? profileJson.dependencies : {};
  const bundles = Array.isArray(profileJson?.dsh?.profile?.bundles)
    ? profileJson.dsh.profile.bundles.filter((value) => typeof value === 'string' && value !== '')
    : [];
  const patchPath = join(profileDir, 'cordis.patch.yml');
  const patchText = io.readText(patchPath) ?? '';
  const patchStructure = validatePatchStructure(patchText);
  const plugins = [];
  const handled = new Set();
  for (const [packageName, spec] of Object.entries(dependencies)) {
    const link = linkTarget(spec);
    if (link === null) continue;
    const dir = isAbsolute(link.path) ? link.path : resolve(profileDir, link.path);
    handled.add(packageName);
    plugins.push(readPlugin({ io, packageName, dir, dependencyKind: link.kind, bundles, patchText }));
  }
  for (const packageName of bundles) {
    if (handled.has(packageName) || isCorePackage(packageName)) continue;
    // Node-style scoped package layout is node_modules/@scope/name, not one
    // literal `@scope/name` child of node_modules.
    plugins.push(
      readPlugin({ io, packageName, dir: join(profileDir, 'node_modules', ...packageName.split('/')), dependencyKind: 'node_modules', bundles, patchText }),
    );
  }
  const pluginByPackage = new Map(plugins.map((plugin) => [plugin.packageName, plugin]));
  const pluginByRowId = new Map();
  for (const plugin of plugins) for (const rowId of plugin.rowIds) if (!pluginByRowId.has(rowId)) pluginByRowId.set(rowId, plugin);
  return { ok: true, profileDir, manifestPath, profileJson, dependencies, bundles, patchText, patchStructure, patchOk: patchStructure.ok, patchErrors: patchStructure.errors, plugins, pluginByPackage, pluginByRowId };
}

function readPlugin({ io, packageName, dir, dependencyKind, bundles, patchText, config }) {
  const manifestPath = join(dir, 'package.json');
  const manifestText = io.readText(manifestPath);
  const manifest = parseJsonObject(manifestText);
  const patchFile = join(dir, 'cordis.patch.yml');
  const ownPatch = io.readText(patchFile) ?? '';
  const rowIds = [
    ...rowIdsFromPatch(ownPatch, packageName).map((row) => row.id),
    ...rowIdsFromPatch(patchText, packageName).map((row) => row.id),
  ].filter((value, index, all) => typeof value === 'string' && value !== '' && all.indexOf(value) === index);
  const rowId = rowIds[0] ?? null;
  const inBundles = bundles.includes(packageName);
  const disabledByPatch = rowId === null ? undefined : patchOverrideDisabled(patchText, rowId, packageName);
  const client = { declared: false, platform: null, inject: [], exportPresent: false, exportPath: null, sourcePresent: null, syntax: null, sourceBytes: null };
  const clientManifest = manifest.ok ? manifest.value?.dsh?.client : undefined;
  if (clientManifest !== undefined && clientManifest !== null && typeof clientManifest === 'object') {
    client.declared = true;
    client.platform = typeof clientManifest.platform === 'string' ? clientManifest.platform : null;
    client.inject = Array.isArray(clientManifest.inject) ? clientManifest.inject.filter((value) => typeof value === 'string' && value !== '') : [];
    const exportsField = manifest.value?.exports;
    const entry = exportsField && typeof exportsField === 'object' ? exportsField['./client'] : undefined;
    client.exportPresent = typeof entry === 'string' && entry !== '';
    if (client.exportPresent) client.exportPath = join(dir, entry);
  }
  return {
    packageName,
    dir,
    dependencyKind,
    outOfTree: !isCorePackage(packageName),
    manifestOk: manifest.ok,
    manifestError: manifest.ok ? null : manifest.error,
    manifestPath,
    hasManifestFile: manifestText !== null,
    manifest: manifest.ok ? manifest.value : null,
    ownPatchPresent: ownPatch !== '',
    rowIds,
    rowId,
    inBundles,
    disabledByPatch,
    enabled: inBundles && disabledByPatch !== true,
    client,
    config: config ?? null,
    _io: io,
  };
}

/** Read + compile the client half (bounded), for the syntax verdict. */
export function inspectClientSource(plugin, { maxBytes }) {
  if (!plugin.client.declared || !plugin.client.exportPresent || typeof plugin.client.exportPath !== 'string') return;
  const text = readCapped(plugin._io, plugin.client.exportPath, maxBytes);
  if (text === null) {
    plugin.client.sourcePresent = false;
    return;
  }
  plugin.client.sourcePresent = true;
  plugin.client.sourceBytes = Buffer.byteLength(text, 'utf8');
  plugin.client.syntax = checkJavaScriptSyntax(text, plugin.client.exportPath);
}

const LEVEL_ORDER = { ok: 0, warn: 1, quarantine: 2 };

function worst(a, b) {
  return LEVEL_ORDER[b] > LEVEL_ORDER[a] ? b : a;
}

/**
 * The loader row id a local package declares by convention: `@local/dsh-foo`
 * inserts `- id: dsh-foo`, `@local/foo` inserts `- id: foo`. Used only when the
 * package's own `cordis.patch.yml` cannot be read (a stale `link:` target, an
 * unparsable manifest) AND the quarantine override asserts `name:` — the
 * loader skips an override whose `name` does not match the row it found
 * (`dsh-app-boot`: "patch: name mismatch for %C … skipping"), so a wrong guess
 * is inert instead of destructive.
 */
export function deriveRowIdCandidate(packageName) {
  if (typeof packageName !== 'string' || packageName === '') return null;
  const unscoped = packageName.startsWith('@') ? packageName.slice(packageName.indexOf('/') + 1) : packageName;
  const candidate = unscoped.replace(/[^A-Za-z0-9._-]/g, '');
  return candidate === '' || candidate === packageName ? null : candidate;
}

/**
 * THE decision table (see README for the prose version). Pure: it takes the
 * registry `collectRegistry` produced and returns per-plugin verdicts.
 */
export function validateRegistry(registry, { maxClientSourceBytes = MAX_CLIENT_SOURCE_BYTES } = {}) {
  const verdicts = [];
  if (!registry?.ok) {
    return { ok: false, error: registry?.error ?? 'no registry', verdicts: [] };
  }
  const byPackage = registry.pluginByPackage;
  const coreRowsKnown = new Set(KNOWN_CLIENT_INJECT_PROVIDERS);
  for (const plugin of registry.plugins) {
    const signals = [];
    if (plugin.manifestOk === false) {
      signals.push({
        code: plugin.dependencyKind === 'node_modules' ? 'bundle-unresolved' : 'manifest-unreadable',
        level: 'quarantine',
        detail: `package.json を解析できません: ${plugin.manifestError ?? 'unknown'}`,
      });
    }
    if (plugin.inBundles === false) {
      // Listed in `dependencies` as a link but absent from `dsh.profile.bundles`:
      // it never loads, which is informational unless something injects it.
      signals.push({ code: 'bundle-not-listed', level: 'warn', detail: 'dsh.profile.bundles に含まれていません' });
    }
    if (plugin.client.declared) {
      if (plugin.client.platform !== 'web') {
        signals.push({
          code: 'client-platform-missing',
          level: 'quarantine',
          detail: `dsh.client.platform が "web" ではありません (${JSON.stringify(plugin.client.platform)})`,
        });
      }
      if (plugin.client.exportPresent === false) {
        signals.push({ code: 'client-export-missing', level: 'quarantine', detail: 'exports["./client"] がありません' });
      } else {
        inspectClientSource(plugin, { maxBytes: maxClientSourceBytes });
        if (plugin.client.sourcePresent === false) {
          signals.push({ code: 'client-source-missing', level: 'quarantine', detail: `クライアント本体を読めません: ${plugin.client.exportPath}` });
        } else if (plugin.client.syntax !== null && plugin.client.syntax.ok === false) {
          signals.push({
            code: 'client-syntax',
            level: 'quarantine',
            detail: `クライアント本体が構文エラー: ${plugin.client.syntax.error}`,
          });
        }
      }
      for (const target of plugin.client.inject) {
        if (CLIENT_SEEDS.includes(target)) {
          signals.push({
            code: 'seed-in-inject',
            level: 'quarantine',
            detail: `dsh.client.inject にモジュールシード "${target}" があります (サービスを提供しないため必ず pending になります)`,
          });
          continue;
        }
        if (coreRowsKnown.has(target)) continue;
        const provider = byPackage.get(target) ?? null;
        if (provider === null) {
          if (isCorePackage(target)) {
            signals.push({
              code: 'inject-provider-core-unverified',
              level: 'warn',
              detail: `inject 先 "${target}" は同梱パッケージですが、サービスを提供するかはプロファイルから確認できません`,
            });
          } else {
            signals.push({
              code: 'inject-provider-unknown',
              level: 'quarantine',
              detail: `dsh.client.inject の "${target}" は登録されたクライアント項目ではありません`,
            });
          }
          continue;
        }
        if (provider.client.declared === false) {
          signals.push({
            code: 'inject-provider-no-client',
            level: 'quarantine',
            detail: `inject 先 "${target}" にクライアント側がありません`,
          });
          continue;
        }
        if (provider.enabled !== true) {
          signals.push({
            code: 'inject-provider-disabled',
            level: 'quarantine',
            detail: `inject 先 "${target}" が無効または未登録です`,
          });
          continue;
        }
        // `dsh.client.inject` targets must *provide a service*; a registered
        // entry whose own client half is defective can never do that.
        if (provider.client.platform !== 'web' || provider.client.exportPresent === false) {
          signals.push({
            code: 'inject-provider-broken',
            level: 'quarantine',
            detail: `inject 先 "${target}" 自身のクライアント側が不正です (platform=${JSON.stringify(provider.client.platform)}, exports["./client"]=${
              provider.client.exportPresent === true
            })`,
          });
        }
      }
    }
    let level = 'ok';
    for (const signal of signals) level = worst(level, signal.level);
    const target = { packageName: plugin.packageName, rowId: plugin.rowId };
    const protectedTarget = isProtectedTarget(target);
    let rowId = plugin.rowId;
    let rowIdSource = plugin.rowId === null ? 'none' : 'patch';
    if (level === 'quarantine' && !protectedTarget && rowId === null) {
      const candidate = deriveRowIdCandidate(plugin.packageName);
      if (candidate !== null) {
        rowId = candidate;
        rowIdSource = 'convention';
      }
    }
    if (level === 'quarantine' && protectedTarget) {
      signals.push({
        code: 'protected-target',
        level: 'warn',
        detail: isCorePackage(plugin.packageName)
          ? '同梱 (@deepseek-ai/*) のため無効化しません'
          : plugin.packageName === PACKAGE
            ? '自分自身は無効化しません'
            : 'ホスト必須 ID のため無効化しません',
      });
      level = 'warn';
    } else if (level === 'quarantine' && rowId === null) {
      signals.push({ code: 'no-row-id-evidence', level: 'warn', detail: 'ローダー行 ID を特定できないため書き換えません' });
      level = 'warn';
    }
    verdicts.push({
      packageName: plugin.packageName,
      dir: plugin.dir,
      rowId,
      rowIdSource,
      rowIds: plugin.rowIds,
      outOfTree: plugin.outOfTree,
      inBundles: plugin.inBundles,
      enabled: plugin.enabled,
      level,
      signals,
      reason: signals.filter((signal) => signal.level === 'quarantine').map((signal) => signal.code).join(',') || null,
    });
  }
  // Bundles that resolve nowhere at all (no dependency entry, no node_modules).
  for (const bundle of registry.bundles) {
    if (isCorePackage(bundle) || byPackage.has(bundle)) continue;
    const dir = join(registry.profileDir, 'node_modules', bundle);
    const candidate = deriveRowIdCandidate(bundle);
    verdicts.push({
      packageName: bundle,
      dir,
      rowId: candidate,
      rowIdSource: candidate === null ? 'none' : 'convention',
      rowIds: [],
      outOfTree: true,
      inBundles: true,
      enabled: false,
      level: candidate === null ? 'warn' : 'quarantine',
      signals: [
        {
          code: 'bundle-unresolved',
          level: 'quarantine',
          detail: 'dsh.profile.bundles にありますが、ディスク上に解決できません',
        },
        ...(candidate === null ? [{ code: 'no-row-id-evidence', level: 'warn', detail: 'ローダー行 ID を特定できないため書き換えません' }] : []),
      ],
      reason: candidate === null ? null : 'bundle-unresolved',
    });
  }
  return { ok: true, verdicts };
}

/** Verdicts that justify a write, capped by the safety rules. */
export function decidePreflight(verdicts) {
  const decisions = [];
  for (const verdict of verdicts) {
    if (verdict.level !== 'quarantine') continue;
    if (verdict.rowId === null) continue;
    if (isProtectedTarget({ packageName: verdict.packageName, rowId: verdict.rowId })) continue;
    const quarantineSignals = verdict.signals.filter((signal) => signal.level === 'quarantine');
    decisions.push({
      packageName: verdict.packageName,
      rowId: verdict.rowId,
      rowIdSource: verdict.rowIdSource ?? 'patch',
      source: 'preflight',
      reason: quarantineSignals.map((signal) => signal.code).join(','),
      signal: quarantineSignals[0]?.code ?? 'unknown',
      detail: quarantineSignals.map((signal) => signal.detail).join(' / '),
      evidence: quarantineSignals.map((signal) => ({ kind: 'preflight', code: signal.code, detail: signal.detail })),
    });
  }
  return { decisions };
}

// ---------------------------------------------------------------------------
// patch editing (pure over a given text)

function renderOverride({ rowId, packageName, markerPrefix, withMarker, disabled }) {
  const idText = /^[A-Za-z0-9_-]+$/.test(rowId) ? rowId : JSON.stringify(rowId);
  const lines = [];
  if (withMarker) lines.push(`${markerPrefix} quarantined ${packageName} — disable override, safe to delete`);
  lines.push(`- id: ${idText}`);
  if (typeof packageName === 'string' && packageName !== '') lines.push(`  name: ${JSON.stringify(packageName)}`);
  lines.push(`  disabled: ${disabled ? 'true' : 'false'}`);
  return lines;
}

function isOwnedBlock(analysis, item, markerPrefix) {
  const keys = [...item.keys];
  if (keys.some((key) => key !== 'id' && key !== 'name' && key !== 'disabled')) return false;
  const above = item.start > 0 ? lineBody(analysis.lines[item.start - 1]) : '';
  return above.trimStart().startsWith(markerPrefix);
}

function replaceLines(analysis, from, to, replacement) {
  const before = analysis.lines.slice(0, from);
  const after = analysis.lines.slice(to + 1);
  return [...before, ...replacement, ...after].join('');
}

function ensureTrailingNewline(text, eol) {
  if (text === '') return text;
  return text.endsWith('\n') ? text : `${text}${eol}`;
}

/**
 * Plan one atomic edit. `enabled: false` = quarantine, `true` = re-enable.
 * Never rewrites an already-correct file (`changed: false`), never removes
 * content it did not write itself, and refuses a document it cannot read.
 */
export function planPatchEdit(text, { rowId, packageName, enabled, markerPrefix = MARKER_PREFIX } = {}) {
  const structure = validatePatchStructure(text);
  if (!structure.ok) {
    return { ok: false, changed: false, error: 'patch-not-parseable', errors: structure.errors, text, edit: { kind: 'refused' } };
  }
  if (typeof rowId !== 'string' || rowId === '') {
    return { ok: false, changed: false, error: 'no-row-id', text, edit: { kind: 'refused' } };
  }
  const analysis = analyzePatch(text);
  const target = findLastOverride(analysis, rowId, packageName);
  if (enabled === false) {
    if (target !== null) {
      const field = target.fields.disabled;
      if (field !== undefined && field.value === 'true') {
        return { ok: true, changed: false, text, edit: { kind: 'none', reason: 'already-disabled' } };
      }
      if (field !== undefined) {
        const lines = [...analysis.lines];
        lines[field.line] = `${' '.repeat(field.indent)}disabled: true${analysis.eol}`;
        const next = lines.join('');
        return { ok: true, changed: true, text: next, edit: { kind: 'in-place-set', previousDisabled: field.value } };
      }
      const indent = target.fields.id?.indent ?? 2;
      const lines = [...analysis.lines];
      lines.splice((target.fields.name?.line ?? target.fields.id.line) + 1, 0, `${' '.repeat(indent)}disabled: true${analysis.eol}`);
      return { ok: true, changed: true, text: lines.join(''), edit: { kind: 'in-place-insert', previousDisabled: undefined } };
    }
    const block = renderOverride({ rowId, packageName, markerPrefix, withMarker: true, disabled: true }).map((line) => `${line}${analysis.eol}`);
    const emptyFlow = analysis.items.length === 0 ? analysis.lines.findIndex((line) => lineBody(line).trim() === '[]') : -1;
    if (emptyFlow >= 0) {
      const lines = [...analysis.lines];
      lines.splice(emptyFlow, 1, ...block);
      return { ok: true, changed: true, text: lines.join(''), edit: { kind: 'append', replacedEmptySequence: true } };
    }
    const body = analysis.lines.join('');
    const prefix = body === '' || body.endsWith('\n') ? body : `${body}${analysis.eol}`;
    return { ok: true, changed: true, text: prefix + block.join(''), edit: { kind: 'append', replacedEmptySequence: false } };
  }
  if (target !== null) {
    if (isOwnedBlock(analysis, target, markerPrefix)) {
      const from = target.start - 1 >= 0 && lineBody(analysis.lines[target.start - 1]).trimStart().startsWith(markerPrefix) ? target.start - 1 : target.start;
      const next = ensureTrailingNewline(replaceLines(analysis, from, target.end, []), analysis.eol);
      return { ok: true, changed: true, text: next, edit: { kind: 'remove-block' } };
    }
    const field = target.fields.disabled;
    if (field !== undefined && field.value === 'true') {
      const lines = [...analysis.lines];
      lines[field.line] = `${' '.repeat(field.indent)}disabled: false${analysis.eol}`;
      return { ok: true, changed: true, text: lines.join(''), edit: { kind: 'in-place-set', previousDisabled: true } };
    }
    return { ok: true, changed: false, text, edit: { kind: 'none', reason: 'not-disabled' } };
  }
  return { ok: true, changed: false, text, edit: { kind: 'none', reason: 'no-override' } };
}

/** Post-edit invariant: the file really says what we meant it to say. */
export function verifyPatchOutcome(text, { rowId, packageName, enabled }) {
  const state = patchOverrideDisabled(text, rowId, packageName);
  if (enabled === false) return state === true;
  return state !== true;
}

// ---------------------------------------------------------------------------
// node IO + state

export function createNodeIo() {
  return {
    exists: (file) => {
      try {
        return existsSync(file);
      } catch {
        return false;
      }
    },
    isDirectory: (file) => {
      try {
        return statSync(file).isDirectory();
      } catch {
        return false;
      }
    },
    size: (file) => {
      try {
        return statSync(file).size;
      } catch {
        return null;
      }
    },
    mtimeMs: (file) => {
      try {
        return statSync(file).mtimeMs;
      } catch {
        return null;
      }
    },
    readText: (file) => {
      try {
        return readFileSync(file, 'utf8');
      } catch {
        return null;
      }
    },
    readCapped,
    listDir: (dir) => {
      try {
        return readdirSync(dir, { withFileTypes: true }).map((entry) => ({
          name: entry.name,
          isDirectory: entry.isDirectory(),
          isFile: entry.isFile(),
          isSymbolicLink: entry.isSymbolicLink(),
          mtimeMs: (() => {
            try {
              return statSync(join(dir, entry.name)).mtimeMs;
            } catch {
              return null;
            }
          })(),
        }));
      } catch {
        return [];
      }
    },
    writeText: (file, text) => {
      mkdirSync(dirname(file), { recursive: true });
      writeFileSync(file, text, 'utf8');
    },
    copyFile: (from, to) => {
      copyFileSync(from, to);
    },
    rename: (from, to) => {
      renameSync(from, to);
    },
    unlink: (file) => {
      try {
        unlinkSync(file);
      } catch {
        /* the temp file may already be gone */
      }
    },
    appendText: (file, text) => {
      mkdirSync(dirname(file), { recursive: true });
      appendFileSync(file, text, 'utf8');
    },
  };
}

/** `$DSH_HOME` first, then `~/.dsh` — the guide's resolution order. */
export function resolveHomeDir({ env = process.env, home = null } = {}) {
  const explicit = env?.DSH_HOME;
  if (typeof explicit === 'string' && explicit.trim() !== '') return resolve(explicit.trim());
  return join(home ?? homedir(), '.dsh');
}

export function bootGuardPaths(homeDir) {
  const stateDir = join(homeDir, 'boot-guard');
  return { stateDir, stateFile: join(stateDir, 'state.json'), auditFile: join(stateDir, 'audit.log') };
}

/**
 * The active profile directory. The desktop host is launched as
 * `… dsh-desktop-host … <dshDir> <profileDir> …`, so the profile is the argv
 * entry that lives under `<home>/profiles/`; the explicit env override and the
 * `desktop` template come next. Never guessed from a computed path alone.
 */
export function resolveProfileDir({ io, homeDir, env = process.env, argv = process.argv } = {}) {
  const explicit = env?.DSH_PROFILE_DIR;
  if (typeof explicit === 'string' && explicit.trim() !== '' && io.isDirectory(explicit.trim())) return resolve(explicit.trim());
  const profilesRoot = join(homeDir, 'profiles');
  for (let index = (argv?.length ?? 0) - 1; index >= 0; index -= 1) {
    const value = argv[index];
    if (typeof value !== 'string' || value === '' || value.startsWith('--')) continue;
    const candidate = resolve(value);
    if (!io.isDirectory(candidate)) continue;
    if (dirname(candidate) !== resolve(profilesRoot)) continue;
    if (io.exists(join(candidate, 'package.json'))) return candidate;
  }
  const fallback = join(profilesRoot, 'desktop');
  if (io.isDirectory(fallback) && io.exists(join(fallback, 'package.json'))) return fallback;
  return null;
}

export function readState({ io, paths }) {
  const text = io.readText(paths.stateFile);
  const empty = { version: STATE_VERSION, updatedAt: null, quarantines: {}, history: [], lastRun: null };
  if (text === null) return empty;
  const parsed = parseJsonObject(text);
  if (!parsed.ok) return { ...empty, corrupt: true };
  const quarantines = parsed.value.quarantines && typeof parsed.value.quarantines === 'object' ? parsed.value.quarantines : {};
  const history = Array.isArray(parsed.value.history) ? parsed.value.history : [];
  return { ...empty, ...parsed.value, quarantines, history };
}

export const MAX_HISTORY = 20;

/**
 * Keep the state truthful: a record whose row is no longer disabled in the
 * patch was re-enabled outside boot-guard (the user edited the profile), so it
 * moves out of the active list and into the bounded history ring.
 */
export function reconcileState(state, patchText, now = Date.now()) {
  const active = {};
  const history = [...(state.history ?? [])];
  for (const [packageName, record] of Object.entries(state.quarantines ?? {})) {
    const stillDisabled =
      typeof record.rowId === 'string' && record.rowId !== '' && patchOverrideDisabled(patchText, record.rowId, packageName) === true;
    if (stillDisabled) {
      active[packageName] = record;
      continue;
    }
    history.unshift({ ...record, applied: false, enabledByUser: true, clearedAt: new Date(now).toISOString() });
  }
  return { ...state, quarantines: active, history: history.slice(0, MAX_HISTORY) };
}

export function writeState({ io, paths, state }) {
  const text = `${JSON.stringify({ ...state, version: STATE_VERSION, updatedAt: new Date().toISOString() }, null, 2)}\n`;
  const tmp = `${paths.stateFile}.tmp`;
  io.writeText(tmp, text);
  io.rename(tmp, paths.stateFile);
}

export const MAX_AUDIT_BYTES = 512 * 1024;

export function appendAudit({ io, paths, record }) {
  const size = io.size(paths.auditFile) ?? 0;
  if (size > MAX_AUDIT_BYTES) {
    io.unlink(paths.auditFile);
    record = { rotated: true, ...record };
  }
  io.appendText(paths.auditFile, `${JSON.stringify(record)}\n`);
}

function stampFor(date) {
  const pad = (value) => String(value).padStart(2, '0');
  return `${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
}

/**
 * Apply one decision to the profile patch: back up, edit, verify, write temp +
 * rename, re-verify. `dryRun` returns the planned text without touching disk.
 */
export function applyProfileEdit({ io, profileDir, decision, dryRun = false, now = new Date(), logger = null }) {
  const file = join(profileDir, 'cordis.patch.yml');
  const desiredEnabled = decision.reenable === true || decision.enabled === true;
  const text = io.readText(file);
  if (text === null) return { ok: false, action: 'refused', packageName: decision.packageName, error: 'profile patch is unreadable; nothing was changed' };
  const plan = planPatchEdit(text, { rowId: decision.rowId, packageName: decision.packageName, enabled: desiredEnabled });
  if (plan.ok === false) {
    logger?.warn?.(`[boot-guard] refusing to touch ${file}: ${plan.error}${plan.errors?.length ? ` (${plan.errors[0]})` : ''}`);
    return { ok: false, action: 'refused', packageName: decision.packageName, error: plan.error, errors: plan.errors ?? [] };
  }
  if (plan.changed === false) {
    return { ok: true, action: 'no-change', packageName: decision.packageName, edit: plan.edit };
  }
  if (!verifyPatchOutcome(plan.text, { rowId: decision.rowId, packageName: decision.packageName, enabled: desiredEnabled })) {
    return { ok: false, action: 'refused', packageName: decision.packageName, error: 'the planned text does not reach the intended state' };
  }
  const structure = validatePatchStructure(plan.text);
  if (!structure.ok) {
    return { ok: false, action: 'refused', packageName: decision.packageName, error: 'edited patch failed validation', errors: structure.errors };
  }
  if (dryRun) return { ok: true, action: 'dry-run', packageName: decision.packageName, edit: plan.edit };
  const backup = `${file}.bak-bootguard-${stampFor(now)}`;
  try {
    io.copyFile(file, backup);
  } catch (error) {
    return { ok: false, action: 'refused', packageName: decision.packageName, error: `backup failed, nothing written: ${error?.message ?? error}` };
  }
  const tmp = `${file}.${process.pid}.bootguard.tmp`;
  try {
    io.writeText(tmp, plan.text);
    io.rename(tmp, file);
  } catch (error) {
    io.unlink(tmp);
    return { ok: false, action: 'refused', packageName: decision.packageName, error: `write failed: ${error?.message ?? error}`, backup };
  }
  const after = io.readText(file);
  if (after !== plan.text) {
    return { ok: false, action: 'verify-failed', packageName: decision.packageName, error: 'the file on disk differs from the planned text', backup };
  }
  return { ok: true, action: 'written', packageName: decision.packageName, edit: plan.edit, backup };
}

// ---------------------------------------------------------------------------
// crash-log discovery (IO) + orchestration

const CRASH_FILE = /^crash-.*-(?:web-boot|host)\.log$/;

export function listCrashLogs({ io, logsDir, limit = CRASH_LOG_LIMIT }) {
  if (typeof logsDir !== 'string' || logsDir === '' || !io.isDirectory(logsDir)) return [];
  return io
    .listDir(logsDir)
    .filter((entry) => entry.isFile === true && CRASH_FILE.test(entry.name))
    .map((entry) => ({ file: join(logsDir, entry.name), name: entry.name, mtimeMs: entry.mtimeMs ?? 0 }))
    // Timestamps embedded in the canonical crash filename provide a stable
    // tie-breaker on filesystems whose mtime precision is coarse (common on
    // Windows and in deterministic tests).
    .sort((left, right) => right.mtimeMs - left.mtimeMs || right.name.localeCompare(left.name))
    .slice(0, Math.max(0, limit));
}

export function resolveCrashLogsDir({ env = process.env, appData = null } = {}) {
  const root = typeof env?.APPDATA === 'string' && env.APPDATA.trim() !== '' ? env.APPDATA.trim() : appData;
  if (typeof root !== 'string' || root === '') return null;
  return join(root, '@deepseek-ai', 'dsh-desktop', 'logs');
}

/**
 * The whole host-side run: pre-flight, crash-log recovery, quarantine writes,
 * state and audit. Synchronous on purpose — it must finish inside `apply`,
 * before the window's client boot asks for its graph.
 */
export function runBootGuard({
  io,
  config,
  profileDir,
  homeDir,
  crashLogsDir,
  logger = null,
  runtimeFailures = [],
  now = Date.now(),
}) {
  const settings = resolveConfig(config);
  const paths = bootGuardPaths(homeDir);
  const report = {
    version: VERSION,
    at: new Date(now).toISOString(),
    dryRun: settings.dryRun,
    autoQuarantine: settings.autoQuarantine,
    profile: { dir: profileDir, ok: false, error: null, patchOk: false, bundles: 0, plugins: 0, quarantined: 0 },
    verdicts: [],
    quarantines: [],
    crash: { dir: crashLogsDir, files: [], entries: [], decisions: [] },
    actions: [],
    timings: {},
  };
  if (settings.disabled || settings.enabled === false) {
    report.disabled = true;
    return report;
  }
  const started = Date.now();
  let state = readState({ io, paths });
  if (profileDir === null) {
    report.profile.error = '有効なプロファイルディレクトリを特定できませんでした';
    report.timings = { totalMs: Date.now() - started };
    return report;
  }
  const registry = collectRegistry({ io, profileDir });
  report.profile.ok = registry.ok === true;
  report.profile.patchOk = registry.patchOk === true;
  if (registry.ok !== true) {
    report.profile.error = registry.error;
    logger?.warn?.(`[boot-guard] ${registry.error} — nothing was changed`);
    report.timings = { totalMs: Date.now() - started };
    return report;
  }
  // A record whose row is enabled again in the patch was cleared by the user:
  // move it out of the active list so the state never claims a disable we do
  // not own any more.
  if (registry.patchStructure.ok) state = reconcileState(state, registry.patchText, now);
  report.enabledByUser = (state.history ?? []).filter((record) => record.enabledByUser === true && record.clearedAt !== undefined);
  report.profile.bundles = registry.bundles.length;
  report.profile.plugins = registry.plugins.length;
  // Both defences collect into one decision list, merged per package: the
  // incident trips the pre-flight AND the crash log, and the user must see one
  // quarantined plugin with two pieces of evidence — not two entries.
  const decisions = new Map();
  const dismissedRecords = (state.history ?? []).filter((record) => record.enabledByUser === true);
  const dismissed = dismissedRecords
    .flatMap((record) => (Array.isArray(record.evidence) ? record.evidence : []))
    .map((evidence) => evidence.key)
    .filter((key) => typeof key === 'string');
  const dismissedPackages = new Set(dismissedRecords.map((record) => record.packageName));
  const addDecision = (decision) => {
    const existing = decisions.get(decision.packageName);
    if (existing === undefined) {
      decisions.set(decision.packageName, { ...decision, sources: [decision.source], evidence: [...(decision.evidence ?? [])] });
      return;
    }
    const codes = new Set(`${existing.reason},${decision.reason}`.split(',').filter((code) => code !== ''));
    // Explicit crash evidence wins over static preflight signals for the
    // primary reason, while retaining both signals and evidence for review.
    if (decision.source === 'crash-log' && existing.source !== 'crash-log') {
      existing.reason = decision.reason;
      existing.signal = decision.signal;
      existing.source = 'crash-log';
    } else if (existing.source !== 'crash-log') {
      existing.reason = [...codes].join(',');
    }
    existing.sources = [...new Set([...existing.sources, decision.source])];
    const seen = new Set(existing.evidence.map((item) => JSON.stringify(item)));
    for (const item of decision.evidence) {
      if (seen.has(JSON.stringify(item))) continue;
      seen.add(JSON.stringify(item));
      existing.evidence.push(item);
    }
    existing.detail = [...new Set([existing.detail, decision.detail].filter((value) => typeof value === 'string' && value !== ''))].join(' / ');
  };
  const preflightStarted = Date.now();
  if (settings.preflight) {
    const validated = validateRegistry(registry, { maxClientSourceBytes: settings.maxClientSourceBytes });
    report.verdicts = validated.verdicts;
    const decided = decidePreflight(validated.verdicts);
    for (const decision of decided.decisions) if (!dismissedPackages.has(decision.packageName)) addDecision(decision);
  }
  report.timings.preflightMs = Date.now() - preflightStarted;
  const crashStarted = Date.now();
  if (settings.crashLogRecovery && crashLogsDir !== null) {
    const files = listCrashLogs({ io, logsDir: crashLogsDir, limit: settings.maxCrashLogs });
    for (const file of files) {
      const text = readCapped(io, file.file, settings.crashLogBytes);
      if (text === null) {
        report.crash.files.push({ file: file.file, name: file.name, read: false });
        continue;
      }
      const parsed = parseCrashLog(text, { file: file.file, mtimeMs: file.mtimeMs, registry });
      report.crash.files.push({ file: file.file, name: file.name, read: true, entries: parsed.entries.length, truncated: parsed.truncated });
      report.crash.entries.push(...parsed.entries);
    }
    const decided = decideCrashQuarantines({ entries: report.crash.entries, registry, dismissed });
    report.crash.decisions = decided.decisions;
    // One quarantine per crash-log evidence; a log naming several plugins names
    // several evidence lines, and each is its own decision.
    for (const decision of decided.decisions) addDecision(decision);
  }
  report.timings.crashMs = Date.now() - crashStarted;
  const runtimeStarted = Date.now();
  for (const failure of Array.isArray(runtimeFailures) ? runtimeFailures.slice(0, 20) : []) {
    const packageName = typeof failure?.packageName === 'string' ? failure.packageName : '';
    const plugin = registry.plugins.find((entry) => entry.packageName === packageName);
    if (!plugin || plugin.enabled !== true || plugin.outOfTree !== true || plugin.inBundles !== true) continue;
    const target = { packageName, rowId: plugin.rowId };
    if (plugin.rowId === null || isProtectedTarget(target) || dismissedPackages.has(packageName)) continue;
    addDecision({
      packageName,
      rowId: plugin.rowId,
      rowIdSource: 'patch',
      reason: 'runtime-activation-failed',
      signal: 'failed',
      detail: 'client entry failed during renderer startup',
      source: 'runtime',
      evidence: [{ kind: 'runtime', key: `runtime:${packageName}:${now}`, detail: 'client entry failed during renderer startup' }],
    });
  }
  report.timings.runtimeFailureMs = Date.now() - runtimeStarted;
  report.decisions = [...decisions.values()];
  for (const decision of report.decisions) {
    report.actions.push(quarantineDecision({ io, paths, state, profileDir, decision, settings, logger, now }));
  }
  for (const action of report.actions) {
    if (action.action !== 'written') continue;
    const record = state.quarantines[action.packageName];
    if (record !== undefined) state.quarantines[action.packageName] = { ...record, applied: true, backup: action.backup ?? null };
  }
  report.quarantines = Object.values(state.quarantines);
  report.profile.quarantined = report.quarantines.length;
  state.lastRun = { at: report.at, verdicts: report.verdicts.length, quarantines: report.quarantines.length, dryRun: settings.dryRun };
  try {
    writeState({ io, paths, state });
  } catch (error) {
    logger?.warn?.(`[boot-guard] state write failed: ${error?.message ?? error}`);
  }
  report.timings.totalMs = Date.now() - started;
  return report;
}

function quarantineDecision({ io, paths, state, profileDir, decision, settings, logger, now }) {
  const existing = state.quarantines[decision.packageName];
  if (existing !== undefined && existing.reason === decision.reason && existing.applied === true) {
    // Idempotent: the same plugin, the same reason, already handled.
    return { packageName: decision.packageName, action: 'no-change', idempotent: true, reason: decision.reason };
  }
  const record = {
    packageName: decision.packageName,
    rowId: decision.rowId,
    rowIdSource: decision.rowIdSource ?? 'patch',
    reason: decision.reason,
    signal: decision.signal,
    detail: decision.detail,
    source: decision.source,
    evidence: decision.evidence,
    at: new Date(now).toISOString(),
    applied: false,
    dryRun: settings.dryRun,
    enabledByUser: false,
  };
  const target = { packageName: decision.packageName, rowId: decision.rowId };
  if (isProtectedTarget(target)) {
    logger?.warn?.(`[boot-guard] refusing to quarantine protected ${decision.packageName}`);
    return { packageName: decision.packageName, action: 'refused', error: 'protected-target' };
  }
  if (!settings.autoQuarantine) {
    logger?.info?.(`[boot-guard] autoQuarantine is off — would quarantine ${decision.packageName} (${decision.reason})`);
    appendAudit({ io, paths, record: { at: record.at, kind: 'observed', ...record, applied: false, skipped: 'autoQuarantine' } });
    return { packageName: decision.packageName, action: 'observed', reason: decision.reason };
  }
  const result = applyProfileEdit({ io, profileDir, decision, dryRun: settings.dryRun, now: new Date(now), logger });
  const entry = { ...record, ...result, applied: result.action === 'written' || (result.action === 'no-change' && result.edit?.reason === 'already-disabled') };
  if (entry.applied) state.quarantines[decision.packageName] = entry;
  appendAudit({
    io,
    paths,
    record: {
      at: record.at,
      kind: result.action === 'written' ? 'quarantine' : result.action,
      packageName: record.packageName,
      rowId: record.rowId,
      reason: record.reason,
      detail: record.detail,
      source: record.source,
      evidence: record.evidence,
      edit: result.edit ?? null,
      backup: result.backup ?? null,
      error: result.error ?? null,
    },
  });
  logger?.info?.(
    `[boot-guard] ${result.action === 'written' ? 'quarantined' : result.action}: ${record.packageName} (${record.reason})` +
      `${result.backup ? ` backup=${basename(result.backup)}` : ''}`,
  );
  return entry;
}

/** Re-enable one plugin we quarantined: content-preserving, verified, audited. */
export function reenablePackage({ io, config, profileDir, homeDir, packageName, logger = null, now = Date.now() }) {
  const settings = resolveConfig(config);
  const paths = bootGuardPaths(homeDir);
  const state = readState({ io, paths });
  const record = state.quarantines[packageName];
  if (record === undefined) {
    return { ok: false, error: 'not-quarantined', packageName };
  }
  const target = { packageName, rowId: record.rowId };
  if (isProtectedTarget(target)) return { ok: false, error: 'protected-target', packageName };
  if (settings.dryRun || !settings.autoQuarantine) {
    appendAudit({ io, paths, record: { at: new Date(now).toISOString(), kind: 'reenable-skipped', packageName, reason: settings.dryRun ? 'dryRun' : 'autoQuarantine' } });
    return { ok: false, error: settings.dryRun ? 'dry-run' : 'auto-quarantine-off', packageName, record };
  }
  const result = applyProfileEdit({
    io,
    profileDir,
    decision: { packageName, rowId: record.rowId, enabled: true, reenable: true },
    dryRun: false,
    now: new Date(now),
    logger,
  });
  if (result.ok !== true) return { ok: false, error: result.error ?? result.action, packageName, record };
  const nextState = { ...state, quarantines: { ...state.quarantines } };
  delete nextState.quarantines[packageName];
  nextState.history = [
    { ...record, applied: false, enabledByUser: true, clearedAt: new Date(now).toISOString() },
    ...(state.history ?? []),
  ].slice(0, MAX_HISTORY);
  try {
    writeState({ io, paths, state: nextState });
  } catch (error) {
    logger?.warn?.(`[boot-guard] state write failed after re-enable: ${error?.message ?? error}`);
  }
  appendAudit({ io, paths, record: { at: new Date(now).toISOString(), kind: 'reenable', packageName, rowId: record.rowId, edit: result.edit ?? null, backup: result.backup ?? null } });
  logger?.info?.(`[boot-guard] re-enabled ${packageName}`);
  return { ok: true, packageName, action: result.action, edit: result.edit ?? null, backup: result.backup ?? null };
}

// ---------------------------------------------------------------------------
// HTTP route (the guide's token contract)

export function authorized(req, token) {
  const site = req?.headers?.['sec-fetch-site'];
  if (typeof site === 'string' && site === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
}

function readBody(req, limit = 8 * 1024) {
  return new Promise((resolvePromise, rejectPromise) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        rejectPromise(new Error('payload too large'));
        req.destroy?.();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolvePromise(Buffer.concat(chunks).toString('utf8')));
    req.on('error', rejectPromise);
  });
}

export function bootstrapRow(value) {
  return { kind: 'global', name: BOOTSTRAP_KEY, value };
}

export function createTokenHandler(token, isAuthenticated) {
  return function bootGuardTokenRoute(req, res) {
    const send = (status, payload) => {
      res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      res.end(JSON.stringify(payload));
    };
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      send(405, { ok: false, error: 'method-not-allowed' });
      return;
    }
    const site = req?.headers?.['sec-fetch-site'];
    if (typeof site === 'string' && site === 'cross-site') {
      send(403, { ok: false, error: 'forbidden' });
      return;
    }
    if (typeof isAuthenticated === 'function') {
      let authenticated = false;
      try {
        authenticated = isAuthenticated(req) === true;
      } catch {
        authenticated = false;
      }
      if (!authenticated) {
        send(401, { ok: false, error: 'unauthorized' });
        return;
      }
    }
    send(200, { ok: true, data: { path: ROUTE_PATH, token } });
  };
}

export function createRouteHandler(control, token) {
  return async function bootGuardRoute(req, res) {
    const send = (status, payload) => {
      res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      res.end(JSON.stringify(payload));
    };
    if (!authorized(req, token)) {
      send(403, { ok: false, error: 'forbidden' });
      return;
    }
    try {
      if (req.method === 'GET' || req.method === 'HEAD') {
        send(200, { ok: true, data: control.snapshot() });
        return;
      }
      if (req.method !== 'POST') {
        send(405, { ok: false, error: 'method-not-allowed' });
        return;
      }
      const raw = await readBody(req);
      const request = raw ? JSON.parse(raw) : {};
      const action = typeof request?.action === 'string' ? request.action : '';
      if (action === 'recheck') {
        const report = await control.recheck();
        send(200, { ok: true, action, data: report });
        return;
      }
      if (action === 'reenable') {
        const packageName = typeof request?.package === 'string' ? request.package : '';
        if (packageName === '') throw new Error('reenable requires a package name');
        const result = await control.reenable(packageName);
        if (result?.ok !== true) {
          send(400, { ok: false, error: result?.error ?? 'reenable failed' });
          return;
        }
        send(200, { ok: true, action, data: { result, report: control.snapshot() } });
        return;
      }
      if (action === 'runtime-failure') {
        const packageName = typeof request?.package === 'string' ? request.package : '';
        if (packageName === '' || packageName.length > 256) throw new Error('runtime-failure requires a valid package name');
        const result = await control.quarantineRuntime(packageName);
        if (result?.ok !== true) {
          send(400, { ok: false, error: result?.error ?? 'runtime quarantine refused' });
          return;
        }
        send(200, { ok: true, action, data: { result: result.action, report: result.report } });
        return;
      }
      throw new Error(`unknown boot-guard action: ${action || '(missing)'}`);
    } catch (error) {
      send(400, { ok: false, error: error instanceof Error ? error.message : String(error) });
    }
  };
}

// ---------------------------------------------------------------------------
// plugin

export function apply(ctx, config = {}) {
  const settings = resolveConfig(config);
  if (settings.disabled || settings.enabled === false) {
    ctx.logger?.info?.('[boot-guard] disabled by config — no validation, no writes');
    return;
  }
  const token = randomBytes(24).toString('hex');
  const io = createNodeIo();
  const homeDir = resolveHomeDir({});
  const profileDir = resolveProfileDir({ io, homeDir });
  const crashLogsDir = resolveCrashLogsDir({});
  let report = {
    version: VERSION,
    at: new Date().toISOString(),
    dryRun: settings.dryRun,
    autoQuarantine: settings.autoQuarantine,
    profile: { dir: profileDir, ok: false, error: 'pre-flight did not run', patchOk: false, bundles: 0, plugins: 0, quarantined: 0 },
    verdicts: [],
    quarantines: [],
    crash: { dir: crashLogsDir, files: [], entries: [], decisions: [] },
    actions: [],
    timings: {},
  };

  // ---- defence 1 + 2: synchronous, as early in the boot as a plugin can be.
  try {
    report = runBootGuard({ io, config: settings, profileDir, homeDir, crashLogsDir, logger: ctx.logger, now: Date.now() });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    report.profile.error = `boot-guard pre-flight failed safely: ${message}`;
    ctx.logger?.warn?.(`[boot-guard] pre-flight failed safely: ${message}`);
  }
  applyClientBootIsolation({ logger: ctx.logger });
  const quarantined = report.quarantines?.length ?? 0;
  if (quarantined > 0) {
    ctx.logger?.warn?.(
      `[boot-guard] ${quarantined} plugin(s) quarantined so this start survives: ${report.quarantines
        .map((record) => `${record.packageName} (${record.reason})`)
        .join(', ')}${settings.dryRun ? ' [DRY RUN — nothing written]' : ''}`,
    );
  } else {
    ctx.logger?.info?.(`[boot-guard] pre-flight clean: ${report.profile.plugins} plugin(s) checked in ${report.timings?.totalMs ?? 0}ms`);
  }

  const control = {
    snapshot: () => report,
    recheck: async () => {
      report = runBootGuard({
        io,
        config: settings,
        profileDir: resolveProfileDir({ io, homeDir }),
        homeDir,
        crashLogsDir,
        logger: ctx.logger,
        now: Date.now(),
      });
      return report;
    },
    quarantineRuntime: async (packageName) => {
      report = runBootGuard({
        io,
        config: { ...settings, preflight: false, crashLogRecovery: false },
        profileDir: resolveProfileDir({ io, homeDir }) ?? profileDir,
        homeDir,
        crashLogsDir,
        logger: ctx.logger,
        runtimeFailures: [{ packageName }],
        now: Date.now(),
      });
      const action = report.actions.find((entry) => entry.packageName === packageName);
      return action && ['written', 'no-change', 'observed'].includes(action.action)
        ? { ok: true, action, report }
        : { ok: false, error: action?.error ?? action?.action ?? 'plugin-not-eligible', action, report };
    },
    reenable: async (packageName) =>
      reenablePackage({
        io,
        config: settings,
        profileDir: resolveProfileDir({ io, homeDir }) ?? profileDir,
        homeDir,
        packageName,
        logger: ctx.logger,
        now: Date.now(),
      }),
  };

  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(
      () => webCtx.webServer.register({ kind: 'exact', path: ROUTE_PATH, handler: createRouteHandler(control, token) }),
      'dsh-boot-guard: route',
    );
    webCtx.effect(
      () =>
        webCtx.webServer.register({
          kind: 'exact',
          path: TOKEN_PATH,
          handler: createTokenHandler(token, (req) => webCtx.get?.('connection')?.isAuthenticated?.(req)),
        }),
      'dsh-boot-guard: token route',
    );
    webCtx.on?.('webserver/index-inject', (table) => {
      table.push(bootstrapRow({ path: ROUTE_PATH, token }));
    });
  });

  ctx.logger?.info?.(
    `[boot-guard] active — pre-flight=${settings.preflight ? 'on' : 'off'} crash-log=${settings.crashLogRecovery ? 'on' : 'off'} autoQuarantine=${
      settings.autoQuarantine ? 'on' : 'off'
    }${settings.dryRun ? ' DRY RUN' : ''}${profileDir === null ? ' (no profile dir: feature inert)' : ''}`,
  );
}

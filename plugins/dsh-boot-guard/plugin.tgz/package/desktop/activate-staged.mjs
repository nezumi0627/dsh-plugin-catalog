import { createHash } from 'node:crypto';
import { copyFileSync, existsSync, openSync, readSync, renameSync, rmSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join, resolve } from 'node:path';
import { closeArchive, findEntry, openArchive, readEntryBuffer, snapshotEntries } from './asar.js';
import { CLIENT_BOOT_DIAGNOSTIC_MARKER, CLIENT_BOOT_MARKER, SHELL_PACKAGE, WEB_ENTRY_PREFIX, transformClientBoot } from './client-boot.js';
import { CORE_WIDGET_ENTRIES, SHELL_FULLSCREEN_ENTRIES, validateChangedEntries, validateCoreWidgetSources, validateDesktopMain, validateDesktopPreload } from './staged-validation.js';

const args = process.argv.slice(2);
const valueAfter = (flag) => {
  const at = args.indexOf(flag);
  return at < 0 ? null : args[at + 1] ?? null;
};
const appDir = resolve(valueAfter('--app') ?? join(process.env.LOCALAPPDATA ?? '', 'Programs', 'DeepSeek Harness'));
const archivePath = join(appDir, 'resources', 'app.asar');
const stagedPath = resolve(valueAfter('--stage') ?? `${archivePath}.dsh-boot-guard.new`);
const checkOnly = args.includes('--check');

function collectFiles(node, prefix = '', found = []) {
  for (const [name, entry] of Object.entries(node?.files ?? {})) {
    const path = prefix ? `${prefix}/${name}` : name;
    if (entry.files) collectFiles(entry, path, found);
    else found.push({ path, parts: path.split('/') });
  }
  return found;
}

function hashRange(handle, offset, length) {
  const hash = createHash('sha256');
  const chunk = Buffer.alloc(1024 * 1024);
  for (let at = 0; at < length;) {
    const amount = Math.min(chunk.length, length - at);
    const read = readSync(handle.fd, chunk, 0, amount, offset + at);
    if (read !== amount) throw new Error('short read while validating staged archive');
    hash.update(chunk.subarray(0, read));
    at += read;
  }
  return hash.digest('hex');
}

function validate() {
  if (!existsSync(archivePath)) throw new Error(`installed DSH archive not found: ${archivePath}`);
  if (!existsSync(stagedPath)) throw new Error(`staged Boot Guard archive not found: ${stagedPath}`);
  const current = openArchive(archivePath);
  const staged = openArchive(stagedPath);
  try {
    const packageOf = (archive) => JSON.parse(readEntryBuffer(archive, findEntry(archive.header, ['package.json'])).toString('utf8'));
    if (packageOf(current).name !== SHELL_PACKAGE || packageOf(staged).name !== SHELL_PACKAGE) throw new Error('archive package identity mismatch');
    const currentEntries = snapshotEntries(current.header);
    const stagedEntries = snapshotEntries(staged.header);
    if (currentEntries.size !== stagedEntries.size) throw new Error('staged archive entry count differs from installed archive');
    const changed = [...stagedEntries].filter(([path, value]) => currentEntries.get(path) !== value).map(([path]) => path);
    const frontendEntry = changed.find((path) => path.startsWith(WEB_ENTRY_PREFIX));
    validateChangedEntries(changed, frontendEntry);
    const allowedChanges = new Set(changed);
    for (const [path, value] of currentEntries) {
      if (!allowedChanges.has(path) && stagedEntries.get(path) !== value) throw new Error(`unrelated entry changed: ${path}`);
    }
    const frontendPath = frontendEntry.split('/');
    const frontend = readEntryBuffer(staged, findEntry(staged.header, frontendPath)).toString('utf8');
    if (!frontend.includes(CLIENT_BOOT_MARKER) || !frontend.includes(CLIENT_BOOT_DIAGNOSTIC_MARKER) || transformClientBoot(frontend).status !== 'already-applied') throw new Error('staged frontend does not contain an active fail-open guard and core activation diagnostics');
    const coreWidgets = Object.fromEntries(CORE_WIDGET_ENTRIES.map((path) => [
      path,
      readEntryBuffer(staged, findEntry(staged.header, path.split('/'))).toString('utf8'),
    ]));
    validateCoreWidgetSources({
      chatManifest: coreWidgets[CORE_WIDGET_ENTRIES[0]],
      chatClient: coreWidgets[CORE_WIDGET_ENTRIES[1]],
      conversationManifest: coreWidgets[CORE_WIDGET_ENTRIES[2]],
      conversationClient: coreWidgets[CORE_WIDGET_ENTRIES[3]],
    });
    const shellSources = Object.fromEntries(SHELL_FULLSCREEN_ENTRIES.map((path) => [
      path,
      readEntryBuffer(staged, findEntry(staged.header, path.split('/'))).toString('utf8'),
    ]));
    const main = shellSources['lib/main.js'];
    validateDesktopMain(main);
    validateDesktopPreload(shellSources['lib/preload-app.cjs']);
    const oldDataLength = current.archiveSize - current.dataOffset;
    if (staged.archiveSize - staged.dataOffset < oldDataLength) throw new Error('staged archive is shorter than the installed data section');
    if (hashRange(current, current.dataOffset, oldDataLength) !== hashRange(staged, staged.dataOffset, oldDataLength)) throw new Error('original archive data, including its trailing bytes, changed');
    return { frontend: frontendEntry, stagedSize: staged.archiveSize };
  } finally {
    closeArchive(current);
    closeArchive(staged);
  }
}

const report = validate();
if (checkOnly) {
  console.log(`validated staged fail-open guard, movable core stats, and native fullscreen bridge: ${report.frontend} (${report.stagedSize} bytes)`);
  console.log('check only: installed app.asar was not changed');
  process.exit(0);
}

const running = Number(execFileSync('powershell.exe', [
  '-NoProfile', '-NonInteractive', '-Command',
  "(Get-Process -Name 'DeepSeek Harness' -ErrorAction SilentlyContinue | Measure-Object).Count",
], { encoding: 'utf8' }).trim());
if (running > 0) throw new Error(`DSH is still running (${running} process(es)); close it completely, then retry`);

const resources = join(appDir, 'resources');
const stamp = new Date().toISOString().replace(/[:.]/gu, '-');
const backupPath = join(resources, `app.asar.pre-boot-guard-${stamp}.bak`);
const rollbackPath = `${archivePath}.rollback-${process.pid}`;
copyFileSync(archivePath, backupPath);
renameSync(archivePath, rollbackPath);
try {
  renameSync(stagedPath, archivePath);
  const installed = openArchive(archivePath);
  try {
    const entry = collectFiles(installed.header).find(({ path }) => path === report.frontend);
    const text = entry ? readEntryBuffer(installed, findEntry(installed.header, entry.parts)).toString('utf8') : '';
    if (!text.includes(CLIENT_BOOT_MARKER) || !text.includes(CLIENT_BOOT_DIAGNOSTIC_MARKER)) throw new Error('post-swap verification did not find the fail-open and core-diagnostic markers');
      const installedCore = Object.fromEntries(CORE_WIDGET_ENTRIES.map((path) => [
        path,
        readEntryBuffer(installed, findEntry(installed.header, path.split('/'))).toString('utf8'),
      ]));
      validateCoreWidgetSources({
        chatManifest: installedCore[CORE_WIDGET_ENTRIES[0]],
        chatClient: installedCore[CORE_WIDGET_ENTRIES[1]],
        conversationManifest: installedCore[CORE_WIDGET_ENTRIES[2]],
        conversationClient: installedCore[CORE_WIDGET_ENTRIES[3]],
      });
      const installedShell = Object.fromEntries(SHELL_FULLSCREEN_ENTRIES.map((path) => [
        path,
        readEntryBuffer(installed, findEntry(installed.header, path.split('/'))).toString('utf8'),
      ]));
      validateDesktopMain(installedShell['lib/main.js']);
      validateDesktopPreload(installedShell['lib/preload-app.cjs']);
  } finally {
    closeArchive(installed);
  }
  rmSync(rollbackPath, { force: true });
  console.log(`activated fail-open guard in ${archivePath}`);
  console.log(`backup: ${backupPath}`);
  console.log('launch DSH normally; optional third-party web plugins can now fail without blocking the whole app');
} catch (error) {
  if (existsSync(archivePath)) renameSync(archivePath, stagedPath);
  if (existsSync(rollbackPath)) renameSync(rollbackPath, archivePath);
  throw error;
}

export const WEB_ENTRY_PREFIX = 'dsh/node_modules/@deepseek-ai/dsh-web-frontend/dist/assets/';
export const SHELL_PACKAGE = '@deepseek-ai/dsh-desktop';
export const CLIENT_BOOT_MARKER = '[dsh-boot-guard] optional client plugin failed';
export const CLIENT_BOOT_DIAGNOSTIC_MARKER = '[dsh-boot-guard] core activation error';

const START = 'function eM(e,n){';
const END = 'function yn(e,n){';

/** Change the frontend's final aggregate into third-party-only failure isolation. */
export function transformClientBoot(source) {
  if (typeof source !== 'string') return { status: 'invalid-source' };
  if (source.includes(CLIENT_BOOT_DIAGNOSTIC_MARKER)) return { status: 'already-applied', source };
  const start = source.indexOf(START);
  const end = source.indexOf(END, start + START.length);
  if (start < 0 || end < 0 || source.indexOf(START, start + START.length) >= 0) {
    return { status: 'unexpected-layout', detail: 'boot summary function boundaries were not unique' };
  }
  const original = source.slice(start, end);
  if (!original.includes('did not activate') || !original.includes('loader.entries()')) {
    return { status: 'unexpected-layout', detail: 'boot summary did not match the known loader contract' };
  }
  const replacement = String.raw`function eM(e,n){const o=[],r=[],t=[];for(const s of e.loader.entries()){const a=s.options.name;if(s.fiber===void 0){const i=n.importError(a),c=i===void 0?a+": import failed (see console for the import error)":a+": import failed: "+i.message;o.push(c);(a.startsWith("@deepseek-ai/")?t:r).push(c);continue}const u=A7[s.fiber.state];if(u!=="active"){let i;if(u==="pending"){const c=Object.keys(s.fiber.inject).filter(f=>e.get(f)===void 0);i=a+": pending (waiting for service"+(c.length===1?"":"s")+": "+(c.join(", ")||"unknown")+")"}else{i=a+": "+u;const c=s.fiber._error;if(a.startsWith("@deepseek-ai/")&&c)i+="\n${CLIENT_BOOT_DIAGNOSTIC_MARKER}: "+String(c.stack||c.message||c)}o.push(i);(a.startsWith("@deepseek-ai/")?t:r).push(i)}}if(r.length){const i=[...new Set(r.map(c=>c.slice(0,c.indexOf(": "))))];console.error("${CLIENT_BOOT_MARKER}; app boot continues:",r);try{fetch("/local/boot-guard-token",{credentials:"same-origin",cache:"no-store"}).then(c=>c.ok?c.json():null).then(c=>{const f=c&&c.data;if(!f||typeof f.path!=="string"||typeof f.token!=="string")return;return Promise.allSettled(i.map(h=>fetch(f.path,{method:"POST",credentials:"same-origin",cache:"no-store",headers:{accept:"application/json","content-type":"application/json","x-dsh-boot-guard-token":f.token},body:JSON.stringify({action:"runtime-failure",package:h})}))) }).catch(c=>console.warn("[dsh-boot-guard] could not persist renderer quarantine",c))}catch(c){console.warn("[dsh-boot-guard] could not report renderer failures",c)}}if(t.length){console.error("web boot: required client entries did not activate",t);throw new Error("web boot: required client entries did not activate\n"+t.join("\n"))}}`;
  return { status: source.includes(CLIENT_BOOT_MARKER) ? 'upgraded' : 'applied', source: source.slice(0, start) + replacement + source.slice(end) };
}

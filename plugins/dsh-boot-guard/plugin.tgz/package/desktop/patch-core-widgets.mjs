import { copyFileSync, existsSync, mkdtempSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { Script } from 'node:vm';
import { execFileSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { closeArchive, findEntry, openArchive, readEntryBuffer, stageReplacedArchive } from './asar.js';
import { transformCoreWidgets } from './core-widgets.js';
import { transformNativeFullscreen } from './fullscreen-bridge.js';

const args = process.argv.slice(2);
const valueAfter = (flag) => { const index = args.indexOf(flag); return index < 0 ? null : args[index + 1] ?? null; };
const appDir = valueAfter('--app') ?? `${process.env.LOCALAPPDATA ?? ''}/Programs/DeepSeek Harness`;
const installedPath = `${appDir}/resources/app.asar`;
const stagedPath = valueAfter('--stage') ?? `${installedPath}.dsh-boot-guard.new`;
const dryRun = args.includes('--check');
const archive = openArchive(stagedPath);
let files;
try {
  const sourceOf = (parts) => readEntryBuffer(archive, findEntry(archive.header, parts)).toString('utf8');
  if (JSON.parse(sourceOf(['package.json'])).name !== '@deepseek-ai/dsh-desktop') throw new Error('staged input is not a DSH desktop archive');
  files = {
    chatManifest: sourceOf(['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-chat', 'package.json']),
    chatClient: sourceOf(['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-chat', 'lib', 'client.js']),
    conversationManifest: sourceOf(['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-conversation', 'package.json']),
    conversationClient: sourceOf(['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-conversation', 'lib', 'client.js']),
    main: sourceOf(['lib', 'main.js']),
    preload: sourceOf(['lib', 'preload-app.cjs']),
  };
} finally {
  closeArchive(archive);
}
const transformed = transformCoreWidgets(files);
const fullscreen = transformNativeFullscreen({ main: files.main, preload: files.preload });
for (const [path, content] of [
  ['ui-chat/client.js', transformed.files.chatClient],
  ['ui-conversation/client.js', transformed.files.conversationClient],
]) new Script(content, { filename: path });
new Script(fullscreen.preload, { filename: 'lib/preload-app.cjs' });
const syntaxDir = mkdtempSync(join(tmpdir(), 'dsh-shell-syntax-'));
try {
  const mainPath = join(syntaxDir, 'main.mjs');
  writeFileSync(mainPath, fullscreen.main);
  execFileSync(process.execPath, ['--check', mainPath], { stdio: 'pipe' });
} finally { rmSync(syntaxDir, { recursive: true, force: true }); }
JSON.parse(transformed.files.chatManifest);
JSON.parse(transformed.files.conversationManifest);
if (dryRun || (transformed.status === 'already-applied' && fullscreen.status === 'already-applied')) {
  console.log(`${transformed.status}/${fullscreen.status}: movable status widgets and native fullscreen bridge are present`);
  console.log('check only: the staged archive was not changed');
  process.exit(0);
}

const stamp = new Date().toISOString().replace(/[:.]/gu, '-');
const candidatePath = `${stagedPath}.core-widgets-${stamp}.new`;
const backupPath = `${stagedPath}.pre-core-widgets-${stamp}.bak`;
const result = stageReplacedArchive(stagedPath, candidatePath, [
  { parts: ['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-chat', 'package.json'], content: Buffer.from(transformed.files.chatManifest) },
  { parts: ['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-chat', 'lib', 'client.js'], content: Buffer.from(transformed.files.chatClient) },
  { parts: ['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-conversation', 'package.json'], content: Buffer.from(transformed.files.conversationManifest) },
  { parts: ['dsh', 'node_modules', '@deepseek-ai', 'dsh-client-ui-conversation', 'lib', 'client.js'], content: Buffer.from(transformed.files.conversationClient) },
  { parts: ['lib', 'main.js'], content: Buffer.from(fullscreen.main) },
  { parts: ['lib', 'preload-app.cjs'], content: Buffer.from(fullscreen.preload) },
]);
copyFileSync(stagedPath, backupPath);
const displacedPath = `${stagedPath}.old-${process.pid}`;
renameSync(stagedPath, displacedPath);
try {
  renameSync(candidatePath, stagedPath);
  renameSync(displacedPath, backupPath);
} catch (error) {
  if (!existsSync(stagedPath) && existsSync(displacedPath)) renameSync(displacedPath, stagedPath);
  throw error;
}
console.log(`staged ${result.entries.join(', ')}`);
console.log(`backup: ${backupPath}`);
console.log(`new staged archive: ${stagedPath}`);

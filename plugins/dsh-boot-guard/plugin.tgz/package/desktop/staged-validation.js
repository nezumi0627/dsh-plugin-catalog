import { Script } from 'node:vm';
import { transformCoreWidgets } from './core-widgets.js';

export const CORE_WIDGET_ENTRIES = [
  'dsh/node_modules/@deepseek-ai/dsh-client-ui-chat/package.json',
  'dsh/node_modules/@deepseek-ai/dsh-client-ui-chat/lib/client.js',
  'dsh/node_modules/@deepseek-ai/dsh-client-ui-conversation/package.json',
  'dsh/node_modules/@deepseek-ai/dsh-client-ui-conversation/lib/client.js',
];
export const SHELL_FULLSCREEN_ENTRIES = ['lib/main.js', 'lib/preload-app.cjs'];

export function validateChangedEntries(changed, frontendPath) {
  const frontendPattern = /^dsh\/node_modules\/@deepseek-ai\/dsh-web-frontend\/dist\/assets\/index-[A-Za-z0-9_-]+\.js$/u;
  if (typeof frontendPath !== 'string' || !frontendPattern.test(frontendPath)) throw new Error('invalid staged frontend entry');
  const expectedFull = new Set([frontendPath, ...CORE_WIDGET_ENTRIES, ...SHELL_FULLSCREEN_ENTRIES]);
  const expectedFrontendOnly = new Set([frontendPath]);
  const exactSet = (expected) => Array.isArray(changed) && changed.length === expected.size && new Set(changed).size === changed.length && changed.every((path) => expected.has(path));
  if (!exactSet(expectedFull) && !exactSet(expectedFrontendOnly)) {
    throw new Error(`unexpected staged archive changes: ${changed?.join(', ') || 'none'}`);
  }
  return true;
}

export function validateCoreWidgetSources(files) {
  for (const key of ['chatManifest', 'chatClient', 'conversationManifest', 'conversationClient']) {
    if (typeof files?.[key] !== 'string') throw new Error(`missing staged core widget source: ${key}`);
  }
  for (const [key, label] of [['chatManifest', 'ui-chat'], ['conversationManifest', 'ui-conversation']]) {
    const manifest = JSON.parse(files[key]);
    if (!manifest?.dsh?.client?.inject?.includes('@local/dsh-status-widgets')) throw new Error(`${label} does not inject dsh-status-widgets`);
  }
  if (!files.chatClient.includes('dsh.core.chat-stats') || !files.chatClient.includes('conversation.composer.stats')) throw new Error('staged ui-chat is missing movable native statistics');
  if (!files.conversationClient.includes('dsh.core.context-meter') || !files.conversationClient.includes('dsh.core.chat-stats') || !files.conversationClient.includes('createPortal')) throw new Error('staged ui-conversation is missing movable core widget portals');
  if (transformCoreWidgets(files).status !== 'already-applied') throw new Error('staged core widget transformation is incomplete');
  new Script(files.chatClient, { filename: 'ui-chat/client.js' });
  new Script(files.conversationClient, { filename: 'ui-conversation/client.js' });
  return true;
}

export function validateDesktopMain(source) {
  if (typeof source !== 'string' || !source.includes('partition = `persist:dsh-sidebar-browser`;')) throw new Error('staged archive lost the persistent Browser partition');
  if (!source.includes('"--trace-deprecation"') || !source.includes('dsh-host-exit-trace') || !source.includes('signal=${String(signal)}')) {
    throw new Error('staged Host does not include deprecation stack and child-exit diagnostics');
  }
  if (!source.includes('windowFullscreenToggle: "dsh-desktop:window-fullscreen-toggle"') || !source.includes('assertDesktopSender(event, ["app"])') || !source.includes('window.setFullScreen(target)') || !source.includes('fullscreenable: true')) {
    throw new Error('staged Desktop main is missing the guarded native fullscreen bridge');
  }
  return true;
}

export function validateDesktopPreload(source) {
  if (typeof source !== 'string' || !source.includes('fullscreen: { toggle: () => electron.ipcRenderer.invoke(DESKTOP_IPC.windowFullscreenToggle) }') || !source.includes('process.platform !== "linux"')) {
    throw new Error('staged Desktop preload is missing the native fullscreen API or Linux state sync');
  }
  return true;
}

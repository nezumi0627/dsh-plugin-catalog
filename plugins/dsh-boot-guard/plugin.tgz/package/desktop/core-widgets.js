const STATUS_PACKAGE = '@local/dsh-status-widgets';

function replaceOnce(source, pattern, replacement, label) {
  const matcher = pattern.global ? pattern : new RegExp(pattern.source, `${pattern.flags}g`);
  const matches = [...source.matchAll(matcher)];
  if (matches.length !== 1) throw new Error(`${label}: expected exactly one source anchor, found ${matches.length}`);
  return source.replace(pattern, replacement);
}

function addClientDependency(source, label) {
  const manifest = JSON.parse(source);
  const inject = manifest?.dsh?.client?.inject;
  if (!Array.isArray(inject)) throw new Error(`${label}: client inject list is missing`);
  if (!inject.includes(STATUS_PACKAGE)) inject.push(STATUS_PACKAGE);
  return `${JSON.stringify(manifest, null, 2)}\n`;
}

function patchChatClient(source) {
  let next = replaceOnce(source, /("sidebarRight"\s*\r?\n\s*\];)/gu, '"sidebarRight",\n\t\t\t"statusWidgets"\n\t\t];', 'ui-chat service inject');
  next = replaceOnce(next, /ctx\.slots\.inject\("conversation\.composer\.dock", \(\) => ctx\.slots\.register\(\{\s*name: "conversation\.composer\.dock",\s*id: "stats",\s*order: 0,\s*locale: NS,\s*inject: \(\) => \(\{ hooks: \{ performanceUsage \} \}\)\s*\}, StatsPills\)\);/gu,
    `ctx.slots.inject("conversation.composer.stats", () => ctx.slots.register({
				name: "conversation.composer.stats",
				id: "stats",
				order: 0,
				locale: NS,
				inject: () => ({ hooks: { performanceUsage } })
			}, StatsPills));
			ctx.effect(() => ctx.get("statusWidgets").register({
				id: "dsh.core.chat-stats",
				title: () => "Token / turn usage",
				zone: "bottom",
				order: 0,
				portalTarget: true
			}), "ui-chat: movable stats");`, 'ui-chat composer stats slot');
  return next;
}

function patchConversationClient(source) {
  let next = replaceOnce(source, /("configForms"\s*\r?\n\s*\];)/gu, '"configForms",\n\t\t\t"statusWidgets"\n\t\t];', 'ui-conversation service inject');
  next = replaceOnce(next, /(\t\t\];\r?\n)(\t\t\/\*\* Validated Conversation runtime configuration\. \*\/)/u,
    `$1		let statusWidgetsApi = null;
			const subscribeContextMeterTarget = (listener) => statusWidgetsApi?.subscribePortalTarget("dsh.core.context-meter", listener) ?? (() => {});
			const readContextMeterTarget = () => statusWidgetsApi?.getPortalTarget("dsh.core.context-meter") ?? null;
			const subscribeChatStatsTarget = (listener) => statusWidgetsApi?.subscribePortalTarget("dsh.core.chat-stats", listener) ?? (() => {});
			const readChatStatsTarget = () => statusWidgetsApi?.getPortalTarget("dsh.core.chat-stats") ?? null;
$2`, 'ui-conversation portal subscriptions');
  next = replaceOnce(next, /(function apply\(ctx, config = Config\(\{\}\)\) \{\r?\n)/u,
    `$1			statusWidgetsApi = ctx.get("statusWidgets");
			if (statusWidgetsApi?.register) ctx.effect(() => statusWidgetsApi.register({
				id: "dsh.core.context-meter",
				title: () => "Context usage",
				zone: "bottom",
				order: 20,
				portalTarget: true
			}), "ui-conversation: movable context meter");
`, 'ui-conversation status widget registration');
  next = replaceOnce(next, /(const InputBar = \(0, react\.memo\)\(function InputBar\(\{[^\n]+\) \{\r?\n)/u,
    `$1			const chatStatsTarget = react.useSyncExternalStore(subscribeChatStatsTarget, readChatStatsTarget, () => null);
			const contextMeterTarget = react.useSyncExternalStore(subscribeContextMeterTarget, readContextMeterTarget, () => null);
`, 'composer portal subscriptions');
  next = replaceOnce(next, /children: \[variant === "composer" && input !== void 0 && sessionId !== void 0 \? renderSlot\("conversation\.composer\.dock", \{\}\) : null, activity \? null : \(0, react_jsx_runtime\.jsx\)\(ContextMeter, \{\s*useProjection,\s*t\s*\}\)\]/u,
    `children: [
							variant === "composer" && input !== void 0 && sessionId !== void 0 ? renderSlot("conversation.composer.dock", {}) : null,
							variant === "composer" && input !== void 0 && sessionId !== void 0 && chatStatsTarget ? (0, react_dom.createPortal)(renderSlot("conversation.composer.stats", {}), chatStatsTarget) : null,
							!activity && contextMeterTarget ? (0, react_dom.createPortal)((0, react_jsx_runtime.jsx)(ContextMeter, { useProjection, t }), contextMeterTarget) : null
						]`, 'composer widget portal rendering');
  next = replaceOnce(next, /("conversation\.composer\.dock": \{\s*kind: "list",\s*scope: "session"\s*\})/u,
    '$1,\n\t\t\t\t\t"conversation.composer.stats": {\n\t\t\t\t\t\tkind: "list",\n\t\t\t\t\t\tscope: "session"\n\t\t\t\t\t}', 'composer stats slot scope');
  return next;
}

export function transformCoreWidgets(files) {
  const expected = ['chatManifest', 'chatClient', 'conversationManifest', 'conversationClient'];
  for (const key of expected) if (typeof files?.[key] !== 'string') throw new TypeError(`missing core widget source: ${key}`);
  const markers = [
    files.chatManifest.includes(STATUS_PACKAGE),
    files.chatClient.includes('dsh.core.chat-stats'),
    files.conversationManifest.includes(STATUS_PACKAGE),
    files.conversationClient.includes('dsh.core.context-meter') && files.conversationClient.includes('dsh.core.chat-stats'),
  ];
  if (markers.every(Boolean)) return { status: 'already-applied', files };
  if (markers.some(Boolean)) throw new Error('partial core widget patch detected; refusing to compound an unknown state');
  return {
    status: 'applied',
    files: {
      chatManifest: addClientDependency(files.chatManifest, 'ui-chat manifest'),
      chatClient: patchChatClient(files.chatClient),
      conversationManifest: addClientDependency(files.conversationManifest, 'ui-conversation manifest'),
      conversationClient: patchConversationClient(files.conversationClient),
    },
  };
}

import { existsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { closeArchive, findEntry, openArchive, readEntryBuffer, stageReplacedArchive } from './asar.js';
import { SHELL_PACKAGE, WEB_ENTRY_PREFIX, transformClientBoot } from './client-boot.js';

function candidates(env = process.env, resourcesPath = process.resourcesPath, executablePath = process.execPath) {
  const paths = [env.DSH_DESKTOP_ASAR];
  if (resourcesPath) paths.push(join(resourcesPath, 'app.asar'));
  if (typeof executablePath === 'string') paths.push(join(dirname(executablePath), 'resources', 'app.asar'));
  if (env.LOCALAPPDATA) paths.push(join(env.LOCALAPPDATA, 'Programs', 'DeepSeek Harness', 'resources', 'app.asar'));
  for (const key of ['ProgramFiles', 'ProgramFiles(x86)', 'ProgramW6432']) {
    if (env[key]) paths.push(join(env[key], 'DeepSeek Harness', 'resources', 'app.asar'));
  }
  return [...new Set(paths.filter((value) => typeof value === 'string' && value.length > 0).map((value) => resolve(value)))];
}

function collectFiles(node, prefix = '', found = []) {
  for (const [name, entry] of Object.entries(node?.files ?? {})) {
    const path = prefix ? `${prefix}/${name}` : name;
    if (entry.files) collectFiles(entry, path, found);
    else found.push({ path, parts: path.split('/') });
  }
  return found;
}

export function locateDesktopArchive(options = {}) {
  for (const path of candidates(options.env, options.resourcesPath, options.executablePath)) {
    if (!existsSync(path)) continue;
    let archive;
    try {
      archive = openArchive(path);
      const manifestEntry = findEntry(archive.header, ['package.json']);
      if (!manifestEntry) continue;
      const manifest = JSON.parse(readEntryBuffer(archive, manifestEntry).toString('utf8'));
      if (manifest.name === SHELL_PACKAGE) return path;
    } catch {
      // Ignore non-DSH or unreadable archives and continue through candidates.
    } finally {
      if (archive) closeArchive(archive);
    }
  }
  return null;
}

export function ensureClientBootIsolation(archivePath) {
  let entryPath = null;
  let source = null;
  let archive;
  try {
    archive = openArchive(archivePath);
    const matches = collectFiles(archive.header).filter(({ path }) =>
      path.startsWith(WEB_ENTRY_PREFIX) && /^index-[A-Za-z0-9_-]+\.js$/u.test(path.slice(WEB_ENTRY_PREFIX.length)),
    );
    if (matches.length !== 1) return { status: 'unexpected-layout', detail: `expected one frontend entry, found ${matches.length}` };
    entryPath = matches[0].parts;
    const entry = findEntry(archive.header, entryPath);
    source = readEntryBuffer(archive, entry).toString('utf8');
  } finally {
    if (archive) closeArchive(archive);
  }

  const transformed = transformClientBoot(source);
  if (transformed.status !== 'applied' && transformed.status !== 'upgraded') return transformed;
  const stagedPath = `${archivePath}.dsh-boot-guard.new`;
  if (existsSync(stagedPath)) {
    let staged;
    try {
      staged = openArchive(stagedPath);
      const stagedEntry = findEntry(staged.header, entryPath);
      const stagedSource = stagedEntry ? readEntryBuffer(staged, stagedEntry).toString('utf8') : '';
      if (stagedSource === transformed.source) return { status: 'staged', stagedPath, entry: entryPath.join('/'), reused: true };
      return { status: 'stage-conflict', stagedPath, detail: 'an existing staged archive does not match the current shell build' };
    } finally {
      if (staged) closeArchive(staged);
    }
  }
  const staged = stageReplacedArchive(archivePath, stagedPath, [{ parts: entryPath, content: Buffer.from(transformed.source, 'utf8') }]);
  return { status: 'staged', stagedPath: staged.stagedPath, entry: entryPath.join('/') };
}

export function applyClientBootIsolation({ logger = null, options = {} } = {}) {
  try {
    const archivePath = options.archivePath ?? locateDesktopArchive(options.locateOptions);
    if (!archivePath) return { status: 'no-archive' };
    const result = ensureClientBootIsolation(archivePath);
    if (result.status === 'staged') logger?.info?.(`[boot-guard] staged optional client boot isolation in ${result.entry} at ${result.stagedPath}; close DSH fully and activate the staged archive before relaunching`);
    else if (result.status !== 'already-applied') logger?.warn?.(`[boot-guard] client boot patch skipped: ${result.detail ?? result.status}`);
    return result;
  } catch (error) {
    const result = { status: 'failed', detail: error?.message ?? String(error) };
    logger?.warn?.(`[boot-guard] client boot isolation patch failed safely: ${result.detail}`);
    return result;
  }
}

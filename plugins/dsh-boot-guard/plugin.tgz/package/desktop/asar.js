/**
 * Minimal, reversible writer for an Electron ASAR archive.
 *
 * The only operation offered is "replace these file entries": the new payloads
 * are appended past the end of the existing data section and the header's
 * `offset` / `size` / `integrity` for those entries is rewritten in place. No
 * existing byte is moved and no entry is added or removed, so an interrupted
 * run can only leave an unreferenced tail — never a broken archive.
 */
import { createHash } from 'node:crypto';
import { closeSync, fsyncSync, ftruncateSync, openSync, readSync, renameSync, rmSync, statSync, writeSync } from 'node:fs';

const DATA_OFFSET_BASE = 16;
const INTEGRITY_BLOCK_SIZE = 4194304;

/** Read the pickle prefix and the JSON header. */
export function openArchive(archivePath) {
  const fd = openSync(archivePath, 'r');
  const prefix = Buffer.alloc(DATA_OFFSET_BASE);
  readSync(fd, prefix, 0, prefix.length, 0);
  const headerSize = prefix.readUInt32LE(12);
  const headerBuffer = Buffer.alloc(headerSize);
  readSync(fd, headerBuffer, 0, headerSize, DATA_OFFSET_BASE);
  return {
    fd,
    prefix,
    headerSize,
    headerBuffer,
    header: JSON.parse(headerBuffer.toString('utf8')),
    dataOffset: DATA_OFFSET_BASE + headerSize,
    archiveSize: statSync(archivePath).size,
  };
}

export function closeArchive(handle) {
  closeSync(handle.fd);
}

export function findEntry(header, parts) {
  let current = header;
  for (const part of parts) {
    current = current?.files?.[part];
    if (!current) return null;
  }
  return current;
}

/** Every file entry as `path -> offset:size:integrityHash`, for untouched-entry checks. */
export function snapshotEntries(header) {
  const map = new Map();
  (function walk(node, prefix) {
    for (const [name, value] of Object.entries(node.files ?? {})) {
      const path = prefix ? `${prefix}/${name}` : name;
      if (value.files) walk(value, path);
      else map.set(path, `${value.offset}:${value.size}:${value.integrity?.hash ?? ''}:${value.unpacked ? 1 : 0}`);
    }
  })(header, '');
  return map;
}

export function readEntryBuffer(handle, entry) {
  const buffer = Buffer.alloc(entry.size);
  readSync(handle.fd, buffer, 0, entry.size, handle.dataOffset + Number(entry.offset));
  return buffer;
}

/** The archive's own per-entry integrity record (SHA-256, 4 MiB blocks). */
export function integrityOf(buffer) {
  const blocks = [];
  for (let offset = 0; offset < buffer.length; offset += INTEGRITY_BLOCK_SIZE) {
    blocks.push(createHash('sha256').update(buffer.subarray(offset, offset + INTEGRITY_BLOCK_SIZE)).digest('hex'));
  }
  if (blocks.length === 0) blocks.push(createHash('sha256').update(Buffer.alloc(0)).digest('hex'));
  return { algorithm: 'SHA256', hash: blocks[0], blockSize: INTEGRITY_BLOCK_SIZE, blocks };
}

function serializeHeader(header, headerSize) {
  const json = JSON.stringify(header);
  const bytes = Buffer.byteLength(json);
  if (bytes > headerSize) throw new Error(`patched header needs ${bytes} bytes but only ${headerSize} are available`);
  const out = Buffer.alloc(headerSize, 0x20);
  out.write(json, 0, 'utf8');
  return out;
}

/**
 * Append `replacements` and repoint their header entries.
 * @param archivePath - archive to modify in place.
 * @param replacements - `[{ parts, content, expectedHash }]`, matched by path parts.
 */
export function replaceEntries(archivePath, replacements) {
  const handle = openArchive(archivePath);
  try {
    const before = snapshotEntries(handle.header);
    for (const replacement of replacements) {
      const entry = findEntry(handle.header, replacement.parts);
      if (!entry) throw new Error(`archive entry not found: ${replacement.parts.join('/')}`);
      const current = readEntryBuffer(handle, entry);
      replacement.previous = { offset: entry.offset, size: entry.size, integrity: entry.integrity };
      replacement.previousSha256 = createHash('sha256').update(current).digest('hex');
      replacement.nextSha256 = createHash('sha256').update(replacement.content).digest('hex');
    }

    // Nothing to do when the archive already carries exactly these payloads.
    const upToDate = replacements.every((r) => r.previousSha256 === r.nextSha256);
    if (upToDate) return { changed: false, entries: replacements.map((r) => r.parts.join('/')) };

    const writable = openSync(archivePath, 'r+');
    let position = handle.archiveSize;
    try {
      for (const replacement of replacements) {
        const relativeOffset = position - handle.dataOffset;
        const entry = findEntry(handle.header, replacement.parts);
        entry.offset = String(relativeOffset);
        entry.size = replacement.content.length;
        entry.integrity = integrityOf(replacement.content);
        writeSync(writable, replacement.content, 0, replacement.content.length, position);
        position += replacement.content.length;
      }
      // The header is written last: a crash before this leaves the old offsets intact.
      writeSync(writable, serializeHeader(handle.header, handle.headerSize), 0, handle.headerSize, DATA_OFFSET_BASE);
    } finally {
      closeSync(writable);
    }

    const after = openArchive(archivePath);
    try {
      const patched = snapshotEntries(after.header);
      for (const [path, value] of before) {
        const replaced = replacements.some((r) => r.parts.join('/') === path);
        if (replaced) {
          if (patched.get(path) === value) throw new Error(`entry ${path} was not repointed`);
          continue;
        }
        if (patched.get(path) !== value) throw new Error(`unrelated entry ${path} changed`);
      }
      if (patched.size !== before.size) throw new Error('archive entry count changed');
      for (const replacement of replacements) {
        const entry = findEntry(after.header, replacement.parts);
        const read = readEntryBuffer(after, entry);
        if (!read.equals(replacement.content)) throw new Error(`verification failed for ${replacement.parts.join('/')}`);
      }
    } finally {
      closeArchive(after);
    }

    return {
      changed: true,
      entries: replacements.map((r) => ({
        path: r.parts.join('/'),
        from: r.previous.size,
        to: r.content.length,
        appendedAt: Number(findEntry(handle.header, r.parts).offset),
      })),
    };
  } finally {
    closeArchive(handle);
  }
}

/**
 * Build a complete staged archive with replacement entries. Unlike
 * `replaceEntries`, this can grow the pickle header and never mutates the live
 * archive. The packed data section (including any unreferenced tail) is copied
 * byte-for-byte; replacement payloads are appended after that entire section.
 */
export function stageReplacedArchive(archivePath, stagedPath, replacements) {
  const source = openArchive(archivePath);
  const temporaryPath = `${stagedPath}.tmp-${process.pid}`;
  let output = null;
  let created = false;
  try {
    if (archivePath === stagedPath) throw new Error('staged archive path must differ from the live archive path');
    const header = structuredClone(source.header);
    const before = snapshotEntries(source.header);
    const replacementPaths = new Set();
    let position = source.archiveSize - source.dataOffset;
    const prepared = [];
    for (const replacement of replacements) {
      const path = replacement.parts.join('/');
      if (replacementPaths.has(path)) throw new Error(`duplicate replacement entry: ${path}`);
      replacementPaths.add(path);
      const entry = findEntry(header, replacement.parts);
      if (!entry) throw new Error(`archive entry not found: ${path}`);
      if (entry.unpacked === true) throw new Error(`cannot replace unpacked entry: ${path}`);
      entry.offset = String(position);
      entry.size = replacement.content.length;
      entry.integrity = integrityOf(replacement.content);
      position += replacement.content.length;
      prepared.push({ path, parts: replacement.parts, content: replacement.content });
    }

    const json = Buffer.from(JSON.stringify(header), 'utf8');
    const paddedSize = Math.ceil(json.length / 4) * 4;
    const padded = Buffer.alloc(paddedSize, 0x20);
    json.copy(padded);
    const prefix = Buffer.alloc(DATA_OFFSET_BASE);
    prefix.writeUInt32LE(4, 0);
    prefix.writeUInt32LE(paddedSize + 8, 4);
    prefix.writeUInt32LE(paddedSize + 4, 8);
    prefix.writeUInt32LE(paddedSize, 12);

    output = openSync(temporaryPath, 'wx');
    created = true;
    writeSync(output, prefix);
    writeSync(output, padded);

    const copyBuffer = Buffer.alloc(1024 * 1024);
    const dataLength = source.archiveSize - source.dataOffset;
    let copied = 0;
    while (copied < dataLength) {
      const length = Math.min(copyBuffer.length, dataLength - copied);
      const read = readSync(source.fd, copyBuffer, 0, length, source.dataOffset + copied);
      if (read !== length) throw new Error(`short read while copying archive data (${read}/${length})`);
      let written = 0;
      while (written < read) written += writeSync(output, copyBuffer, written, read - written);
      copied += read;
    }
    for (const replacement of prepared) {
      let written = 0;
      while (written < replacement.content.length) {
        written += writeSync(output, replacement.content, written, replacement.content.length - written);
      }
    }
    fsyncSync(output);
    closeSync(output);
    output = null;

    const staged = openArchive(temporaryPath);
    try {
      const after = snapshotEntries(staged.header);
      if (after.size !== before.size) throw new Error('staged archive entry count changed');
      for (const [path, value] of before) {
        if (replacementPaths.has(path)) continue;
        if (after.get(path) !== value) throw new Error(`unrelated archive entry changed: ${path}`);
      }
      for (const replacement of prepared) {
        const entry = findEntry(staged.header, replacement.parts);
        if (!readEntryBuffer(staged, entry).equals(replacement.content)) throw new Error(`staged payload verification failed: ${replacement.path}`);
      }

      // Verify the complete original data section, not only indexed entries.
      // This also proves that any orphaned tail was preserved without shifting
      // offsets or losing bytes.
      const digestRange = (handle, offset, length) => {
        const hash = createHash('sha256');
        const chunk = Buffer.alloc(1024 * 1024);
        for (let at = 0; at < length;) {
          const amount = Math.min(chunk.length, length - at);
          const read = readSync(handle.fd, chunk, 0, amount, offset + at);
          if (read !== amount) throw new Error('short read while verifying archive data');
          hash.update(chunk.subarray(0, read));
          at += read;
        }
        return hash.digest('hex');
      };
      const originalDataLength = source.archiveSize - source.dataOffset;
      if (digestRange(source, source.dataOffset, originalDataLength) !== digestRange(staged, staged.dataOffset, originalDataLength)) {
        throw new Error('staged archive changed bytes in the original data section');
      }
      const expectedSize = staged.dataOffset + originalDataLength + prepared.reduce((sum, item) => sum + item.content.length, 0);
      if (staged.archiveSize !== expectedSize) throw new Error('staged archive size does not match its verified layout');
    } finally {
      closeArchive(staged);
    }

    renameSync(temporaryPath, stagedPath);
    created = false;
    return { changed: true, stagedPath, entries: prepared.map((item) => item.path) };
  } catch (error) {
    if (output !== null) closeSync(output);
    if (created) rmSync(temporaryPath, { force: true });
    throw error;
  } finally {
    closeArchive(source);
  }
}

/** Restore a header prefix written by `backupHeader` and drop the appended tail. */
export function restoreArchive(archivePath, backup) {
  const fd = openSync(archivePath, 'r+');
  try {
    writeSync(fd, backup.prefix, 0, backup.prefix.length, 0);
    writeSync(fd, backup.header, 0, backup.header.length, DATA_OFFSET_BASE);
    ftruncateSync(fd, backup.archiveSize);
  } finally {
    closeSync(fd);
  }
}

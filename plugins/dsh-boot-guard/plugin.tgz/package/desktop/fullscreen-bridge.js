const IPC_ANCHOR = '\twindowFullscreen: "dsh-desktop:window-fullscreen",\n';
const MAIN_MARKER = 'windowFullscreenToggle: "dsh-desktop:window-fullscreen-toggle"';
const PRELOAD_MARKER = 'fullscreen: { toggle: () => electron.ipcRenderer.invoke(DESKTOP_IPC.windowFullscreenToggle) }';

function replaceOnce(source, before, after, label) {
  if (source.includes(after)) return source;
  const first = source.indexOf(before);
  if (first < 0 || source.indexOf(before, first + before.length) >= 0) {
    throw new Error(`${label}: expected exactly one source anchor`);
  }
  return source.slice(0, first) + after + source.slice(first + before.length);
}

function transformMain(source) {
  let next = source;
  next = replaceOnce(next, IPC_ANCHOR, `${IPC_ANCHOR}\twindowFullscreenToggle: "dsh-desktop:window-fullscreen-toggle",\n`, 'main IPC channel');
  next = replaceOnce(next, 'if (process.platform === "darwin" || process.platform === "win32") {\n\t\tconst sendFullscreen', 'if (process.platform === "darwin" || process.platform === "win32" || process.platform === "linux") {\n\t\tconst sendFullscreen', 'main fullscreen state');
  next = replaceOnce(next, '\t\tfullscreenable: false,', '\t\tfullscreenable: true,', 'main fullscreen option');
  const handlerAnchor = '\tipcMain.handle(DESKTOP_IPC.boot, async (event) => {\n';
  const handler = `\tipcMain.handle(DESKTOP_IPC.windowFullscreenToggle, (event) => {
\t\tassertDesktopSender(event, ["app"]);
\t\tconst window = mainWindow;
\t\tif (window === void 0 || window.isDestroyed() || event.sender !== window.webContents || event.senderFrame !== window.webContents.mainFrame) throw new Error("dsh desktop: rejected fullscreen request from a non-primary frame");
\t\tconst target = !window.isFullScreen();
\t\twindow.setFullScreen(target);
\t\treturn target;
\t});
${handlerAnchor}`;
  next = replaceOnce(next, handlerAnchor, handler, 'main fullscreen handler');
  return next;
}

function transformPreload(source) {
  let next = source;
  next = replaceOnce(next, IPC_ANCHOR, `${IPC_ANCHOR}\twindowFullscreenToggle: "dsh-desktop:window-fullscreen-toggle",\n`, 'preload IPC channel');
  next = replaceOnce(next, 'if (process.platform !== "darwin" && process.platform !== "win32") return;', 'if (process.platform !== "darwin" && process.platform !== "win32" && process.platform !== "linux") return;', 'preload fullscreen state');
  next = replaceOnce(next, '\t\tbrowser: createDesktopBrowserBridge(),\n', `\t\tbrowser: createDesktopBrowserBridge(),
\t\t${PRELOAD_MARKER},
`, 'preload fullscreen API');
  return next;
}

export function transformNativeFullscreen({ main, preload }) {
  if (typeof main !== 'string' || typeof preload !== 'string') throw new TypeError('main and preload source must be strings');
  const mainApplied = main.includes(MAIN_MARKER);
  const preloadApplied = preload.includes(PRELOAD_MARKER);
  if (mainApplied && preloadApplied) return { status: 'already-applied', main, preload };
  if (mainApplied || preloadApplied) throw new Error('native fullscreen bridge is only partially applied');
  return { status: 'applied', main: transformMain(main), preload: transformPreload(preload) };
}

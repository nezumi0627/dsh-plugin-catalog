# dsh-boot-guard verification report

Verified on Node.js in the workspace with no live profile writes.

## Commands and current evidence

- `node --check index.js` — exit 0.
- `node --check client.js` — exit 0.
- `node test-boot-guard.mjs` — **44/44 checks passed**.
- `node test-client.mjs` — **1/1 checks passed**, including settings registration and authenticated token + host POST flow.
- Read-only real-profile registry inspection: `{ ok: true, plugins: 10, verdicts: 10 }`; no write function was called.

## Desktop archive and current boot failure (2026-10-12)

- The staged archive adds the fail-open client guard, four composer portal UI entries, native F11-to-Electron fullscreen IPC in the main/preload entries, and detailed core activation error stacks in the web-boot report.
- The full patch allowlist is one hashed frontend entry plus four core UI entries and two shell entries. An already-patched installation may take a frontend-only diagnostics upgrade. Both paths validate source markers and syntax, then hash the original packed data section to prove it is unchanged.
- The latest crash report says `@deepseek-ai/dsh-client-ui-sidebar-right: failed`; the 13 `pending` entries are blocked on its missing services. Earlier boot reports also recorded failures in the built-in sidebar and `dsh-chat-events`. The report omitted the underlying exception, so this is not yet a proven cause.
- `transformClientBoot` now upgrades the previous guard and includes the original stack for failed `@deepseek-ai` entries in the next boot error. The upgrade was activated in `resources/app.asar` after confirming no DSH process was running; a timestamped backup was saved. This does not launch DSH.

## Important implementation limits

- Host crash-log recovery reads a bounded number/size of logs and may quarantine only registered, out-of-tree plugins. Core packages, required host IDs, and itself are protected. Profile patch edits are backed up, atomic, verified, and idempotent. User-confirmed re-enable history prevents immediate preflight re-quarantine.
- A failed built-in core service is not quarantined. The boot report now carries its captured error stack so the responsible source can be fixed instead of disabling downstream dependents.
- Crash recovery changes the next launch only; it cannot repair the currently failed renderer.
- The client now provides a settings panel with status, manual recheck, and explicit re-enable for applied quarantine records, using the authenticated local route. The live DSH route was not exercised because the plugin is not integrated.
- Parser is an intentionally bounded line-oriented YAML reader; unsupported/ambiguous structures are refused rather than rewritten.
- Tests write only temporary fixtures and delete them after the assertions.

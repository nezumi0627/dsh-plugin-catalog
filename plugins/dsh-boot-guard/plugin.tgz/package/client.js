window.__ModuleLoader__.load({
  id: '@local/dsh-boot-guard',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useEffect, useState } = React;
    const ID = '@local/dsh-boot-guard';
    const NS = 'dshBootGuard';
    const CSS = `.dshbg{display:grid;gap:10px;padding:14px;border:1px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-lg);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:var(--dsw-font-base-14)}.dshbg-head,.dshbg-row{display:flex;align-items:center;justify-content:space-between;gap:12px}.dshbg-title{font:var(--dsw-font-base-16);font-weight:600}.dshbg-muted{color:var(--dsw-alias-label-secondary);font:var(--dsw-font-xxs-12)}.dshbg-list{display:grid;gap:8px}.dshbg-row{padding:9px 0;border-top:1px solid var(--dsw-alias-border-l1)}.dshbg button{border:1px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-sm);padding:6px 10px;background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-primary);font:inherit;cursor:pointer}.dshbg button:disabled{opacity:.55;cursor:default}.dshbg-error{color:var(--dsw-alias-state-error-primary)}`;
    const EN = { title: 'Boot Guard', summary: '{plugins} plugins checked · {quarantined} disabled', refresh: 'Run check', empty: 'No quarantined plugins.', reenable: 'Re-enable', busy: 'Working…', unavailable: 'Boot Guard is not reachable. The next launch may be needed to recover from a boot failure.', actionFailed: 'The action could not be completed.', reenabled: 'Plugin re-enabled. It will load on the next application start.', applied: 'Disabled for the next application start.' };
    const JA = { title: '起動ガード', summary: '{plugins} 個のプラグインを確認 · {quarantined} 個を無効化', refresh: '再チェック', empty: '隔離中のプラグインはありません。', reenable: '再有効化', busy: '処理中…', unavailable: '起動ガードに接続できません。起動失敗からの復旧は次回起動時になる場合があります。', actionFailed: '操作を完了できませんでした。', reenabled: '再有効化しました。反映は次回のアプリ起動時です。', applied: '次回のアプリ起動に向けて無効化しました。' };
    const style = typeof document === 'undefined' ? null : (() => { const node = document.createElement('style'); node.setAttribute('data-plugin-css', ID); node.textContent = CSS; document.head.append(node); return node; })();

    async function request(method = 'GET', body = null) {
      const tokenResponse = await fetch('/local/boot-guard-token', { credentials: 'same-origin', headers: { accept: 'application/json' } });
      if (!tokenResponse.ok) throw new Error('token-unavailable');
      const tokenPayload = await tokenResponse.json();
      const route = tokenPayload?.data?.path;
      const token = tokenPayload?.data?.token;
      if (typeof route !== 'string' || typeof token !== 'string' || token === '') throw new Error('token-invalid');
      const response = await fetch(route, {
        method,
        credentials: 'same-origin',
        headers: { accept: 'application/json', 'x-dsh-boot-guard-token': token, ...(body === null ? {} : { 'content-type': 'application/json' }) },
        ...(body === null ? {} : { body: JSON.stringify(body) }),
      });
      const payload = await response.json();
      if (!response.ok || payload?.ok !== true) throw new Error('request-failed');
      return payload.data;
    }

    function Panel({ t }) {
      const [report, setReport] = useState(null);
      const [busy, setBusy] = useState(false);
      const [message, setMessage] = useState('');
      const translate = typeof t === 'function' ? t : (key, values) => {
        const language = String(window.__DSH_LOCALE__?.active ?? navigator.language ?? 'en').slice(0, 2).toLowerCase();
        const value = (language === 'ja' ? JA : EN)[key] ?? EN[key] ?? key;
        return values ? value.replace(/\{(\w+)\}/g, (full, name) => values[name] ?? full) : value;
      };
      const refresh = async () => {
        setBusy(true);
        setMessage('');
        try { setReport(await request()); } catch { setMessage(translate('unavailable')); }
        finally { setBusy(false); }
      };
      useEffect(() => { refresh(); }, []);
      const reenable = async (packageName) => {
        setBusy(true);
        setMessage('');
        try {
          await request('POST', { action: 'reenable', package: packageName });
          setReport(await request('POST', { action: 'recheck' }));
          setMessage(translate('reenabled'));
        } catch { setMessage(translate('actionFailed')); }
        finally { setBusy(false); }
      };
      const quarantines = Array.isArray(report?.quarantines) ? report.quarantines : [];
      const pluginCount = Number(report?.profile?.plugins) || 0;
      return h('section', { className: 'dshbg', 'aria-label': translate('title') },
        h('div', { className: 'dshbg-head' },
          h('div', null, h('div', { className: 'dshbg-title' }, translate('title')),
            h('div', { className: 'dshbg-muted' }, translate('summary', { plugins: pluginCount, quarantined: quarantines.length }))),
          h('button', { type: 'button', disabled: busy, onClick: refresh }, busy ? translate('busy') : translate('refresh')),
        ),
        message ? h('div', { className: 'dshbg-muted', role: 'status' }, message) : null,
        quarantines.length === 0
          ? h('div', { className: 'dshbg-muted' }, translate('empty'))
          : h('div', { className: 'dshbg-list' }, ...quarantines.map((record) => h('div', { className: 'dshbg-row', key: record.packageName },
            h('div', null, h('div', null, record.packageName), h('div', { className: 'dshbg-muted' }, translate(record.applied ? 'applied' : 'busy'))),
            record.applied ? h('button', { type: 'button', disabled: busy, onClick: () => reenable(record.packageName) }, translate('reenable')) : null,
          ))),
      );
    }

    return {
      name: 'dsh-boot-guard',
      inject: ['slots', 'locale'],
      apply(ctx) {
        ctx.effect(() => () => style?.remove(), 'dsh-boot-guard: styles');
        ctx.effect(() => ctx.locale.register(NS, { en: EN, ja: JA }), 'dsh-boot-guard: locale');
        ctx.effect(() => ctx.slots.inject('settings.general.item', () => ctx.slots.register({
          name: 'settings.general.item', id: ID, order: 70, locale: NS,
        }, Panel)), 'dsh-boot-guard: settings panel');
      },
      __test: { request, Panel, ID, NS },
    };
  },
});

import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { transformNativeFullscreen } from './desktop/fullscreen-bridge.js';

const main = `const DESKTOP_IPC = {
\twindowFullscreen: "dsh-desktop:window-fullscreen",
\twindowsAppearance: "dsh-desktop:windows-appearance"
};
if (process.platform === "darwin" || process.platform === "win32") {
\t\tconst sendFullscreen = () => window.webContents.send(DESKTOP_IPC.windowFullscreen, window.isFullScreen());
}
\t\tfullscreenable: false,
\tipcMain.handle(DESKTOP_IPC.boot, async (event) => {
\t\treturn true;
\t});`;

const preload = `const DESKTOP_IPC = {
\twindowFullscreen: "dsh-desktop:window-fullscreen",
\twindowsAppearance: "dsh-desktop:windows-appearance"
};
function syncWindowFullscreen() {
\tif (process.platform !== "darwin" && process.platform !== "win32") return;
}
function createProductApi() {
\treturn {
\t\tprotocolVersion: 1,
\t\tbrowser: createDesktopBrowserBridge(),
\t\tdeviceInfo: () => electron.ipcRenderer.invoke(DESKTOP_IPC.deviceInfo)
\t};
}`;

const transformed = transformNativeFullscreen({ main, preload });
assert.equal(transformed.status, 'applied');
assert.match(transformed.main, /windowFullscreenToggle: "dsh-desktop:window-fullscreen-toggle"/u);
assert.match(transformed.main, /process\.platform === "linux"/u);
assert.match(transformed.main, /fullscreenable: true/u);
assert.match(transformed.main, /assertDesktopSender\(event, \["app"\]\)/u);
assert.match(transformed.main, /window\.setFullScreen\(target\)/u);
assert.match(transformed.preload, /fullscreen: \{ toggle: \(\) => electron\.ipcRenderer\.invoke\(DESKTOP_IPC\.windowFullscreenToggle\) \}/u);
assert.match(transformed.preload, /process\.platform !== "linux"/u);
const syntaxDir = mkdtempSync(join(tmpdir(), 'dsh-fullscreen-'));
try {
  const mainPath = join(syntaxDir, 'main.mjs');
  const preloadPath = join(syntaxDir, 'preload.cjs');
  writeFileSync(mainPath, transformed.main);
  writeFileSync(preloadPath, transformed.preload);
  execFileSync(process.execPath, ['--check', mainPath], { stdio: 'pipe' });
  execFileSync(process.execPath, ['--check', preloadPath], { stdio: 'pipe' });
} finally { rmSync(syntaxDir, { recursive: true, force: true }); }
assert.equal(transformNativeFullscreen(transformed).status, 'already-applied');
assert.throws(() => transformNativeFullscreen({ main: `${main}\n${main}`, preload }), /expected exactly one/u);
console.log('10/10 native fullscreen bridge transform checks passed');

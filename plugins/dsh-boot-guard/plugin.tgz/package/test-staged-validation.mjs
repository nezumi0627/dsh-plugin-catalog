import assert from 'node:assert/strict';
import { CORE_WIDGET_ENTRIES, SHELL_FULLSCREEN_ENTRIES, validateChangedEntries, validateCoreWidgetSources, validateDesktopMain, validateDesktopPreload } from './desktop/staged-validation.js';

const frontend = 'dsh/node_modules/@deepseek-ai/dsh-web-frontend/dist/assets/index-test.js';
const valid = [frontend, ...CORE_WIDGET_ENTRIES, ...SHELL_FULLSCREEN_ENTRIES];
assert.equal(validateChangedEntries(valid, frontend), true);
assert.equal(validateChangedEntries([frontend], frontend), true, 'an already-patched install may receive a diagnostic-only frontend upgrade');
assert.throws(() => validateChangedEntries([...valid, 'lib/renderer.js'], frontend), /unexpected staged archive changes/);
assert.throws(() => validateChangedEntries([frontend, ...CORE_WIDGET_ENTRIES.slice(0, 3), CORE_WIDGET_ENTRIES[2]], frontend), /unexpected staged archive changes/);
assert.throws(() => validateChangedEntries(['lib/main.js', ...CORE_WIDGET_ENTRIES], 'lib/main.js'), /invalid staged frontend entry/);

const sources = {
  chatManifest: JSON.stringify({ dsh: { client: { inject: ['@local/dsh-status-widgets'] } } }),
  chatClient: 'dsh.core.chat-stats conversation.composer.stats',
  conversationManifest: JSON.stringify({ dsh: { client: { inject: ['@local/dsh-status-widgets'] } } }),
  conversationClient: 'dsh.core.context-meter dsh.core.chat-stats',
};
assert.throws(() => validateCoreWidgetSources(sources), /missing movable core widget portals/);
const main = 'partition = `persist:dsh-sidebar-browser`; "--trace-deprecation" dsh-host-exit-trace signal=${String(signal)} windowFullscreenToggle: "dsh-desktop:window-fullscreen-toggle" assertDesktopSender(event, ["app"]) window.setFullScreen(target) fullscreenable: true';
assert.equal(validateDesktopMain(main), true);
assert.throws(() => validateDesktopMain('partition = `persist:dsh-sidebar-browser`;'), /deprecation stack and child-exit diagnostics/);
assert.throws(() => validateDesktopMain('partition = `persist:dsh-sidebar-browser`; "--trace-deprecation" dsh-host-exit-trace signal=${String(signal)}'), /guarded native fullscreen bridge/);
assert.equal(validateDesktopPreload('fullscreen: { toggle: () => electron.ipcRenderer.invoke(DESKTOP_IPC.windowFullscreenToggle) } process.platform !== "linux"'), true);
assert.throws(() => validateDesktopPreload(''), /native fullscreen API or Linux state sync/);
console.log('staged archive validator accepts only the frontend, four core UI entries and two fullscreen shell entries');

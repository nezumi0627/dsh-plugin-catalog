import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { test } from 'node:test';
import { encodeFrame, decodeFrame, socketPaths, activityFor, apply, createRpcBridge } from './index.js';

class FakeSocket extends EventEmitter {
  writable = true;
  destroyed = false;
  writes = [];
  write(frame) { this.writes.push(Buffer.from(frame)); return true; }
  unref() { this.unrefCalled = true; }
  destroy() { this.destroyed = true; this.writable = false; this.emit('close'); }
  receive(frame) { this.emit('data', frame); }
  decoded() { return this.writes.map(decodeFrame); }
}
class FakeTimers {
  now = 0; nextId = 1; tasks = new Map();
  setTimeout(fn, delay) {
    const timer = { id: this.nextId++, fn, delay, at: this.now + delay, unref() { this.unrefCalled = true; } };
    this.tasks.set(timer.id, timer); return timer;
  }
  clearTimeout(timer) { if (timer) this.tasks.delete(timer.id); }
  advance(ms) {
    const end = this.now + ms;
    while (true) {
      const due = [...this.tasks.values()].filter((t) => t.at <= end).sort((a, b) => a.at - b.at)[0];
      if (!due) break;
      this.tasks.delete(due.id); this.now = due.at; due.fn();
    }
    this.now = end;
  }
}
function fixture({ state = true, paths = ['/ipc-0', '/ipc-1'], appId = 'test-app' } = {}) {
  const timers = new FakeTimers();
  const sockets = [];
  const attempts = [];
  const netModule = { createConnection(path) { attempts.push(path); const s = new FakeSocket(); sockets.push(s); return s; } };
  let current = { state, model: 'Model A', startedAt: 100_000 };
  const listeners = new Set();
  const source = () => current;
  source.subscribe = (fn) => { listeners.add(fn); return () => listeners.delete(fn); };
  source.set = (value) => { current = value; for (const fn of listeners) fn(); };
  let clock = 1_000;
  let sequence = 0;
  const dispose = createRpcBridge({ applicationId: appId, statusSource: source, netModule, paths, timers, now: () => clock, uuid: () => `nonce-${++sequence}`, pid: 55 });
  return { timers, sockets, attempts, source, dispose, setNow(v) { clock = v; } };
}
function connectReady(f) {
  const s = f.sockets.at(-1);
  s.emit('connect');
  return s;
}

test('frames round-trip payload; malformed/truncated/oversized frames are rejected', () => {
  const value = { marker: crypto.randomUUID(), nested: [1, true] };
  assert.deepEqual(decodeFrame(encodeFrame(0, value)), { opcode: 0, data: value });
  assert.deepEqual(decodeFrame(encodeFrame(3, 'ping')), { opcode: 3, data: 'ping' });
  assert.throws(() => decodeFrame(encodeFrame(1, value).subarray(0, 9)), /invalid Discord IPC frame/);
  const malformed = Buffer.alloc(9); malformed.writeUInt32LE(0, 0); malformed.writeUInt32LE(1, 4); malformed[8] = 0xff;
  assert.throws(() => decodeFrame(malformed));
  const oversized = Buffer.alloc(8); oversized.writeUInt32LE(2_000_000, 4);
  assert.throws(() => decodeFrame(oversized), /invalid Discord IPC frame/);
});

test('activity includes only supplied safe values', () => {
  assert.deepEqual(activityFor({ state: true, model: 'Known model', startedAt: 1000 }), { details: 'AI running', state: 'Known model', start: 1 });
  assert.deepEqual(activityFor({}), {});
  assert.equal(JSON.stringify(activityFor({ state: null, model: null })).includes('null'), false);
});

test('socket paths are ordered and deduplicated', () => {
  assert.deepEqual(socketPaths({ platform: 'win32' }), Array.from({ length: 10 }, (_, i) => `\\\\?\\pipe\\discord-ipc-${i}`));
  assert.deepEqual(socketPaths({ platform: 'linux', env: { XDG_RUNTIME_DIR: '/run/u', TMPDIR: '/tmp/u' }, tmpdir: '/tmp/u' }).slice(0, 3), ['/run/u/discord-ipc-0', '/run/u/discord-ipc-1', '/run/u/discord-ipc-2']);
});

test('handshake is v1 and no activity is sent before READY; READY sends activity', () => {
  const f = fixture(); const s = connectReady(f);
  assert.deepEqual(s.decoded()[0], { opcode: 0, data: { v: 1, client_id: 'test-app' } });
  assert.equal(s.decoded().filter((m) => m.data?.cmd === 'SET_ACTIVITY').length, 0);
  s.receive(encodeFrame(1, { evt: 'READY' }));
  const activity = s.decoded().find((m) => m.data?.cmd === 'SET_ACTIVITY');
  assert.equal(activity.opcode, 1);
  assert.equal(activity.data.args.pid, 55);
  assert.deepEqual(activity.data.args.activity, { details: 'AI running', state: 'Model A', start: 1 });
  assert.equal(activity.data.nonce, 'nonce-1');
  s.receive(encodeFrame(1, { cmd: 'SET_ACTIVITY', data: { code: 0 }, nonce: activity.data.nonce }));
  assert.equal(s.decoded().filter((m) => m.data?.cmd === 'SET_ACTIVITY').length, 1, 'SET_ACTIVITY acknowledgement must not trigger another update');
  f.dispose();
});

test('PING receives matching PONG; fragmented and coalesced frames work', () => {
  const f = fixture(); const s = connectReady(f);
  s.receive(encodeFrame(3, { nonce: 'ping-1' }).subarray(0, 5));
  assert.equal(s.decoded().length, 1);
  s.receive(Buffer.concat([encodeFrame(3, { nonce: 'ping-1' }).subarray(5), encodeFrame(1, { evt: 'READY' })]));
  const messages = s.decoded();
  assert.deepEqual(messages[1], { opcode: 4, data: { nonce: 'ping-1' } });
  assert.ok(messages.some((m) => m.data?.cmd === 'SET_ACTIVITY'));
  f.dispose();
});

test('malformed JSON frame tears down only its socket and schedules bounded retry', () => {
  const f = fixture(); const s = connectReady(f);
  const malformed = Buffer.alloc(9); malformed.writeUInt32LE(1, 0); malformed.writeUInt32LE(1, 4); malformed[8] = 0xff;
  s.receive(malformed);
  assert.equal(s.destroyed, true);
  assert.equal([...f.timers.tasks.values()].filter((t) => t.delay === 30_000).length, 1);
  f.dispose();
});

test('absent Discord retries after exactly 30 seconds and socket is unrefed', () => {
  const f = fixture(); const s = f.sockets[0];
  assert.equal(s.unrefCalled, true);
  s.emit('error', Object.assign(new Error('ENOENT'), { code: 'ENOENT' }));
  assert.deepEqual(f.attempts, ['/ipc-0']);
  const retry = [...f.timers.tasks.values()][0];
  assert.equal(retry.delay, 30_000);
  assert.equal(retry.unrefCalled, true);
  f.timers.advance(29_999);
  assert.equal(f.attempts.length, 1);
  f.timers.advance(1);
  assert.deepEqual(f.attempts, ['/ipc-0', '/ipc-1']);
  f.dispose();
});

test('updates are capped to five in any rolling 20-second window', () => {
  const f = fixture(); const s = connectReady(f);
  s.receive(encodeFrame(1, { evt: 'READY' }));
  const count = () => s.decoded().filter((m) => m.data?.cmd === 'SET_ACTIVITY').length;
  assert.equal(count(), 1);
  for (let i = 0; i < 10; i++) f.source.set({ state: true, model: `M${i}`, startedAt: 100_000 });
  assert.equal(count(), 5);
  f.setNow(20_999); f.source.set({ state: true, model: 'Still window', startedAt: 100_000 });
  assert.equal(count(), 5);
  f.setNow(21_000); f.source.set({ state: true, model: 'Window expired', startedAt: 100_000 });
  assert.equal(count(), 6);
  f.dispose();
});

test('idle/unknown source does not connect; empty app id logs once and does nothing', () => {
  const idle = fixture({ state: false });
  assert.equal(idle.sockets.length, 0); idle.dispose();
  const logs = [];
  apply({ effect() { throw Error('unexpected effect'); }, logger: { info: (s) => logs.push(s) } }, { applicationId: '' });
  assert.equal(logs.length, 1);
});

test('effect disposer unsubscribes, sends CLOSE, destroys socket, and clears retry timers', () => {
  const f = fixture(); const s = connectReady(f);
  s.receive(encodeFrame(1, { evt: 'READY' }));
  f.dispose();
  assert.deepEqual(s.decoded().at(-1), { opcode: 2, data: {} });
  assert.equal(s.destroyed, true);
  assert.equal(f.timers.tasks.size, 0);
  assert.equal(f.source.set({ state: true, model: 'later' }), undefined);
  assert.equal(f.sockets.length, 1);
});

test('apply preserves empty-id one-log no-op and missing source no-op', () => {
  let effects = 0; const logs = [];
  apply({ effect() { effects++; }, logger: { info: (s) => logs.push(s) } }, { applicationId: 'configured' });
  assert.equal(effects, 0);
  apply({ effect() { effects++; }, logger: { info: (s) => logs.push(s) } }, { applicationId: '' });
  assert.equal(effects, 0); assert.equal(logs.length, 2);
});

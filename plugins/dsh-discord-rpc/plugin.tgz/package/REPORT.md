# dsh-discord-rpc implementation report

## Scope and sources

- Discord application ID: **not supplied**. `applicationId` defaults to the empty string and causes a single log message plus an immediate no-op; no ID was invented.
- AI status/model source: **not available/verified in the host services inspected for this task**. With no verified `statusSource`, the plugin logs idle and creates no socket/timer. The bridge accepts a dependency-injected trusted source; `state: true` is required to connect and publish. It does not infer or fabricate status.
- Session elapsed source: `process.uptime()` at host plugin activation (or a finite `startedAt` supplied by the trusted host source), emitted as Discord's `start` timestamp.
- Workspace opt-in was not added; no workspace data, paths, filenames, conversation values/IDs, prompts, token counts, secrets, or `~/.dsh` data are read or sent.
- Platform: native `node:net` IPC; no dependencies. Candidate paths are Windows named pipes `\\?\pipe\discord-ipc-0` through `-9`, and on POSIX XDG runtime, TMPDIR, OS temp, then `/tmp` roots, each numbered 0–9.

## Protocol behavior

- Sends protocol v1 HANDSHAKE `{ v: 1, client_id }` only after socket connect; does not publish activity until a FRAME containing `evt: "READY"` arrives.
- Parses partial and coalesced frames, enforces a 1 MiB payload limit, rejects malformed JSON/frames, and closes only the bad socket.
- Replies to Discord opcode 3 PING with opcode 4 PONG carrying the same JSON payload.
- Socket failures try remaining pipe candidates and then schedule one retry after 30 seconds; retry timers and sockets are unrefed. Idle/unknown source does not connect/retry.
- Activity sends are capped at five per rolling 20 seconds. Extra changes are coalesced to one latest-value update after the oldest rate-window entry expires.
- Disposer unsubscribes from the source, clears retry/rate timers, sends CLOSE, and destroys the socket.

## Verification commands and exact output

```powershell
node --check index.js
node --check client.js
node test-host.mjs
node test-client.mjs
```

Both syntax checks exited successfully without output. Host tests:

```text
✔ frames round-trip payload; malformed/truncated/oversized frames are rejected
✔ activity includes only supplied safe values
✔ socket paths are ordered and deduplicated
✔ handshake is v1 and no activity is sent before READY; READY sends activity
✔ PING receives matching PONG; fragmented and coalesced frames work
✔ malformed JSON frame tears down only its socket and schedules bounded retry
✔ absent Discord retries after exactly 30 seconds and socket is unrefed
✔ updates are capped to five in any rolling 20-second window
✔ idle/unknown source does not connect; empty app id logs once and does nothing
✔ effect disposer unsubscribes, sends CLOSE, destroys socket, and clears retry timers
✔ apply preserves empty-id one-log no-op and missing source no-op
ℹ tests 11
ℹ pass 11
ℹ fail 0
```

Client test:

```text
✔ client loads through supported React seed and registers settings only
ℹ tests 1
ℹ pass 1
ℹ fail 0
```

## Runtime/live checks

- Discord running: not tested; application ID not supplied.
- Discord not running: exercised with injected fake socket `ENOENT`; next attempt occurred exactly 30,000 ms later. No live Discord process was used.
- Socket path in live use and actual presence display remain unverified because no application ID / verified host status source is available.
- No profile changes or external dependencies were made.

## Known gaps

The production integration still has no verified AI/model status source and no user-owned Discord application ID. As required, no presence status is fabricated; source missing is a no-op, and an empty ID logs once then returns. Live Discord verification cannot be claimed until those inputs are supplied.

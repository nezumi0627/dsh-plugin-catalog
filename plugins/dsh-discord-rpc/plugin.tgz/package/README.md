# DSH Discord RPC

Host-side Discord Rich Presence via dependency-free `node:net` IPC. Configure your own Discord application ID in the plugin row; blank means a one-line logged no-op. The current host integration has no verified AI-state or model service source, so it does not fabricate or publish those fields. No workspace, file, conversation, token, or secret data is sent. Discord running/live presence requires a user-owned application ID.

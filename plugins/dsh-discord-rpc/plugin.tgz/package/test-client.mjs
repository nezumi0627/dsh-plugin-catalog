import assert from 'node:assert/strict';
import { test } from 'node:test';

test('client loads through supported React seed and registers settings only', async () => {
  const specs = [];
  globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
  await import(`./client.js?t=${Date.now()}`);
  assert.equal(specs.length, 1);
  const React = { createElement: (...args) => args };
  const module = specs[0].factory((name) => { if (name === 'react') return React; throw Error(`unexpected require: ${name}`); });
  let registration;
  const ctx = { slots: { inject: (_name, cb) => cb(), register: (...args) => { registration = args; } }, effect: (fn) => fn() };
  module.apply(ctx);
  assert.equal(registration[0].name, 'settings.section');
  assert.equal(registration[0].id, 'discord-rpc');
  assert.equal(registration[0].order, 70);
  assert.equal('timer' in module, false);
  assert.equal('fetch' in globalThis, true);
});

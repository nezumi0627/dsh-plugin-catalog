window.__ModuleLoader__.load({
  id: '@local/dsh-discord-rpc',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const ID = '@local/dsh-discord-rpc', NS = 'dshDiscordRpc';
    function Settings() {
      return h('section', null,
        h('h2', null, 'Discord Rich Presence'),
        h('p', null, 'Discord RPC configuration is managed by the host plugin row.'),
        h('p', null, 'Only known status and model information may be shared; private content is never published.'));
    }
    return {
      name: 'dsh-discord-rpc', inject: ['slots', 'locale'],
      apply(ctx) {
        ctx.effect(() => ctx.slots.inject('settings.section', () => ctx.slots.register({
          name: 'settings.section', id: 'discord-rpc', order: 70, locale: NS,
          label: () => 'Discord Rich Presence', inject: () => ({}),
        }, Settings)), 'dsh-discord-rpc.settings');
      },
      __test: { id: ID, Settings },
    };
  },
});

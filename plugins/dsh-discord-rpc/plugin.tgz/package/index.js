import net from 'node:net';
import os from 'node:os';
import { randomUUID } from 'node:crypto';

export const name = 'dsh-discord-rpc';
export const DEFAULT_CONFIG = { applicationId: '', assetKey: '' };
const MAX_FRAME_BYTES = 1024 * 1024;
const RETRY_MS = 30_000;
const RATE_WINDOW_MS = 20_000;
const RATE_MAX = 5;

export function encodeFrame(opcode, value) {
  const body = Buffer.from(JSON.stringify(value));
  const frame = Buffer.allocUnsafe(8 + body.length);
  frame.writeUInt32LE(opcode, 0); frame.writeUInt32LE(body.length, 4); body.copy(frame, 8);
  return frame;
}
export function decodeFrame(frame) {
  if (!Buffer.isBuffer(frame) || frame.length < 8) throw new Error('invalid Discord IPC frame');
  const size = frame.readUInt32LE(4);
  if (size > MAX_FRAME_BYTES || frame.length !== 8 + size) throw new Error('invalid Discord IPC frame');
  const data = frame.subarray(8).toString('utf8');
  return { opcode: frame.readUInt32LE(0), data: data ? JSON.parse(data) : null };
}
export function socketPaths({ platform = process.platform, env = process.env, tmpdir = os.tmpdir() } = {}) {
  if (platform === 'win32') return Array.from({ length: 10 }, (_, i) => `\\\\?\\pipe\\discord-ipc-${i}`);
  const roots = [env.XDG_RUNTIME_DIR, env.TMPDIR, tmpdir, '/tmp'].filter(Boolean);
  return [...new Set(roots)].flatMap((root) => Array.from({ length: 10 }, (_, i) => `${root.replace(/[\\/]+$/, '')}/discord-ipc-${i}`));
}
export function activityFor({ state, model, startedAt } = {}) {
  const activity = {};
  if (typeof state === 'boolean') activity.details = state ? 'AI running' : 'Idle';
  if (typeof model === 'string' && model.trim()) activity.state = model.trim().slice(0, 128);
  if (Number.isFinite(startedAt)) activity.start = Math.floor(startedAt / 1000);
  return activity;
}

/** Host IPC bridge. Dependencies are injectable for deterministic protocol tests. */
export function createRpcBridge({
  applicationId, statusSource, netModule = net, paths = socketPaths(),
  timers = globalThis, now = Date.now, uuid = randomUUID, pid = process.pid,
  logger = { info() {} },
}) {
  if (!applicationId || typeof statusSource !== 'function') return () => {};
  let disposed = false, socket = null, retryTimer = null, rateTimer = null, rx = Buffer.alloc(0);
  let pathIndex = 0, ready = false, startedAt = now();
  let retryEligible = false;
  const sentUpdates = [];
  const clearTimer = (timer) => { if (timer) timers.clearTimeout(timer); };
  const unref = (timer) => timer?.unref?.();
  const activeStatus = () => {
    try { const s = statusSource(); return s && s.state === true ? s : null; }
    catch { return null; }
  };
  const send = (opcode, value) => {
    try { if (socket?.writable) socket.write(encodeFrame(opcode, value)); }
    catch { /* socket error/close handlers own recovery */ }
  };
  const cleanupSocket = (client) => {
    if (socket !== client) return;
    socket = null; ready = false; rx = Buffer.alloc(0);
    try { client.destroy(); } catch {}
    if (!disposed && retryEligible && activeStatus()) scheduleRetry();
  };
  function scheduleRetry() {
    if (disposed || retryTimer || !retryEligible || !activeStatus()) return;
    retryTimer = timers.setTimeout(() => {
      retryTimer = null;
      if (!disposed && activeStatus()) connect();
    }, RETRY_MS);
    unref(retryTimer);
  }
  function publish() {
    if (disposed || !ready || !socket?.writable) return;
    const status = activeStatus();
    if (!status) return;
    const time = now();
    while (sentUpdates.length && time - sentUpdates[0] >= RATE_WINDOW_MS) sentUpdates.shift();
    if (sentUpdates.length >= RATE_MAX) {
      if (!rateTimer) {
        const wait = Math.max(1, sentUpdates[0] + RATE_WINDOW_MS - time);
        rateTimer = timers.setTimeout(() => { rateTimer = null; publish(); }, wait);
        unref(rateTimer);
      }
      return;
    }
    const activity = activityFor({ ...status, startedAt });
    sentUpdates.push(time);
    send(1, { cmd: 'SET_ACTIVITY', args: { pid, activity }, nonce: uuid() });
  }
  function onData(client, chunk) {
    if (socket !== client || disposed) return;
    rx = Buffer.concat([rx, chunk]);
    while (rx.length >= 8) {
      const length = rx.readUInt32LE(4);
      if (length > MAX_FRAME_BYTES) { cleanupSocket(client); return; }
      const frameLength = 8 + length;
      if (rx.length < frameLength) return;
      const frame = rx.subarray(0, frameLength); rx = rx.subarray(frameLength);
      let message;
      try { message = decodeFrame(frame); }
      catch { cleanupSocket(client); return; }
      if (message.opcode === 3) send(4, message.data);
      else if (message.opcode === 1 && message.data?.evt === 'READY') {
        ready = true;
        publish(); // Never publish before READY.
      }
    }
  }
  function connect() {
    if (disposed || socket || !activeStatus() || !paths.length) return;
    retryEligible = true;
    if (pathIndex >= paths.length) { pathIndex = 0; scheduleRetry(); return; }
    const target = paths[pathIndex++];
    let client;
    try { client = netModule.createConnection(target); }
    catch { scheduleRetry(); return; }
    socket = client;
    try { client.unref?.(); } catch {}
    client.on('error', () => cleanupSocket(client));
    client.on('close', () => cleanupSocket(client));
    client.on('connect', () => {
      if (socket !== client || disposed) return;
      pathIndex = 0; rx = Buffer.alloc(0); ready = false;
      send(0, { v: 1, client_id: applicationId });
    });
    client.on('data', (chunk) => onData(client, chunk));
  }
  function onStatusChange() {
    const status = activeStatus();
    if (!status) {
      retryEligible = false; clearTimer(retryTimer); retryTimer = null;
      clearTimer(rateTimer); rateTimer = null;
      if (socket) { const client = socket; socket = null; ready = false; try { client.destroy(); } catch {} }
      return;
    }
    startedAt = Number.isFinite(status.startedAt) ? status.startedAt : startedAt;
    if (!socket && !retryTimer) connect();
    else publish();
  }
  // Explicit initial state check; unknown/idle is a true no-op.
  if (activeStatus()) connect();
  let unsubscribe;
  try { unsubscribe = statusSource.subscribe?.(onStatusChange); } catch { unsubscribe = undefined; }
  return () => {
    if (disposed) return;
    disposed = true;
    try { if (typeof unsubscribe === 'function') unsubscribe(); } catch {}
    clearTimer(retryTimer); retryTimer = null;
    if (socket) {
      const client = socket; socket = null; ready = false;
      try { if (client.writable) client.write(encodeFrame(2, {})); } catch {}
      try { client.destroy(); } catch {}
    }
  };
}

export function apply(ctx, config = {}, { statusSource, netModule, timers, now, uuid, paths, pid } = {}) {
  const applicationId = typeof config.applicationId === 'string' ? config.applicationId.trim() : '';
  if (!applicationId) { ctx.logger?.info?.('[discord-rpc] disabled: applicationId is empty'); return; }
  if (typeof statusSource !== 'function') { ctx.logger?.info?.('[discord-rpc] idle: no verified host status source'); return; }
  ctx.effect(() => createRpcBridge({ applicationId, statusSource, netModule, timers, now, uuid, paths, pid, logger: ctx.logger }), 'dsh-discord-rpc.ipc');
}

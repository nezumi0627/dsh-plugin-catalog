import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const specs = [];
globalThis.document = {
  visibilityState: 'visible',
  documentElement: { lang: 'en' },
  head: { append() {} },
  createElement: () => ({ setAttribute() {}, remove() {} }),
  addEventListener() {},
  removeEventListener() {},
};
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
await import('./client.js?controls-test');

let hookStates = null;
let stateIndex = 0;
const React = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState: (initial) => [hookStates ? hookStates[stateIndex++] ?? initial : initial, () => {}],
  useEffect() {},
  useRef: (current) => ({ current }),
};
const plugin = specs[0].factory((name) => name === 'react' ? React : (() => { throw Error(name); })());
const descriptors = [];
plugin.apply({
  get: () => ({ register: (descriptor) => { descriptors.push(descriptor); return () => {}; } }),
  locale: { register: () => () => {} },
  effect: (run) => run(),
});

assert.equal(descriptors.length, 1, 'the dynamic hub must be a single draggable widget');
assert.equal(descriptors[0].id, 'dsh-dynamic-hub.main');
assert.equal(descriptors[0].render({ value: null }).type, plugin.__test.Component,
  'the top panel mounts the real media controls');

hookStates = [{
  active: true, title: 'Song', artist: 'Artist', app: 'Player',
  position: 15, duration: 90, hasArt: false,
  volume: { available: true, level: 0.4 },
}, '', 'UP 00:10:00', false, '', null, null, 0.4];
stateIndex = 0;
const view = plugin.__test.Component();
const flatten = (node) => Array.isArray(node) ? node.flatMap(flatten)
  : node && typeof node === 'object' ? [node, ...flatten(node.children ?? [])] : [];
const nodes = flatten(view);
const labels = nodes.map((node) => node.props?.['aria-label']).filter(Boolean);
assert.ok(labels.includes('Playback position'));
assert.ok(labels.includes('Playback app volume'), 'the volume control must target the current media app');
assert.equal(nodes.find((node) => node.props?.['aria-label'] === 'Playback app volume')?.props.disabled, false,
  'a uniquely resolved app session enables playback volume control');
assert.equal(nodes.some((node) => node.props?.className === 'ddh-time'), false,
  'the dynamic hub must not duplicate the status panel clock');
console.log('PASS dynamic hub: one widget renders playback, seek, and per-app volume controls without duplicating the clock');

const mediaScript = readFileSync(fileURLToPath(new URL('./scripts/media-probe.ps1', import.meta.url)), 'utf8');
const controlBody = mediaScript.match(/function Invoke-Control \{([\s\S]*?)\n\}/)?.[1] ?? '';
assert.ok(controlBody, 'the Windows media transport function exists');
for (const method of ['TryTogglePlayPauseAsync', 'TryPlayAsync', 'TryPauseAsync', 'TryStopAsync', 'TrySkipNextAsync', 'TrySkipPreviousAsync']) {
  assert.ok(controlBody.includes(method), `the transport supports ${method}`);
}
assert.match(controlBody, /Await-WinRt[\s\S]*?ResultType\s+\(\[bool\]\)/,
  'transport actions wait for Windows to confirm whether it accepted the command');
assert.match(controlBody, /if\s*\(-not\s+\[bool\]\$accepted\)/,
  'a refused transport action is reported as a failure');
assert.doesNotMatch(controlBody, /\$null\s*=\s*\$session\.Try/,
  'transport results must not be discarded');

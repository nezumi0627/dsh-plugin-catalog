<#
  dsh-dynamic-hub — SMTC verification fixture.

  This machine has no media app running, so `GetCurrentSession()` returns null
  and the media path cannot be exercised at all. This fixture manufactures a
  *real* System Media Transport Controls session with no third-party software
  and no binary assets: it synthesizes one WAV tone and one PNG cover into
  %TEMP%, plays them through `Windows.Media.Playback.MediaPlayer` (which
  registers with SMTC automatically), and publishes display properties so
  title / artist / album / thumbnail are all populated.

  `MediaPlaybackCommandManager.{Next,Previous}Behavior.EnablingRule = Always`
  turns the skip buttons on for a single-item session, and every received
  command is appended to a log file. That is what makes the host's control
  route provable end to end: `TrySkipNextAsync()` returning true only means the
  app took the command, so the fixture records the receipt separately.

    powershell.exe -NoProfile -ExecutionPolicy Bypass -File scripts\media-fixture.ps1

  It prints one JSON line once the session is live, then stays alive until its
  duration elapses or stdin closes (Ctrl+C also ends it).
#>
[CmdletBinding()]
param(
  [int] $Seconds = 300,
  [int] $SampleRate = 8000,
  [int] $ToneSeconds = 120,
  <#
    Audible frequency. 0 (the default) writes digital silence: the session is
    just as real to SMTC, and a fixture left running in the background is not
    going to hum at somebody for fifteen minutes.
  #>
  [double] $Frequency = 0,
  [switch] $StartPaused,
  <#
    Opt-in stdin watch: end as soon as stdin closes. It is off by default
    because a launcher that redirects stdin from an already-closed handle makes
    `IsInputRedirected` true and `ReadLine()` return null immediately, which
    would end the fixture before anything could observe it.
  #>
  [switch] $UntilStdinCloses
)

$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false

Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Drawing

$null = [Windows.Media.Core.MediaSource, Windows.Media.Core, ContentType = WindowsRuntime]
$null = [Windows.Media.Playback.MediaPlaybackItem, Windows.Media.Playback, ContentType = WindowsRuntime]
$null = [Windows.Media.Playback.MediaPlayer, Windows.Media.Playback, ContentType = WindowsRuntime]
$null = [Windows.Media.Playback.MediaCommandEnablingRule, Windows.Media.Playback, ContentType = WindowsRuntime]
$null = [Windows.Media.MediaPlaybackType, Windows.Media, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.RandomAccessStreamReference, Windows.Storage.Streams, ContentType = WindowsRuntime]

$directory = Join-Path $env:TEMP 'dsh-dynamic-hub-fixture'
New-Item -ItemType Directory -Force -Path $directory | Out-Null
$log = Join-Path $directory 'commands.log'
Set-Content -LiteralPath $log -Value '' -Encoding UTF8

function Write-CommandLog {
  param([string] $Name)
  Add-Content -LiteralPath $log -Value ("{0} {1}" -f (Get-Date).ToString('HH:mm:ss.fff'), $Name) -Encoding UTF8
}

<#
  Write a PCM WAV of the requested length.

  The buffer is built in one allocation and the audio (when asked for) is one
  whole period tiled with `[Array]::Copy`. A per-sample `[math]::Sin` loop over
  minutes of audio is millions of PowerShell statements: it pins a core for
  tens of seconds and this workspace's own auto-kill guard terminates the job
  for it — which is exactly what happened on the first attempt.
#>
function New-ToneWav {
  param([string] $Path, [double] $Tone, [int] $Length)
  $samples = $SampleRate * $Length
  $dataBytes = $samples * 2
  $frames = New-Object byte[] (44 + $dataBytes)

  $put = {
    param([int] $Offset, [string] $Text)
    for ($index = 0; $index -lt $Text.Length; $index++) { $frames[$Offset + $index] = [byte][char]$Text[$index] }
  }
  $int32 = { param([int] $Value) [BitConverter]::GetBytes($Value) }
  $int16 = { param([int] $Value) [BitConverter]::GetBytes([int16]$Value) }

  & $put 0 'RIFF'
  [Array]::Copy((& $int32 (36 + $dataBytes)), 0, $frames, 4, 4)
  & $put 8 'WAVE'
  & $put 12 'fmt '
  [Array]::Copy((& $int32 16), 0, $frames, 16, 4)
  [Array]::Copy((& $int16 1), 0, $frames, 20, 2)
  [Array]::Copy((& $int16 1), 0, $frames, 22, 2)
  [Array]::Copy((& $int32 $SampleRate), 0, $frames, 24, 4)
  [Array]::Copy((& $int32 ($SampleRate * 2)), 0, $frames, 28, 4)
  [Array]::Copy((& $int16 2), 0, $frames, 32, 2)
  [Array]::Copy((& $int16 16), 0, $frames, 34, 2)
  & $put 36 'data'
  [Array]::Copy((& $int32 $dataBytes), 0, $frames, 40, 4)

  if ($Tone -gt 0) {
    $period = [int][math]::Round($SampleRate / $Tone)
    if ($period -lt 2) { $period = 2 }
    $pattern = New-Object byte[] ($period * 2)
    for ($index = 0; $index -lt $period; $index++) {
      $value = [int16]([math]::Sin(2 * [math]::PI * $index / $period) * 4000)
      [Array]::Copy([BitConverter]::GetBytes($value), 0, $pattern, $index * 2, 2)
    }
    $offset = 44
    while ($offset -lt $frames.Length) {
      $chunk = [math]::Min($pattern.Length, $frames.Length - $offset)
      [Array]::Copy($pattern, 0, $frames, $offset, $chunk)
      $offset += $chunk
    }
  }

  [System.IO.File]::WriteAllBytes($Path, $frames)
}

function New-CoverPng {
  param([string] $Path)
  $bitmap = New-Object System.Drawing.Bitmap 160, 160
  $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
  $graphics.Clear([System.Drawing.Color]::FromArgb(255, 38, 92, 196))
  $font = New-Object System.Drawing.Font 'Segoe UI', 22, ([System.Drawing.FontStyle]::Bold)
  $graphics.DrawString('DH', $font, [System.Drawing.Brushes]::White, 44, 62)
  $graphics.Dispose()
  $bitmap.Save($Path, [System.Drawing.Imaging.ImageFormat]::Png)
  $bitmap.Dispose()
  $font.Dispose()
}

<#
  A thumbnail reference SMTC can actually read.

  `RandomAccessStreamReference.CreateFromUri` only accepts http / https /
  ms-appx / ms-appdata — a `file://` URI throws NotImplementedException
  ("この API でサポートされる URI スキームは、http、https、ms-appx、ms-appdata だけです")
  the moment SMTC opens it. Handing SMTC the bytes through a random-access
  stream is the route that works for a locally generated image.
#>
function New-CoverReference {
  param([string] $Path)
  $fileStream = [System.IO.File]::OpenRead($Path)
  $randomAccess = [System.IO.WindowsRuntimeStreamExtensions]::AsRandomAccessStream($fileStream)
  return [Windows.Storage.Streams.RandomAccessStreamReference]::CreateFromStream($randomAccess)
}

$wav = Join-Path $directory 'Probe-Tone.wav'
$png = Join-Path $directory 'Probe-Tone.png'
New-ToneWav -Path $wav -Tone $Frequency -Length $ToneSeconds
New-CoverPng -Path $png

$source = [Windows.Media.Core.MediaSource]::CreateFromUri([uri]$wav)
$item = [Windows.Media.Playback.MediaPlaybackItem]::new($source)
$display = $item.GetDisplayProperties()
$display.Type = [Windows.Media.MediaPlaybackType]::Music
$display.MusicProperties.Title = 'Probe Tone'
$display.MusicProperties.Artist = 'dsh-dynamic-hub'
$display.MusicProperties.AlbumTitle = 'Verification'
$display.Thumbnail = New-CoverReference -Path $png
$item.ApplyDisplayProperties($display)

$player = [Windows.Media.Playback.MediaPlayer]::new()
$player.Source = $item

$manager = $player.CommandManager
$manager.NextBehavior.EnablingRule = [Windows.Media.Playback.MediaCommandEnablingRule]::Always
$manager.PreviousBehavior.EnablingRule = [Windows.Media.Playback.MediaCommandEnablingRule]::Always

# The delegates must outlive the statement that created them, so they are held
# in script scope; a collected delegate silently stops firing.
$script:handlers = @(
  $manager.add_NextReceived({ Write-CommandLog 'next' }),
  $manager.add_PreviousReceived({ Write-CommandLog 'previous' }),
  $manager.add_PlayReceived({ Write-CommandLog 'play' }),
  $manager.add_PauseReceived({ Write-CommandLog 'pause' })
)

if (-not $StartPaused) { $player.Play() }

# A MediaPlaybackItem's own display properties do not reach
# `TryGetMediaPropertiesAsync().Thumbnail` on this build; the session's
# DisplayUpdater is the surface SMTC actually reads, so publish the cover there
# too. Without this the probe honestly reports `hasArt:false`, which is a real
# state but not the one this fixture is meant to produce.
$updater = $player.SystemMediaTransportControls.DisplayUpdater
$updater.Type = [Windows.Media.MediaPlaybackType]::Music
$updater.MusicProperties.Title = 'Probe Tone'
$updater.MusicProperties.Artist = 'dsh-dynamic-hub'
$updater.MusicProperties.AlbumTitle = 'Verification'
$updater.Thumbnail = New-CoverReference -Path $png
$updater.Update()

Start-Sleep -Milliseconds 900
[Console]::Out.WriteLine((ConvertTo-Json -InputObject ([ordered]@{
        ok      = $true
        fixture = 'media-fixture'
        title   = 'Probe Tone'
        artist  = 'dsh-dynamic-hub'
        album   = 'Verification'
        cover   = $png
        log     = $log
        seconds = $ToneSeconds
        paused  = [bool]$StartPaused
      }) -Compress))
[Console]::Out.Flush()

$deadline = (Get-Date).AddSeconds($Seconds)
while ((Get-Date) -lt $deadline) {
  if ($UntilStdinCloses) {
    $line = [Console]::In.ReadLine()
    if ($null -eq $line) { break }
  } else {
    Start-Sleep -Milliseconds 500
  }
}
$player.Dispose()
exit 0

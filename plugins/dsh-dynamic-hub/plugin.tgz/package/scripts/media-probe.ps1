<#
  dsh-dynamic-hub — Windows media bridge.

  Windows PowerShell 5.1 ONLY. PowerShell 7 has no WinRT projection, so the
  `[Windows.Media.Control.*,ContentType=WindowsRuntime]` type literals below
  resolve to nothing under `pwsh`. The host half invokes this file through
  `C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe` explicitly.

  Two ways to run it:

    * one shot   — `-Mode status|art|control|volume` prints one JSON object.
    * worker     — `-Mode worker` reads one JSON request per line on stdin and
                   writes exactly one JSON response line per request on stdout.
                   The host keeps one worker alive for the life of the poll
                   window, which is what keeps a 1 Hz poll cheap: process start
                   plus the WinRT/COM setup is paid once, not once per second.

  The worker also exits on its own when stdin reaches EOF. That is the orphan
  guard: if the DSH host dies without disposing this plugin the pipe closes and
  this process leaves with it. `-IdleExitMs` adds a second, time-based guard.

  Everything it prints is measured, never invented: a value it cannot read is
  reported as `null` together with an `error` string.
#>
[CmdletBinding()]
param(
  [ValidateSet('status', 'art', 'control', 'volume', 'worker')]
  [string]$Mode = 'status',
  [ValidateSet('playpause', 'play', 'pause', 'stop', 'next', 'previous')]
  [string]$Action = 'playpause',
  [double]$Level = -1,
  [int]$MuteState = -1,
  [string]$OutFile = '',
  [int]$TimeoutMs = 4000,
  [int]$IdleExitMs = 600000
)

$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = New-Object System.Text.UTF8Encoding $false
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false

Add-Type -AssemblyName System.Runtime.WindowsRuntime

# --- WinRT ---------------------------------------------------------------
# Loading these type literals is what makes the projection available; PS 5.1
# resolves `ContentType=WindowsRuntime` at parse/load time, not by reflection.
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]

$script:AsTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and
    $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
  })[0]

if ($null -eq $script:AsTaskGeneric) {
  throw 'System.Runtime.WindowsRuntime does not expose AsTask(IAsyncOperation<T>)'
}

<#
  Await one WinRT IAsyncOperation.

  `.Wait($ms)` is the whole reason this probe cannot hang the host: the wait is
  bounded, and a timeout throws instead of blocking forever. Awaiting directly
  in PowerShell 5.1 is otherwise impossible — the projection has no
  GetAwaiter() that script can bind to.
#>
function Await-WinRt {
  param(
    [Parameter(Mandatory = $true)] $Operation,
    [Parameter(Mandatory = $true)] [Type] $ResultType,
    [int] $WaitMs = 4000
  )
  $task = $script:AsTaskGeneric.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
  if (-not $task.Wait($WaitMs)) {
    throw "WinRT operation timed out after ${WaitMs}ms"
  }
  return $task.Result
}

# `[math]::Min(1, x)` binds to the Int32 overload when the literal is an int, so
# 0.42 truncates to 0 and every fractional volume reads back as silence. The
# literals here must stay doubles.
function Limit-Unit {
  param([double] $Value)
  if ($Value -lt 0.0) { return 0.0 }
  if ($Value -gt 1.0) { return 1.0 }
  return $Value
}

function Get-SessionManager {
  return Await-WinRt -Operation ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) `
    -ResultType ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]) -WaitMs $TimeoutMs
}

<#
  Read the current SMTC session.

  `active` is deliberately narrow: Playing / Paused / Changing. A session that
  exists but is Closed, Stopped or merely Opened has nothing on screen, which is
  the case the widget shows the clock face for.
#>
function Get-MediaStatus {
  $manager = Get-SessionManager
  $session = $manager.GetCurrentSession()
  if ($null -eq $session) {
    return [ordered]@{ active = $false; reason = 'no-session'; status = 'None' }
  }

  $properties = $null
  $propertiesError = $null
  try {
    $properties = Await-WinRt -Operation ($session.TryGetMediaPropertiesAsync()) `
      -ResultType ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]) -WaitMs $TimeoutMs
  } catch {
    $propertiesError = $_.Exception.Message
  }

  $playback = $session.GetPlaybackInfo()
  $timeline = $session.GetTimelineProperties()
  $status = [string]$playback.PlaybackStatus
  $controls = $playback.Controls

  $can = {
    param($value)
    if ($null -eq $value) { return $false }
    return [bool]$value
  }

  $title = $null; $artist = $null; $album = $null; $hasArt = $false
  if ($null -ne $properties) {
    $title = [string]$properties.Title
    $artist = [string]$properties.Artist
    $album = [string]$properties.AlbumTitle
    $hasArt = ($null -ne $properties.Thumbnail)
    if ([string]::IsNullOrWhiteSpace($title)) { $title = $null }
    if ([string]::IsNullOrWhiteSpace($artist)) { $artist = $null }
    if ([string]::IsNullOrWhiteSpace($album)) { $album = $null }
  }

  $duration = [double]$timeline.EndTime.TotalSeconds
  $position = [double]$timeline.Position.TotalSeconds
  if ($duration -le 0) { $duration = $null }

  return [ordered]@{
    active     = ($status -eq 'Playing' -or $status -eq 'Paused' -or $status -eq 'Changing')
    reason     = 'session'
    status     = $status
    title      = $title
    artist     = $artist
    album      = $album
    app        = [string]$session.SourceAppUserModelId
    hasArt     = $hasArt
    position   = [math]::Round([math]::Max(0, $position), 2)
    duration   = if ($null -eq $duration) { $null } else { [math]::Round($duration, 2) }
    canPlay    = & $can $controls.IsPlayEnabled
    canPause   = & $can $controls.IsPauseEnabled
    canNext    = & $can $controls.IsNextEnabled
    canPrevious = & $can $controls.IsPreviousEnabled
    error      = $propertiesError
  }
}

# --- Core Audio (default output endpoint volume) -------------------------
# Compiled on first use, then cached for the life of the worker. Add-Type is
# roughly a third of a second, which is why it must not run on every poll.
$script:AudioReady = $null
$script:AudioError = $null
$script:VolumeCache = $null
$script:VolumeCacheAt = [datetime]::MinValue

$audioSource = @'
using System;
using System.Runtime.InteropServices;

namespace DshDynamicHub
{
    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IAudioEndpointVolume
    {
        int RegisterControlChangeNotify(IntPtr pNotify);
        int UnregisterControlChangeNotify(IntPtr pNotify);
        int GetChannelCount(out uint pnChannelCount);
        int SetMasterVolumeLevel(float fLevelDB, ref Guid pguidEventContext);
        int SetMasterVolumeLevelScalar(float fLevel, ref Guid pguidEventContext);
        int GetMasterVolumeLevel(out float pfLevelDB);
        int GetMasterVolumeLevelScalar(out float pfLevel);
        int SetChannelVolumeLevel(uint nChannel, float fLevelDB, ref Guid pguidEventContext);
        int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, ref Guid pguidEventContext);
        int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
        int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, ref Guid pguidEventContext);
        int GetMute([MarshalAs(UnmanagedType.Bool)] out bool pbMute);
        int GetVolumeStepInfo(out uint pnStep, out uint pnStepCount);
        int VolumeStepUp(ref Guid pguidEventContext);
        int VolumeStepDown(ref Guid pguidEventContext);
        int QueryHardwareSupport(out uint pdwHardwareSupportMask);
        int GetVolumeRange(out float pfMin, out float pfMax, out float pfIncrement);
    }

    [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMMDevice
    {
        int Activate(ref Guid iid, int dwClsCtx, IntPtr pActivationParams,
                     [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
    }

    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMMDeviceEnumerator
    {
        int EnumAudioEndpoints(int dataFlow, int dwStateMask, out IntPtr ppDevices);
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice ppEndpoint);
    }

    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    public class MMDeviceEnumeratorComObject
    {
    }

    public static class EndpointVolume
    {
        private const int CLSCTX_ALL = 23;
        private const int eRender = 0;
        private const int eMultimedia = 1;

        public static IAudioEndpointVolume Endpoint()
        {
            IMMDeviceEnumerator enumerator = (IMMDeviceEnumerator)(new MMDeviceEnumeratorComObject());
            IMMDevice device;
            Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(eRender, eMultimedia, out device));
            Guid iid = typeof(IAudioEndpointVolume).GUID;
            object iface;
            Marshal.ThrowExceptionForHR(device.Activate(ref iid, CLSCTX_ALL, IntPtr.Zero, out iface));
            return (IAudioEndpointVolume)iface;
        }

        public static float GetLevel()
        {
            IAudioEndpointVolume endpoint = Endpoint();
            float level;
            Marshal.ThrowExceptionForHR(endpoint.GetMasterVolumeLevelScalar(out level));
            return level;
        }

        public static bool GetMute()
        {
            IAudioEndpointVolume endpoint = Endpoint();
            bool mute;
            Marshal.ThrowExceptionForHR(endpoint.GetMute(out mute));
            return mute;
        }

        public static int GetChannelCount()
        {
            IAudioEndpointVolume endpoint = Endpoint();
            uint count;
            Marshal.ThrowExceptionForHR(endpoint.GetChannelCount(out count));
            return (int)count;
        }

        public static int GetStepCount()
        {
            IAudioEndpointVolume endpoint = Endpoint();
            uint step;
            uint count;
            Marshal.ThrowExceptionForHR(endpoint.GetVolumeStepInfo(out step, out count));
            return (int)count;
        }

        public static void StepUp()
        {
            IAudioEndpointVolume endpoint = Endpoint();
            Guid context = Guid.Empty;
            Marshal.ThrowExceptionForHR(endpoint.VolumeStepUp(ref context));
        }

        public static void StepDown()
        {
            IAudioEndpointVolume endpoint = Endpoint();
            Guid context = Guid.Empty;
            Marshal.ThrowExceptionForHR(endpoint.VolumeStepDown(ref context));
        }

        public static void SetLevel(float level)
        {
            IAudioEndpointVolume endpoint = Endpoint();
            Guid context = Guid.Empty;
            Marshal.ThrowExceptionForHR(endpoint.SetMasterVolumeLevelScalar(level, ref context));
        }

        public static void SetMute(bool mute)
        {
            IAudioEndpointVolume endpoint = Endpoint();
            Guid context = Guid.Empty;
            Marshal.ThrowExceptionForHR(endpoint.SetMute(mute, ref context));
        }
    }
}
'@

function Initialize-Audio {
  if ($null -ne $script:AudioReady) { return $script:AudioReady }
  try {
    Add-Type -TypeDefinition $audioSource -Language CSharp | Out-Null
    $script:AudioReady = $true
  } catch {
    $script:AudioReady = $false
    $script:AudioError = $_.Exception.Message
  }
  return $script:AudioReady
}

function Get-VolumeSnapshot {
  param([int] $MaxAgeMs = 8000, [switch] $Force)
  $age = ([datetime]::UtcNow - $script:VolumeCacheAt).TotalMilliseconds
  if (-not $Force -and $null -ne $script:VolumeCache -and $age -lt $MaxAgeMs) {
    return $script:VolumeCache
  }
  if (-not (Initialize-Audio)) {
    $script:VolumeCache = [ordered]@{ available = $false; level = $null; mute = $null; steps = 0; step = $null; channels = $null; error = $script:AudioError }
    $script:VolumeCacheAt = [datetime]::UtcNow
    return $script:VolumeCache
  }
  try {
    $level = [double][DshDynamicHub.EndpointVolume]::GetLevel()
    $mute = [bool][DshDynamicHub.EndpointVolume]::GetMute()
    $steps = [int][DshDynamicHub.EndpointVolume]::GetStepCount()
    $channels = [int][DshDynamicHub.EndpointVolume]::GetChannelCount()
    $script:VolumeCache = [ordered]@{
      available = $true
      level     = [math]::Round([math]::Min(1, [math]::Max(0, $level)), 4)
      mute      = $mute
      # `steps <= 1` means the endpoint quantizes: every scalar write lands on
      # 0 or 1 regardless of the value sent (observed on this machine's default
      # output). The UI must offer +- / mute instead of a slider there, and the
      # host must not pretend a continuous write took effect.
      steps     = $steps
      continuous = ($steps -gt 1)
      channels  = $channels
      error     = $null
    }
  } catch {
    $script:VolumeCache = [ordered]@{ available = $false; level = $null; mute = $null; steps = 0; continuous = $false; channels = $null; error = $_.Exception.Message }
  }
  $script:VolumeCacheAt = [datetime]::UtcNow
  return $script:VolumeCache
}

# --- album art -----------------------------------------------------------
function Get-MediaArt {
  param([string] $Path)
  if ([string]::IsNullOrWhiteSpace($Path)) { throw 'art requires -OutFile' }
  $manager = Get-SessionManager
  $session = $manager.GetCurrentSession()
  if ($null -eq $session) { return [ordered]@{ ok = $false; error = 'no-session' } }
  $properties = Await-WinRt -Operation ($session.TryGetMediaPropertiesAsync()) `
    -ResultType ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]) -WaitMs $TimeoutMs
  if ($null -eq $properties.Thumbnail) { return [ordered]@{ ok = $false; error = 'no-thumbnail' } }

  $stream = Await-WinRt -Operation ($properties.Thumbnail.OpenReadAsync()) `
    -ResultType ([Windows.Storage.Streams.IRandomAccessStreamWithContentType]) -WaitMs $TimeoutMs
  $contentType = [string]$stream.ContentType
  $source = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($stream)
  $target = [System.IO.File]::Create($Path)
  try {
    $buffer = New-Object byte[] 81920
    $total = 0
    while (($count = $source.Read($buffer, 0, $buffer.Length)) -gt 0) {
      $total += $count
      if ($total -gt 1048576) { throw 'art-size-limit' }
      $target.Write($buffer, 0, $count)
    }
  } finally {
    $target.Dispose()
    $source.Dispose()
    $stream.Dispose()
  }
  return [ordered]@{
    ok      = $true
    bytes   = (Get-Item -LiteralPath $Path).Length
    mime    = if ([string]::IsNullOrWhiteSpace($contentType)) { 'image/png' } else { $contentType }
    # The caller compares this with the status it asked for, so art that raced a
    # track change is discarded instead of shown against the wrong title.
    title   = if ([string]::IsNullOrWhiteSpace([string]$properties.Title)) { $null } else { [string]$properties.Title }
    artist  = if ([string]::IsNullOrWhiteSpace([string]$properties.Artist)) { $null } else { [string]$properties.Artist }
  }
}

# --- transport control ---------------------------------------------------
function Invoke-Control {
  param([string] $Which)
  $manager = Get-SessionManager
  $session = $manager.GetCurrentSession()
  if ($null -eq $session) { return [ordered]@{ ok = $false; error = 'no-session' } }
  $operation = switch ($Which) {
    'playpause' { $session.TryTogglePlayPauseAsync() }
    'play' { $session.TryPlayAsync() }
    'pause' { $session.TryPauseAsync() }
    'stop' { $session.TryStopAsync() }
    'next' { $session.TrySkipNextAsync() }
    'previous' { $session.TrySkipPreviousAsync() }
    default { return [ordered]@{ ok = $false; error = "unknown action: $Which" } }
  }
  $accepted = Await-WinRt -Operation $operation -ResultType ([bool]) -WaitMs $TimeoutMs
  if (-not [bool]$accepted) {
    return [ordered]@{ ok = $false; error = 'control-not-accepted'; action = $Which }
  }
  return [ordered]@{ ok = $true; action = $Which; status = (Get-MediaStatus) }
}

# --- request dispatch ----------------------------------------------------
function Invoke-Request {
  param([hashtable] $Request)
  $op = [string]$Request.op
  switch ($op) {
    'seek' {
      $position = [double]$Request.position
      if ([double]::IsNaN($position) -or [double]::IsInfinity($position) -or $position -lt 0) { return [ordered]@{ ok = $false; error = 'invalid-position' } }
      $manager = Get-SessionManager
      $session = $manager.GetCurrentSession()
      if ($null -eq $session) { return [ordered]@{ ok = $false; error = 'no-session' } }
      $accepted = Await-WinRt -Operation ($session.TryChangePlaybackPositionAsync([long][math]::Round($position * 10000000))) -ResultType ([bool]) -WaitMs $TimeoutMs
      return [ordered]@{ ok = [bool]$accepted; position = $position; status = (Get-MediaStatus) }
    }
    'ping' { return [ordered]@{ ok = $true; pong = $true } }
    'status' {
      $media = Get-MediaStatus
      $volume = Get-VolumeSnapshot
      return [ordered]@{ ok = $true; media = $media; volume = $volume }
    }
    'art' {
      $result = Get-MediaArt -Path ([string]$Request.path)
      return [ordered]@{ ok = [bool]$result.ok; art = $result }
    }
    'control' {
      $result = Invoke-Control -Which ([string]$Request.action)
      return [ordered]@{ ok = [bool]$result.ok; control = $result }
    }
    'volume' {
      Initialize-Audio | Out-Null
      if (-not $script:AudioReady) {
        return [ordered]@{ ok = $false; error = 'audio-endpoint-unavailable'; detail = $script:AudioError }
      }
      try {
        if ($Request.ContainsKey('level') -and $null -ne $Request.level) {
          $level = [double]$Request.level
          [DshDynamicHub.EndpointVolume]::SetLevel([float]([math]::Min(1, [math]::Max(0, $level))))
        }
        if ($Request.ContainsKey('mute') -and $null -ne $Request.mute) {
          [DshDynamicHub.EndpointVolume]::SetMute([bool]$Request.mute)
        }
        if ($Request.ContainsKey('step') -and [string]$Request.step -eq 'up') { [DshDynamicHub.EndpointVolume]::StepUp() }
        if ($Request.ContainsKey('step') -and [string]$Request.step -eq 'down') { [DshDynamicHub.EndpointVolume]::StepDown() }
      } catch {
        return [ordered]@{ ok = $false; error = 'volume-write-failed'; detail = $_.Exception.Message }
      }
      $snapshot = Get-VolumeSnapshot -Force
      return [ordered]@{ ok = [bool]$snapshot.available; volume = $snapshot }
    }
    default { return [ordered]@{ ok = $false; error = "unknown op: $op" } }
  }
}

function Write-Line {
  param([string] $Text)
  [Console]::Out.WriteLine($Text)
  [Console]::Out.Flush()
}

function ConvertTo-Response {
  param($Id, $Payload)
  $envelope = [ordered]@{ id = $Id }
  foreach ($key in $Payload.Keys) { $envelope[$key] = $Payload[$key] }
  return (ConvertTo-Json -InputObject $envelope -Compress -Depth 6)
}

if ($Mode -ne 'worker') {
  try {
    switch ($Mode) {
      'status' {
        $payload = Invoke-Request -Request @{ op = 'status' }
        Write-Line (ConvertTo-Json -InputObject $payload -Compress -Depth 6)
      }
      'art' {
        $payload = Invoke-Request -Request @{ op = 'art'; path = $OutFile }
        Write-Line (ConvertTo-Json -InputObject $payload -Compress -Depth 6)
      }
      'control' {
        $payload = Invoke-Request -Request @{ op = 'control'; action = $Action }
        Write-Line (ConvertTo-Json -InputObject $payload -Compress -Depth 6)
      }
      'volume' {
        $request = @{ op = 'volume' }
        if ($Level -ge 0) { $request.level = $Level }
        if ($MuteState -ge 0) { $request.mute = ($MuteState -eq 1) }
        $payload = Invoke-Request -Request $request
        Write-Line (ConvertTo-Json -InputObject $payload -Compress -Depth 6)
      }
    }
  } catch {
    Write-Line (ConvertTo-Json -InputObject ([ordered]@{ ok = $false; error = $_.Exception.Message }) -Compress -Depth 6)
  }
  exit 0
}

# --- worker loop ---------------------------------------------------------
$deadline = [datetime]::UtcNow.AddMilliseconds($IdleExitMs)
while ($true) {
  $line = [Console]::In.ReadLine()
  if ($null -eq $line) { break }            # stdin closed => DSH host is gone
  if ([string]::IsNullOrWhiteSpace($line)) { continue }
  if (([datetime]::UtcNow) -gt $deadline) { break }

  $id = $null
  $payload = $null
  try {
    $request = ConvertFrom-Json -InputObject $line
    $id = $request.id
    if ([string]$request.op -eq 'quit') {
      Write-Line (ConvertTo-Response -Id $id -Payload ([ordered]@{ ok = $true; bye = $true }))
      break
    }
    $table = @{}
    foreach ($property in $request.PSObject.Properties) { $table[$property.Name] = $property.Value }
    $payload = Invoke-Request -Request $table
  } catch {
    $payload = [ordered]@{ ok = $false; error = $_.Exception.Message }
  }
  $deadline = [datetime]::UtcNow.AddMilliseconds($IdleExitMs)
  Write-Line (ConvertTo-Response -Id $id -Payload $payload)
}
exit 0

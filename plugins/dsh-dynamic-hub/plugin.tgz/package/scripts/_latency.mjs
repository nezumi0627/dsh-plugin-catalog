// Throwaway: measure worker round-trip latency and exercise every op.
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

const here = dirname(fileURLToPath(import.meta.url));
const script = join(here, '..', 'scripts', 'media-probe.ps1');
const exe = 'C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe';

const t0 = Date.now();
const child = spawn(exe, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-Mode', 'worker'], {
  stdio: ['pipe', 'pipe', 'pipe'],
  windowsHide: true,
});
let buffer = '';
const waiting = new Map();
child.stdout.setEncoding('utf8');
child.stdout.on('data', (chunk) => {
  buffer += chunk;
  let index;
  while ((index = buffer.indexOf('\n')) >= 0) {
    const line = buffer.slice(0, index).trim();
    buffer = buffer.slice(index + 1);
    if (!line) continue;
    const parsed = JSON.parse(line);
    const resolve = waiting.get(parsed.id);
    waiting.delete(parsed.id);
    resolve?.(parsed);
  }
});
child.stderr.setEncoding('utf8');
child.stderr.on('data', (chunk) => process.stderr.write(`[err] ${chunk}`));

let nextId = 1;
function call(op, extra = {}, timeoutMs = 8000) {
  const id = nextId++;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      waiting.delete(id);
      reject(new Error(`timeout on ${op}`));
    }, timeoutMs);
    waiting.set(id, (value) => {
      clearTimeout(timer);
      resolve(value);
    });
    child.stdin.write(`${JSON.stringify({ id, op, ...extra })}\n`);
  });
}

const first = await call('status');
console.log(`COLD worker start + first status: ${Date.now() - t0}ms`);
console.log(`  media=${JSON.stringify(first.media)}`);
console.log(`  volume=${JSON.stringify(first.volume)}`);

const samples = [];
for (let i = 0; i < 10; i += 1) {
  const start = process.hrtime.bigint();
  await call('status');
  samples.push(Number(process.hrtime.bigint() - start) / 1e6);
}
samples.sort((a, b) => a - b);
console.log(`WARM status x10: min=${samples[0].toFixed(1)}ms median=${samples[5].toFixed(1)}ms max=${samples[9].toFixed(1)}ms`);

const before = (await call('volume')).volume;
console.log(`volume before: ${JSON.stringify(before)}`);
const tSet = Date.now();
const set = await call('volume', { level: 0.42 });
console.log(`volume set 0.42: ${Date.now() - tSet}ms -> ${JSON.stringify(set.volume)}`);
const tMute = Date.now();
const muted = await call('volume', { mute: true });
console.log(`mute on: ${Date.now() - tMute}ms -> ${JSON.stringify(muted.volume)}`);
await call('volume', { mute: false, level: before.level });
console.log(`restored to ${JSON.stringify((await call('volume')).volume)}`);

for (const action of ['next', 'previous', 'pause', 'play']) {
  const start = process.hrtime.bigint();
  const value = await call('control', { action });
  const ms = Number(process.hrtime.bigint() - start) / 1e6;
  console.log(`control ${action.padEnd(9)} ${ms.toFixed(1)}ms ok=${value.ok} status=${value.control?.status?.status}`);
}

await call('quit');
await new Promise((r) => child.on('exit', r));
console.log('worker exited cleanly');

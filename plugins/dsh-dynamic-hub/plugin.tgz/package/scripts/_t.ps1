$ErrorActionPreference = 'Continue'
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Media.Playback.MediaPlaybackList, Windows.Media.Playback, ContentType = WindowsRuntime]
$null = [Windows.Media.Playback.MediaPlaybackItem, Windows.Media.Playback, ContentType = WindowsRuntime]
$null = [Windows.Media.Core.MediaSource, Windows.Media.Core, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.RandomAccessStreamReference, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
    $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]

# --- IVector<T> via the metadata name `Append` -----------------------------
$wav = Join-Path $env:TEMP 'dsh-dynamic-hub-fixture\Probe-Tone.wav'
$png = Join-Path $env:TEMP 'dsh-dynamic-hub-fixture\Probe-Tone.png'
$list = [Windows.Media.Playback.MediaPlaybackList]::new()
try {
  $source = [Windows.Media.Core.MediaSource]::CreateFromUri([uri]$wav)
  $item = [Windows.Media.Playback.MediaPlaybackItem]::new($source)
  $list.Items.Append($item)
  Write-Host ("Items.Append -> OK, count = {0}" -f $list.Items.Count)
} catch {
  Write-Host ("Items.Append -> FAILED: {0}" -f $_.Exception.Message)
}

# --- why does OpenReadAsync on a CreateFromUri reference fail? ------------
$reference = [Windows.Storage.Streams.RandomAccessStreamReference]::CreateFromUri([uri]$png)
$task = $asTaskGeneric.MakeGenericMethod([Windows.Storage.Streams.IRandomAccessStreamWithContentType]).Invoke(
  $null, @($reference.OpenReadAsync()))
try {
  $stream = $task.GetAwaiter().GetResult()
  Write-Host ("in-memory open OK type={0} size={1}" -f $stream.ContentType, $stream.Size)
} catch {
  $inner = $_.Exception
  while ($inner.InnerException) { $inner = $inner.InnerException }
  Write-Host ("open FAILED: {0} :: {1}" -f $inner.GetType().FullName, $inner.Message)
  Write-Host ("hresult: 0x{0:X8}" -f $inner.HResult)
}

# --- open the PNG through a plain file stream instead ---------------------
$fileStream = [System.IO.File]::OpenRead($png)
$winStream = [System.IO.WindowsRuntimeStreamExtensions]::AsRandomAccessStream($fileStream)
Write-Host ("AsRandomAccessStream -> {0}" -f $winStream.GetType().FullName)
$read = [System.IO.WindowsRuntimeStreamExtensions]::AsStreamForRead($winStream)
$target = Join-Path $env:TEMP 'dsh-dynamic-hub-fixture\art-extract-check.png'
$out = [System.IO.File]::Create($target)
try { $read.CopyTo($out, 81920) } finally { $out.Dispose(); $read.Dispose(); $winStream.Dispose(); $fileStream.Dispose() }
Write-Host ("extracted {0} bytes (source {1} bytes) -> {2}" -f (Get-Item $target).Length, (Get-Item $png).Length, $target)

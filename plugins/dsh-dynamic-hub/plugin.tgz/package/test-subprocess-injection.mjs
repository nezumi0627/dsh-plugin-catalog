import assert from 'node:assert/strict';
import { apply } from './index.js';

const disposers = [];
const registrations = [];
const subprocess = {
  resolveExecutable: async () => 'powershell.exe',
  spawn: () => { throw new Error('worker should not start during plugin activation'); },
};
const ctx = {
  inject(services, callback) {
    if (services.includes('subprocess')) callback({ subprocess });
    if (services.includes('webServer')) callback({
      webServer: { register(route) { registrations.push(route); return () => {}; } },
      effect(setup) { disposers.push(setup()); },
      on() {},
      get() { return { isAuthenticated: () => true }; },
    });
  },
  effect(setup) { disposers.push(setup()); },
  logger: { info() {} },
  get subprocess() {
    throw new Error('cannot get property "subprocess" without inject at new apply');
  },
};

assert.doesNotThrow(() => apply(ctx), 'Host services must only be read from their injected context');
assert.deepEqual(registrations.map((route) => route.path), [
  '/local/dynamic-hub',
  '/local/dynamic-hub-token',
  '/local/dynamic-hub-art',
]);
for (const dispose of disposers.reverse()) dispose?.();
console.log('dynamic hub registers routes and worker using injected subprocess service');

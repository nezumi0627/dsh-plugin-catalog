# Verification report

Scope limited to `dsh-dynamic-hub/`; no dependency, profile, or other package changes. No standalone task brief or recon file was present in this package; prior `REPORT.md` documented the relevant gaps and runtime constraints.

## Changes made

- Added a bounded WinRT SMTC seek operation using `TryChangePlaybackPositionAsync`, awaiting its `IAsyncOperation<bool>` with the existing timeout and reporting actual acceptance/state.
- Added authenticated `GET /local/dynamic-hub-art`. It requests thumbnail bytes through the existing worker, transfers only files up to 1 MiB, returns the thumbnail MIME type, and removes its temporary file. The client fetches through the token header and displays a revocable object URL.
- Removed the default-output endpoint volume slider and action from the media controls; no device volume is represented as session volume.
- Expanded host route and rendered-media tests for status/method/auth/body errors, seek/art presentation, and absence of volume controls.

## Commands and observed output

Command:

```text
node --check index.js; node --check client.js; node test-host.mjs; node test-client.mjs; node test-render.mjs
```

Observed: exit 0; syntax checks emitted no output; remaining output:

```text
ok route status/method/auth fences, bootstrap, disposer
ok module loading, service contract, memoized formatters, uptime formatting
ok reduced-motion, directional slides, seek/art render, no device-volume control, uptime
```

Live attempt using the existing worker only:

```powershell
$req = '{"id":1,"op":"status"}'; $req | powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File scripts\media-probe.ps1 -Mode worker
```

Observed exact response:

```json
{"id":1,"ok":true,"media":{"active":false,"reason":"no-session","status":"None"},"volume":{"available":true,"level":1,"mute":false,"steps":51,"continuous":true,"channels":2,"error":null}}
```

The WinRT projection and worker ran successfully, but no current SMTC media session was available. A direct worker seek attempt (`{"id":2,"op":"seek","position":5}`) returned exactly `{"id":2,"ok":false,"error":"no-session"}`. Therefore live seek acceptance and thumbnail retrieval are unverified; no media behavior is claimed from this attempt. The measured `volume` data is the default output endpoint and is intentionally not exposed as a media-session control. Art transfer size cap and client rendering are covered by implementation/test evidence, not a live art response.

## Shared status-widget store contract follow-up

The clock/media stores now return stable `useSyncExternalStore` snapshots (clock string; media snapshot object) and notify subscribers after updates. The shared `statusWidgets` consumer subscribes to descriptor stores and passes each snapshot as `render({value})`; Dynamic Hub descriptors consume those values and the local clock readout uses `getSnapshot()` rather than internal mutable fields. Current client contract tests assert descriptor snapshot values and stable identity. Fresh verification from this follow-up: syntax checks exit 0; host route test, client descriptor/store test, and render test each emit their `ok ...` success line (all commands exit 0).

## Seek sample validation (2026-10-12)

The playback seek range previously accepted malformed media timing (`position:null`, `duration:0`) and appeared as an enabled control at zero. A new render regression failed on the enabled seek control. Seek is now disabled unless both position and positive duration are finite; the accessible value reports `Unavailable` otherwise. Fresh syntax, host, client, and render checks passed.

## Host service injection fix (2026-10-12)

The live plugin warning reported `cannot get property "subprocess" without inject at new apply`. `apply()` read `ctx.subprocess` directly before its empty `ctx.inject(['subprocess'], ...)` call. Added a regression harness whose context throws on direct access; it failed on the original code at `index.js:167`. The plugin now obtains the provider only from the injected context, and media requests degrade to `not-supported` if no provider is present. The empty late injection was removed.

Fresh checks:

```text
node --check dsh-dynamic-hub/index.js — passed
node dsh-dynamic-hub/test-subprocess-injection.mjs — dynamic hub registers routes and worker using injected subprocess service
node dsh-dynamic-hub/test-host.mjs — ok route status/method/auth fences, bootstrap, disposer
node dsh-dynamic-hub/test-worker.mjs — ok worker lifecycle: transient spawn retries, abrupt exit drains requests, and subsequent calls recover
```

The plugin is linked in the active profile. DSH was not restarted; live media controls remain for the next launch to verify.

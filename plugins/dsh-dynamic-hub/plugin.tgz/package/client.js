window.__ModuleLoader__.load({
  id: '@local/dsh-dynamic-hub',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useEffect, useState, useRef } = React;
    const ID = '@local/dsh-dynamic-hub';
    const NS = 'dshDynamicHub';
    const css = `
      .ddh{display:flex;align-items:center;gap:8px;min-width:0;color:var(--dsw-alias-label-primary);font:var(--dsw-font-xxs-12);font-variant-numeric:tabular-nums}
      .ddh-readout{display:grid;gap:2px;min-width:0}.ddh-sub{color:var(--dsw-alias-label-tertiary)}
      .ddh-media{display:flex;align-items:center;gap:8px;min-width:0;overflow:hidden}.ddh-track{display:grid;gap:2px;min-width:0;overflow:hidden}.ddh-title{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .ddh-art{width:28px;height:28px;object-fit:cover;border-radius:4px;flex:none}.ddh-controls{display:flex;align-items:center;gap:4px;flex:none}
      .ddh-volume,.ddh-progress{width:72px;accent-color:var(--dsw-alias-state-business-primary)}
      .ddh button{color:inherit;background:transparent;border:0;cursor:pointer;-webkit-app-region:no-drag}.ddh button:disabled{opacity:.45;cursor:default}
      .ddh-media.slide-left{animation:ddh-slide-left 155ms ease-out}.ddh-media.slide-right{animation:ddh-slide-right 155ms ease-out}
      @keyframes ddh-slide-left{from{opacity:.65;transform:translateX(10px)}to{opacity:1;transform:translateX(0)}}
      @keyframes ddh-slide-right{from{opacity:.65;transform:translateX(-10px)}to{opacity:1;transform:translateX(0)}}
      @media(prefers-reduced-motion:reduce){.ddh-media{animation:none!important}}
    `;
    const style = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = css;
      document.head.append(element);
      return element;
    })();

    function createStore(initial) {
      let value = initial;
      const listeners = new Set();
      return {
        getSnapshot: () => value,
        subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); },
        set(next) { value = next; for (const listener of listeners) listener(); },
      };
    }
    const mediaStore = createStore({ active: false });

    function appVolumeFor(sessions, appId) {
      if (typeof appId !== 'string' || !appId || !Array.isArray(sessions)) return null;
      const normalizedAppId = appId.toLowerCase();
      const matching = sessions.filter((session) => typeof session?.appId === 'string' && session.appId.toLowerCase() === normalizedAppId && session.supported === true && Number.isFinite(session.volume));
      if (!matching.length) return null;
      const first = matching[0].volume;
      if (matching.some((session) => session.volume !== first)) return null;
      return Math.min(100, Math.max(0, first)) / 100;
    }

    function formatUptime(total) {
      const days = Math.floor(total / 86400);
      const hours = Math.floor(total % 86400 / 3600);
      const minutes = Math.floor(total % 3600 / 60);
      const seconds = total % 60;
      const pad = (value) => String(value).padStart(2, '0');
      return days ? `${days}d ${pad(hours)}:${pad(minutes)}:${pad(seconds)}` : `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
    }

    function Component() {
      const [snapshot, setSnapshot] = useState(null);
      const [slide, setSlide] = useState('');
      const [uptime, setUptime] = useState('UP —');
      const [compact, setCompact] = useState(false);
      const [artUrl, setArtUrl] = useState('');
      const [seekDraft, setSeekDraft] = useState(null);
      const [volumeDraft, setVolumeDraft] = useState(null);
      const [appVolume, setAppVolume] = useState(null);
      const slideTimer = useRef(null);

      useEffect(() => {
        let alive = true;
        let timer = null;
        let startedAt = window.__DSH_DYNAMIC_HUB__?.startedAt;

        const refresh = async () => {
          if (!alive || document.visibilityState === 'hidden') return;
          if (!startedAt) {
            try {
              const response = await fetch('/local/dynamic-hub-token', { cache: 'no-store' });
              const body = await response.json();
              startedAt = body.data?.startedAt;
              if (body.data?.path && body.data?.token) window.__DSH_DYNAMIC_HUB__ = body.data;
            } catch {}
          }

          const now = Date.now();
          const elapsed = startedAt ? formatUptime(Math.max(0, Math.floor((now - startedAt) / 1000))) : '—';
          setUptime(`UP ${elapsed}`);

          const bootstrap = window.__DSH_DYNAMIC_HUB__;
          if (bootstrap?.path && bootstrap?.token) {
            try {
              const response = await fetch(bootstrap.path, {
                headers: { 'x-dsh-dynamic-hub-token': bootstrap.token },
                cache: 'no-store',
              });
              if (response.status === 403) window.__DSH_DYNAMIC_HUB__ = null;
              else if (response.ok) {
                const body = await response.json();
                if (alive) {
                  setSnapshot(body.data);
                  mediaStore.set(body.data);
                }
              }
            } catch {}
          }
          if (alive && document.visibilityState !== 'hidden') timer = setTimeout(refresh, 1000);
        };

        const visibility = () => {
          if (document.visibilityState === 'hidden') {
            clearTimeout(timer);
            timer = null;
          } else if (timer === null) refresh();
        };
        document.addEventListener('visibilitychange', visibility);
        refresh();
        return () => {
          alive = false;
          clearTimeout(timer);
          document.removeEventListener('visibilitychange', visibility);
        };
      }, []);

      useEffect(() => {
        let live = true;
        let objectUrl = '';
        const bootstrap = window.__DSH_DYNAMIC_HUB__;
        if (snapshot?.hasArt && bootstrap?.token) {
          fetch('/local/dynamic-hub-art', {
            headers: { 'x-dsh-dynamic-hub-token': bootstrap.token },
            cache: 'no-store',
          }).then((response) => response.ok ? response.blob() : null).then((blob) => {
            if (blob && live) {
              objectUrl = URL.createObjectURL(blob);
              setArtUrl(objectUrl);
            }
          }).catch(() => {});
        } else {
          setArtUrl('');
        }
        return () => {
          live = false;
          if (objectUrl) URL.revokeObjectURL(objectUrl);
        };
      }, [snapshot?.title, snapshot?.artist, snapshot?.hasArt]);

      useEffect(() => {
        let alive = true;
        setAppVolume(null);
        const appId = snapshot?.active && typeof snapshot.app === 'string' ? snapshot.app : '';
        const mixer = window.__DSH_AUDIO_MIXER__;
        if (!appId || !mixer?.path || !mixer?.token) return () => { alive = false; };
        fetch(mixer.path, { headers: { 'x-dsh-audio-mixer-token': mixer.token }, cache: 'no-store' })
          .then((response) => response.ok ? response.json() : null)
          .then((body) => { if (alive && body?.ok) setAppVolume(appVolumeFor(body.data?.apps, appId)); })
          .catch(() => {});
        return () => { alive = false; };
      }, [snapshot?.active, snapshot?.app]);

      useEffect(() => () => clearTimeout(slideTimer.current), []);

      const act = async (action, extra = {}) => {
        const bootstrap = window.__DSH_DYNAMIC_HUB__;
        if (!bootstrap?.path || !bootstrap?.token) return;
        if (action === 'next' || action === 'prev') {
          setSlide(action === 'next' ? 'slide-left' : 'slide-right');
          clearTimeout(slideTimer.current);
          slideTimer.current = setTimeout(() => setSlide(''), 170);
        }
        if (action === 'volume') {
          const mixer = window.__DSH_AUDIO_MIXER__;
          const appId = snapshot?.app;
          if (!mixer?.path || !mixer?.token || typeof appId !== 'string' || !appId) return;
          try {
            const response = await fetch(mixer.path, {
              method: 'POST',
              headers: { 'content-type': 'application/json', 'x-dsh-audio-mixer-token': mixer.token },
              body: JSON.stringify({ action: 'set-app-id', params: { appId, volume: Math.round(extra.level * 100) } }),
              cache: 'no-store',
            });
            const result = await response.json();
            if (result?.ok) setAppVolume(appVolumeFor(result.data?.apps, appId));
          } catch {}
          return;
        }
        try {
          const response = await fetch(bootstrap.path, {
            method: 'POST',
            headers: { 'content-type': 'application/json', 'x-dsh-dynamic-hub-token': bootstrap.token },
            body: JSON.stringify({ action, ...extra }),
            cache: 'no-store',
          });
          const result = await response.json();
          if (action === 'volume' && result.data?.volume) {
            setSnapshot((previous) => previous ? { ...previous, volume: result.data.volume } : previous);
            setVolumeDraft(null);
          }
        } catch {}
      };

      const commitSeek = (event) => {
        const position = event?.currentTarget?.value == null ? seekDraft : Number(event.currentTarget.value);
        if (Number.isFinite(position)) act('seek', { position }).finally(() => setSeekDraft(null));
      };
      const commitVolume = (event) => {
        const level = event?.currentTarget?.value == null ? volumeDraft : Number(event.currentTarget.value);
        if (Number.isFinite(level)) act('volume', { level }).finally(() => setVolumeDraft(null));
      };

      const position = seekDraft ?? snapshot?.position;
      const duration = snapshot?.duration;
      const seekAvailable = Number.isFinite(position) && Number.isFinite(duration) && duration > 0;
      const volumeAvailable = typeof appVolume === 'number' && Number.isFinite(appVolume);
      const value = snapshot?.active
        ? h('div', { className: `ddh-media ${slide}` },
            artUrl && h('img', { className: 'ddh-art', src: artUrl, alt: '' }),
            h('div', { className: 'ddh-track' },
              h('strong', { className: 'ddh-title' }, snapshot.title || '—'),
              h('span', { className: 'ddh-sub' }, `${snapshot.artist || '—'} · ${snapshot.app || '—'}`)),
            !compact && h('div', { className: 'ddh-controls' },
              h('button', { type: 'button', disabled: snapshot.canPrevious === false, onClick: () => act('prev'), 'aria-label': 'Previous track' }, '⏮'),
              h('button', { type: 'button', disabled: snapshot.canPlay === false && snapshot.canPause === false, onClick: () => act('play-pause'), 'aria-label': snapshot.status === 'Playing' ? 'Pause' : 'Play' }, snapshot.status === 'Playing' ? '⏸' : '▶'),
              h('button', { type: 'button', disabled: snapshot.canNext === false, onClick: () => act('next'), 'aria-label': 'Next track' }, '⏭'),
              h('input', {
                className: 'ddh-progress', type: 'range', min: 0, max: seekAvailable ? duration : 0,
                value: seekAvailable ? Math.min(position, duration) : 0, disabled: !seekAvailable,
                'aria-valuetext': seekAvailable ? `${position} of ${duration} seconds` : 'Unavailable',
                onChange: (event) => setSeekDraft(Number(event.target.value)),
                onPointerUp: commitSeek, onKeyUp: commitSeek,
                'aria-label': 'Playback position',
              }),
              h('input', {
                className: 'ddh-volume', type: 'range', min: 0, max: 1, step: 0.01,
                value: volumeDraft ?? (volumeAvailable ? appVolume : 0),
                disabled: !volumeAvailable,
                'aria-valuetext': volumeAvailable ? `${Math.round((volumeDraft ?? appVolume) * 100)}% playback app` : 'Unavailable for this app',
                onChange: (event) => setVolumeDraft(Number(event.target.value)),
                onPointerUp: commitVolume, onKeyUp: commitVolume,
                'aria-label': 'Playback app volume',
              })))
        : h('div', { className: 'ddh-readout' },
            h('span', { className: 'ddh-sub' }, uptime),
            h('button', { type: 'button', onClick: () => setCompact(!compact), 'aria-label': 'Toggle compact display' }, compact ? '＋' : '−'));

      return h('div', { className: 'ddh', 'aria-label': 'Dynamic Hub' }, value);
    }

    function Widget() { return h(Component); }

    return {
      name: 'dsh-dynamic-hub',
      inject: ['slots', 'locale'],
      apply(ctx) {
        let missingLogged = false;
        ctx.effect(() => ctx.locale.register(NS, {
          ja: { media: 'メディア' },
          en: { media: 'Media' },
          zh: { media: '媒体' },
        }), 'dynamic-hub.locale');
        ctx.effect(() => {
          const service = ctx.get?.('statusWidgets');
          if (!service) {
            if (!missingLogged) {
              ctx.logger?.warn?.('[dynamic-hub] statusWidgets unavailable; widgets hidden');
              missingLogged = true;
            }
            return;
          }
          const dispose = service.register({
            id: 'dsh-dynamic-hub.main',
            title: 'Dynamic Hub',
            zone: 'top',
            order: 5,
            sizes: ['compact', 'standard', 'detailed'],
            render: () => h(Component),
          });
          return () => dispose?.();
        }, 'dynamic-hub.widgets');
        ctx.effect(() => () => style?.remove(), 'dynamic-hub.styles');
      },
      __test: { ID, NS, Widget, Component, formatUptime, appVolumeFor, css, mediaStore },
    };
  },
});

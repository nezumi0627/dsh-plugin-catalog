# dsh-dynamic-hub

Uptime and Windows media-session widget package. The system status panel owns the only wall clock. This package requires the optional `statusWidgets` client service to display media controls; if absent, the client logs once and stays hidden. Host token route: `GET /local/dynamic-hub-token`; authenticated data route: `GET/POST /local/dynamic-hub`.

The included and packaged media probe uses Windows PowerShell 5.1 and WinRT `GlobalSystemMediaTransportControlsSessionManager`, not synthetic session data. Transport commands wait for WinRT acceptance and report rejected commands. Playback volume uses the audio-mixer route and matches Windows AppUserModelId values; if Windows cannot identify a matching controllable audio session, the slider is disabled instead of changing system-wide volume. Its single JSONL worker drains pending requests on failure, uses bounded restart backoff, and is disposed with the plugin; PowerShell 7 is not supported for this projection. Media operations depend on host subprocess support; the status panel clock remains available if this projection is unavailable.

Run checks from this directory with `node --check index.js`, `node --check client.js`, `node test-host.mjs`, `node test-client.mjs`, and `node test-render.mjs`.

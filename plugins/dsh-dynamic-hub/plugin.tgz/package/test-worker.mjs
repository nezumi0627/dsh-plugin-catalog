import assert from 'node:assert/strict';
import { PassThrough } from 'node:stream';
import { createMediaWorker } from './index.js';

function harness({ failStarts = 0, resolveGate = null } = {}) {
  let spawnCount = 0;
  let resolveCount = 0;
  const children = [];
  const subprocess = {
    async resolveExecutable(name) { resolveCount += 1; assert.equal(name, 'powershell.exe'); if (resolveGate) await resolveGate; return name; },
    spawn() {
      spawnCount += 1;
      if (spawnCount <= failStarts) throw new Error('temporary launch failure');
      let rejectDone;
      const child = {
        stdout: new PassThrough(),
        stderr: { resume() {} },
        stdin: {
          async write(line) {
            const request = JSON.parse(line);
            if (child.dropNext) { child.dropNext = false; return; }
            child.stdout.write(`${JSON.stringify({ id: request.id, ok: true, op: request.op })}\n`);
          },
          end() {},
        },
        done: new Promise((_resolve, reject) => { rejectDone = reject; }),
        terminate() { rejectDone(new Error('terminated')); child.stdout.end(); },
        crash() { rejectDone(new Error('worker crashed')); child.stdout.end(); },
        dropNext: false,
      };
      children.push(child);
      return child;
    },
  };
  return { subprocess, children, get spawnCount() { return spawnCount; }, get resolveCount() { return resolveCount; } };
}

const first = harness({ failStarts: 1 });
const client = createMediaWorker(first.subprocess, { script: 'fixture.ps1', platform: 'win32', retryMs: 0, timeoutMs: 50 });
assert.deepEqual(await client.request('status'), { ok: false, error: 'worker-start-failed', detail: 'temporary launch failure' });
assert.deepEqual(await client.request('status'), { id: '1', ok: true, op: 'status' }, 'a transient start failure retries on the next poll');
assert.equal(first.spawnCount, 2);

first.children[0].dropNext = true;
const waiting = client.request('status');
first.children[0].crash();
assert.deepEqual(await waiting, { ok: false, error: 'worker-exited', detail: 'worker crashed' }, 'an abrupt exit settles pending requests immediately');
assert.deepEqual(await client.request('status'), { id: '3', ok: true, op: 'status' }, 'the next request starts a fresh worker');
assert.equal(first.spawnCount, 3);
client.dispose();

let releaseResolve;
const resolveGate = new Promise((resolve) => { releaseResolve = resolve; });
const concurrent = harness({ resolveGate });
const concurrentClient = createMediaWorker(concurrent.subprocess, { script: 'fixture.ps1', platform: 'win32', timeoutMs: 50 });
const concurrentCalls = [concurrentClient.request('status'), concurrentClient.request('status')];
await new Promise((resolve) => setImmediate(resolve));
assert.equal(concurrent.resolveCount, 1, 'overlapping refreshes share the pending startup');
releaseResolve();
assert.deepEqual(await Promise.all(concurrentCalls), [
  { id: '1', ok: true, op: 'status' },
  { id: '2', ok: true, op: 'status' },
]);
assert.equal(concurrent.spawnCount, 1, 'overlapping refreshes never orphan duplicate PowerShell workers');
concurrentClient.dispose();

const timeoutHarness = harness();
const timeoutClient = createMediaWorker(timeoutHarness.subprocess, { script: 'fixture.ps1', platform: 'win32', retryMs: 0, timeoutMs: 15 });
assert.deepEqual(await timeoutClient.request('status'), { id: '1', ok: true, op: 'status' });
timeoutHarness.children[0].dropNext = true;
const keepTestLoopAlive = setTimeout(() => {}, 100);
assert.deepEqual(await timeoutClient.request('status'), { ok: false, error: 'worker-timeout' });
clearTimeout(keepTestLoopAlive);
assert.deepEqual(await timeoutClient.request('status'), { id: '3', ok: true, op: 'status' }, 'a timed-out worker is replaced before it can accumulate stale requests');
assert.equal(timeoutHarness.spawnCount, 2);
timeoutClient.dispose();

let releaseDisposedResolve;
const disposedGate = new Promise((resolve) => { releaseDisposedResolve = resolve; });
const disposedHarness = harness({ resolveGate: disposedGate });
const disposedClient = createMediaWorker(disposedHarness.subprocess, { script: 'fixture.ps1', platform: 'win32', timeoutMs: 50 });
const disposedCall = disposedClient.request('status');
disposedClient.dispose();
releaseDisposedResolve();
assert.equal((await disposedCall).error, 'worker-disposed');
await new Promise((resolve) => setImmediate(resolve));
assert.equal(disposedHarness.spawnCount, 0, 'disposing during startup never leaves an orphan subprocess');

const unsupported = createMediaWorker(null, { platform: 'win32' });
assert.equal((await unsupported.request('status')).error, 'not-supported');
unsupported.dispose();
console.log('ok worker lifecycle: transient spawn retries, abrupt exit drains requests, and subsequent calls recover');

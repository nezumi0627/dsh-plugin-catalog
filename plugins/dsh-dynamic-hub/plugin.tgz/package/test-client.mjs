import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const specs = [];
globalThis.document = {
  visibilityState: 'visible', documentElement: { lang: 'en' }, head: { append() {} },
  createElement: () => ({ setAttribute() {}, remove() {} }),
  addEventListener() {}, removeEventListener() {},
};
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
await import('./client.js?media-only-hub');
const manifest = JSON.parse(readFileSync(fileURLToPath(new URL('./package.json', import.meta.url)), 'utf8'));
assert.ok(manifest.files.includes('scripts/media-probe.ps1'), 'the Windows media worker script must ship with the plugin');
const React = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState: (value) => [value, () => {}], useEffect() {}, useRef: (value) => ({ current: value }),
};
const mod = specs[0].factory((name) => {
  if (name === 'react') return React;
  throw new Error(`unexpected require: ${name}`);
});
assert.deepEqual(mod.inject, ['slots', 'locale', 'statusWidgets']);
assert.equal('clockStore' in mod.__test, false, 'the status bar is the single source of wall-clock display');

const descriptors = [];
mod.apply({
  get: () => ({ register: (descriptor) => { descriptors.push(descriptor); return () => {}; } }),
  locale: { register: () => () => {} },
  effect: (run) => run(),
});
mod.__test.mediaStore.set({ active: true, title: 'Track' });
assert.equal(descriptors.length, 1);
assert.equal(descriptors[0].id, 'dsh-dynamic-hub.main');
assert.equal(descriptors[0].render().type, mod.__test.Component);
assert.equal(mod.__test.mediaStore.getSnapshot(), mod.__test.mediaStore.getSnapshot(), 'media snapshots stay stable until changed');
assert.equal(mod.__test.formatUptime(86400), '1d 00:00:00');
assert.equal(mod.__test.appVolumeFor([{ appId: 'Spotify.Player', supported: true, volume: 42 }], 'Spotify.Player'), 0.42);
assert.equal(mod.__test.appVolumeFor([{ appId: 'Other.App', supported: true, volume: 42 }], 'Spotify.Player'), null);
assert.equal(mod.__test.appVolumeFor([{ appId: 'Spotify.Player', supported: true, volume: 30 }, { appId: 'Spotify.Player', supported: true, volume: 40 }], 'Spotify.Player'), null, 'mixed sessions do not claim one misleading app volume');
console.log('ok media widget registration, no duplicate clock, and uptime formatting');

import assert from 'node:assert/strict';
import { Readable } from 'node:stream';
import { apply, ROUTE_PATH, TOKEN_HEADER } from './index.js';

const routes = [], events = {};
const ctx = {
  inject(_services, run) {
    run({
      webServer: { register(route) { routes.push(route); return () => {}; } },
      effect: (runEffect) => runEffect(),
      on(name, handler) { events[name] = handler; },
      get: () => ({ isAuthenticated: () => true }),
    });
  },
  effect: (runEffect) => runEffect(),
  logger: { info() {} },
};
apply(ctx);
const route = routes.find((item) => item.path === ROUTE_PATH);
const rows = [];
events['webserver/index-inject'](rows);
const token = rows[0].value.token;
for (const level of [-0.01, 1.01, Number.NaN]) {
  const request = Readable.from([JSON.stringify({ action: 'volume', level })]);
  request.method = 'POST';
  request.headers = { [TOKEN_HEADER]: token };
  const response = { setHeader() {}, end(body) { this.body = body; } };
  await route.handler(request, response);
  assert.equal(response.statusCode, 400);
  assert.equal(JSON.parse(response.body).error, 'invalid-value');
}
console.log('PASS dynamic hub: invalid master-volume values rejected at the host boundary');

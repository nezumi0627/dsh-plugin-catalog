import { randomBytes, timingSafeEqual } from 'node:crypto';
import { readFileSync, statSync, unlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';

export const name = 'dsh-dynamic-hub';
export const ROUTE_PATH = '/local/dynamic-hub';
export const TOKEN_PATH = '/local/dynamic-hub-token';
export const ART_PATH = '/local/dynamic-hub-art';
const MAX_ART_BYTES = 1024 * 1024;
export const BOOTSTRAP_KEY = '__DSH_DYNAMIC_HUB__';
export const TOKEN_HEADER = 'x-dsh-dynamic-hub-token';
const PROCESS_STARTED_AT = Date.now() - process.uptime() * 1000;
const SCRIPT = join(dirname(fileURLToPath(import.meta.url)), 'scripts', 'media-probe.ps1');
const WORKER_TIMEOUT_MS = 5000;
const WORKER_RETRY_MS = 1000;
const WORKER_OUTPUT_CAP = 65536;
export const bootstrapRow = (path, token, startedAt = PROCESS_STARTED_AT) => ({ kind:'global', name:BOOTSTRAP_KEY, value:{ path, token, startedAt } });
export function authorized(req, token) {
  if (req?.headers?.['sec-fetch-site'] === 'cross-site') return false;
  const supplied=req?.headers?.[TOKEN_HEADER];
  return typeof supplied==='string' && supplied.length===token.length && timingSafeEqual(Buffer.from(supplied),Buffer.from(token));
}
const json=(res,status,data)=>{res.statusCode=status;res.setHeader('content-type','application/json; charset=utf-8');res.setHeader('cache-control','no-store');res.end(JSON.stringify(data));};
function body(req){return new Promise((resolve,reject)=>{let text='';req.on('data',chunk=>{text+=chunk;if(Buffer.byteLength(text)>8192){reject(new Error('body-too-large'));req.destroy();}});req.on('end',()=>{try{resolve(JSON.parse(text));}catch{reject(new Error('invalid-json'));}});req.on('error',reject);});}

/** A single bounded JSONL worker; a failed process is drained and retried, not latched off. */
export function createMediaWorker(subprocess, options = {}) {
  const platform = options.platform ?? process.platform;
  const script = options.script ?? SCRIPT;
  const timeoutMs = options.timeoutMs ?? WORKER_TIMEOUT_MS;
  const retryMs = options.retryMs ?? WORKER_RETRY_MS;
  const maxRetryMs = options.maxRetryMs ?? 30000;
  const outputCap = options.outputCap ?? WORKER_OUTPUT_CAP;
  const now = options.now ?? Date.now;
  let child = null;
  let starting = null;
  let disposed = false;
  let nextId = 0;
  let retryAt = 0;
  let consecutiveFailures = 0;
  const pending = new Map();

  const settleAll = (result) => {
    for (const settle of pending.values()) settle(result);
    pending.clear();
  };
  const scheduleRetry = () => {
    const exponent = Math.min(10, consecutiveFailures++);
    retryAt = now() + Math.min(maxRetryMs, retryMs * (2 ** exponent));
  };
  const failChild = (instance, error = 'worker-exited') => {
    if (child !== instance) return;
    child = null;
    scheduleRetry();
    const message = typeof error === 'string' ? error : error?.message || 'worker-exited';
    settleAll({ ok: false, error: 'worker-exited', detail: String(message).slice(0, 512) });
    try { instance.terminate?.(); } catch {}
  };

  function start() {
    if (child !== null) return Promise.resolve({ child });
    if (starting !== null) return starting;
    if (disposed) return Promise.resolve({ error: 'worker-disposed' });
    if (platform !== 'win32' || !subprocess?.spawn || !subprocess?.resolveExecutable) {
      return Promise.resolve({ error: 'not-supported' });
    }
    if (now() < retryAt) return Promise.resolve({ error: 'worker-restarting' });
    const operation = (async () => {
      try {
        const executable = await subprocess.resolveExecutable('powershell.exe');
        if (disposed) return { error: 'worker-disposed' };
        const instance = subprocess.spawn({
          argv: [executable, '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', script, '-Mode', 'worker'],
          stdio: { stdin: 'pipe', stdout: 'pipe', stderr: { maxBytes: 8192 } },
          graceMs: 500,
        });
        if (!instance?.stdin?.write || typeof instance.stdout?.on !== 'function') {
          try { instance?.terminate?.(); } catch {}
          throw new Error('subprocess provider does not expose streaming JSONL pipes');
        }
        child = instance;
        let buffer = '';
        instance.stdout.setEncoding?.('utf8');
        instance.stdout.on('data', (chunk) => {
          if (child !== instance) return;
          buffer += chunk;
          if (Buffer.byteLength(buffer) > outputCap) {
            failChild(instance, 'worker-output-limit');
            return;
          }
          let end;
          while ((end = buffer.indexOf('\n')) >= 0) {
            const line = buffer.slice(0, end);
            buffer = buffer.slice(end + 1);
            if (line === '') continue;
            let response;
            try { response = JSON.parse(line); } catch { continue; }
          const settle = pending.get(String(response?.id));
          if (settle) {
            consecutiveFailures = 0;
            retryAt = 0;
            settle(response);
          }
          }
        });
        instance.stdout.on('end', () => failChild(instance));
        instance.stdout.on('close', () => failChild(instance));
        instance.stdout.on('error', (error) => failChild(instance, error));
        instance.stderr?.resume?.();
        if (instance.done && typeof instance.done.then === 'function') {
          instance.done.then(() => failChild(instance), (error) => failChild(instance, error));
        }
        return { child: instance };
      } catch (error) {
        scheduleRetry();
        return { error: 'worker-start-failed', detail: String(error?.message ?? error).slice(0, 512) };
      }
    })();
    starting = operation.finally(() => { starting = null; });
    return starting;
  }

  async function request(op, extra = {}) {
    const started = await start();
    if (!started.child) return { ok: false, error: started.error, ...(started.detail ? { detail: started.detail } : {}) };
    const instance = started.child;
    const id = String(++nextId);
    return new Promise((resolve) => {
      let timer;
      const settle = (result) => {
        if (!pending.delete(id)) return;
        clearTimeout(timer);
        resolve(result);
      };
      timer = setTimeout(() => {
        settle({ ok: false, error: 'worker-timeout' });
        failChild(instance, 'worker-timeout');
      }, timeoutMs);
      timer.unref?.();
      pending.set(id, settle);
      Promise.resolve().then(() => instance.stdin.write(`${JSON.stringify({ id, op, ...extra })}\n`)).catch((error) => {
        settle({ ok: false, error: 'worker-write-failed', detail: String(error?.message ?? error).slice(0, 512) });
        failChild(instance, error);
      });
    });
  }

  function dispose() {
    disposed = true;
    starting = null;
    const instance = child;
    child = null;
    settleAll({ ok: false, error: 'worker-disposed' });
    if (instance) {
      try { instance.stdin?.end?.(); } catch {}
      try { instance.terminate?.(); } catch {}
    }
  }

  return { request, dispose };
}

export function apply(ctx) {
 const token=randomBytes(24).toString('hex');
 let mediaWorker=null;
 ctx.inject(['subprocess'],s=>{mediaWorker=createMediaWorker(s.subprocess??s);});
 const media={available:false,error:'not-supported',active:false};
 const call=(op,extra={})=>mediaWorker?.request(op,extra)??Promise.resolve({ok:false,error:'not-supported'});
 const actionSet=new Set(['play-pause','next','prev','seek','volume']);
 const dispatch=async(req,res)=>{
   if(req.method==='GET'){const result=await call('status');if(result?.media)Object.assign(media,result.media);if(result?.volume)media.volume=result.volume;json(res,200,{ok:true,data:media});return;}
   if(req.method!=='POST'){json(res,405,{ok:false,error:'method-not-allowed'});return;}
   let data;try{data=await body(req);}catch(e){json(res,400,{ok:false,error:e.message});return;}
   if(!data||!actionSet.has(data.action)){json(res,400,{ok:false,error:'invalid-action'});return;}
   const reqData=data.action==='seek'?{position:Number(data.position)}:data.action==='volume'?{level:data.level}:{};
   const invalidSeek=data.action==='seek'&&(!Number.isFinite(reqData.position)||reqData.position<0);
   const invalidVolume=data.action==='volume'&&(typeof reqData.level!=='number'||!Number.isFinite(reqData.level)||reqData.level<0||reqData.level>1);
   if(invalidSeek||invalidVolume){json(res,400,{ok:false,error:'invalid-value'});return;}
   const op=data.action==='play-pause'||data.action==='next'||data.action==='prev'?'control':data.action;
   const extra=op==='control'?{action:data.action==='play-pause'?'playpause':data.action==='prev'?'previous':'next'}:reqData;
   json(res,200,{ok:true,data:await call(op,extra)});
 };
 const art=async(_req,res)=>{const path=join(tmpdir(),`dsh-dynamic-hub-${randomBytes(12).toString('hex')}.img`);try{const result=await call('art',{path});if(!result?.ok||!statSync(path).isFile()){json(res,404,{ok:false,error:result?.error||result?.art?.error||'art-unavailable'});return;}const size=statSync(path).size;if(size<=0||size>MAX_ART_BYTES){json(res,413,{ok:false,error:'art-size-limit'});return;}const bytes=readFileSync(path);res.statusCode=200;res.setHeader('content-type',result.art?.mime||'image/png');res.setHeader('content-length',bytes.length);res.setHeader('cache-control','no-store');res.end(bytes);}catch{json(res,404,{ok:false,error:'art-unavailable'});}finally{try{unlinkSync(path)}catch{}}};
  ctx.inject(['webServer'],webCtx=>{
   webCtx.effect(()=>webCtx.webServer.register({kind:'exact',path:ROUTE_PATH,handler:async(req,res)=>{if(!authorized(req,token)){json(res,403,{ok:false,error:'forbidden'});return;}await dispatch(req,res);}}),'dynamic-hub:route');
   webCtx.effect(()=>webCtx.webServer.register({kind:'exact',path:TOKEN_PATH,handler:(req,res)=>{if(req.method!=='GET'){json(res,405,{ok:false,error:'method-not-allowed'});return;}if(webCtx.get?.('connection')?.isAuthenticated?.(req)===false){json(res,401,{ok:false,error:'unauthorized'});return;}json(res,200,{ok:true,data:{path:ROUTE_PATH,token}});}}),'dynamic-hub:token');
   webCtx.effect(()=>webCtx.webServer.register({kind:'exact',path:ART_PATH,handler:async(req,res)=>{if(!authorized(req,token)){json(res,403,{ok:false,error:'forbidden'});return;}if(req.method!=='GET'){json(res,405,{ok:false,error:'method-not-allowed'});return;}await art(req,res);}}),'dynamic-hub:art');
    webCtx.on?.('webserver/index-inject',table=>table.push(bootstrapRow(ROUTE_PATH,token)));
 });
 ctx.effect(()=>()=>mediaWorker?.dispose(),'dynamic-hub:worker');
 ctx.logger?.info?.('[dynamic-hub] active');
}

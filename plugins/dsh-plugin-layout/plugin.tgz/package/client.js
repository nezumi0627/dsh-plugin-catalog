window.__ModuleLoader__.load({
  id: '@local/dsh-plugin-layout',
  factory() {
    const ID = '@local/dsh-plugin-layout';
    const CSS = `
/* Scoped to the plugin inventory; no other settings page is affected. */
[data-plugin-panel="true"] {
  --dshpl-border: var(--dsw-alias-border-l1, rgba(255, 255, 255, .09));
  --dshpl-border-hover: var(--dsw-alias-border-l2, rgba(255, 255, 255, .16));
  --dshpl-surface: var(--dsw-alias-bg-layer-1, #202127);
  --dshpl-surface-hover: var(--dsw-alias-bg-layer-2, #26282f);
  --dshpl-text: var(--dsw-alias-label-primary, #f2f3f5);
  --dshpl-muted: var(--dsw-alias-label-secondary, #b5bac1);
  --dshpl-accent: #3ba6a0;
}

[data-plugin-panel="true"] [data-plugin-group] > ul {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  align-items: stretch;
  gap: 14px;
  margin: 16px 0 30px;
  padding: 0;
  list-style: none;
}

[data-plugin-panel="true"] [data-plugin-package] {
  min-width: 0;
  min-height: 112px;
  padding: 16px;
  border: 1px solid var(--dshpl-border);
  border-radius: 12px;
  background: var(--dshpl-surface);
  box-shadow: none;
}

[data-plugin-panel="true"] [data-plugin-package]:hover {
  border-color: var(--dshpl-border-hover);
  background: var(--dshpl-surface-hover);
}

[data-plugin-panel="true"] [data-plugin-package] > [class*="cardHead"] {
  display: grid;
  grid-template-columns: 40px minmax(0, 1fr) auto;
  align-items: center;
  gap: 12px;
  min-width: 0;
}

[data-plugin-panel="true"] [data-plugin-package] [class*="cardIcon"] {
  display: grid;
  width: 40px;
  height: 40px;
  flex: none;
  place-items: center;
  overflow: hidden;
  border: 1px solid var(--dshpl-border);
  border-radius: 10px;
  background: var(--dshpl-surface-hover);
}

[data-plugin-panel="true"] [data-plugin-package] [class*="packageImage"],
[data-plugin-panel="true"] [data-plugin-package] [class*="cardIcon"] svg {
  width: 28px;
  height: 28px;
  object-fit: contain;
}

[data-plugin-panel="true"] [data-plugin-package] [class*="cardMain"] {
  display: grid;
  min-width: 0;
  gap: 7px;
}

[data-plugin-panel="true"] [data-plugin-package] [class*="titleRow"] {
  display: flex;
  min-width: 0;
  flex-wrap: wrap;
  align-items: center;
  gap: 6px 9px;
}

[data-plugin-panel="true"] [data-plugin-package] [class*="cardTitle"] {
  min-width: 0;
  color: var(--dshpl-text);
  font-size: 14px;
  font-weight: 620;
  line-height: 1.4;
  text-align: left;
  overflow-wrap: anywhere;
}

[data-plugin-panel="true"] [data-plugin-package] [class*="cardTitle"]:focus-visible {
  outline: 2px solid var(--dshpl-accent);
  outline-offset: 3px;
  border-radius: 2px;
}

[data-plugin-panel="true"] [data-plugin-package] [class*="cardDesc"] {
  display: -webkit-box;
  overflow: hidden;
  color: var(--dshpl-muted);
  font-size: 12px;
  line-height: 1.55;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
}

[data-plugin-panel="true"] [data-plugin-package] [class*="cardEnd"] {
  display: flex;
  align-items: center;
  justify-content: flex-end;
  margin-left: 2px;
}

[data-plugin-panel="true"] [data-plugin-group] > [class*="groupHead"] {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 12px 0 10px;
  border-bottom: 1px solid var(--dshpl-border);
}

[data-plugin-panel="true"] [data-plugin-group] [class*="groupTitle"] {
  color: var(--dshpl-text);
  font-size: 13px;
  font-weight: 650;
}

[data-plugin-panel="true"] [data-plugin-group] [class*="count"] {
  display: inline-grid;
  min-width: 23px;
  height: 22px;
  padding: 0 7px;
  place-items: center;
  border: 1px solid var(--dshpl-border);
  border-radius: 999px;
  background: var(--dshpl-surface);
  color: var(--dshpl-muted);
  font-size: 11px;
  font-variant-numeric: tabular-nums;
}

@media (max-width: 760px) {
  [data-plugin-panel="true"] [data-plugin-group] > ul {
    grid-template-columns: minmax(0, 1fr);
    gap: 10px;
  }

  [data-plugin-panel="true"] [data-plugin-package] {
    min-height: 100px;
    padding: 14px;
  }
}
`;

    return {
      name: 'dsh-plugin-layout',
      inject: [],
      apply(ctx) {
        ctx.effect(() => {
          if (typeof document === 'undefined' || !document.head) return;
          const style = document.createElement('style');
          style.dataset.pluginCss = ID;
          style.textContent = CSS;
          document.head.append(style);
          return () => style.remove();
        }, 'dsh-plugin-layout: styles');
      },
    };
  },
});

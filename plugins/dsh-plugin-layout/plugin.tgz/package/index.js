/** Host entry for the browser-only plugin library layout. */
export const name = 'dsh-plugin-layout';
export const VERSION = '1.0.0';

export function apply(ctx) {
  ctx.logger?.info?.('[plugin-layout] active — compact plugin library layout');
}

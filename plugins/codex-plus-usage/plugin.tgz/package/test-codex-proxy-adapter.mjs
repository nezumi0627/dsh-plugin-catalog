import test from 'node:test';
import assert from 'node:assert/strict';
import { createCodexProxyAdapter } from './codex-proxy-adapter.js';

test('discovers chat models from the authenticated live proxy catalog', async () => {
  const requests = [];
  const adapter = createCodexProxyAdapter({
    baseURL: 'http://127.0.0.1:8317/v1',
    resolveApiKey: async () => 'test-secret',
    fetchImpl: async (url, init) => {
      requests.push({ url, init });
      return new Response(JSON.stringify({ data: [
        { id: 'gpt-6-sol' }, { id: 'gpt-image-2' }, { id: 'gpt-5.6-sol' },
      ] }), { status: 200, headers: { 'content-type': 'application/json' } });
    },
  });

  assert.deepEqual((await adapter.listModels('codex-proxy')).map(({ id }) => id), ['gpt-6-sol', 'gpt-5.6-sol']);
  assert.equal(requests[0].url, 'http://127.0.0.1:8317/v1/models');
  assert.equal(requests[0].init.headers.authorization, 'Bearer test-secret');
});

test('streams OpenAI-compatible text and keeps the request on the selected proxy route', async () => {
  let requestBody;
  const adapter = createCodexProxyAdapter({
    baseURL: 'http://127.0.0.1:8317/v1',
    resolveApiKey: async () => 'test-secret',
    fetchImpl: async (_url, init) => {
      requestBody = JSON.parse(init.body);
      return new Response('data: {"choices":[{"delta":{"content":"hello"}}]}\n\ndata: [DONE]\n\n', {
        status: 200,
        headers: { 'content-type': 'text/event-stream' },
      });
    },
  });
  const prepared = await adapter.prepareCall('codex-proxy', 'gpt-6-sol');
  const chunks = [];
  for await (const chunk of prepared.stream({
    provider: 'codex-proxy', model: 'gpt-6-sol', messages: [], signal: new AbortController().signal,
  })) chunks.push(chunk);

  assert.equal(requestBody.model, 'gpt-6-sol');
  assert.equal(requestBody.stream, true);
  assert.ok(chunks.some((chunk) => chunk.type === 'text-delta' && chunk.text === 'hello'));
  assert.equal(chunks.at(-1).type, 'finish');
});

test('preserves DSH tool schemas, assistant call identity, and tool results across a streamed tool call', async () => {
  let requestBody;
  const events = [
    { choices: [{ delta: { tool_calls: [{ index: 0, id: 'call_abc', type: 'function', function: { name: 'read_file', arguments: '{"path":' } }] } }] },
    { choices: [{ delta: { tool_calls: [{ index: 0, function: { arguments: '"notes.txt"}' } }] }, finish_reason: 'tool_calls' }] },
  ].map((value) => `data: ${JSON.stringify(value)}\n\n`).join('') + 'data: [DONE]\n\n';
  const adapter = createCodexProxyAdapter({
    resolveApiKey: async () => 'test-secret',
    fetchImpl: async (_url, init) => {
      requestBody = JSON.parse(init.body);
      return new Response(events, { status: 200, headers: { 'content-type': 'text/event-stream' } });
    },
  });
  const schema = { name: 'read_file', description: 'Read a file', parameters: { type: 'object', properties: { path: { type: 'string' } } } };
  const prepared = await adapter.prepareCall('codex-proxy', 'gpt-6-sol');
  const chunks = [];
  for await (const chunk of prepared.stream({
    provider: 'codex-proxy', model: 'gpt-6-sol', signal: new AbortController().signal,
    tools: [schema], messages: [
      { role: 'assistant', content: [{ type: 'tool-call', id: 'call_old', name: 'read_file', arguments: '{"path":"old.txt"}' }] },
      { role: 'tool', toolCallId: 'call_old', isError: false, content: [{ type: 'text', text: 'old file' }] },
    ],
  })) chunks.push(chunk);

  assert.deepEqual(requestBody.tools, [{ type: 'function', function: { name: schema.name, description: schema.description, parameters: schema.parameters } }]);
  assert.equal(requestBody.messages[0].tool_calls[0].id, 'call_old');
  assert.equal(requestBody.messages[1].tool_call_id, 'call_old');
  assert.ok(chunks.some((chunk) => chunk.type === 'tool-call-delta' && chunk.id === 'call_abc' && chunk.name === 'read_file'));
  assert.equal(chunks.at(-1).reason.kind, 'tool-calls');
});

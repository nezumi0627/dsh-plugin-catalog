// Client half of @local/codex-plus-usage.
//
// One pill in the composer dock that answers two questions the
// composer itself cannot: how much of the ChatGPT (Plus) Codex allowance is
// spent, and what the local codex-proxy (127.0.0.1:8317) has served.
//
// Data comes from the proxy's own management API, both endpoints local-only:
//   GET /v8/management/usage        totals / by_model / quota / cooldowns / fast_mode
//   GET /v8/management/credentials  account, plan and quota signals per credential
// The statistics live in the proxy's memory (see _dsh/ws8/MATRIX.md), so the
// popover is explicit about the window it is showing: "codex-proxy 起動以降".
//
// The power button beside 更新 closes the loop: when the proxy is down the pill
// says so, and pressing the button asks the Host half to start it. Its state
// comes from `GET <route>` and the click from `POST <route>` (see POWER_* below).
//
// The management key is the plaintext of `management.secret-key` in
// %LOCALAPPDATA%\CodexProxy\config.yaml. The bundle is local-only and the API
// refuses anything that is not loopback, so the value stays in this file; rotate
// it by changing config.yaml AND this constant together.
window.__ModuleLoader__.load({
  id: '@local/codex-plus-usage',
  factory(require) {
    const React = require('react');
    const ReactDOM = require('react-dom');
    // The panel is a portaled, fixed-position surface. The composer dock lives inside
    // clipped and scrolled containers, so the control this pill sits beside (the
    // ContextMeter) portals its panel and hands geometry to these two primitives
    // instead of anchoring an absolutely positioned child in place.
    const { MenuSurface, useAnchoredPosition, useDismissOnOutsidePointer } = require('@deepseek-ai/dsh-client-ui-primitives');
    const h = React.createElement;
    const USAGE_ENDPOINT = '/local/codex-proxy?resource=usage';
    const CREDENTIALS_ENDPOINT = '/local/codex-proxy?resource=credentials';
    const REFRESH_MS = 30000;
    const USAGE_STORAGE_KEY = 'codex-plus-usage:usage:v1';
    function readUsageSnapshot() {
      try {
        const value = JSON.parse(window.localStorage.getItem(USAGE_STORAGE_KEY) || 'null');
        return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
      } catch {
        return null;
      }
    }
    function writeUsageSnapshot(snapshot) {
      try { window.localStorage.setItem(USAGE_STORAGE_KEY, JSON.stringify(snapshot)); } catch {}
    }
    // The power button starts codex-proxy when it is down. Only the Host half can
    // spawn a process, so the click goes to this bundle's own exact route: the
    // served page carries the path and a per-process token (injected by
    // index.js), and a local page without that token gets 403.
    const POWER_BOOTSTRAP_KEY = '__DSH_CODEX_PROXY__';
    const POWER_TOKEN_HEADER = 'x-dsh-codex-proxy-token';
    const POWER_REFRESH_MS = 5000;
    // Trigger metrics and panel surface mirror the composer's own controls:
    // StatsPills.module.css (.iq1doa_*) and ContextMeter.module.css (_2WTFBq_panel,
    // which is position:fixed because it is portaled to the body).
    const styles = `
      .cplus-root{box-sizing:border-box;min-width:0;max-width:100%;flex:0 0 auto;font-size:calc(var(--dsh-content-font-size-secondary,13px) - 1px);line-height:calc(20px + var(--dsh-content-font-delta-secondary,0px));justify-content:center;gap:6px;display:flex;white-space:nowrap}
      .cplus-pill{box-sizing:border-box;corner-shape:round;max-width:100%;color:var(--dsw-alias-label-tertiary);font:inherit;font-variant-numeric:tabular-nums;line-height:inherit;white-space:nowrap;background:0 0;border:none;border-radius:999px;align-items:center;gap:6px;padding:1px 8px;display:inline-flex;cursor:pointer}
      .cplus-pill svg{flex:none;width:14px;height:14px}
      .cplus-pill:hover,.cplus-pill[aria-expanded=true]{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}
      .cplus-label{display:inline-block;vertical-align:bottom;text-overflow:ellipsis;min-width:0;overflow:hidden;white-space:nowrap}
      .cplus-sep{color:var(--dsw-alias-separator-primary,currentColor);margin:0 6px}
      .cplus-popover{position:fixed;z-index:1200;box-sizing:border-box;width:min(320px,calc(100vw - 32px));max-height:min(70vh,520px);overflow:hidden;padding:12px;color:var(--dsw-alias-label-secondary);font-size:12px;line-height:20px;-webkit-app-region:no-drag;display:flex;flex-direction:column}
      .cplus-body{min-height:0;overflow:auto;flex:1}
      .cplus-title{font-weight:600;color:var(--dsw-alias-label-primary);margin-bottom:2px}
      .cplus-plan,.cplus-foot,.cplus-reset{color:var(--dsw-alias-label-caption);font-size:11px}
      .cplus-sub{margin-top:10px;padding-top:8px;border-top:1px solid var(--dsw-alias-border-l1);font-size:11px;color:var(--dsw-alias-label-caption)}
      .cplus-row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:6px;color:var(--dsw-alias-label-secondary)}
      .cplus-row span:last-child{font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-primary);text-align:right}
      .cplus-pct{color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums}
      .cplus-track{corner-shape:round;height:4px;margin-top:3px;border-radius:999px;background:var(--dsw-alias-interactive-bg-hover);overflow:hidden}
      .cplus-fill{height:100%;border-radius:1px;background:var(--dsw-alias-state-business-primary)}
      .cplus-fill-warn{background:var(--dsw-alias-state-warning-primary,var(--dsw-alias-state-error-primary))}
      .cplus-reset{margin-top:2px;text-align:right}
      .cplus-foot{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:10px}
      .cplus-actions{display:inline-flex;align-items:center;gap:2px}
      .cplus-power-wrap{display:inline-flex;align-items:center}
      .cplus-power{border:0;border-radius:var(--dsw-radius-sm);padding:2px;background:0 0;font:inherit;display:inline-flex;align-items:center;cursor:pointer}
      .cplus-power svg{width:14px;height:14px;display:block}
      .cplus-power-off{color:var(--dsw-alias-label-tertiary)}
      .cplus-power-on{color:var(--dsw-alias-state-business-primary)}
      .cplus-power:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
      .cplus-power-off:hover:not(:disabled){color:var(--dsw-alias-label-primary)}
      .cplus-power:disabled{cursor:default}
      .cplus-power-busy{opacity:.55}
      .cplus-refresh{border:0;border-radius:var(--dsw-radius-sm);padding:2px 8px;background:0 0;color:inherit;font:inherit;cursor:pointer}
      .cplus-refresh:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
      .cplus-refresh:disabled{opacity:.5;cursor:default}
      .cplus-error{color:var(--dsw-alias-state-error-primary)}
      .cplus-warn{color:var(--dsw-alias-state-warning-primary,var(--dsw-alias-label-secondary))}
      .cplus-mono{font-variant-numeric:tabular-nums}
      .cplus-model{display:flex;justify-content:space-between;gap:8px;margin-top:4px}
      .cplus-model-name{text-overflow:ellipsis;overflow:hidden;white-space:nowrap;color:var(--dsw-alias-label-secondary)}
      .cplus-model-num{font-variant-numeric:tabular-nums;color:var(--dsw-alias-label-caption);flex:none}
    `;
    const styleElement = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', '@local/codex-plus-usage');
      element.textContent = styles;
      document.head.append(element);
      return element;
    })();
    const relativeTime = (value) => {
      if (!Number.isFinite(value)) return '—';
      if (value <= 0) return 'まもなく';
      const days = Math.floor(value / 86400);
      const hours = Math.floor(value % 86400 / 3600);
      const minutes = Math.floor(value % 3600 / 60);
      return days ? `${days}日${hours}時間` : hours ? `${hours}時間${minutes}分` : `${minutes}分`;
    };
    const number = (value) => {
      if (value === null || value === undefined || value === '') return null;
      const parsed = Number(value);
      return Number.isFinite(parsed) ? parsed : null;
    };
    const count = (value) => {
      const parsed = number(value);
      if (parsed === null) return '—';
      if (Math.abs(parsed) >= 1e6) return `${(parsed / 1e6).toFixed(parsed >= 1e7 ? 0 : 1)}M`;
      if (Math.abs(parsed) >= 1e3) return `${(parsed / 1e3).toFixed(parsed >= 1e4 ? 0 : 1)}k`;
      return String(parsed);
    };
    const duration = (ms) => {
      const parsed = number(ms);
      if (parsed === null || parsed <= 0) return '—';
      return parsed >= 1000 ? `${(parsed / 1000).toFixed(1)}s` : `${Math.round(parsed)}ms`;
    };
    const clock = (value) => {
      const at = new Date(value);
      return Number.isNaN(at.getTime()) ? null : at.toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' });
    };
    /** The route + token the Host half injected, or null when this page has none. */
    const readPowerApi = () => {
      const boot = typeof window === 'undefined' ? null : window[POWER_BOOTSTRAP_KEY];
      if (!boot || typeof boot.path !== 'string' || typeof boot.token !== 'string' || !boot.path || !boot.token) return null;
      return boot;
    };
    /** `false` only when a document exists and says the window is hidden. */
    const onScreen = () => typeof document === 'undefined' || document.visibilityState !== 'hidden';
    /**
     * Refresh now, then every `ms`, but only while the window is on screen.
     *
     * Each tick of the usage poll is two loopback reads plus a `setState`, so an
     * off-screen window schedules
     * nothing at all. Becoming visible again refreshes once immediately instead
     * of waiting out the period, which is what keeps the pill from being stale.
     * The returned function stops the timer and removes the listener.
     */
    function pollWhileVisible(poll, ms) {
      let timer = null;
      const stop = () => {
        if (timer !== null) {
          clearInterval(timer);
          timer = null;
        }
      };
      const start = () => {
        stop();
        timer = setInterval(() => { if (onScreen()) poll(); }, ms);
      };
      const onVisibilityChange = () => {
        if (!onScreen()) {
          stop();
          return;
        }
        stop();
        poll();
        start();
      };
      if (onScreen()) {
        poll();
        start();
      }
      if (typeof document !== 'undefined') document.addEventListener('visibilitychange', onVisibilityChange);
      return () => {
        stop();
        if (typeof document !== 'undefined') document.removeEventListener('visibilitychange', onVisibilityChange);
      };
    }
    /** Standard power glyph: a ring broken at the top by the stem. */
    function PowerIcon() {
      return h('svg', { viewBox: '0 0 16 16', fill: 'none', stroke: 'currentColor', 'stroke-width': 1.3, 'stroke-linecap': 'round', 'aria-hidden': 'true' },
        h('path', { d: 'M8 2.4v4.4' }),
        h('path', { d: 'M11.8 4.6a5 5 0 1 1-7.6 0' }),
      );
    }
    /** Tooltip and accessible name: the button is icon-only, so this carries the state. */
    const powerTitle = (power, busy) => {
      if (busy) return 'codex-proxy を起動しています…';
      if (power === undefined) return 'codex-proxy の状態を取得中…';
      if (power.running) return `codex-proxy 起動中${power.version ? ` (v${power.version})` : ''}${power.owned ? ' · DSH が管理' : ' · 外部プロセス'}`;
      if (power.starting) return 'codex-proxy を起動しています…';
      if (power.unknown) return 'codex-proxy 停止中（状態を確認できませんでした）— 押すと起動します';
      if (power.error) return `codex-proxy を起動できません: ${power.error}`;
      return 'codex-proxy 停止中 — 押すと起動します';
    };
    /** Press-only-when-down: a running or already-starting proxy is not pressable. */
    const powerLocked = (power, busy) => busy || power?.running === true || power?.starting === true;
    /**
     * Flatten the two management payloads into exactly what the panel renders.
     * Pure on purpose: `__test__` exposes it, and the tests drive it with the
     * raw JSON captured from the live proxy (_dsh/ws8/artifacts).
     */
    function shape(usage, credentials) {
      const files = credentials?.files || [];
      const account = files.find((entry) => entry.provider === 'codex' && entry.account_type === 'oauth' && !entry.disabled) || files[0] || {};
      const signals = account.quota?.signals || {};
      const quota = usage?.quota || {};
      const totals = usage?.totals || {};
      const pick = (...values) => values.map(number).find((value) => value !== null) ?? null;
      // `by_model` is an ARRAY of per-model rows in the current proxy
      // ([{ model, requests, ... }]); an older build keyed a map by model id.
      // Reading only the map shape turned array indices into "model names", so
      // モデル別 listed 0 / 1 / 2 instead of gpt-6-luna and friends.
      const modelRows = Array.isArray(usage?.by_model)
        ? usage.by_model.map((stats) => [stats?.model ?? stats?.id ?? stats?.name ?? null, stats])
        : Object.entries(usage?.by_model || {});
      const byModel = modelRows
        .map(([id, stats]) => ({ id: id ?? '?', requests: number(stats?.requests) ?? 0, totalTokens: number(stats?.total_tokens) ?? 0, avgLatencyMs: number(stats?.avg_latency_ms) }))
        .sort((a, b) => b.requests - a.requests)
        .slice(0, 3);
      return {
        plan: quota.plan_type || signals['X-Codex-Plan-Type'] || account.plan_type || 'plus',
        fiveHour: pick(quota.primary_used_percent, signals['X-Codex-Primary-Used-Percent']),
        week: pick(quota.secondary_used_percent, signals['X-Codex-Secondary-Used-Percent']),
        fiveReset: pick(quota.primary_reset_seconds, signals['X-Codex-Primary-Reset-After-Seconds']),
        weekReset: pick(quota.secondary_reset_seconds, signals['X-Codex-Secondary-Reset-After-Seconds']),
        credits: quota.credits_balance ?? signals['X-Codex-Credits-Balance'] ?? null,
        limitReached: signals['X-Codex-Limit-Reached'] ?? signals['X-Codex-Rate-Limit-Reached'] ?? null,
        activeLimit: quota.active_limit ?? signals['X-Codex-Active-Limit'] ?? null,
        observed: usage?.observed_at || account.quota?.observed_at || null,
        startedAt: usage?.started_at || null,
        version: usage?.version || null,
        totals: {
          requests: number(totals.requests),
          errors: number(totals.errors),
          streamed: number(totals.streamed),
          fast: number(totals.fast_requests),
          input: number(totals.input_tokens),
          output: number(totals.output_tokens),
          total: number(totals.total_tokens),
          cached: number(totals.cached_tokens),
          reasoning: number(totals.reasoning_tokens),
          images: number(totals.images),
          toolCalls: number(totals.tool_calls),
          avgLatency: number(totals.avg_latency_ms),
          p95Latency: number(totals.p95_latency_ms),
          avgFirstToken: number(totals.avg_first_token_ms),
        },
        byModel,
        cooldowns: usage?.cooldowns || [],
        fastMode: usage?.fast_mode || null,
        accountError: account.error || null,
      };
    }
    // Same glyph the neighbouring stats pill uses (dsh-client-ui-primitives IconGaugeOutlineRegular, 1px stroke).
    const GaugeIcon = () => h('svg', { viewBox: '0 0 16 16', width: 16, height: 16, fill: 'none', strokeWidth: 1, 'aria-hidden': true },
      h('path', { d: 'M3.4041 13.096C2.49514 12.187 1.87614 11.0288 1.62537 9.76798C1.37459 8.50716 1.50331 7.20028 1.99525 6.01261C2.48719 4.82494 3.32025 3.80981 4.3891 3.09557C5.45795 2.38134 6.71458 2.00008 8.0001 2C9.28563 2.00008 10.5423 2.38134 11.6111 3.09557C12.68 3.80981 13.513 4.82494 14.005 6.01261C14.4969 7.20028 14.6256 8.50716 14.3748 9.76798C14.1241 11.0288 13.5051 12.187 12.5961 13.096', stroke: 'currentColor' }),
      h('path', { d: 'M8 8.49994L11.6114 4.88855', stroke: 'currentColor' }),
      h('path', { d: 'M8 9.75C8.69036 9.75 9.25 9.19036 9.25 8.5C9.25 7.80964 8.69036 7.25 8 7.25C7.30964 7.25 6.75 7.80964 6.75 8.5C6.75 9.19036 7.30964 9.75 8 9.75Z', fill: 'currentColor' }),
    );
    function PlusUsage({ model, error, busy, fetchQuota, open, setOpen, httpStatus, power, powerBusy, powerReady, startProxy }) {
      const anchorRef = React.useRef(null);
      const panelRef = React.useRef(null);
      // Match the composer's ContextMeter: the button itself is the measured anchor,
      // and the shared primitives keep the portaled panel positioned and dismissible.
      const position = useAnchoredPosition({ open, anchorRef, panelRef, side: 'top', gap: 8, margin: 12 });
      useDismissOnOutsidePointer(anchorRef, open, setOpen, panelRef);
      const line = (label, percent, reset, window) => {
        const safe = Number.isFinite(percent) ? Math.max(0, Math.min(100, percent)) : 0;
        const warn = safe >= 80 ? ' cplus-fill-warn' : '';
        return h('div', { key: label },
          h('div', { className: 'cplus-row' }, h('span', null, `${label}${window ? ` (${window})` : ''}`), h('span', { className: 'cplus-pct' }, Number.isFinite(percent) ? `${Math.round(percent)}% 使用` : '—')),
          h('div', { className: 'cplus-track', role: 'meter', 'aria-label': `${label}: ${Math.round(safe)}% 使用`, 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-valuenow': Math.round(safe) }, h('div', { className: `cplus-fill${warn}`, style: { width: `${safe}%` } })),
          h('div', { className: 'cplus-reset' }, `リセットまで ${relativeTime(reset)}`),
        );
      };
      const stat = (label, value) => h('div', { className: 'cplus-row', key: label }, h('span', null, label), h('span', null, value));
      const five = Number.isFinite(model?.fiveHour) ? `${Math.round(model.fiveHour)}%` : '—';
      const week = Number.isFinite(model?.week) ? `${Math.round(model.week)}%` : '—';
      const totals = model?.totals || {};
      const aria = `ChatGPT Plus 使用量 · 5時間 ${five} · 週間 ${week}${Number.isFinite(totals.requests) ? ` · ${totals.requests} リクエスト` : ''}`;
      return h('div', { className: 'cplus-root' },
        h('button', { ref: anchorRef, type: 'button', className: 'cplus-pill', 'aria-haspopup': 'dialog', 'aria-expanded': open, 'aria-label': aria, title: aria, onClick: () => setOpen((v) => !v) },
            h(GaugeIcon, null),
            h('span', { className: 'cplus-label' }, 'Plus',
              h('span', { className: 'cplus-sep', 'aria-hidden': true }, '·'),
              `5h ${five}`,
              h('span', { className: 'cplus-sep', 'aria-hidden': true }, '·'),
              `週 ${week}`),
          ),
          open ? ReactDOM.createPortal(h(MenuSurface, { ref: panelRef, className: 'cplus-popover', style: { position: 'fixed', zIndex: 1200, width: 'min(320px, calc(100vw - 32px))', maxHeight: 'min(70vh, 520px)', overflow: 'hidden', display: 'flex', flexDirection: 'column', padding: 12, pointerEvents: 'auto', ...(position ?? { visibility: 'hidden', left: 0, top: 0 }) }, role: 'dialog', 'aria-label': 'ChatGPT Plus 使用量' },
            h('div', { className: 'cplus-title' }, 'ChatGPT Plus (codex-proxy)'),
            h('div', { className: 'cplus-body' },
              h('div', { className: 'cplus-plan' },
                model ? `${model.plan} プラン` : 'Codex OAuth 使用枠',
                model?.activeLimit ? ` · ${model.activeLimit}` : '',
                model?.fastMode?.enabled ? ` · fast ${model.fastMode.tier}` : '',
              ),
              error
              ? h('div', { className: 'cplus-row cplus-error', role: 'status' }, `管理 API に接続できません${httpStatus ? ` (HTTP ${httpStatus})` : ''}`)
              : model
                ? h(React.Fragment, null,
                  line('5時間枠', model.fiveHour, model.fiveReset, '300分'),
                  line('週間枠', model.week, model.weekReset, '7日'),
                  model.accountError ? h('div', { className: 'cplus-row cplus-warn', role: 'status' }, `credential: ${model.accountError}`) : null,
                  model.limitReached ? h('div', { className: 'cplus-row cplus-warn', role: 'status' }, `上限到達: ${model.limitReached}`) : null,
                  (model.cooldowns || []).length
                    ? h('div', { className: 'cplus-row cplus-warn', role: 'status' }, `クールダウン ${model.cooldowns[0].model || ''} 残り ${model.cooldowns[0].reset_time || relativeTime(model.cooldowns[0].reset_seconds)}`)
                    : null,
                  h('div', { className: 'cplus-sub' }, model.startedAt ? `codex-proxy 起動以降（${clock(model.startedAt) || '—'} から）` : 'codex-proxy 起動以降'),
                  stat('リクエスト', Number.isFinite(totals.requests) ? `${count(totals.requests)}${totals.errors ? ` · 失敗 ${count(totals.errors)}` : ''}` : '—'),
                  stat('トークン', Number.isFinite(totals.total) ? `${count(totals.total)}（入 ${count(totals.input)} / 出 ${count(totals.output)}）` : '—'),
                  stat('推論トークン', count(totals.reasoning)),
                  stat('キャッシュ', count(totals.cached)),
                  stat('画像 / ツール', `${count(totals.images)} / ${count(totals.toolCalls)}`),
                  stat('ストリーミング / fast', `${count(totals.streamed)} / ${count(totals.fast)}`),
                  stat('応答 平均 / p95', `${duration(totals.avgLatency)} / ${duration(totals.p95Latency)}`),
                  stat('初トークン 平均', duration(totals.avgFirstToken)),
                  model.byModel?.length
                    ? h('div', { className: 'cplus-sub' }, 'モデル別',
                      model.byModel.map((row) => h('div', { className: 'cplus-model', key: row.id },
                        h('span', { className: 'cplus-model-name' }, row.id),
                        h('span', { className: 'cplus-model-num' }, `${count(row.requests)} req · ${count(row.totalTokens)} tok`))))
                    : null,
                )
                : h('div', { className: 'cplus-row', role: 'status' }, '使用量を取得中…'),
            ),
            h('div', { className: 'cplus-foot' },
              h('span', null, model?.observed ? `${clock(model.observed)} 時点 · ${REFRESH_MS / 1000}秒ごと更新` : 'Plus 残量の目安'),
              h('span', { className: 'cplus-actions' },
                // Start-only by design: while the proxy serves, the button shows
                // that state and refuses to be pressed, so a stray click cannot
                // take the ChatGPT Plus route down mid-session.
                powerReady
                  // The title lives on the wrapper too: Chromium shows no tooltip
                  // for a disabled button, and the running case *is* disabled.
                  ? h('span', { className: 'cplus-power-wrap', title: powerTitle(power, powerBusy) },
                    h('button', {
                      className: `cplus-power ${power?.running ? 'cplus-power-on' : 'cplus-power-off'}${powerLocked(power, powerBusy) ? ' cplus-power-busy' : ''}`,
                      type: 'button',
                      onClick: startProxy,
                      disabled: powerLocked(power, powerBusy),
                      title: powerTitle(power, powerBusy),
                      'aria-label': powerTitle(power, powerBusy),
                    }, h(PowerIcon, null)))
                  : null,
                h('button', { className: 'cplus-refresh', type: 'button', onClick: fetchQuota, disabled: busy }, busy ? '更新中…' : '更新'),
              ),
            ),
          ), document.body) : null,
      );
    }
    return {
      inject: ['slots'],
      __test__: {
        shape,
        count,
        duration,
        relativeTime,
        onScreen,
        pollWhileVisible,
        endpoints: { USAGE_ENDPOINT, CREDENTIALS_ENDPOINT },
        power: { bootstrapKey: POWER_BOOTSTRAP_KEY, tokenHeader: POWER_TOKEN_HEADER, refreshMs: POWER_REFRESH_MS, title: powerTitle },
        REFRESH_MS,
        USAGE_STORAGE_KEY,
        readUsageSnapshot,
        writeUsageSnapshot,
      },
      apply(ctx) {
        ctx.effect(() => () => styleElement?.remove(), 'codex-plus-usage.styles');
        ctx.effect(
          () => ctx.slots.inject('conversation.composer.dock', () =>
            ctx.slots.register({ name: 'conversation.composer.dock', id: '@local/codex-plus-usage', order: 10 }, PlusUsageDock)),
          'codex-plus-usage.composer-dock',
        );
        function PlusUsageDock() {
          const [model, setModel] = React.useState(readUsageSnapshot);
          const [error, setError] = React.useState(false);
          const [httpStatus, setHttpStatus] = React.useState(null);
          const [busy, setBusy] = React.useState(false);
          const [open, setOpen] = React.useState(false);
          // undefined = never checked (button hidden until the Host route is known).
          const [power, setPower] = React.useState(undefined);
          const [powerBusy, setPowerBusy] = React.useState(false);
          const fetchQuota = React.useCallback(async () => {
            setBusy(true);
            const headers = { [POWER_TOKEN_HEADER]: window[POWER_BOOTSTRAP_KEY]?.token ?? '' };
            try {
              const [usageResponse, credentialsResponse] = await Promise.all([
                fetch(USAGE_ENDPOINT, { headers, cache: 'no-store' }),
                fetch(CREDENTIALS_ENDPOINT, { headers, cache: 'no-store' }),
              ]);
              // The usage snapshot is authoritative for the panel; credentials
              // only add the account/plan fallback, so a 403 there is not fatal.
              if (!usageResponse.ok) {
                setHttpStatus(usageResponse.status);
                throw new Error(`HTTP ${usageResponse.status}`);
              }
              const usage = await usageResponse.json();
              const credentials = credentialsResponse.ok ? await credentialsResponse.json() : null;
              const snapshot = shape(usage, credentials);
              setModel(snapshot);
              writeUsageSnapshot(snapshot);
              setHttpStatus(null);
              setError(false);
            } catch {
              setError(true);
            } finally {
              setBusy(false);
            }
          }, []);
          // Ask the Host half whether codex-proxy is serving. A failed check is
          // reported as "not running" on purpose: the button must stay pressable
          // when the answer is unknown, and starting an already-running proxy is
          // a no-op on the Host side.
          const fetchPower = React.useCallback(async () => {
            const api = readPowerApi();
            if (!api) return;
            try {
              const response = await fetch(api.path, { headers: { [POWER_TOKEN_HEADER]: api.token }, cache: 'no-store' });
              const payload = await response.json().catch(() => null);
              if (!response.ok || payload?.ok !== true || !payload.data) throw new Error(payload?.error || `HTTP ${response.status}`);
              setPower(payload.data);
            } catch {
              setPower({ running: false, owned: false, unknown: true, version: null });
            }
          }, []);
          const startProxy = React.useCallback(async () => {
            const api = readPowerApi();
            if (!api) return;
            setPowerBusy(true);
            try {
              const response = await fetch(api.path, { method: 'POST', headers: { [POWER_TOKEN_HEADER]: api.token }, cache: 'no-store' });
              const payload = await response.json().catch(() => null);
              if (payload?.data) setPower(payload.data);
              if (!response.ok || payload?.ok !== true) throw new Error(payload?.error || `HTTP ${response.status}`);
              // The panel's numbers describe this proxy process, so a fresh
              // process means a fresh (empty) window: refetch right away.
              await fetchQuota();
            } catch (error) {
              setPower((previous) => ({ ...(previous || {}), running: false, unknown: false, error: error instanceof Error ? error.message : String(error) }));
            } finally {
              setPowerBusy(false);
            }
          }, [fetchQuota]);
          // The pill's own numbers every 30 s: one immediate read, then the loop,
          // both owned by the effect so unmounting the dock ends them.
          React.useEffect(() => pollWhileVisible(fetchQuota, REFRESH_MS), [fetchQuota]);
          React.useEffect(() => {
            if (!open) return undefined;
            return pollWhileVisible(fetchPower, POWER_REFRESH_MS);
          }, [open, fetchPower]);
          React.useEffect(() => {
            if (!open) return undefined;
            const close = (event) => { if (event.key === 'Escape') setOpen(false); };
            window.addEventListener('keydown', close);
            return () => window.removeEventListener('keydown', close);
          }, [open]);
          return h(PlusUsage, { model, error, busy, fetchQuota, open, setOpen, httpStatus, power, powerBusy, powerReady: readPowerApi() !== null, startProxy });
        }
      },
    };
  },
});

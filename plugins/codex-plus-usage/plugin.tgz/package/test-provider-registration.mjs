import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const patch = readFileSync(new URL('./cordis.patch.yml', import.meta.url), 'utf8');

test('the plugin patch does not replace the user-owned llm-pi-ai config', () => {
  assert.doesNotMatch(patch, /^- id: llm-pi-ai\s*$/m);
});

test('Codex Proxy provider configuration is not hard-coded in the bundle patch', () => {
  assert.doesNotMatch(patch, /^\s{6}codex-proxy:\s*$/m);
});
# Codex Provider Auto Registration — Design

Date: 2026-10-12
Status: Draft for review
Owner: DSH local profile

## Intent

Improve the existing `@local/codex-plus-usage` plugin so enabling it in DSH
automatically exposes both existing local Codex backends in the model picker:

- Codex Proxy at `http://127.0.0.1:8317/v1` (Codex account/API route).
- Codex Web GPT at `http://127.0.0.1:17843/v1` (ChatGPT Web route).

The plugin already starts and owns Codex Proxy when necessary. Provider
registration should be part of that same plugin bundle, so users do not need to
edit profile model settings by hand. Preserve the existing `gpt-web` provider on
port 8321; it is a separate browser-automation bridge and is not Codex Web GPT.

## Observed current state

- The active profile has `@deepseek-ai/dsh-llm-pi-ai` configured with a provider
  named `gpt-web` at port 8321 and a separate `c-c-g` route. There is no
  `codex-proxy` route or direct Codex Web GPT route in that configuration.
- Codex Proxy is reachable on port 8317 and its authenticated `/v1/models`
  endpoint returned 22 model IDs during read-only inspection: 17 chat-capable
  entries and five `gpt-image-*` entries. Image generation already has its own
  plugin tools, so only the 17 chat-capable entries belong in the chat model picker.
- Codex Web GPT is reachable on port 17843; `/healthz` reports v6.1.8,
  `mode: full`, and `accepting_turns: true`.
- The local Codex model cache lists `chatgpt-web/*` IDs, including
  `chatgpt-web/light`, `chatgpt-web/medium`, `chatgpt-web/high`, and the
  GPT-5.6/GPT-6 Sol variants with context windows.
- Existing `gpt-web-adapter/adapter.mjs` is not full compatible: it removes
  `tools`, `tool_choice`, and related fields, and stamps a restricted,
  read-only environment. It must not be the transport for a full Native2 flow.
- The Codex Web GPT `full` mode uses an MCP tunnel based on `openai/tunnel-client`
  to receive Codex harness capabilities. The exact Native2-to-DSH tool route has
  not yet been verified.
- The installed `dsh-llm-pi-ai` supports `openai-responses` and performs authenticated
  `GET {baseURL}/models` discovery for custom Responses routes. DSH patches replace
  the targeted row config wholesale; bundle patches run before the user profile,
  whose row wins. A bundle patch cannot safely append providers to that row.
- The local Codex Web GPT MCP implementation requires a turn-scoped
  `turn_token`; its `codex_tool_call` invokes tools in the outer Codex runtime,
  including its approvals and UI lifecycle. DSH cannot claim this is available
  just because the Web GPT HTTP daemon is healthy.
- A read-only `GET http://127.0.0.1:17843/v1/models` currently returns HTTP 502,
  while `C:\Users\ren11\.codex\models_cache.json` contains seven exact
  `chatgpt-web/*` IDs and their context/compaction limits. The DSH credential
  store already has both `CLIPROXYAPI_API_KEY` and `GPT_WEB_LOCAL_KEY` references;
  their values were not displayed.
- The installed Codex Web GPT 6.1.8 process is live on port 17843 in `full`
  mode. Its broker named pipe answered the read-only `owner_status` request with
  protocol version 5 and `acceptingExternalOwners: true`. The local source tree's
  older `RemoteTurnBroker` accepts only protocol version 1; the installed 6.1.8
  broker adds `owner_register_safe`, `surfaceNonce` checks, completion fences,
  and safe wait calls. DSH has not established a safe owner session or obtained
  a surface nonce, so protocol compatibility cannot be inferred from a reachable
  pipe. Do not issue `owner_register` or `owner_register_safe` experimentally:
  those operations create an active turn owner.
- The installed 6.1.8 `/v1/models` handler returns the exact error
  `Native Codex passthrough requires the incoming Bearer authorization` when
  DSH calls without a bearer. The handler forwards the incoming Authorization
  header to the native Codex upstream; it does not authenticate DSH from the
  local `controlToken` or the Native2 turn broker. The known DSH `GPT_WEB_LOCAL_KEY`
  was rejected with 401, so cached model IDs cannot make this route usable.
- DSH's live host started before the adapter code was edited (the autostart log
  timestamp matches the current process start). It has not loaded the new
  adapter yet. Requiring a full app restart could interrupt open sessions, so
  the current live model picker remains unverified.
- Authentication probing confirmed `GPT_WEB_LOCAL_KEY` receives HTTP 401 at
  port 17843. That credential belongs to another local Web route and is not
  valid there. The local Codex Responses route expects the calling Codex
  runtime's authorization and turn metadata; do not register it with the
  unrelated key.

## Goals

1. Enabling the existing usage plugin adds both providers to DSH model selection.
2. Codex Proxy model discovery reflects the live `/v1/models` catalog when the
   configured local credential is available.
3. Codex Web GPT models use their exact `chatgpt-web/*` IDs and are identified as
   Web models; capacities come from authoritative model metadata when available.
4. A stopped or unhealthy Web GPT endpoint yields an explicit route error and
   never silently falls back to the Codex Proxy quota.
5. Preserve existing plugin functions, profile providers, and credentials.
6. Investigate and implement the supported Codex Native2 tool bridge so DSH can
   provide tools, approvals, file access, and execution in Codex Web GPT `full`
   mode without claiming equivalence before it is verified.
7. Improve existing code where practical; do not build a second DOM automation
   stack or access browser cookies/tokens.

## Non-goals and limits

- No direct ChatGPT private API, Cookie decryption, or Cloudflare bypass.
- No fallback across Web and Codex quota pools.
- No fake assertion that DSH is the official Codex Desktop app. Compatibility
  should be achieved through the Native2 MCP/tool contract or another supported
  route, with provenance stated accurately.
- Do not change Codex Desktop's `~/.codex/config.toml` or route settings.
- Do not enable remote shell/input or auto-approve tool calls.

## Proposed implementation

Extend `@local/codex-plus-usage`'s existing `cordis.patch.yml` contribution to
the configured `llm-pi-ai` row with provider profiles. Use the provider profile
schema already supported by `@deepseek-ai/dsh-llm-pi-ai`; do not import private
DSH packages from plugin runtime code.

- Codex Proxy: `openai-completions`, loopback base URL 8317, authenticated with
  the existing `CLIPROXYAPI_API_KEY` credential reference, with authenticated
  endpoint model discovery.
- Codex Web GPT cannot yet be registered as a usable direct HTTP provider. Its
  local model route does not accept the stored Web key and needs a supported
  Native2/turn-authenticated call path. Keep the seven cache IDs as discovery
  evidence until the correct route is implemented.
- Codex Proxy uses the existing `CLIPROXYAPI_API_KEY` DSH credential reference;
  values remain in the DSH credential store.
- If the installed DSH model adapter no longer supports Responses, keep the
  plugin and Proxy route usable, omit the Web route with an explicit compatibility
  error, and never substitute a different provider or quota.
- Leave the current `gpt-web` 8321 profile untouched.
- Do not duplicate the plugin row or modify user secrets. Keep configuration
  additive so disabling/removing this bundle removes only its contribution.

For Native2 parity, trace the installed Codex Web GPT tunnel and the actual
`Codex Native2` connector/tool contract. The acceptance threshold for claiming
Full compatibility is the entire tool inventory exposed to the active DSH turn,
with exact names/schemas, turn binding, matching call/result identity,
cancellation, image transfer, workspace context, and the outer Native2 approval
and UI lifecycle. A partial bridge may be developed behind a preview label, but
must not be advertised as Full compatibility. If no supported route gives DSH a
turn-scoped Native2 capability, report that boundary explicitly and do not invent
or persist a `turn_token`. Keep mutations and approvals gated by DSH's existing
authorization.

## Security and reliability

- Bind new listeners to `127.0.0.1`; retain the endpoint's auth model.
- Keep API keys in the existing DSH credential path and never log them or place
  them in a model URL or browser client.
- Fail closed per route when health/auth is missing.
- Set route identity per model so usage accounting cannot confuse Web and Proxy.
- Preserve provider-key uniqueness and avoid mutating the profile's source files
  as a side effect of enabling the plugin.

## Verification and completion criteria

### Automatic model registration

- With the plugin enabled, DSH's provider/model catalog contains both Codex Proxy
  and Codex Web GPT entries without a manual profile model edit.
- Proxy entries match live `GET /v1/models` and a selected model makes a real
  request through 8317.
- Web entries use exact IDs from the live Codex Web GPT catalog/cache; a selected
  Web model makes a real request through 17843.
- Restart/reload and enable/disable checks prove the bundle contribution is
  additive and repeatable.
- Stopping either endpoint produces a route-specific error without cross-quota
  fallback.
- When Responses API support is absent, the Proxy route stays available and the
  Web route is explicitly marked unavailable rather than causing plugin startup
  failure.

### Codex Native2 compatibility

- A real `full` mode run passes a DSH tool call through the Native2 MCP route and
  returns the matching result to the same Web GPT turn.
- Verify one read-only filesystem tool, one shell/tool call requiring approval,
  cancellation, image input, and tool errors, with no false success when tools
  are unavailable.
- Verify DSH approval policy remains authoritative and every action is auditable.
- Test on the actual installed Codex Web GPT and DSH versions; mocks alone are
  insufficient for the final compatibility claim.

## Builder decisions

- Use the current installed DSH/Codex Web GPT protocols and models as the initial
  compatibility target; version-check at runtime before advertising full parity.
- Discover Proxy models from authenticated `/v1/models`; do not replace the
  user-owned `llm-pi-ai` config row with a bundle patch. Prefer an additive DSH
  adapter registration owned by this plugin, if its public API can preserve request
  semantics and live model discovery. The endpoint's client key is
  stored in DSH credentials, never in the bundle.
- Treat the seven `chatgpt-web/*` cache IDs as discovery evidence only. Do not
  advertise them as usable models until a supported authenticated turn path is proven.
- Keep the work in the existing `@local/codex-plus-usage` bundle, since it already
  owns the Proxy lifecycle and is the feature the user wants to enable.
- Do not claim the end goal complete until Native2-compatible end-to-end
  verification passes.

## Runtime revalidation (2026-10-12)

- Correction to the earlier description: historical live evidence in
  `_dsh/ws7/LIVE.md` identifies port 8321 as the legacy CDP ChatGPT-web bridge.
  It exposed 32 web-chat model IDs and produced real web answers, but the live
  run could not select the requested model because Temporary Chat had no model
  picker. It was not the Codex Native2 route, and it has no listener now.
- `gpt-web-adapter/adapter.mjs` is a separate bridge: it listens on 17844 by
  default, accepts only `/v1/responses`, and forwards to 17843. The active DSH
  profile instead declares `openai-completions` at 8321. So the active provider
  does not match either the stopped legacy service or the separate Responses
  adapter.
- The active desktop profile still points `gpt-web` at port 8321, but that port
  has no listener. Its configured 32 static IDs do not establish a working
  connection to Codex Web GPT.
- Codex Web GPT v6.1.8 is live on port 17843. Its `/healthz` is healthy, but
  unauthenticated `/v1/models` returns HTTP 502 with
  `Native Codex passthrough requires the incoming Bearer authorization`.
  `GPT_WEB_LOCAL_KEY` was already verified to be rejected with HTTP 401.
- The plugin's Proxy adapter remains independently registered and does not
  overwrite the profile's `llm-pi-ai` row. Its current targeted Node suite passes
  16/16, including integration with the real DSH LLM runtime. That proves provider
  registration behavior under the test runtime; the live DSH picker and live
  Proxy request remain unverified at this runtime snapshot.
- Current upstream broker protocol v5 confirms `owner_register_safe` is only a
  request reservation. It becomes an executable browser turn only after the
  matching local `surfaceNonce`, an explicit Sent confirmation, and connector
  startup. The mechanism cannot be treated as an implicit plugin-on model route;
  its user-visible handshake and lifecycle must be preserved by any integration.
- The installed `codex-chatgpt-web doctor --json` reports the model route,
  service, embedded browser, tunnel binary, private runtime key, and tunnel
  runtime healthy, but warns it cannot prove the `Codex Native2` connector is
  attached to the tunnel. The browser check proves only that the embedded
  ChatGPT surface is authenticated and reachable; connector attachment remains
  unverified.
- The upstream broker also exposes the regular `owner_register` / `owner_next` /
  `owner_complete` external-owner flow in protocol v5. Unlike
  `owner_register_safe`, this regular flow does not require a Zero Risk
  `surfaceNonce`/manual-send handshake. The active Web UI bridge can initiate the
  ChatGPT turn while DSH owns and services its tool requests through this broker.
- DSH's public `ctx.agents.requireInitiator()` and `ctx.tools.execute()` are
  available from the asynchronous model call chain. `ToolRuntime.execute()` runs
  the registered tool pipeline, including `tools/pre-execute`, approval, guards,
  execution wrappers, post-execute policy, and result finalization. This is a
  candidate path for dispatching Native2 tool calls into the exact active DSH
  Agent without bypassing its approval policy.
- The current Web UI bridge at `_dsh/ws7` uses real ChatGPT web conversations
  and resolves its CDP endpoint from the Codex Web GPT launcher descriptor. DSH
  can avoid the direct Responses `/v1` Bearer requirement by sending through
  that UI bridge, attaching a turn-scoped token and polling the external-owner
  broker. The existing adapter still needs per-model selection fixed, exact
  tool/result correlation, cancellation, and session-visible activity before
  this can be called compatible.
- Connector attachment remains unverified by the installed doctor. A real
  `Codex Native2` MCP call through the connected tunnel is a prerequisite for
  claiming tool compatibility. Next: prototype the adapter/broker loop under
  mocks, then run a single live turn only after the connector is confirmed.

## Live Native2 broker check (2026-10-13)

- Read only `owner_status` against the live named pipe from
  `%USERPROFILE%\.codex-chatgpt-web\config.json`; it returned protocol version
  **5** and `acceptingExternalOwners: true`. No owner or tool turn was created.
- The installed `6.1.8` runtime's `app/cli.js` confirms protocol 5 exposes
  `owner_completion_fence_begin`, `owner_completion_fence_commit`,
  `owner_wait_retirement`, `owner_request_compaction`, and
  `owner_compaction_delivery_count` in addition to the register/next/complete
  calls. `codex-native2-broker.js` now wraps these methods, with tests for fence
  commit, retirement, and compaction state.
- The separate `E:\projects\codex-chatgpt-web` source tree reports
  `protocolVersion: 1` in its `TurnBroker.dispatch()`. It is not the source of
  the live 6.1.8 runtime, so its protocol value must not override the installed
  runtime evidence. Target adapter behavior to the broker actually running on
  this machine and retain a strict version check.
- `node --test test-codex-native2-broker.mjs`: 7/7 pass. Still unverified: the
  `Codex Native2` connector is attached, and a real MCP call is routed through
  DSH's approval/tool pipeline.

## Implementation update (2026-10-13)

- The implemented `codex-web-gpt` route uses the existing CDP web bridge at
  `127.0.0.1:8321` plus the protocol-v5 regular external-owner broker. It does
  not call the authenticated Responses endpoint at `127.0.0.1:17843`.
- Rechecked the live Temporary Chat UI: it now has a model picker, with visible
  labels including `Instant`, `6`, and `GPT-5.6 Sol`. The prior statement that
  the picker was absent is historical and no longer describes the live screen.
  Selection uses exact matching; `GPT-6 Sol` is an explicit alias for `6`, and
  `GPT-6.1 Sol` does not match it.
- Removed the bridge's previous `/api/auth/session` access-token read. `/v1/models`
  now derives entries from visible picker labels and does not include stale
  fallback models when the UI provides a catalog.
- The installed DSH profile includes `@local/codex-plus-usage`, and the Native2
  broker reports protocol v5 with external owners accepted. The running DSH
  process predates the current auto-start changes; port 8321 is not listening,
  so the live process has not loaded the current bridge/provider code.
- Re-ran under DSH's bundled Node `v24.21.0`: the full plugin suite passes
  **37/37**, including the composer-dock client tests, provider registration,
  Native2 broker, exact workspace context, startup, and durable-image projection.
  `gpt-web` is **41 pass, 4 live tests skipped, 0 fail**.
- Live read-only picker discovery now returns four choices (`Instant`, `6`,
  `GPT-5.6 Sol`, and `GPT-5.5 Leaving on October 14`). Passing that live catalog
  through a temporary HTTP bridge into the plugin adapter yields five DSH rows
  (the `GPT-6 Sol` `-wm` slug plus its alias) with display labels intact.
- Two live Temporary Chat checks succeeded: `GPT-6 Sol` selected the exact `6`
  picker item and returned `OK`; an attached synthetic blue-circle PNG selected
  the same model and was described as a blue circle on a white background.
- Image data URLs now pass through message conversion and the bridge's ChatGPT
  composer file-input path, with bounded inline formats and remote URLs rejected.
  Hermetic tests verify MIME/base64 validation, forwarding, temporary-file cleanup,
  and the CDP file-input call. A repository-generated synthetic blue-circle PNG
  was also uploaded in a live Temporary Chat and described correctly.
- HTTP client disconnects now abort queued/running bridge turns, and the browser
  session clicks ChatGPT's Stop control when an active turn is cancelled. Hermetic
  tests cover queue cancellation, active-turn cancellation, and SSE disconnect.
  The plugin adapter test also verifies DSH cancellation aborts the HTTP stream,
  Native2 poll, and owner lifetime. Live cancellation remains untested.
- Still required before claiming completion: reload DSH and verify both routes
  in its live model picker, execute a real Web GPT turn that invokes a Native2
  tool through DSH's approval pipeline, and verify the image path live. General
  file attachments plus session and cancellation behavior also remain open. The
  current mocks do not establish full compatibility.

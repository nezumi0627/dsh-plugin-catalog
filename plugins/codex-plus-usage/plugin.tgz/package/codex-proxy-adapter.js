const DEFAULT_BASE_URL = 'http://127.0.0.1:8317/v1';

/** One additive DSH adapter for the locally authenticated OpenAI-compatible Proxy. */
export function createCodexProxyAdapter({
  baseURL = DEFAULT_BASE_URL,
  resolveApiKey,
  fetchImpl = globalThis.fetch,
  attributionHeaders = () => ({}),
} = {}) {
  if (typeof resolveApiKey !== 'function') throw new TypeError('resolveApiKey is required');
  if (typeof fetchImpl !== 'function') throw new TypeError('fetchImpl is required');
  const root = `${baseURL.replace(/\/+$/, '')}`;

  async function headers(signal) {
    signal?.throwIfAborted();
    const key = await resolveApiKey();
    if (typeof key !== 'string' || key.trim() === '') throw new Error('Codex Proxy credential CLIPROXYAPI_API_KEY is unavailable');
    return { ...attributionHeaders(), authorization: `Bearer ${key.trim()}` };
  }

  async function models(signal) {
    const response = await fetchImpl(`${root}/models`, { headers: await headers(signal), signal });
    if (!response.ok) throw new Error(`Codex Proxy model discovery failed (HTTP ${response.status})`);
    const payload = await response.json();
    if (!Array.isArray(payload?.data)) throw new Error('Codex Proxy returned an invalid model catalog');
    return payload.data
      .filter((model) => typeof model?.id === 'string' && model.id && !model.id.toLowerCase().includes('image'))
      .map((model) => ({ provider: 'codex-proxy', id: model.id, name: model.name || model.id }));
  }

  function messageText(content) {
    if (typeof content === 'string') return content;
    if (!Array.isArray(content)) throw new Error('Codex Proxy adapter received unsupported message content');
    return content.map((block) => {
      if (block?.type !== 'text' || typeof block.text !== 'string') {
        throw new Error('Codex Proxy adapter currently supports text message blocks only');
      }
      return block.text;
    }).join('');
  }

  function toChatMessages(messages = []) {
    return messages.map((message) => {
      if (message.role === 'tool') {
        return {
          role: 'tool',
          tool_call_id: message.toolCallId,
          content: messageText(message.content),
        };
      }
      const blocks = Array.isArray(message.content) ? message.content : [];
      const text = typeof message.content === 'string' ? message.content : blocks
        .filter((block) => block?.type === 'text')
        .map((block) => block.text)
        .join('');
      const calls = blocks.filter((block) => block?.type === 'tool-call').map((block) => ({
        id: block.id,
        type: 'function',
        function: { name: block.name, arguments: block.arguments },
      }));
      if (blocks.some((block) => block?.type !== 'text' && block?.type !== 'tool-call')) {
        throw new Error('Codex Proxy adapter currently supports text and tool-call message blocks only');
      }
      return {
        role: message.role,
        content: text || calls.length ? text || null : '',
        ...(calls.length ? { tool_calls: calls } : {}),
      };
    });
  }

  return {
    providerInfo: (provider) => ({ id: provider, name: 'Codex Proxy' }),
    providerRetryPolicy: () => undefined,
    async listModels(provider) {
      if (provider !== 'codex-proxy') return [];
      return models();
    },
    async resolveModel(provider, model, signal) {
      if (provider !== 'codex-proxy') throw new Error(`Unknown Codex Proxy provider: ${provider}`);
      signal?.throwIfAborted();
      return { provider, id: model, name: model };
    },
    async prepareCall(provider, model, signal) {
      if (provider !== 'codex-proxy') throw new Error(`Unknown Codex Proxy provider: ${provider}`);
      return {
        model: { provider, id: model, name: model },
        stream: (options) => stream(options, model),
      };
    },
    stream: (options) => stream(options, options.model),
  };

  async function* stream(options, model) {
    options.signal?.throwIfAborted();
    const response = await fetchImpl(`${root}/chat/completions`, {
      method: 'POST',
      headers: { ...(await headers(options.signal)), 'content-type': 'application/json', accept: 'text/event-stream' },
      signal: options.signal,
      body: JSON.stringify({
        model,
        stream: true,
        messages: toChatMessages(options.messages),
        ...(options.tools?.length ? { tools: options.tools.map((tool) => ({
          type: 'function',
          function: { name: tool.name, description: tool.description, parameters: tool.parameters },
        })) } : {}),
        ...(options.temperature === undefined ? {} : { temperature: options.temperature }),
        ...(options.maxTokens === undefined ? {} : { max_tokens: options.maxTokens }),
      }),
    });
    if (!response.ok) throw new Error(`Codex Proxy request failed (HTTP ${response.status})`);
    if (!response.body) throw new Error('Codex Proxy returned an empty stream');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let receivedDone = false;
    let textStarted = false;
    let text = '';
    let finishReason = 'stop';
    const toolCalls = new Map();
    try {
      while (true) {
        options.signal?.throwIfAborted();
        const { value, done } = await reader.read();
        buffer += decoder.decode(value, { stream: !done });
        const events = buffer.split(/\r?\n\r?\n/);
        buffer = events.pop() ?? '';
        for (const event of events) {
          for (const line of event.split(/\r?\n/)) {
            if (!line.startsWith('data:')) continue;
            const data = line.slice(5).trim();
            if (data === '[DONE]') { receivedDone = true; break; }
            let payload;
            try { payload = JSON.parse(data); } catch { throw new Error('Codex Proxy returned malformed stream data'); }
            const choice = payload?.choices?.[0];
            const delta = choice?.delta;
            if (choice?.finish_reason) finishReason = choice.finish_reason;
            if (typeof delta?.content === 'string' && delta.content.length) {
              if (!textStarted) {
                textStarted = true;
                yield { type: 'block-start', index: 0, blockType: 'text' };
              }
              text += delta.content;
              yield { type: 'text-delta', index: 0, text: delta.content };
            }
            for (const fragment of delta?.tool_calls ?? []) {
              if (!Number.isInteger(fragment.index) || fragment.index < 0) throw new Error('Codex Proxy returned an invalid tool-call index');
              const state = toolCalls.get(fragment.index) ?? { id: '', name: '', arguments: '', sentArguments: 0, started: false };
              if (typeof fragment.id === 'string') state.id = fragment.id;
              if (typeof fragment.function?.name === 'string') state.name += fragment.function.name;
              if (typeof fragment.function?.arguments === 'string') state.arguments += fragment.function.arguments;
              toolCalls.set(fragment.index, state);
              if (state.id && !state.started) {
                state.started = true;
                yield { type: 'block-start', index: fragment.index + 1, blockType: 'tool-call' };
              }
              if (state.started) {
                const argumentsDelta = state.arguments.slice(state.sentArguments);
                state.sentArguments = state.arguments.length;
                yield { type: 'tool-call-delta', index: fragment.index + 1, id: state.id,
                  ...(state.name ? { name: state.name } : {}), argumentsDelta };
              }
            }
          }
          if (receivedDone) break;
        }
        if (done || receivedDone) break;
      }
    } finally {
      reader.releaseLock();
    }
    if (!receivedDone) throw new Error('Codex Proxy stream ended without a terminal marker');
    if (textStarted) yield { type: 'block-end', index: 0, block: { type: 'text', text } };
    for (const [index, call] of toolCalls) {
      if (!call.id || !call.name || !call.started) throw new Error('Codex Proxy returned an incomplete tool call');
      yield { type: 'block-end', index: index + 1, block: { type: 'tool-call', id: call.id, name: call.name, arguments: call.arguments } };
    }
    yield { type: 'finish', reason: { kind: finishReason === 'tool_calls' ? 'tool-calls' : finishReason === 'length' ? 'max-tokens' : 'stop' } };
  }
}

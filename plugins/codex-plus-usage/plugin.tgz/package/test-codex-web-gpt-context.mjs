import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveDshTurnContext } from './index.js';

function context(mode = 'read-only') {
  const agent = { session: { id: 'session-1', header: { cwd: 'C:/work/project' } } };
  return {
    agents: { requireInitiator: () => agent },
    workspaceRegistry: { list: () => [{ path: 'C:/work', sessionIds: ['session-1'] }] },
    sandboxPolicy: { resolve: ({ session }) => { assert.equal(session, agent.session); return { mode, workspaceRoot: 'C:/work/project' }; } },
  };
}

test('binds Native2 environment to the exact DSH session, workspace, sandbox, and visible tools', () => {
  const ctx = context('workspace-write');
  const tool = { name: 'read_file', description: 'Read a file', parameters: { type: 'object' }, deferLoading: true };
  const resolved = resolveDshTurnContext(ctx, { sessionId: 'session-1', tools: [tool] });
  assert.equal(resolved.agent.session.id, 'session-1');
  assert.deepEqual(resolved.environment, {
    cwd: 'C:\\work\\project', roots: ['C:\\work'], writableRoots: ['C:\\work\\project'],
    sandboxPolicy: { type: 'workspaceWrite', writableRoots: ['C:\\work\\project'], networkAccess: false },
    tools: [{ name: 'read_file', description: 'Read a file', parameters: { type: 'object' } }],
  });
});

test('fails closed when a Native2 call cannot be tied to the exact DSH session workspace', () => {
  assert.throws(() => resolveDshTurnContext(context(), { sessionId: 'session-2', tools: [] }), /exact initiating DSH session/);
  const detached = context();
  detached.workspaceRegistry.list = () => [];
  assert.throws(() => resolveDshTurnContext(detached, { sessionId: 'session-1', tools: [] }), /workspace/);
});

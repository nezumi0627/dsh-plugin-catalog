import { randomUUID } from 'node:crypto';
import { createConnection } from 'node:net';

const MAX_FRAME_BYTES = 64 * 1024 * 1024;
const DEFAULT_TIMEOUT_MS = 15_000;

/** A single request/response over Codex Web GPT's private turn-broker socket. */
function socketRequest(socketPath, frame, { signal, timeoutMs = DEFAULT_TIMEOUT_MS, connect = createConnection } = {}) {
  signal?.throwIfAborted();
  return new Promise((resolve, reject) => {
    let settled = false;
    let response;
    let buffer = Buffer.alloc(0);
    const socket = connect(socketPath);
    const timer = timeoutMs === null ? null : setTimeout(() => {
      socket.destroy(new Error('Codex Native2 turn broker request timed out'));
    }, timeoutMs);
    const cleanup = () => {
      if (timer) clearTimeout(timer);
      signal?.removeEventListener('abort', abort);
      socket.removeAllListeners();
    };
    const finish = (error, value) => {
      if (settled) return;
      settled = true;
      cleanup();
      error ? reject(error) : resolve(value);
    };
    const abort = () => socket.destroy(signal.reason instanceof Error ? signal.reason : new DOMException('Aborted', 'AbortError'));

    socket.once('connect', () => {
      socket.write(`${JSON.stringify(frame)}\n`);
    });
    socket.on('data', (chunk) => {
      if (response) return;
      buffer = Buffer.concat([buffer, chunk]);
      if (buffer.length > MAX_FRAME_BYTES) {
        socket.destroy(new Error('Codex Native2 turn broker response exceeds size limit'));
        return;
      }
      const newline = buffer.indexOf(0x0a);
      if (newline < 0) return;
      try {
        response = JSON.parse(buffer.subarray(0, newline).toString('utf8'));
      } catch {
        socket.destroy(new Error('Codex Native2 turn broker returned invalid JSON'));
        return;
      }
      if (!response || typeof response !== 'object' || Array.isArray(response)
        || response.id !== frame.id
        || (Object.hasOwn(response, 'result') === Object.hasOwn(response, 'error'))
        || (Object.hasOwn(response, 'error') && (typeof response.error !== 'string' || !response.error))) {
        socket.destroy(new Error('Codex Native2 turn broker returned an invalid response frame'));
        return;
      }
    });
    socket.once('error', (error) => finish(error));
    socket.once('close', () => {
      if (!response) {
        finish(new Error('Codex Native2 turn broker closed before replying'));
      } else if (Object.hasOwn(response, 'error')) {
        finish(new Error(response.error));
      } else {
        finish(null, response.result);
      }
    });
    if (signal) {
      signal.addEventListener('abort', abort, { once: true });
      if (signal.aborted) abort();
    }
  });
}

function requireRecord(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`Codex Native2 broker returned invalid ${label}`);
  return value;
}

function requireToken(value, prefix) {
  if (typeof value !== 'string' || !value.startsWith(prefix) || value.length < 20 || value.length > 256) {
    throw new Error(`Codex Native2 broker returned an invalid ${prefix} token`);
  }
  return value;
}

/** Normal protocol-v5 external-owner client; it never uses the Zero Risk/manual contract. */
export function createNative2Broker({ socketPath, connect = createConnection, requestImpl } = {}) {
  if (typeof socketPath !== 'string' || socketPath.trim() === '') throw new TypeError('socketPath is required');
  const call = (method, payload = {}, options = {}) => {
    const frame = { id: randomUUID(), method, ...payload };
    return requestImpl
      ? requestImpl(socketPath, frame, options)
      : socketRequest(socketPath, frame, { ...options, connect });
  };

  return {
    async assertCompatible(signal) {
      const status = requireRecord(await call('owner_status', {}, { signal }), 'status');
      if (status.protocolVersion !== 5) throw new Error(`Unsupported Codex Native2 broker protocol version: ${String(status.protocolVersion)}`);
      if (status.acceptingExternalOwners !== true) throw new Error('Codex Native2 broker is not accepting external owners');
      return status;
    },

    async register(environment, { ttlMs, traceId } = {}) {
      await this.assertCompatible();
      const result = requireRecord(await call('owner_register', {
        environment,
        ...(ttlMs === undefined ? {} : { ttlMs }),
        ...(traceId === undefined ? {} : { traceId }),
      }), 'owner registration');
      return requireToken(result.token, 'turn_');
    },

    async nextToolBatch(token, signal) {
      requireToken(token, 'turn_');
      const result = requireRecord(await call('owner_next', { token }, { signal, timeoutMs: null }), 'tool batch');
      if (!Array.isArray(result.requests) || result.requests.some((item) => {
        if (!item || typeof item !== 'object' || Array.isArray(item)) return true;
        return typeof item.callId !== 'string' || !item.callId
          || typeof item.wireName !== 'string' || !item.wireName
          || typeof item.freeform !== 'boolean'
          || (item.freeform ? typeof item.input !== 'string' : !item.arguments || typeof item.arguments !== 'object' || Array.isArray(item.arguments));
      })) throw new Error('Codex Native2 broker returned an invalid tool batch');
      return result.requests;
    },

    async completeTool(token, callId, toolResult) {
      requireToken(token, 'turn_');
      if (typeof callId !== 'string' || !callId) throw new TypeError('callId is required');
      if (!toolResult || typeof toolResult !== 'object' || !Array.isArray(toolResult.content)) throw new TypeError('toolResult.content is required');
      await call('owner_complete', { token, callId, toolResult });
    },

    async beginCompletionFence(token) {
      requireToken(token, 'turn_');
      const result = requireRecord(await call('owner_completion_fence_begin', { token }), 'completion fence');
      if (result.revision === null) return undefined;
      if (!Number.isSafeInteger(result.revision) || result.revision < 0) throw new Error('Codex Native2 broker returned an invalid completion fence revision');
      return result.revision;
    },

    async commitCompletionFence(token, revision) {
      requireToken(token, 'turn_');
      if (!Number.isSafeInteger(revision) || revision < 0) throw new TypeError('revision must be a non-negative safe integer');
      const result = requireRecord(await call('owner_completion_fence_commit', { token, revision }), 'completion fence result');
      if (typeof result.committed !== 'boolean') throw new Error('Codex Native2 broker returned an invalid completion fence result');
      return result.committed;
    },

    async waitForRetirement(token, signal) {
      requireToken(token, 'turn_');
      const result = requireRecord(await call('owner_wait_retirement', { token }, { signal, timeoutMs: null }), 'retirement');
      if (result.retired !== true) throw new Error('Codex Native2 broker returned an invalid retirement result');
      return result.failure;
    },

    async requestCompaction(token, toolResult) {
      requireToken(token, 'turn_');
      if (!toolResult || typeof toolResult !== 'object' || !Array.isArray(toolResult.content)) throw new TypeError('toolResult.content is required');
      const result = requireRecord(await call('owner_request_compaction', { token, toolResult }), 'compaction result');
      if (!Number.isSafeInteger(result.interrupted) || result.interrupted < 0) throw new Error('Codex Native2 broker returned an invalid compaction interrupt count');
      return result.interrupted;
    },

    async compactionDeliveryCount(token) {
      requireToken(token, 'turn_');
      const result = requireRecord(await call('owner_compaction_delivery_count', { token }), 'compaction delivery count');
      if (!Number.isSafeInteger(result.count) || result.count < 0) throw new Error('Codex Native2 broker returned an invalid compaction delivery count');
      return result.count;
    },

    async revoke(token) {
      requireToken(token, 'turn_');
      await call('owner_revoke', { token });
    },
  };
}


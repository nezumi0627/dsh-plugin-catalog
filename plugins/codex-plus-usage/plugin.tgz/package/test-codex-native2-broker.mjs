import test from 'node:test';
import assert from 'node:assert/strict';
import { createNative2Broker } from './codex-native2-broker.js';

function fakeBroker(respond) {
  const seen = [];
  const client = createNative2Broker({
    socketPath: 'fake-pipe',
    requestImpl: async (_path, request) => {
      seen.push(request);
      return respond(request);
    },
  });
  return { client, seen };
}

test('checks Native2 broker protocol v5 without creating a turn', async () => {
  const { client, seen } = fakeBroker(async () => ({ protocolVersion: 5, acceptingExternalOwners: true }));
  await client.assertCompatible();
  assert.deepEqual(seen.map(({ method }) => method), ['owner_status']);
});

test('rejects an incompatible or draining broker before registering an owner', async () => {
  const { client, seen } = fakeBroker(async () => ({ protocolVersion: 1, acceptingExternalOwners: true }));
  await assert.rejects(client.assertCompatible(), /protocol version/);
  assert.deepEqual(seen.map(({ method }) => method), ['owner_status']);
});

test('registers a normal external owner with the DSH environment and validates its turn token', async () => {
  const environment = {
    cwd: 'C:/work', roots: ['C:/work'], writableRoots: [],
    sandboxPolicy: { type: 'readOnly', networkAccess: false }, tools: [],
  };
  const { client, seen } = fakeBroker(async (request) => request.method === 'owner_status'
    ? { protocolVersion: 5, acceptingExternalOwners: true }
    : { token: 'turn_12345678901234567890' });
  const token = await client.register(environment, { ttlMs: 90_000, traceId: 'dsh_123456' });
  assert.equal(token, 'turn_12345678901234567890');
  assert.match(seen[1].id, /^[0-9a-f-]{36}$/i);
  assert.deepEqual({ method: seen[1].method, environment: seen[1].environment, ttlMs: seen[1].ttlMs, traceId: seen[1].traceId }, {
    method: 'owner_register', environment, ttlMs: 90_000, traceId: 'dsh_123456',
  });
  assert.deepEqual(seen.map(({ method }) => method), ['owner_status', 'owner_register']);
});

test('polls Native2 tool requests and completes the same call with a DSH result', async () => {
  const request = {
    callId: 'call_1', wireName: 'read_file', freeform: false,
    arguments: { path: 'README.md' },
  };
  const result = { content: [{ type: 'text', text: 'contents' }], isError: false };
  const { client, seen } = fakeBroker(async (frame) => {
    if (frame.method === 'owner_next') return { requests: [request] };
    if (frame.method === 'owner_complete') return { completed: true };
    throw new Error(`unexpected ${frame.method}`);
  });
  const token = 'turn_12345678901234567890';
  assert.deepEqual(await client.nextToolBatch(token, new AbortController().signal), [request]);
  await client.completeTool(token, 'call_1', result);
  assert.deepEqual(seen.map(({ method }) => method), ['owner_next', 'owner_complete']);
  assert.equal(seen[1].callId, 'call_1');
  assert.deepEqual(seen[1].toolResult, result);
});

test('preserves completion fences and retirement results for Native2 call correlation', async () => {
  const { client, seen } = fakeBroker(async (request) => {
    if (request.method === 'owner_completion_fence_begin') return { revision: 12 };
    if (request.method === 'owner_completion_fence_commit') return { committed: true };
    if (request.method === 'owner_wait_retirement') return { retired: true };
    throw new Error(`unexpected ${request.method}`);
  });
  const token = 'turn_12345678901234567890';
  const revision = await client.beginCompletionFence(token);
  assert.equal(revision, 12);
  assert.equal(await client.commitCompletionFence(token, revision), true);
  assert.equal(await client.waitForRetirement(token), undefined);
  assert.deepEqual(seen.map(({ method }) => method), [
    'owner_completion_fence_begin', 'owner_completion_fence_commit', 'owner_wait_retirement',
  ]);
});

test('surfaces Native2 compaction interrupts and delivery count', async () => {
  const toolResult = { content: [{ type: 'text', text: 'compact now' }], isError: false };
  const { client, seen } = fakeBroker(async (request) => {
    if (request.method === 'owner_request_compaction') return { interrupted: 2 };
    if (request.method === 'owner_compaction_delivery_count') return { count: 3 };
    throw new Error(`unexpected ${request.method}`);
  });
  const token = 'turn_12345678901234567890';
  assert.equal(await client.requestCompaction(token, toolResult), 2);
  assert.equal(await client.compactionDeliveryCount(token), 3);
  assert.deepEqual(seen.map(({ method }) => method), ['owner_request_compaction', 'owner_compaction_delivery_count']);
  assert.deepEqual(seen[0].toolResult, toolResult);
});

test('refuses to register if external owners are not accepted', async () => {
  const { client, seen } = fakeBroker(async () => ({ protocolVersion: 5, acceptingExternalOwners: false }));
  await assert.rejects(client.assertCompatible(), /not accepting/);
  assert.deepEqual(seen.map(({ method }) => method), ['owner_status']);
});


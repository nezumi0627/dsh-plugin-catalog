#!/usr/bin/env node
/**
 * Client-half test for this bundle (`client.js`): the visibility gate on the two
 * poll loops, and the cleanup that ends them.
 *
 * The composer dock stays mounted in every window, so each tick is two loopback
 * reads against the proxy's management API plus a `setState`, whether or not
 * anyone can see the pill. The loop lives in the effect-owned helper
 * `pollWhileVisible`: it does not start while the document is hidden, and coming
 * back to the window polls once immediately instead of waiting out the period.
 *
 * The bundle is captured the way the Web loader takes it, in a `node:vm` sandbox
 * whose document visibility this test owns. Its own `setInterval` is a recorder,
 * so "does the timer still exist" is an assertion rather than an assumption.
 * Nothing here touches the real proxy, its port 8317, or its credential
 * directory, so the test is safe to run at any time, including while DSH owns a
 * live proxy.
 *
 * This is a separate file from `test-autostart.mjs` on purpose: that one mounts
 * the Host row through the real Cordis runtime, and installing browser globals in
 * that process would change what it is testing.
 *
 *   $node --test codex-plus-usage/test-client.mjs
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import { createContext, runInContext } from 'node:vm';

const SOURCE = readFileSync(new URL('./client.js', import.meta.url), 'utf8');
const MANIFEST = JSON.parse(readFileSync(new URL('./package.json', import.meta.url), 'utf8'));
test('Plus usage registers in the DSH conversation composer dock', () => {
  const harness = makeHarness();
  assert.ok(MANIFEST.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-layout'));
  assert.equal(harness.slot.name, 'conversation.composer.dock');
  assert.equal(harness.slot.id, '@local/codex-plus-usage');
  assert.equal(harness.slot.order, 10);
});

test('the renderer delegates usage requests without embedding the management credential', () => {
  const embedsManagementCredential = /MANAGEMENT_SECRET|Authorization\s*:\s*[`'\"]Bearer/i.test(SOURCE);
  assert.equal(embedsManagementCredential, false, 'renderer contains a management credential');
  assert.match(SOURCE, /__DSH_CODEX_PROXY__/);
  assert.match(SOURCE, /resource=usage/);
  assert.match(SOURCE, /resource=credentials/);
  assert.equal(/127\.0\.0\.1:8317\/v8\/management/.test(SOURCE), false, 'renderer calls proxy management API directly');
});

/** React, with deps-aware effects so an effect that owns a timer can be checked. */
function makeReact() {
  const cells = [];
  let cursor = 0;
  const sameDeps = (previous, next) => (previous === undefined || next === undefined
    ? previous === next
    : previous.length === next.length && previous.every((value, index) => Object.is(value, next[index])));
  return {
    createElement: (type, props, ...children) => ({ type, props: props ?? {}, children: children.flat(Infinity) }),
    Fragment: 'Fragment',
    useState(initial) {
      const index = cursor;
      cursor += 1;
      if (!(index in cells)) cells[index] = typeof initial === 'function' ? initial() : initial;
      return [cells[index], (value) => { cells[index] = typeof value === 'function' ? value(cells[index]) : value; }];
    },
    useRef(initial) {
      const index = cursor;
      cursor += 1;
      if (!(index in cells)) cells[index] = { current: initial };
      return cells[index];
    },
    useCallback(fn) {
      cursor += 1;
      return fn;
    },
    useEffect(fn, deps) {
      const index = cursor;
      cursor += 1;
      const previous = cells[index];
      if (previous !== undefined) {
        if (sameDeps(previous.deps, deps)) return;
        if (typeof previous.cleanup === 'function') previous.cleanup();
      }
      cells[index] = { deps, cleanup: fn() };
    },
    __reset() {
      cursor = 0;
    },
    __read(index) {
      return cells[index];
    },
    /** Unmount the tree: every effect cleanup runs, the way React runs them. */
    __unmount() {
      for (const cell of cells) {
        if (cell !== null && typeof cell === 'object' && typeof cell.cleanup === 'function') cell.cleanup();
      }
    },
  };
}

function makeHarness() {
  const loads = [];
  const fetches = [];
  const intervals = [];
  const listeners = new Set();
  const anchors = [];
  const panels = [];
  const portalTargets = [];
  let outsideDismiss = null;
  const headStyles = [];
  const localStorage = new Map();
  const storage = {
    getItem: (key) => localStorage.get(key) ?? null,
    setItem: (key, value) => localStorage.set(key, value),
  };
  const document = {
    visibilityState: 'visible',
    body: {},
    head: { append(style) { headStyles.push(style); } },
    createElement(tag) {
      return { tagName: tag, attributes: {}, setAttribute(name, value) { this.attributes[name] = value; }, remove() { this.removed = true; } };
    },
    addEventListener(name, listener) {
      if (name === 'visibilitychange') listeners.add(listener);
    },
    removeEventListener(name, listener) {
      if (name === 'visibilitychange') listeners.delete(listener);
    },
  };
  const window = {
    localStorage: storage,
    __ModuleLoader__: { load: (entry) => loads.push(entry) },
    addEventListener() {},
    removeEventListener() {},
  };
  const context = createContext({
    window,
    document,
    console,
    fetch: async (url, init) => {
      fetches.push({ url: String(url), init });
      return { ok: true, status: 200, json: async () => ({}) };
    },
    setInterval: (fn, ms) => {
      intervals.push({ fn, ms, cleared: false });
      return intervals.length;
    },
    clearInterval: (id) => {
      const entry = intervals[id - 1];
      if (entry !== undefined) entry.cleared = true;
    },
    setTimeout,
    clearTimeout,
  });
  runInContext(SOURCE, context);
  assert.equal(loads.length, 1, 'the bundle did not call window.__ModuleLoader__.load');
  const react = makeReact();
  const MenuSurface = function MenuSurface() {};
  const module = loads[0].factory((name) => {
    if (name === 'react') return react;
    if (name === 'react-dom') return { createPortal: (node, target) => { portalTargets.push(target); return { type: 'Portal', props: { target }, children: [node] }; } };
    if (name === '@deepseek-ai/dsh-client-ui-primitives') {
      return {
        MenuSurface,
        useAnchoredPosition: ({ anchorRef, panelRef }) => {
          anchors.push(anchorRef);
          panels.push(panelRef);
          return { left: 12, top: 34 };
        },
        useDismissOnOutsidePointer: (anchorRef, _open, close, panelRef) => {
          outsideDismiss = { anchorRef, close, panelRef };
        },
      };
    }
    throw new Error(`unexpected require: ${name}`);
  });
  const registrations = [];
  const slots = {
    inject(name, apply) {
      assert.equal(name, 'conversation.composer.dock');
      return apply();
    },
    register(descriptor, render) {
      registrations.push({ descriptor, render });
      return () => {};
    },
  };
  module.apply({
    effect(effect) { effect(); },
    slots,
  });
  assert.equal(registrations.length, 1, 'the dock widget did not register itself');
  const { descriptor: slot, render: Dock } = registrations[0];
  return { module, react, Dock, slot, MenuSurface, anchors, panels, portalTargets, getOutsideDismiss: () => outsideDismiss, document, headStyles, localStorage, fetches, intervals, listeners };
}

const flush = () => new Promise((resolve) => setImmediate(resolve));

function findElement(node, predicate) {
  if (node === null || node === undefined || typeof node !== 'object') return null;
  if (predicate(node)) return node;
  for (const child of node.children ?? []) {
    const found = findElement(child, predicate);
    if (found) return found;
  }
  return null;
}

test('the Plus trigger anchors and dismisses its shared menu surface', () => {
  const harness = makeHarness();
  const renderPlus = () => {
    harness.react.__reset();
    const dock = harness.Dock();
    const plus = findElement(dock, (node) => typeof node.type === 'function');
    harness.react.__reset();
    return plus.type(plus.props);
  };

  harness.react.__reset();
  const dock = harness.Dock();
  const plus = findElement(dock, (node) => typeof node.type === 'function');
  const plusComponent = plus.type;
  harness.react.__reset();
  const closed = plusComponent(plus.props);
  assert.equal(harness.headStyles.length, 1, 'widget styles must be installed in document.head');
  assert.match(harness.headStyles[0].textContent, /\.cplus-popover\{position:fixed[^}]*width:min\(320px/);
  assert.match(harness.headStyles[0].textContent, /max-height:min\(70vh,520px\);overflow:hidden/);
  assert.match(harness.headStyles[0].textContent, /\.cplus-body\{min-height:0;overflow:auto;flex:1\}/);
  const trigger = findElement(closed, (node) => node.type === 'button' && node.props.className === 'cplus-pill');
  assert.ok(trigger, 'the Plus trigger is missing');
  assert.equal(trigger.props.ref, harness.anchors.at(-1), 'the trigger itself must anchor the panel');

  const open = plusComponent({ ...plus.props, open: true, setOpen() {} });

  const button = findElement(open, (node) => node.type === 'button' && node.props.className === 'cplus-pill');
  const panel = findElement(open, (node) => node.type === harness.MenuSurface);
  assert.equal(button.props.ref, harness.anchors.at(-1), 'the trigger itself must anchor the panel');
  assert.equal(button.props.title, button.props['aria-label'], 'the trigger must expose the same readable tooltip and accessible name');
  assert.equal(panel?.props.role, 'dialog', 'the shared menu surface must be a dialog');
  const body = findElement(panel, (node) => node.props.className === 'cplus-body');
  const footer = findElement(panel, (node) => node.props.className === 'cplus-foot');
  assert.ok(body, 'long panel details must have a dedicated scroll region');
  assert.ok(footer, 'the update timestamp and button must remain rendered after the scroll region');
  assert.equal(body.children.includes(footer), false, 'the footer must not scroll out of view with the details');
  assert.equal(panel?.props.style?.left, 12, 'the shared anchor geometry must position the panel horizontally');
  assert.equal(panel?.props.style?.top, 34, 'the shared anchor geometry must position the panel vertically');
  assert.equal(panel?.props.style?.position, 'fixed', 'the panel must keep fixed positioning from overriding surface defaults');
  assert.equal(panel?.props.style?.width, 'min(320px, calc(100vw - 32px))', 'the panel must stay compact');
  assert.equal(panel?.props.style?.maxHeight, 'min(70vh, 520px)', 'the panel must stay within viewport height');
  assert.equal(panel?.props.style?.overflow, 'hidden', 'the footer must remain outside the scrolling viewport');
  assert.equal(panel?.props.style?.display, 'flex', 'panel must reserve space for the footer');
  assert.equal(panel?.props.style?.pointerEvents, 'auto', 'the panel must remain interactive in the click-through dock');
  assert.equal(harness.portalTargets.at(-1), harness.document.body, 'the panel must be portaled outside clipped dock containers');
  assert.equal(harness.getOutsideDismiss().anchorRef, button.props.ref, 'outside dismissal must use the trigger as its root');
  assert.equal(harness.getOutsideDismiss().panelRef, harness.panels.at(-1), 'outside dismissal must recognize the portaled panel');
});

test('a saved usage snapshot restores without persisting credentials', () => {
  const harness = makeHarness();
  const key = harness.module.__test__.USAGE_STORAGE_KEY;
  const snapshot = { plan: 'plus', fiveHour: 6, week: 7, totals: { requests: 417 }, observed: '2026-06-18T02:31:00Z' };

  harness.module.__test__.writeUsageSnapshot(snapshot);
  assert.deepEqual(JSON.parse(harness.localStorage.get(key)), snapshot);
  assert.equal(JSON.stringify(harness.module.__test__.readUsageSnapshot()), JSON.stringify(snapshot));
  harness.react.__reset();
  harness.Dock();
  assert.equal(JSON.stringify(harness.react.__read(0)), JSON.stringify(snapshot), 'the plugin must initialize from the saved usage snapshot');
  assert.equal(harness.localStorage.has('management.secret-key'), false);
});

test('the usage poll runs only while the window is on screen', async () => {
  const harness = makeHarness();
  const { REFRESH_MS } = harness.module.__test__;

  // Visible at mount: one immediate refresh (usage + credentials) and the loop.
  harness.react.__reset();
  harness.Dock();
  await flush();
  assert.equal(harness.fetches.length, 2, 'the pill did not refresh once on mount');
  assert.equal(harness.intervals.length, 1, 'expected exactly one poll timer while the panel is closed');
  const [quota] = harness.intervals;
  assert.equal(quota.ms, REFRESH_MS, 'the poll period is not REFRESH_MS');
  assert.equal(REFRESH_MS, 30000, 'the documented cadence changed');

  // Hidden: the timer stops, and nothing is fetched.
  harness.document.visibilityState = 'hidden';
  for (const listener of harness.listeners) listener();
  assert.equal(quota.cleared, true, 'the usage poll kept running in a hidden window');
  assert.equal(harness.fetches.length, 2, 'hiding the window triggered a fetch');

  // Visible again: one immediate refresh, then a fresh period. Waiting out the
  // old 30 s would leave the pill stale for as long as the window was away.
  harness.document.visibilityState = 'visible';
  for (const listener of harness.listeners) listener();
  await flush();
  assert.equal(harness.fetches.length, 4, 'coming back to the window did not refresh once');
  assert.equal(harness.intervals.length, 2, 'coming back did not start the timer again');
  assert.equal(harness.intervals[1].ms, REFRESH_MS);

  // A tick that lands while hidden is a no-op even if a stop was missed.
  harness.document.visibilityState = 'hidden';
  harness.intervals[1].fn();
  await flush();
  assert.equal(harness.fetches.length, 4, 'a tick in a hidden window still polled');
  harness.document.visibilityState = 'visible';
  harness.intervals[1].fn();
  await flush();
  assert.equal(harness.fetches.length, 6, 'a visible tick did not poll');

  // Unmount: the timer and the listener both go away.
  harness.react.__unmount();
  assert.equal(harness.intervals[1].cleared, true, 'unmounting left the usage poll running');
  assert.equal(harness.listeners.size, 0, 'unmounting left the visibilitychange listener behind');
});

/**
 * Host row of the `@local/codex-plus-usage` bundle.
 *
 * The "ChatGPT Plus (codex-proxy)" route in the desktop profile points at
 * http://127.0.0.1:8317/v1, and only our own Go proxy (`<workspace>/codex-proxy`)
 * serves it. This row owns that proxy's lifetime as an event-driven hook — no
 * polling watchdog:
 *
 *   - when the row loads (DSH start) the proxy is started, unless 8317 already
 *     answers `/healthz`;
 *   - when the row is disposed (DSH exit, or a profile reload) the proxy DSH
 *     started is terminated through the subprocess service, whose Windows Job
 *     containment also reaps it when DSH dies without a clean shutdown.
 *
 * A proxy that already answered `/healthz` when the row loaded was not started by
 * DSH, so it is deliberately left alone: this row only ever kills the process it
 * spawned itself. Nothing runs after DSH exits.
 *
 * The usage pill itself lives entirely in `client.js`; this file is the host half
 * of the bundle.
 */
import { randomBytes, timingSafeEqual } from 'node:crypto';
import { appendFileSync, mkdirSync, readFileSync } from 'node:fs';
import { request } from 'node:http';
import { homedir } from 'node:os';
import { dirname, isAbsolute, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createCodexProxyAdapter } from './codex-proxy-adapter.js';
import { createCodexWebGptAdapter } from './codex-web-gpt-adapter.js';
import { createNative2Broker } from './codex-native2-broker.js';

export const name = 'codex-plus-usage';
export const inject = ['subprocess'];

/** Exact HTTP route the usage pill's power button calls; named so it beats the SPA fallback. */
export const ROUTE_PATH = '/local/codex-proxy';
/** Page global carrying the route and this process's token into the GUI. */
export const BOOTSTRAP_KEY = '__DSH_CODEX_PROXY__';
/** Header that proves the caller is the served page, not some other local page. */
export const TOKEN_HEADER = 'x-dsh-codex-proxy-token';
export const MANAGEMENT_SECRET_FILE = join(
  process.env.APPDATA || join(homedir(), 'AppData', 'Roaming'),
  '@deepseek-ai', 'dsh-desktop', 'secrets', 'codex-proxy-management.key',
);
export const NATIVE2_CONFIG_FILE = join(homedir(), '.codex-chatgpt-web', 'config.json');
const PLUGIN_DIR = dirname(fileURLToPath(import.meta.url));
const DEFAULT_WEB_BRIDGE_DIR = resolve(PLUGIN_DIR, '..', 'gpt-web');

/** Defaults; every value can be overridden by the row's `config`. */
const DEFAULTS = {
  exe: 'C:/Users/ren11/Documents/deepseek-harness/default-workspace/codex-proxy/codex-proxy.exe',
  config: 'C:/Users/ren11/AppData/Local/CodexProxy/config.yaml',
  cwd: 'C:/Users/ren11/AppData/Local/CodexProxy',
  healthUrl: 'http://127.0.0.1:8317/healthz',
  logFile: 'C:/Users/ren11/Documents/deepseek-harness/default-workspace/_dsh/codex-proxy-autostart.log',
  managementSecretFile: process.env.DSH_CODEX_PROXY_MANAGEMENT_SECRET_FILE || MANAGEMENT_SECRET_FILE,
  /** How long one start attempt may take to serve `/healthz`. */
  readyTimeoutMs: 15000,
  /** Per-probe HTTP timeout; loopback either answers at once or not at all. */
  probeTimeoutMs: 800,
  pollIntervalMs: 250,
  /** Attempts cover the moment a previous proxy is still releasing the port. */
  startupAttempts: 3,
  /** Grace between terminate() and the provider's force kill. */
  graceMs: 5000,
  /** Extra argv after `-config <file>`; the test moves the listen port with it. */
  args: [],
  webBridgeBaseURL: 'http://127.0.0.1:8321/v1',
  webBridgeNode: 'node',
  webBridgeServer: resolve(DEFAULT_WEB_BRIDGE_DIR, 'server.mjs'),
  webBridgeCwd: DEFAULT_WEB_BRIDGE_DIR,
  webBridgeHealthUrl: 'http://127.0.0.1:8321/healthz',
  webBridgePort: 8321,
  webBridgeReadyTimeoutMs: 15000,
  webBridgeProbeTimeoutMs: 800,
  webBridgeEnabled: true,
  native2ConfigFile: NATIVE2_CONFIG_FILE,
};

/** Resolve the active DSH scope and policy into the Native2 turn environment. */
export function resolveDshTurnContext(ctx, options) {
  const agent = ctx.agents.requireInitiator();
  if (!agent?.session || (options.sessionId && agent.session.id !== options.sessionId)) {
    throw new Error('Codex Web GPT could not resolve the exact initiating DSH session');
  }
  const owners = ctx.workspaceRegistry.list().filter((workspace) => workspace.sessionIds.includes(agent.session.id));
  if (owners.length !== 1) throw new Error(`Codex Web GPT requires one DSH workspace for session ${agent.session.id}`);
  const workspace = owners[0];
  const cwd = agent.session.header?.cwd;
  const root = workspace.path;
  if (typeof cwd !== 'string' || !isAbsolute(cwd) || typeof root !== 'string' || !isAbsolute(root)) {
    throw new Error('Codex Web GPT requires an absolute DSH session cwd and workspace');
  }
  const relativeCwd = relative(resolve(root), resolve(cwd));
  if (relativeCwd === '..' || relativeCwd.startsWith(`..${process.platform === 'win32' ? '\\' : '/'}`) || isAbsolute(relativeCwd)) {
    throw new Error('Codex Web GPT session cwd is outside its DSH workspace');
  }
  const policy = ctx.sandboxPolicy.resolve({ session: agent.session });
  let sandboxPolicy;
  let writableRoots;
  if (policy.mode === 'danger-full-access') {
    sandboxPolicy = { type: 'dangerFullAccess' };
    writableRoots = [root];
  } else if (policy.mode === 'workspace-write') {
    const writable = policy.workspaceRoot;
    const rel = typeof writable === 'string' && isAbsolute(writable) ? relative(resolve(root), resolve(writable)) : '..';
    if (rel === '..' || rel.startsWith(`..${process.platform === 'win32' ? '\\' : '/'}`) || isAbsolute(rel)) {
      throw new Error('Codex Web GPT DSH writable root is outside its workspace');
    }
    writableRoots = [resolve(writable)];
    sandboxPolicy = { type: 'workspaceWrite', writableRoots, networkAccess: false };
  } else {
    writableRoots = [];
    sandboxPolicy = { type: 'readOnly', networkAccess: false };
  }
  const tools = (options.tools ?? []).map(({ name, description, parameters }) => ({ name, description, parameters }));
  if (tools.some((tool) => typeof tool.name !== 'string' || typeof tool.description !== 'string' || !tool.parameters || typeof tool.parameters !== 'object')) {
    throw new Error('Codex Web GPT received an invalid DSH tool schema');
  }
  return {
    agent,
    environment: { cwd: resolve(cwd), roots: [resolve(root)], writableRoots, sandboxPolicy, tools },
  };
}

function readNative2SocketPath(file) {
  try {
    const text = readFileSync(file, 'utf8');
    const match = /"brokerSocketPath"\s*:\s*("(?:\\.|[^"\\])*")/.exec(text);
    if (!match) return null;
    const value = JSON.parse(match[1]);
    return typeof value === 'string' && value.trim() ? value : null;
  } catch {
    return null;
  }
}

/**
 * Append one line to the autostart trace and forward it to the host log.
 * A trace must never be the reason startup fails, so every write is contained.
 */
function trace(options, message) {
  const line = `[${new Date().toISOString()}] ${message}`;
  try {
    mkdirSync(dirname(options.logFile), { recursive: true });
    appendFileSync(options.logFile, `${line}\n`);
  } catch {
    /* the trace is diagnostic only */
  }
  try {
    options.onTrace?.(line);
  } catch {
    /* a logger must never break startup */
  }
}

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Read the proxy's unauthenticated health endpoint.
 * @returns the parsed snapshot, or `null` when nothing answers with 200.
 */
function probe(options) {
  return new Promise((resolve) => {
    const call = request(options.healthUrl, { method: 'GET', timeout: options.probeTimeoutMs }, (response) => {
      if (response.statusCode !== 200) {
        response.resume();
        resolve(null);
        return;
      }
      let body = '';
      response.setEncoding('utf8');
      response.on('data', (chunk) => {
        body += chunk;
      });
      response.on('end', () => {
        try {
          const parsed = JSON.parse(body);
          resolve(parsed && typeof parsed === 'object' ? parsed : {});
        } catch {
          resolve({});
        }
      });
    });
    call.on('timeout', () => {
      call.destroy();
      resolve(null);
    });
    call.on('error', () => resolve(null));
    call.end();
  });
}

/**
 * True when the proxy answers its health endpoint, which means something already
 * owns 127.0.0.1:8317 and no start is needed.
 */
async function healthy(options) {
  return (await probe(options)) !== null;
}

/** A gpt-web 503 still proves that its bridge is listening, even if its browser is unhealthy. */
function probeWebBridge(options) {
  return new Promise((resolve) => {
    const call = request(options.webBridgeHealthUrl, { method: 'GET', timeout: options.webBridgeProbeTimeoutMs }, (response) => {
      let body = '';
      response.setEncoding('utf8');
      response.on('data', (chunk) => { body += chunk; });
      response.on('end', () => {
        try {
          const payload = JSON.parse(body);
          resolve(payload?.service === 'gpt-web' ? payload : null);
        } catch { resolve(null); }
      });
    });
    call.on('timeout', () => { call.destroy(); resolve(null); });
    call.on('error', () => resolve(null));
    call.end();
  });
}

async function webBridgeSpawnOnce(ctx, options) {
  const executable = await ctx.subprocess.resolveExecutable(options.webBridgeNode);
  const handle = ctx.subprocess.spawn({
    argv: [executable, options.webBridgeServer],
    cwd: options.webBridgeCwd,
    env: { GPT_WEB_HOST: '127.0.0.1', GPT_WEB_PORT: String(options.webBridgePort) },
    stdio: { stdin: 'ignore', stdout: { maxBytes: 262144 }, stderr: { maxBytes: 262144 } },
    graceMs: options.graceMs,
  });
  let outcome;
  let failure;
  handle.done.then((value) => { outcome = value; }, (error) => { failure = error; });
  const deadline = Date.now() + options.webBridgeReadyTimeoutMs;
  while (Date.now() < deadline) {
    if (outcome !== undefined || failure !== undefined) break;
    if (await probeWebBridge(options)) return handle;
    await delay(options.pollIntervalMs);
  }
  if (outcome === undefined && failure === undefined) {
    trace(options, 'gpt-web is alive but /healthz has not answered yet; leaving it running');
    return handle;
  }
  const reason = failure ? `could not be spawned (${failure.message})`
    : `exited before it served (code ${outcome.exitCode}${outcome.signal ? `, signal ${outcome.signal}` : ''})`;
  const stderr = streamTail(handle, 'stderr') || streamTail(handle, 'stdout');
  await terminate(handle);
  throw new Error(`gpt-web ${reason}${stderr ? `: ${stderr}` : ''}`);
}

async function ensureWebBridge(ctx, options) {
  if (await probeWebBridge(options)) {
    trace(options, 'gpt-web bridge is already listening; DSH attaches without owning it');
    return null;
  }
  let lastError;
  for (let attempt = 1; attempt <= options.startupAttempts; attempt += 1) {
    try {
      const handle = await webBridgeSpawnOnce(ctx, options);
      trace(options, `gpt-web started (attempt ${attempt}) from ${options.webBridgeServer}`);
      return handle;
    } catch (error) {
      lastError = error;
      trace(options, `gpt-web start attempt ${attempt}/${options.startupAttempts} failed: ${error.message}`);
      if (attempt < options.startupAttempts) await delay(attempt * 1000);
    }
  }
  throw lastError;
}

/** What the GUI's power button renders: serving now, starting, and whether DSH owns it. */
async function status(options, state) {
  const snapshot = await probe(options);
  return {
    running: snapshot !== null,
    starting: state.inflight !== null,
    owned: state.handle !== null,
    version: typeof snapshot?.version === 'string' ? snapshot.version : null,
    uptimeSeconds: Number.isFinite(snapshot?.uptime_seconds) ? snapshot.uptime_seconds : null,
    credentials: Number.isFinite(snapshot?.credentials) ? snapshot.credentials : null,
    models: Number.isFinite(snapshot?.models) ? snapshot.models : null,
  };
}

/** The token is a same-origin capability: only the served page carries it. */
function authorized(req, token) {
  const site = req?.headers?.['sec-fetch-site'];
  if (typeof site === 'string' && site === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
}

function readManagementSecret(options) {
  if (typeof options.managementSecret === 'string' && options.managementSecret.trim() !== '') {
    return options.managementSecret.trim();
  }
  try {
    const secret = readFileSync(options.managementSecretFile || DEFAULTS.managementSecretFile, 'utf8').replace(/^\uFEFF/, '').trim();
    return secret || null;
  } catch {
    return null;
  }
}

const MANAGEMENT_RESOURCES = Object.freeze({
  usage: '/v8/management/usage',
  credentials: '/v8/management/credentials',
});

function requestManagement(options, secret, resource) {
  const endpoint = MANAGEMENT_RESOURCES[resource];
  if (!endpoint) return Promise.reject(new Error('unsupported management resource'));
  const base = new URL(options.healthUrl);
  return new Promise((resolve, reject) => {
    let body = '';
    let size = 0;
    const upstream = request({
      hostname: '127.0.0.1',
      port: Number(base.port) || 8317,
      path: endpoint,
      method: 'GET',
      headers: { authorization: `Bearer ${secret}`, accept: 'application/json' },
    }, (response) => {
      response.setEncoding('utf8');
      response.on('data', (chunk) => {
        size += Buffer.byteLength(chunk);
        if (size > 1024 * 1024) {
          response.destroy(new Error('management response too large'));
          return;
        }
        body += chunk;
      });
      response.on('end', () => {
        if (response.statusCode < 200 || response.statusCode >= 300) {
          reject(new Error('management API unavailable'));
          return;
        }
        try { resolve(JSON.parse(body)); } catch { reject(new Error('invalid management response')); }
      });
      response.on('error', reject);
    });
    upstream.setTimeout(5000, () => upstream.destroy(new Error('management API timeout')));
    upstream.on('error', reject);
    upstream.end();
  });
}

/**
 * Exact-route handler behind the usage pill's power button: `GET` reports the
 * proxy's state, `POST` starts it through the same path boot uses (so a proxy
 * started from the GUI is still owned by, and dies with, DSH).
 */
export function createRouteHandler(options, state, ensure, token, fetchManagement = requestManagement) {
  return async function codexProxyRoute(req, res) {
    const send = (code, payload) => {
      res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
      res.end(JSON.stringify(payload));
    };
    if (!authorized(req, token)) {
      send(403, { ok: false, error: 'forbidden' });
      return;
    }
    try {
      if (req.method === 'GET' || req.method === 'HEAD') {
        const resource = new URL(req.url || ROUTE_PATH, 'http://dsh.local').searchParams.get('resource');
        if (resource !== null) {
          if (req.method !== 'GET' || !Object.hasOwn(MANAGEMENT_RESOURCES, resource)) {
            send(400, { ok: false, error: 'unsupported-resource' });
            return;
          }
          const secret = readManagementSecret(options);
          if (!secret) {
            send(503, { ok: false, error: 'management-key-unavailable' });
            return;
          }
          try {
            send(200, { ok: true, data: await fetchManagement(options, secret, resource) });
          } catch {
            send(502, { ok: false, error: 'management-api-unavailable' });
          }
          return;
        }
        send(200, { ok: true, data: await status(options, state) });
        return;
      }
      if (req.method !== 'POST') {
        send(405, { ok: false, error: 'method-not-allowed' });
        return;
      }
      let error = null;
      try {
        await ensure();
      } catch (failure) {
        error = failure instanceof Error ? failure.message : String(failure);
      }
      const data = await status(options, state);
      if (!data.running) {
        send(502, { ok: false, error: error ?? 'codex-proxy is not running', data });
        return;
      }
      send(200, { ok: true, data: { ...data, error } });
    } catch (failure) {
      send(500, { ok: false, error: failure instanceof Error ? failure.message : String(failure) });
    }
  };
}

/** Inject the route and token into the served index so only the GUI page can call it. */
export function injectBootstrap(html, token) {
  if (typeof html !== 'string') return html;
  const payload = JSON.stringify({ path: ROUTE_PATH, token }).replace(/</g, '\\u003c');
  const script = `<script>window.${BOOTSTRAP_KEY}=${payload};</script>`;
  const headEnd = html.search(/<\/head>/i);
  if (headEnd === -1) return `${html}${script}`;
  return `${html.slice(0, headEnd)}${script}${html.slice(headEnd)}`;
}

/** Bounded tail of one collected stream, for a failure message. */
function streamTail(handle, stream, maxChars = 600) {
  try {
    return (handle.collected?.[stream]?.readFrom(0)?.text ?? '').trim().slice(-maxChars);
  } catch {
    return '';
  }
}

/** Stop one managed process and wait for its range to go quiet. Idempotent. */
async function terminate(handle) {
  if (!handle) return;
  try {
    await handle.terminate();
    await handle.waitForExit();
  } catch {
    /* already gone, or the provider cannot prove quiescence */
  }
}

/**
 * Start one proxy process and wait for `/healthz`.
 *
 * Resolves with the live handle once the proxy serves (or while it is still
 * alive and merely slow). Rejects when the process died before serving, which is
 * what a port still held by a shutting-down predecessor looks like — the caller
 * then retries.
 */
async function spawnOnce(ctx, options) {
  const executable = await ctx.subprocess.resolveExecutable(options.exe);
  const handle = ctx.subprocess.spawn({
    argv: [executable, '-config', options.config, ...options.args],
    cwd: options.cwd,
    stdio: { stdin: 'ignore', stdout: { maxBytes: 262144 }, stderr: { maxBytes: 262144 } },
    graceMs: options.graceMs,
  });

  let outcome;
  let failure;
  // `done` rejects for spawn/provider failures; both handlers keep it observed.
  handle.done.then(
    (value) => {
      outcome = value;
    },
    (error) => {
      failure = error;
    },
  );

  const deadline = Date.now() + options.readyTimeoutMs;
  while (Date.now() < deadline) {
    if (outcome !== undefined || failure !== undefined) break;
    if (await healthy(options)) return handle;
    await delay(options.pollIntervalMs);
  }

  if (outcome === undefined && failure === undefined) {
    trace(options, 'codex-proxy is alive but /healthz has not answered yet; leaving it running');
    return handle;
  }

  const reason = failure
    ? `could not be spawned (${failure.message})`
    : `exited before it served (code ${outcome.exitCode}${outcome.signal ? `, signal ${outcome.signal}` : ''})`;
  const stderr = streamTail(handle, 'stderr') || streamTail(handle, 'stdout');
  await terminate(handle);
  throw new Error(`codex-proxy ${reason}${stderr ? `: ${stderr}` : ''}`);
}

/**
 * Ensure the proxy is running.
 * @returns the handle DSH owns, or `null` when a proxy was already serving and
 * was therefore adopted without ownership.
 * @throws when no attempt produced a serving proxy.
 */
async function ensureRunning(ctx, options) {
  if (await healthy(options)) {
    trace(options, '/healthz already answers; a proxy is running, so DSH attaches without owning it');
    return null;
  }
  let lastError;
  for (let attempt = 1; attempt <= options.startupAttempts; attempt += 1) {
    try {
      const handle = await spawnOnce(ctx, options);
      trace(options, `codex-proxy started (attempt ${attempt}) from ${options.exe}`);
      return handle;
    } catch (error) {
      lastError = error;
      trace(options, `start attempt ${attempt}/${options.startupAttempts} failed: ${error.message}`);
      if (attempt < options.startupAttempts) await delay(attempt * 1000);
    }
  }
  throw lastError;
}

/**
 * Start the proxy while this row is loaded and stop it when the row is disposed.
 * Startup runs off the boot path: the effect returns as soon as it registered a
 * disposer, and Cordis awaits the launch before running that disposer.
 *
 * The GUI's power button starts the proxy through the same `ensure`, so a proxy
 * started from the page lands in the same ownership slot and is still reaped when
 * DSH exits. `state.inflight` collapses a boot start and a click into one attempt.
 */
export function apply(ctx, config) {
  const options = {
    ...DEFAULTS,
    ...(config ?? {}),
    onTrace: (line) => ctx.logger?.info?.(`[codex-plus-usage] ${line}`),
  };
  const state = { handle: null, inflight: null, webBridgeHandle: null };

  // Register an independent provider route. The plugin owns only this route;
  // it never edits or replaces the profile's llm-pi-ai configuration.
  ctx.inject(['llm', 'credentials'], (llmCtx) => {
    const adapter = createCodexProxyAdapter({
      baseURL: options.providerBaseURL || 'http://127.0.0.1:8317/v1',
      resolveApiKey: async () => (await llmCtx.credentials.resolve('CLIPROXYAPI_API_KEY'))?.value,
      attributionHeaders: () => ({ 'user-agent': 'deepseek-harness/0.2.0-rc.2 (+https://github.com/deepseek-ai/deepseek-harness)' }),
    });
    llmCtx.effect(
      () => llmCtx.llm.registerAdapter(['codex-proxy'], adapter),
      'codex-plus-usage: Codex Proxy model provider',
    );
  });

  ctx.inject(['llm', 'agents', 'tools', 'workspaceRegistry', 'sandboxPolicy', 'attachments'], (llmCtx) => {
    const socketPath = readNative2SocketPath(options.native2ConfigFile);
    if (!socketPath) {
      trace(options, `Codex Web GPT provider not registered: brokerSocketPath is missing from ${options.native2ConfigFile}`);
      return;
    }
    const broker = createNative2Broker({ socketPath });
    const adapter = createCodexWebGptAdapter({
      baseURL: options.webBridgeBaseURL,
      broker,
      getTurnContext: (requestOptions) => ({
        ...resolveDshTurnContext(llmCtx, requestOptions),
        attachments: llmCtx.attachments,
      }),
      executeTool: (execution) => llmCtx.tools.execute(execution),
    });
    llmCtx.effect(
      () => llmCtx.llm.registerAdapter(['codex-web-gpt'], adapter),
      'codex-plus-usage: Codex Web GPT model provider',
    );
  });

  const ensure = () => {
    if (state.inflight) return state.inflight;
    const run = ensureRunning(ctx, options).then((owned) => {
      if (owned) state.handle = owned;
      return owned;
    });
    state.inflight = run;
    const clear = () => {
      if (state.inflight === run) state.inflight = null;
    };
    run.then(clear, clear);
    return run;
  };

  ctx.logger?.info?.('[codex-plus-usage] Host plugin active');

  ctx.effect(async () => {
    try {
      await ensure();
    } catch (error) {
      // A missing proxy degrades this route only; DSH itself must still start.
      trace(options, `gave up starting codex-proxy: ${error.message}`);
      return;
    }
    return async () => {
      const owned = state.handle;
      state.handle = null;
      if (!owned) return;
      trace(options, 'DSH is disposing this row; stopping the codex-proxy DSH started');
      await terminate(owned);
    };
  }, 'codex-plus-usage: codex-proxy lifetime');

  ctx.effect(async () => {
    if (!options.webBridgeEnabled) return;
    try {
      const handle = await ensureWebBridge(ctx, options);
      if (handle) state.webBridgeHandle = handle;
    } catch (error) {
      trace(options, `gave up starting gpt-web: ${error.message}`);
      return;
    }
    return async () => {
      const owned = state.webBridgeHandle;
      state.webBridgeHandle = null;
      if (!owned) return;
      trace(options, 'DSH is disposing this row; stopping the gpt-web bridge DSH started');
      await terminate(owned);
    };
  }, 'codex-plus-usage: gpt-web bridge lifetime');

  // Optional service: a profile without a web server (a CLI run) keeps the
  // lifetime hook and simply has no power button behind it.
  ctx.inject(['webServer'], (webCtx) => {
    const token = randomBytes(32).toString('hex');
    webCtx.effect(
      () => webCtx.webServer.register({ kind: 'exact', path: ROUTE_PATH, handler: createRouteHandler(options, state, ensure, token) }),
      'codex-plus-usage: proxy route',
    );
    webCtx.effect(() => webCtx.webServer.tapIndex((html) => injectBootstrap(html, token)), 'codex-plus-usage: page bootstrap');
  });
}

#!/usr/bin/env node
/**
 * Host-row test for this bundle (`index.js`): the lifetime hook and the power
 * button's route.
 *
 * The row is loaded through the real Cordis runtime that ships inside DSH, with a
 * stub `ctx.subprocess` provider standing in for `@deepseek-ai/dsh-subprocess-local`
 * and a stub `ctx.webServer` standing in for `@deepseek-ai/dsh-host-webserver`.
 * The stubs record the exact requests the row makes — so the real executable,
 * configuration path, route path and page token are asserted — while the process
 * actually run is a throwaway Node HTTP server that answers `/healthz`. Nothing
 * here touches the real proxy, its port 8317, or its credential directory, so the
 * test is safe to run at any time, including while DSH owns a live proxy.
 *
 * Covered: boot starts the proxy; a proxy that is already serving is adopted
 * without a second start and survives disposal of the adopting row; an attempt
 * that dies before serving is retried; every attempt failing degrades quietly
 * instead of breaking the host; disposal reaps the process the row started; the
 * route is exact, refuses a caller without the page token, reports the state, and
 * starts a proxy that died mid-session while still owning what it started.
 *
 *   $node codex-plus-usage/test-autostart.mjs
 */
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { createServer, request } from 'node:http';
import net from 'node:net';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { after, test } from 'node:test';

/** The DSH runtime's own packages, used exactly as the desktop host loads them. */
const ASAR = 'C:/Users/ren11/Documents/deepseek-harness/default-workspace/_asar_full/dsh/node_modules/@deepseek-ai';
const { Context, Service } = await import(pathToFileURL(`${ASAR}/cordis/lib/index.js`).href);
const { SubprocessRuntime } = await import(pathToFileURL(`${ASAR}/dsh-subprocess/lib/index.js`).href);
const { LlmRuntime } = await import(pathToFileURL(`${ASAR}/dsh-llm/lib/index.js`).href);
const plugin = await import(new URL('./index.js', import.meta.url).href);

/** The real artifacts the row must name when DSH owns the proxy. */
const EXE = 'C:/Users/ren11/Documents/deepseek-harness/default-workspace/codex-proxy/codex-proxy.exe';
const CONFIG = 'C:/Users/ren11/AppData/Local/CodexProxy/config.yaml';
const EXPECTED_STDIO = { stdin: 'ignore', stdout: { maxBytes: 262144 }, stderr: { maxBytes: 262144 } };

/** What the stub provider runs instead of the real proxy. */
const FAKE_PROXY = `
const http = require('node:http');
if (process.env.STUB_PROXY_EXIT === '1') process.exit(1);
const server = http.createServer((req, res) => {
  if (req.url === '/healthz') {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end('{"status":"ok"}');
    return;
  }
  res.writeHead(404);
  res.end();
});
server.listen(Number(process.env.STUB_PROXY_PORT), '127.0.0.1', () => process.stderr.write('fake proxy listening\\n'));
`;
const FAKE_WEB_BRIDGE = `
const http = require('node:http');
const server = http.createServer((req, res) => {
  if (req.url === '/healthz') {
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end('{"service":"gpt-web","version":"test","ok":true}');
    return;
  }
  res.writeHead(404);
  res.end();
});
server.listen(Number(process.env.STUB_PROXY_PORT), '127.0.0.1');
`;

const workDir = mkdtempSync(join(tmpdir(), 'codex-plus-usage-'));
const mounted = [];
let caseId = 0;
// A failed assertion must not leave a managed process (and its open pipes)
// behind: that would keep this process alive instead of reporting the failure.
after(async () => {
  for (const root of mounted) {
    try {
      await root.fiber.dispose();
    } catch {
      /* already disposed by the test itself */
    }
  }
  rmSync(workDir, { recursive: true, force: true });
});

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/** One bounded collected stream, shaped like the subprocess service's reader. */
class Collector {
  constructor(limit) {
    this.limit = limit;
    this.text = '';
  }

  push(chunk) {
    this.text = (this.text + chunk).slice(-this.limit);
  }

  readFrom() {
    return { text: this.text };
  }
}

/** `ctx.subprocess` with the same shape and semantics the row relies on. */
class StubSubprocess extends SubprocessRuntime {
  constructor(ctx, config) {
    super(ctx, 'subprocess');
    this.mode = config?.mode ?? 'serves';
    this.port = config?.port;
    this.spawns = [];
    this.live = new Set();
  }

  async resolveExecutable(command) {
    this.resolved = command;
    return command;
  }

  spawn(spec) {
    const attempt = this.spawns.length + 1;
    this.spawns.push(spec);
    const isWebBridge = typeof spec.env?.GPT_WEB_PORT === 'string';
    const env = { ...process.env, STUB_PROXY_PORT: isWebBridge ? spec.env.GPT_WEB_PORT : String(this.port) };
    if (this.mode === 'dies-always' || (this.mode === 'dies-once' && attempt === 1)) env.STUB_PROXY_EXIT = '1';
    const child = spawn(process.execPath, ['-e', isWebBridge ? FAKE_WEB_BRIDGE : FAKE_PROXY], {
      cwd: spec.cwd,
      env,
      stdio: ['ignore', 'pipe', 'pipe'],
      windowsHide: true,
    });
    const stdout = new Collector(65536);
    const stderr = new Collector(65536);
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', (chunk) => stdout.push(chunk));
    child.stderr.setEncoding('utf8');
    child.stderr.on('data', (chunk) => stderr.push(chunk));
    const done = new Promise((resolve, reject) => {
      child.once('error', reject);
      child.once('exit', (exitCode, signal) => resolve({ exitCode, signal }));
    });
    const handle = {
      collected: { stdout, stderr },
      done,
      async terminate() {
        if (child.exitCode === null && child.signalCode === null) child.kill();
      },
      async waitForExit() {
        await done.catch(() => {});
      },
    };
    this.live.add(handle);
    done.then(
      () => this.live.delete(handle),
      () => this.live.delete(handle),
    );
    return handle;
  }
}

async function freePort() {
  const server = net.createServer();
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  await new Promise((resolve) => server.close(resolve));
  return port;
}

/**
 * `ctx.webServer` with the two behaviours the row depends on: a duplicate path
 * throws (the shipped service's contract, so a second row of this bundle cannot
 * silently steal the route), and both registration and the index tap return a
 * disposer.
 */
class StubWebServer extends Service {
  constructor(ctx) {
    super(ctx, 'webServer');
    this.routes = [];
    this.taps = [];
  }

  register(route) {
    if (this.routes.some((existing) => existing.path === route.path)) throw new Error(`duplicate path: ${route.path}`);
    this.routes.push(route);
    return () => {
      this.routes = this.routes.filter((existing) => existing !== route);
    };
  }

  tapIndex(transform) {
    this.taps.push(transform);
    return () => {
      this.taps = this.taps.filter((existing) => existing !== transform);
    };
  }
}

class StubLlm extends Service {
  constructor(ctx) { super(ctx, 'llm'); this.registrations = []; }
  registerAdapter(providers, adapter) {
    const item = { providers, adapter };
    this.registrations.push(item);
    return () => { this.registrations = this.registrations.filter((entry) => entry !== item); };
  }
}

class StubCredentials extends Service {
  constructor(ctx) { super(ctx, 'credentials'); }
  async resolve(name) { return name === 'CLIPROXYAPI_API_KEY' ? { value: 'test-secret' } : undefined; }
}

class StubAgents extends Service {
  constructor(ctx) { super(ctx, 'agents'); }
  requireInitiator() { return { session: { id: 'session-1', header: { cwd: workDir } } }; }
}

class StubTools extends Service {
  constructor(ctx) { super(ctx, 'tools'); }
  async execute() { return { content: [], isError: false }; }
}

class StubWorkspaceRegistry extends Service {
  constructor(ctx) { super(ctx, 'workspaceRegistry'); }
  list() { return [{ path: workDir, sessionIds: ['session-1'] }]; }
}

class StubSandboxPolicy extends Service {
  constructor(ctx) { super(ctx, 'sandboxPolicy'); }
  resolve() { return { mode: 'read-only', workspaceRoot: workDir }; }
}

class StubAttachments extends Service {
  constructor(ctx) { super(ctx, 'attachments'); }
  async readImageRequest(ref, target) { return { mediaType: ref.mediaType, data: new Uint8Array(target.width * target.height) }; }
}

/** `/healthz` status of a live endpoint, or null when nothing answers. */
function healthStatus(port) {
  return new Promise((resolve) => {
    const probe = request(`http://127.0.0.1:${port}/healthz`, { method: 'GET', timeout: 500 }, (response) => {
      response.resume();
      resolve(response.statusCode);
    });
    probe.on('timeout', () => {
      probe.destroy();
      resolve(null);
    });
    probe.on('error', () => resolve(null));
    probe.end();
  });
}

async function waitFor(predicate, timeoutMs, label) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    if (await predicate()) return;
    await delay(100);
  }
  throw new Error(`timed out after ${timeoutMs}ms waiting for ${label}`);
}

/** Mount the row with a fresh port, work directory, and trace file. */
async function mount(mode, { port: given, web = true, config: extraConfig = {} } = {}) {
  const port = given ?? (await freePort());
  const root = new Context();
  await root.plugin(StubSubprocess, { mode, port });
  if (web) await root.plugin(StubWebServer);
  const stub = root.get('subprocess');
  const logFile = join(workDir, `trace-${(caseId += 1)}-${mode}.log`);
  const config = {
    exe: EXE,
    config: CONFIG,
    cwd: workDir,
    healthUrl: `http://127.0.0.1:${port}/healthz`,
    logFile,
    readyTimeoutMs: 5000,
    probeTimeoutMs: 200,
    pollIntervalMs: 50,
    args: [],
    webBridgeEnabled: false,
    ...extraConfig,
  };
  const fiber = await root.plugin({ ...plugin }, config);
  mounted.push(root);
  return { root, stub, fiber, port, logFile, config, web: web ? root.get('webServer') : null };
}

/** Drive one registered route exactly as `node:http` would. */
async function callRoute(handler, method, headers = {}) {
  const out = {};
  await handler({ method, headers }, {
    writeHead(code, responseHeaders) {
      out.code = code;
      out.headers = responseHeaders;
    },
    end(body) {
      out.body = JSON.parse(body);
    },
  });
  return out;
}

/** Recover the token from the markup the row injects into the served page. */
function routeToken(web) {
  assert.equal(web.taps.length, 1, 'the page bootstrap was not registered');
  const html = web.taps[0]('<html><head></head><body></body></html>');
  const match = /<script>window\.__DSH_CODEX_PROXY__=(\{[^<]*?\});<\/script>/.exec(html);
  assert.ok(match, 'the page bootstrap was not injected into the index');
  const boot = JSON.parse(match[1]);
  assert.equal(boot.path, '/local/codex-proxy');
  assert.equal(typeof boot.token, 'string');
  return boot.token;
}

const traceOf = (logFile) => readFileSync(logFile, 'utf8');

test('boot starts the proxy with the real executable and configuration', async () => {
  const { root, stub, port, logFile } = await mount('serves');
  await waitFor(async () => (await healthStatus(port)) === 200, 10000, 'the started proxy to serve /healthz');

  assert.equal(stub.spawns.length, 1);
  assert.equal(stub.resolved, EXE);
  assert.deepEqual(stub.spawns[0].argv, [EXE, '-config', CONFIG]);
  assert.equal(stub.spawns[0].cwd, workDir);
  assert.deepEqual(stub.spawns[0].stdio, EXPECTED_STDIO);
  // The row traces only after its own await resumes, which can trail the first
  // healthy answer the test observed.
  await waitFor(() => /codex-proxy started \(attempt 1\)/.test(safeTrace(logFile)), 5000, 'the start to be traced');

  await root.fiber.dispose();
  await waitFor(async () => (await healthStatus(port)) === null, 10000, 'the proxy to be reaped on disposal');
  assert.equal(stub.live.size, 0, 'disposal must leave no live managed process');
  assert.match(safeTrace(logFile), /stopping the codex-proxy DSH started/);
});

test('plugin activation starts and owns the loopback gpt-web bridge', async () => {
  const proxyPort = await freePort();
  const bridgePort = await freePort();
  const { root, stub, fiber } = await mount('serves', {
    port: proxyPort,
    config: {
      webBridgeEnabled: true, webBridgePort: bridgePort,
      webBridgeHealthUrl: `http://127.0.0.1:${bridgePort}/healthz`,
      webBridgeProbeTimeoutMs: 200, webBridgeReadyTimeoutMs: 5000,
      webBridgeServer: 'C:/workspace/gpt-web/server.mjs', webBridgeCwd: workDir,
    },
  });
  try {
    await waitFor(async () => (await healthStatus(bridgePort)) === 200, 10000, 'gpt-web bridge to serve /healthz');
  } catch (error) {
    throw new Error(`${error.message}; spawns=${JSON.stringify(stub.spawns)}`);
  }
  const webSpawn = stub.spawns.find((spec) => typeof spec.env?.GPT_WEB_PORT === 'string');
  assert.deepEqual(webSpawn.argv, ['node', 'C:/workspace/gpt-web/server.mjs']);
  assert.equal(webSpawn.cwd, workDir);
  assert.equal(webSpawn.env.GPT_WEB_HOST, '127.0.0.1');
  assert.equal(webSpawn.env.GPT_WEB_PORT, String(bridgePort));
  await fiber.dispose();
  await waitFor(async () => (await healthStatus(bridgePort)) === null, 10000, 'gpt-web bridge to stop on disposal');
});

test('enabling the plugin registers an independent live-catalog Codex Proxy provider', async () => {
  const port = await freePort();
  const root = new Context();
  await root.plugin(StubSubprocess, { mode: 'serves', port });
  await root.plugin(StubLlm);
  await root.plugin(StubCredentials);
  const config = {
    exe: EXE, config: CONFIG, cwd: workDir, healthUrl: `http://127.0.0.1:${port}/healthz`,
    logFile: join(workDir, 'trace-provider-registration.log'), readyTimeoutMs: 5000,
    probeTimeoutMs: 200, pollIntervalMs: 50, args: [], webBridgeEnabled: false,
  };
  const fiber = await root.plugin({ ...plugin }, config);
  mounted.push(root);
  await waitFor(() => root.get('llm').registrations.length === 1, 1000, 'Codex Proxy adapter registration');
  const [{ providers, adapter }] = root.get('llm').registrations;
  assert.deepEqual(providers, ['codex-proxy']);
  assert.equal(adapter.providerInfo('codex-proxy').name, 'Codex Proxy');
  assert.equal(await root.get('credentials').resolve('CLIPROXYAPI_API_KEY').then((item) => item.value), 'test-secret');
  await fiber.dispose();
  assert.equal(root.get('llm').registrations.length, 0);
});

test('the real DSH LLM runtime lists and disposes the plugin-owned provider route', async () => {
  const port = await freePort();
  const root = new Context();
  await root.plugin(StubSubprocess, { mode: 'serves', port });
  await root.plugin(LlmRuntime);
  await root.plugin(StubCredentials);
  const config = {
    exe: EXE, config: CONFIG, cwd: workDir, healthUrl: `http://127.0.0.1:${port}/healthz`,
    logFile: join(workDir, 'trace-real-provider-registration.log'), readyTimeoutMs: 5000,
    probeTimeoutMs: 200, pollIntervalMs: 50, args: [], webBridgeEnabled: false,
  };
  const originalFetch = globalThis.fetch;
  let catalogRequest;
  mounted.push(root);
  globalThis.fetch = async (url, init) => {
    catalogRequest = { url: String(url), init };
    if (String(url).endsWith('/chat/completions')) {
      const events = [
        { choices: [{ delta: { tool_calls: [{ index: 0, id: 'call_runtime', function: { name: 'read_file', arguments: '{"path":"x"}' } }] } }] },
        { choices: [{ delta: {}, finish_reason: 'tool_calls' }] },
      ].map((value) => `data: ${JSON.stringify(value)}\n\n`).join('') + 'data: [DONE]\n\n';
      return new Response(events, { status: 200, headers: { 'content-type': 'text/event-stream' } });
    }
    return new Response(JSON.stringify({ data: [{ id: 'gpt-6-sol' }, { id: 'gpt-image-2' }] }), {
      status: 200, headers: { 'content-type': 'application/json' },
    });
  };
  let fiber;
  try {
    fiber = await root.plugin({ ...plugin }, config);
    await waitFor(() => root.get('llm').listProviders().some(({ id }) => id === 'codex-proxy'), 1000, 'real llm provider route');
    assert.equal(root.get('llm').listProviders().find(({ id }) => id === 'codex-proxy').name, 'Codex Proxy');
    assert.deepEqual((await root.get('llm').listModels('codex-proxy')).map(({ id }) => id), ['gpt-6-sol']);
    assert.equal(catalogRequest.url, 'http://127.0.0.1:8317/v1/models');
    assert.equal(catalogRequest.init.headers.authorization, 'Bearer test-secret');
    assert.equal(catalogRequest.init.headers['user-agent'], 'deepseek-harness/0.2.0-rc.2 (+https://github.com/deepseek-ai/deepseek-harness)');
    const streamChunks = [];
    for await (const chunk of root.get('llm').stream({
      provider: 'codex-proxy', model: 'gpt-6-sol', signal: new AbortController().signal,
      tools: [{ name: 'read_file', description: 'Read a file', parameters: { type: 'object' } }],
      messages: [{ role: 'user', content: [{ type: 'text', text: 'read x' }] }],
    })) streamChunks.push(chunk);
    assert.ok(streamChunks.some((chunk) => chunk.type === 'tool-call-delta' && chunk.id === 'call_runtime'));
    assert.equal(streamChunks.at(-1).reason.kind, 'tool-calls');
  } finally {
    globalThis.fetch = originalFetch;
  }
  if (fiber) await fiber.dispose();
  assert.equal(root.get('llm').listProviders().some(({ id }) => id === 'codex-proxy'), false);
});

test('the real DSH LLM runtime registers and discovers the Codex Web GPT route when enabled', async () => {
  const port = await freePort();
  const root = new Context();
  await root.plugin(StubSubprocess, { mode: 'serves', port });
  await root.plugin(LlmRuntime);
  await root.plugin(StubCredentials);
  await root.plugin(StubAgents);
  await root.plugin(StubTools);
  await root.plugin(StubWorkspaceRegistry);
  await root.plugin(StubSandboxPolicy);
  await root.plugin(StubAttachments);
  const configFile = join(workDir, 'codex-web-gpt-test-config.json');
  writeFileSync(configFile, JSON.stringify({ brokerSocketPath: 'test-native2-pipe' }), 'utf8');
  const config = {
    exe: EXE, config: CONFIG, cwd: workDir, healthUrl: `http://127.0.0.1:${port}/healthz`,
    logFile: join(workDir, 'trace-web-provider-registration.log'), readyTimeoutMs: 5000,
    probeTimeoutMs: 200, pollIntervalMs: 50, args: [], webBridgeEnabled: false,
    webBridgeBaseURL: 'http://127.0.0.1:18722/v1', native2ConfigFile: configFile,
  };
  const originalFetch = globalThis.fetch;
  let fiber;
  mounted.push(root);
  globalThis.fetch = async (url) => {
    assert.equal(String(url), 'http://127.0.0.1:18722/v1/models');
    return Response.json({ data: [{ id: 'gpt-6-sol-wm', title: 'GPT-6 Sol' }] });
  };
  try {
    fiber = await root.plugin({ ...plugin }, config);
    await waitFor(() => root.get('llm').listProviders().some(({ id }) => id === 'codex-web-gpt'), 1000, 'Codex Web GPT provider route');
    assert.equal(root.get('llm').listProviders().find(({ id }) => id === 'codex-web-gpt').name, 'Codex Web GPT');
    assert.deepEqual(await root.get('llm').listModels('codex-web-gpt'), [
      { provider: 'codex-web-gpt', id: 'gpt-6-sol-wm', name: 'GPT-6 Sol', inputModalities: ['text', 'image'] },
    ]);
  } finally {
    globalThis.fetch = originalFetch;
    if (fiber) await fiber.dispose();
    await waitFor(async () => (await healthStatus(port)) === null, 10000, 'proxy to be reaped');
  }
  assert.equal(root.get('llm').listProviders().some(({ id }) => id === 'codex-web-gpt'), false);
});

test('an already serving proxy is adopted, never double-started, never killed by the adopter', async () => {
  const first = await mount('serves');
  await waitFor(async () => (await healthStatus(first.port)) === 200, 10000, 'the owner proxy to serve /healthz');

  // Two rows of this bundle in one profile would collide on the route (the stub
  // throws exactly as the shipped service does), so the adopter stands in for the
  // non-web case — a CLI run — and mounts no web server of its own.
  const adopterRoot = new Context();
  await adopterRoot.plugin(StubSubprocess, { mode: 'serves', port: first.port });
  mounted.push(adopterRoot);
  const adopterLog = join(workDir, 'trace-adopter.log');
  const adopter = await adopterRoot.plugin({ ...plugin }, { ...first.config, logFile: adopterLog });
  await waitFor(
    () => /already answers/.test(safeTrace(adopterLog)),
    5000,
    'the adopting row to report the attach',
  );
  assert.equal(first.stub.spawns.length, 1, 'the adopting row must not start a second proxy');
  assert.equal(adopterRoot.get('subprocess').spawns.length, 0);

  await adopter.dispose();
  assert.equal(await healthStatus(first.port), 200, 'disposing the adopter must leave the owner proxy alone');

  await first.root.fiber.dispose();
  await waitFor(async () => (await healthStatus(first.port)) === null, 10000, 'the owner to reap its proxy');
});

test('an attempt that dies before serving is retried', async () => {
  const { root, stub, port, logFile } = await mount('dies-once');
  await waitFor(async () => (await healthStatus(port)) === 200, 15000, 'the retried proxy to serve /healthz');

  assert.equal(stub.spawns.length, 2);
  assert.match(traceOf(logFile), /start attempt 1\/3 failed: codex-proxy exited before it served \(code 1\)/);

  await root.fiber.dispose();
  await waitFor(async () => (await healthStatus(port)) === null, 10000, 'the proxy to be reaped');
});

test('every attempt failing degrades quietly and disposal stays clean', async () => {
  const { root, stub, port, logFile } = await mount('dies-always');
  await waitFor(() => /gave up starting codex-proxy/.test(safeTrace(logFile)), 20000, 'the row to give up');

  assert.equal(stub.spawns.length, 3);
  assert.equal(await healthStatus(port), null, 'nothing should serve after every attempt failed');
  await root.fiber.dispose();
  assert.equal(stub.live.size, 0);
});

function safeTrace(logFile) {
  try {
    return traceOf(logFile);
  } catch {
    return '';
  }
}

test('the power button route is exact, token-gated and reports the state', async () => {
  const { root, web, port } = await mount('serves');
  await waitFor(async () => (await healthStatus(port)) === 200, 10000, 'the boot proxy to serve /healthz');
  assert.equal(web.routes.length, 1, 'the row must register exactly one route');
  assert.equal(web.routes[0].kind, 'exact', 'an exact route is what beats the SPA fallback');
  assert.equal(web.routes[0].path, '/local/codex-proxy');

  const token = routeToken(web);
  const handler = web.routes[0].handler;
  assert.equal((await callRoute(handler, 'GET')).code, 403, 'a caller without the page token must be refused');
  assert.equal(
    (await callRoute(handler, 'GET', { [plugin.TOKEN_HEADER]: 'x'.repeat(token.length) })).code,
    403,
    'a wrong token of the right length must be refused',
  );
  assert.equal(
    (await callRoute(handler, 'GET', { [plugin.TOKEN_HEADER]: token, 'sec-fetch-site': 'cross-site' })).code,
    403,
    'a cross-site caller must be refused even with the token',
  );

  // `starting` is true while the boot launch is still in its ready poll, so wait
  // for it to clear before reading the settled state.
  await waitFor(
    async () => (await callRoute(handler, 'GET', { [plugin.TOKEN_HEADER]: token })).body.data.starting === false,
    5000,
    'the boot start to settle',
  );

  const ok = await callRoute(handler, 'GET', { [plugin.TOKEN_HEADER]: token });
  assert.equal(ok.code, 200);
  assert.equal(ok.headers['cache-control'], 'no-store');
  assert.equal(ok.body.ok, true);
  assert.equal(ok.body.data.running, true);
  assert.equal(ok.body.data.starting, false, 'a served request must not report an in-flight start');
  assert.equal(ok.body.data.owned, true);
  assert.equal((await callRoute(handler, 'DELETE', { [plugin.TOKEN_HEADER]: token })).code, 405);

  await root.fiber.dispose();
  assert.deepEqual(web.routes, [], 'disposal must remove the route');
});

test('pressing the button starts a proxy that died mid-session, and DSH still reaps it', async () => {
  const { root, stub, web, port } = await mount('serves');
  await waitFor(async () => (await healthStatus(port)) === 200, 10000, 'the boot proxy to serve /healthz');
  const handler = web.routes[0].handler;
  const headers = { [plugin.TOKEN_HEADER]: routeToken(web) };

  // The case the button exists for: the proxy is gone while DSH keeps running.
  for (const handle of [...stub.live]) await handle.terminate();
  await waitFor(async () => (await healthStatus(port)) === null, 10000, 'the dead proxy to stop answering');
  assert.equal((await callRoute(handler, 'GET', headers)).body.data.running, false);

  const started = await callRoute(handler, 'POST', headers);
  assert.equal(started.code, 200);
  assert.equal(started.body.ok, true);
  assert.equal(started.body.data.running, true);
  assert.equal(started.body.data.owned, true, 'a proxy the GUI started is owned by DSH');
  assert.equal(stub.spawns.length, 2);
  assert.equal(await healthStatus(port), 200);

  await root.fiber.dispose();
  await waitFor(async () => (await healthStatus(port)) === null, 10000, 'the GUI-started proxy to die with DSH');
  assert.equal(stub.live.size, 0, 'disposal must leave no live managed process');
});

test('the button adopts a proxy DSH did not start and never claims it', async () => {
  const port = await freePort();
  // A foreign proxy, started outside DSH, exactly like a manual or legacy start.
  const foreign = spawn(process.execPath, ['-e', FAKE_PROXY], {
    env: { ...process.env, STUB_PROXY_PORT: String(port) },
    stdio: 'ignore',
    windowsHide: true,
  });
  try {
    await waitFor(async () => (await healthStatus(port)) === 200, 10000, 'the foreign proxy to serve');
    const { root, stub, web } = await mount('serves', { port });
    assert.equal(stub.spawns.length, 0, 'the row must not start a second proxy on an occupied port');

    const data = (await callRoute(web.routes[0].handler, 'GET', { [plugin.TOKEN_HEADER]: routeToken(web) })).body.data;
    assert.equal(data.running, true);
    assert.equal(data.owned, false, 'a proxy DSH did not start is reported as unowned');

    await root.fiber.dispose();
    assert.equal(await healthStatus(port), 200, 'disposal must leave the foreign proxy alone');
  } finally {
    foreign.kill();
  }
});

test('usage management requests are proxied through the token-gated host route', async () => {
  const calls = [];
  const token = 'test-page-capability';
  const secret = 'test-management-secret';
  const handler = plugin.createRouteHandler(
    { managementSecret: secret },
    { handle: null, inflight: null },
    async () => null,
    token,
    async (_options, suppliedSecret, resource) => {
      calls.push({ suppliedSecret, resource });
      return { resource };
    },
  );
  const response = { code: 0, headers: {}, body: '', writeHead(code, headers) { this.code = code; this.headers = headers; }, end(body) { this.body = body; } };
  await handler({
    method: 'GET',
    url: `${plugin.ROUTE_PATH}?resource=usage`,
    headers: { [plugin.TOKEN_HEADER]: token },
  }, response);
  assert.equal(response.code, 200);
  assert.deepEqual(JSON.parse(response.body).data, { resource: 'usage' });
  assert.deepEqual(calls, [{ suppliedSecret: secret, resource: 'usage' }]);
  assert.equal(response.body.includes(secret), false, 'management secret must not be returned to the renderer');
});

test('the host adds the management secret upstream and never returns it to the page', async () => {
  const secret = 'test-only-management-key';
  const root = mkdtempSync(join(tmpdir(), 'codex-plus-secret-test-'));
  const secretFile = join(root, 'management.key');
  writeFileSync(secretFile, `${secret}\n`, 'utf8');
  let receivedPath;
  let receivedAuthorization;
  const upstream = createServer((req, res) => {
    receivedPath = req.url;
    receivedAuthorization = req.headers.authorization;
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ used: 12 }));
  });
  const port = await new Promise((resolve, reject) => {
    upstream.once('error', reject);
    upstream.listen(0, '127.0.0.1', () => resolve(upstream.address().port));
  });
  try {
    const handler = plugin.createRouteHandler(
      { healthUrl: `http://127.0.0.1:${port}/healthz`, managementSecretFile: secretFile },
      { handle: null, inflight: null },
      async () => null,
      'page-capability',
    );
    const response = { code: 0, headers: {}, body: '', writeHead(code, headers) { this.code = code; this.headers = headers; }, end(body) { this.body = body; } };
    await handler({
      method: 'GET',
      url: `${plugin.ROUTE_PATH}?resource=usage`,
      headers: { [plugin.TOKEN_HEADER]: 'page-capability' },
    }, response);
    assert.equal(response.code, 200);
    assert.equal(receivedPath, '/v8/management/usage');
    assert.equal(receivedAuthorization, `Bearer ${secret}`);
    assert.equal(response.body.includes(secret), false);
    assert.deepEqual(JSON.parse(response.body).data, { used: 12 });
  } finally {
    await new Promise((resolve) => upstream.close(resolve));
    rmSync(root, { recursive: true, force: true });
  }
});

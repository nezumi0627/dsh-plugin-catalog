# @local/codex-plus-usage

DSH の `conversation.composer.dock` に登録する **Codex Proxy / Codex Web GPT モデルプロバイダー**と ChatGPT Plus 使用量ウィジェット。クリックでポップオーバーを開き、Codex 枠の残量と、ローカルプロキシ `codex-proxy`（127.0.0.1:8317）が実際に捌いた量を表示する。

## Codex Proxy モデル

- 有効化時に DSH の公開 `ctx.llm.registerAdapter` API で独立ルート `codex-proxy` を登録する。既存の `llm-pi-ai` プロファイル設定は変更しない。
- モデル一覧は `CLIPROXYAPI_API_KEY` を DSH Credentials から解決し、`http://127.0.0.1:8317/v1/models` から取得する。`image` を含むIDはチャット一覧から除く。
- 選択モデルは同じProxyの `/v1/chat/completions` に送る。テキストストリームに加え、DSHのツールスキーマ・tool-call ID・ツール結果をOpenAI互換形式へ変換する。画像・ファイルブロックは明示的に未対応として失敗する。

## Codex Web GPT

- 有効化時に同梱 `gpt-web/server.mjs` を `127.0.0.1:8321` で起動し、既存の `Codex Web GPT` launcher browser にCDP接続する。既に同じbridgeが応答する場合は採用し、プラグインが起動した子プロセスだけをDSH終了時に止める。
- `~/.codex-chatgpt-web/config.json` の `brokerSocketPath` を読み、protocol v5のNative2 external-owner brokerと、DSHの公開 `agents` / `tools` / `workspaceRegistry` / `sandboxPolicy` APIを結ぶ。Native2ツールは同一Agent・session ID・workspace・sandbox policyで `ctx.tools.execute()` を通す。
- モデル一覧はbridgeの `/v1/models` から都度取得し、独立ルート `codex-web-gpt` に登録する。選択したモデルがWeb UIで選べない場合、ブリッジは送信前に失敗する。既定モデルへ黙って切り替えない。
- DSH側のリクエストキャンセル／切断をbridgeからChatGPTのStop操作まで伝播する。DSHの永続画像参照は添付サービスで読み取り、1MiB以下の要求画像へ投影してChatGPTのファイル入力に渡す。各経路は自動テスト済み。
- ライブの一時チャットで `GPT-6 Sol` → 表示名 `6` の選択と応答、および合成PNGの添付・画像理解応答を確認済み。`GPT-6.1 Sol` は誤選択せず、指定モデルが選べなければ送信前に失敗する。
- Codex Native2 connectorを実際に通すDSH上のエンドツーエンドターンは未検証。一般ファイル入力、ネイティブCodexの承認/確認UIやセッション継続を含む完全互換性も未証明。完全互換とは扱わない。

## 何を表示するか

| 表示 | 出典 |
| --- | --- |
| 5時間枠 / 週間枠の使用率・リセットまでの残り時間 | `GET /v8/management/usage` → ルート直下 `.quota`（無ければ `GET /v8/management/credentials` の `.files[].quota.signals["X-Codex-*"]`） |
| プラン / active limit / fast mode | `.quota.plan_type` / `.quota.active_limit` / `.fast_mode` |
| リクエスト数・失敗数 | `.totals.requests` / `.totals.errors` |
| トークン（合計・入力・出力・推論・キャッシュ） | `.totals.total_tokens` / `input_tokens` / `output_tokens` / `reasoning_tokens` / `cached_tokens` |
| 画像・ツール呼び出し | `.totals.images` / `.totals.tool_calls`（**ツールは proxy 側の欠陥で常に 0**。`_dsh/ws8/MATRIX.md` 参照） |
| ストリーミング / fast の件数 | `.totals.streamed` / `.totals.fast_requests` |
| 応答 平均 / p95、初トークン平均 | `.totals.avg_latency_ms` / `p95_latency_ms` / `avg_first_token_ms` |
| モデル別 Top3 | `.by_model`（リクエスト数順） |
| クールダウン / 上限到達 | `.cooldowns` / `credentials` の `X-Codex-Limit-Reached` |

- **`.totals` はルート直下**（`usage.totals` ではない）。`usage.json` は読まない — 走行中のプロキシはそれを書けていない（`_dsh/ws8/MATRIX.md`「永続化」）。
- `.totals` は**プロキシに接続した全クライアントの合算**（DSH の各セッション・他エージェント・curl）。1 会話の消費量ではない。
- 値は 30 秒ごとに自動更新。ポップオーバーの「更新」で即時取得。閉じるのは `Esc`・外側クリック・ピル再クリックのいずれか。パネルは本体の ContextMeter と同じ作法（`createPortal` + `position:fixed`、位置は `useAnchoredPosition`、外側クリックは `useDismissOnOutsidePointer`）で描画するので、コンポーザーがスクロール・リサイズ・クリップされても位置がズレない。
- `.by_model` は**配列**（`[{ model, requests, total_tokens, avg_latency_ms }]`）。旧ビルドの map 形式（モデルID をキーにした object）も読める。配列を map として読むと「モデル別」に 0 / 1 / 2 と出る。
- 管理 API が落ちている／鍵が変わった場合は古い数字を出さず `管理 API に接続できません (HTTP 403)` のように状態を表示する。

## 構成

- `codex-proxy-adapter.js` — ライブモデル一覧とOpenAI互換テキストストリームのDSHアダプター
- `index.js` — Host 側バンドル。使用量ピルの相棒として **codex-proxy 本体の寿命**と、電源ボタンの**起動ルート**を持つ（下記「codex-proxy の自動起動」「電源ボタン」）。データ取得はレンダラ側で完結する
- `client.js` — Client 側バンドル。`conversation.composer.dock` に使用量ピル＋`更新`／電源ボタンを固定表示（並び替えサービスには依存しない）
- `cordis.patch.yml` — プロファイルへ挿入する行（`@local/codex-plus-usage` と、画像ツール用 MCP `codex-plus-image`）
- `test-autostart.mjs` — 自動起動フックのテスト（下記）

## codex-proxy の自動起動

DSH のプロバイダ `ChatGPT Plus (codex-proxy)` は `http://127.0.0.1:8317/v1` を見ているので、**DSH が動いている間は codex-proxy も動いている必要がある**。以前は Startup フォルダの `.cmd` ＋ `_dsh\proxy-watchdog.ps1`（20 秒ポーリング）が担当していたが、その `.cmd` は現存せず、proxy が落ちたままになっていた。いまは `index.js` がこの寿命を **イベント駆動のフック**として持つ:

| タイミング | 動き |
| --- | --- |
| 行のロード（＝DSH 起動） | `/healthz` が応答しなければ `codex-proxy.exe -config %LOCALAPPDATA%\CodexProxy\config.yaml` を起動し、最大 15 秒待って ready を確認。起動前に既に応答していれば**何もしない** |
| 起動が早すぎて死んだ場合 | 直前の proxy がポートを離す瞬間を想定して最大 3 回リトライ（1 秒 → 2 秒） |
| 行の dispose（＝DSH 終了・プロファイル再読込） | **DSH 自身が起動した proxy だけ**を停止。`ctx.subprocess` 経由なので Windows Job に閉じ込められ、DSH が異常終了しても道連れで消える |
| DSH 起動中に proxy が落ちた | 自動では**何もしない**（ポーリング監視はしない方針）。ポップオーバーの**電源ボタン**を押せばその場で起動できる（下記） |

- 起動時に既に応答していた proxy は DSH が起動したものではないので**採用するだけで殺さない**（手動起動や他セッションの proxy を巻き込まない）。
- 実行の記録は `_dsh\codex-proxy-autostart.log` に追記され、同時に Host ログへ出る。起動に失敗しても DSH の起動は妨げない（そのルートが使えなくなるだけ）。
- 反映には **DSH の再起動が必要**（`index.js` はプロファイル再読込では読み直されない。`hmr` の `root` は `[]`）。
- 調整は `cordis.patch.yml` の `codex-plus-usage` 行に `config` を足して行う（`exe` / `config` / `cwd` / `healthUrl` / `logFile` / `readyTimeoutMs` / `probeTimeoutMs` / `pollIntervalMs` / `startupAttempts` / `graceMs` / `args`）。

## 管理鍵について

`client.js` の `MANAGEMENT_SECRET` は `%LOCALAPPDATA%\CodexProxy\config.yaml` の `management.secret-key`（bcrypt）に対応する**平文**。bcrypt は一方向なので Host 側で復元できず、レンダラから直接管理 API を叩く現在の構成ではこの定数が必要になる。

- 管理 API は **loopback 限定**（`management.allow-remote: false`）なので、鍵はマシン外に出ない。
- ローテーションするときは `config.yaml` の `secret-key` とこの定数を**同時に**変える（`state.json` の生成鍵は無視されるため使えない）。
- CORS は `Access-Control-Allow-Origin: *` を返すので、レンダラからの `fetch` はプリフライト（`OPTIONS` → 204）を含めて成功する（実測は `_dsh/ws8/LIVE.md` の `cors`）。

## 電源ボタン（手動起動）

使用量ピルのポップオーバー、`更新` の左にある電源アイコン。**停止しているときだけ押せる**（起動専用。押しても走っている proxy を止めることはない）。

| 表示 | 状態 | 押すと |
| --- | --- | --- |
| 灰 | 停止中 | `codex-proxy.exe -config %LOCALAPPDATA%\CodexProxy\config.yaml` を起動 |
| 緑 | 起動中（`title` に version と「DSH が管理」/「外部プロセス」） | 何も起きない（押せない） |
| 薄い灰 | 起動処理中（DSH 起動時のもたつきを含む） | 何も起きない（押せない） |
| 灰 + 注記 | 状態を確認できなかった | 押すと起動を試す |

- 状態は `GET /local/codex-proxy`（Host 側が `/healthz` を叩く）、押下は `POST /local/codex-proxy`。**プロセスを起動できるのは Host 側だけ**なので、レンダラは同じページのルート経由で頼む。
- ルートは `exact` で、ページにだけ埋め込まれる**プロセスごとのトークン**（`window.__DSH_CODEX_PROXY__`）を要求する。トークン無し・不一致・`sec-fetch-site: cross-site` は 403、`GET`/`POST` 以外は 405。
- **UI から起動した proxy も DSH 所有**（起動経路が同じ）なので、DSH を終了すれば一緒に落ちる。既に外部で動いていた proxy は「外部プロセス」と表示し、DSH は採用するだけで殺さない。
- 起動に失敗してもパネルは使用量の表示を続け、`title` に理由を出す。もう一度押せる。
- 反映には **DSH の再起動が必要**（Host 行もクライアントバンドルも起動時に読まれる）。

## 反映

クライアントバンドルは起動時に読まれる。`client.js` を変更したあとは **GUI の再読込か DSH の再起動**が必要（`~/.dsh/profiles/desktop/` は Lead 管轄なのでこのリポジトリからは触らない）。`index.js` はプロファイル再読込では読み直されないので DSH の再起動が要る。

## テスト

```powershell
$node = "C:\Users\ren11\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
& $node --test C:\Users\ren11\Documents\deepseek-harness\default-workspace\codex-plus-usage\test-autostart.mjs
```

自動起動フックと電源ボタンのルート（`index.js`）のテスト。**DSH に同梱の本物の Cordis**（`_asar_full` の展開コピー）で行をロードし、`ctx.subprocess` と `ctx.webServer` だけをスタブに差し替える。スタブは行が渡した spawn 要求（`argv` / `cwd` / `stdio`）とルート登録（`kind` / `path`）をそのまま記録するので**実 exe と実 config のパスを検証**しつつ、実際に走らせるのは `-e` の使い捨て HTTP サーバー。実 proxy・ポート 8317・資格情報ディレクトリには一切触れないため、DSH が proxy を抱えている最中でも実行できる（7 pass）。

検証範囲: 起動して `/healthz` が 200 になる / 既に応答している proxy は二重起動せず採用され、採用側の dispose でも殺されない / 途中で死んだ試行はリトライされる / 全試行が失敗しても DSH を壊さず dispose も正常 / dispose で起動元の proxy が確実に消える / ルートは `exact` でトークン無し・不一致・cross-site を 403、`GET`/`POST` 以外を 405 にする / **死んだ proxy をボタンから起動でき、それも DSH 終了で消える** / 外部起動の proxy は「所有していない」と報告し dispose でも残る。

```powershell
& $node --test C:\Users\ren11\Documents\deepseek-harness\default-workspace\_dsh\ws8\test-plugin-client.mjs
```

`node:vm` でバンドルを読み、React スタブで実際に描画し、ライブで採取した管理 API ペイロードを流し込む。登録 id・エンドポイント・`Bearer` 送信・ペイロード写像・失敗時の表示、および電源ボタン（Host のブートストラップが無いページでは非表示／停止中は押せて `POST` にトークンを載せ起動後に使用量を読み直す／起動中・起動処理中は押せない／状態不明なら押せる／失敗理由を `title` に出す）を検査する（16 pass）。

### 現在の検証状況

- DSH同梱 Node `v24.21.0` で自動登録・Native2 broker・セッション環境・起動経路・画像投影の対象テストは **32件成功**。
- プラグイン全体は **37/37件成功**。`gpt-web` は **41件成功、4件スキップ、0件失敗**。GPT-6 Solの選択と合成画像の一時チャット試験も成功。
- DSH Native2 broker と画像投影を含む自動テストは通過。現行コードを読み込んだDSHでの実プロバイダー選択とNative2ツール実行は未検証。
- 現行DSHプロセス（PID 12296）はプラグインコード更新前に起動しており、bridgeポート8321も待受していない。DSHから実際にNative2ツールを呼ぶエンドツーエンド試験はまだ行えていない。

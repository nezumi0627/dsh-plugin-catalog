const DEFAULT_BASE_URL = 'http://127.0.0.1:8321/v1';
const IMAGE_REQUEST_MAX_BYTES = 1024 * 1024;

function record(value, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error(`Codex Web GPT returned invalid ${label}`);
  return value;
}

function asToolResult(value) {
  if (!value || typeof value !== 'object' || !Array.isArray(value.content)) {
    return { content: [{ type: 'text', text: 'Error: DSH tool returned an invalid result' }], isError: true };
  }
  return {
    content: value.content,
    ...(value.value === undefined ? {} : { structuredContent: value.value }),
    ...(value.meta === undefined ? {} : { _meta: value.meta }),
    isError: value.isError === true,
  };
}

function reason(signal) {
  return signal.reason instanceof Error ? signal.reason : new DOMException('Aborted', 'AbortError');
}

async function prepareWebMessages(messages, attachments, signal) {
  const refs = new Map();
  for (const message of messages) {
    for (const block of Array.isArray(message.content) ? message.content : []) {
      if (block?.type !== 'image' || !block.attachment || block.data !== undefined) continue;
      if (block.offloaded === true) throw new Error('Codex Web GPT received an offloaded image that is missing its model projection');
      refs.set(block.attachment.attachmentId, block.attachment);
    }
  }
  if (refs.size === 0) return messages;
  if (typeof attachments?.readImageRequest !== 'function') {
    throw new Error('Codex Web GPT image input requires the DSH attachment service');
  }

  const images = new Map();
  await Promise.all([...refs.values()].map(async (ref) => {
    signal.throwIfAborted();
    const image = await attachments.readImageRequest(ref, {
      width: ref.width,
      height: ref.height,
      maxBytes: IMAGE_REQUEST_MAX_BYTES,
    }, signal);
    if (!/^image\/(?:png|jpeg|webp|gif)$/i.test(image?.mediaType ?? '') || !(image.data instanceof Uint8Array)) {
      throw new Error('DSH returned an invalid Codex Web GPT image request');
    }
    images.set(ref.attachmentId, `data:${image.mediaType};base64,${Buffer.from(image.data).toString('base64')}`);
  }));
  signal.throwIfAborted();

  return messages.map((message) => {
    if (!Array.isArray(message.content)) return message;
    let changed = false;
    const content = message.content.map((block) => {
      const data = block?.type === 'image' && block.attachment
        ? images.get(block.attachment.attachmentId)
        : undefined;
      if (!data) return block;
      changed = true;
      return { type: 'image_url', image_url: { url: data } };
    });
    return changed ? { ...message, content } : message;
  });
}

/** Additive adapter for the ChatGPT Web UI bridge and its Native2 turn broker. */
export function createCodexWebGptAdapter({
  baseURL = DEFAULT_BASE_URL,
  fetchImpl = globalThis.fetch,
  broker,
  getTurnContext,
  executeTool,
} = {}) {
  if (typeof fetchImpl !== 'function') throw new TypeError('fetchImpl is required');
  if (!broker || typeof broker.register !== 'function') throw new TypeError('broker is required');
  if (typeof getTurnContext !== 'function') throw new TypeError('getTurnContext is required');
  if (typeof executeTool !== 'function') throw new TypeError('executeTool is required');
  const root = baseURL.replace(/\/+$/, '');

  async function models(signal) {
    signal?.throwIfAborted();
    const response = await fetchImpl(`${root}/models`, { signal });
    if (!response.ok) throw new Error(`Codex Web GPT model discovery failed (HTTP ${response.status})`);
    const payload = await response.json();
    if (!Array.isArray(payload?.data)) throw new Error('Codex Web GPT returned an invalid model catalog');
    return payload.data.filter((model) => typeof model?.id === 'string' && model.id.trim())
      .map((model) => ({
        provider: 'codex-web-gpt',
        id: model.id,
        name: model.name || model.title || model.web_title || model.id,
        inputModalities: ['text', 'image'],
      }));
  }

  async function prepareCall(provider, model, signal) {
    if (provider !== 'codex-web-gpt') throw new Error(`Unknown Codex Web GPT provider: ${provider}`);
    signal?.throwIfAborted();
    const discovered = await models(signal);
    const resolved = discovered.find((candidate) => candidate.id === model);
    if (!resolved) throw new Error(`Codex Web GPT model is not available: ${model}`);
    return { model: resolved, stream: (options) => stream({ ...options, signal: options.signal ?? signal }, model) };
  }

  async function dispatchRequests(token, requests, options, agent) {
    for (const request of requests) {
      options.signal?.throwIfAborted();
      const schema = options.tools?.find((tool) => tool.name === request.wireName);
      let result;
      if (!schema) {
        result = { content: [{ type: 'text', text: `Error: DSH tool is not available in this turn: ${request.wireName}` }], isError: true };
      } else {
        try {
          result = asToolResult(await executeTool({
            callId: request.callId,
            rootCallId: request.callId,
            name: request.wireName,
            schema,
            arguments: request.freeform ? request.input : request.arguments,
            agent,
            signal: options.signal,
          }));
        } catch (error) {
          result = { content: [{ type: 'text', text: `Error: ${error instanceof Error ? error.message : String(error)}` }], isError: true };
        }
      }
      await broker.completeTool(token, request.callId, result);
    }
  }

  async function pumpTools(token, options, agent, controller) {
    while (!controller.signal.aborted) {
      const requests = await broker.nextToolBatch(token, controller.signal);
      if (requests.length) await dispatchRequests(token, requests, options, agent);
    }
  }

  async function finishNativeTurn(token, options) {
    for (;;) {
      options.signal?.throwIfAborted();
      const revision = await broker.beginCompletionFence(token);
      if (revision === undefined || await broker.commitCompletionFence(token, revision)) break;
      const requests = await broker.nextToolBatch(token, options.signal);
      await dispatchRequests(token, requests, options, options.agent);
    }
    const failure = await broker.waitForRetirement(token, options.signal);
    if (failure) throw new Error(`Codex Native2 tool retirement failed: ${JSON.stringify(failure)}`);
  }

  async function* stream(options, model) {
    const setup = await getTurnContext(options);
    const agent = setup?.agent;
    if (!agent?.session || (options.sessionId && agent.session.id !== options.sessionId)) {
      throw new Error('Codex Web GPT could not resolve the exact initiating DSH session');
    }
    const turnController = new AbortController();
    const abortTurn = () => turnController.abort(reason(options.signal));
    options.signal?.addEventListener('abort', abortTurn, { once: true });
    if (options.signal?.aborted) abortTurn();
    const turnOptions = { ...options, signal: turnController.signal, agent };
    let token;
    let pollController;
    let poller;
    let pollFailure;
    let textStarted = false;
    let emittedText = '';
    let pendingText = '';
    let finishReason = 'stop';

    try {
      turnController.signal.throwIfAborted();
      token = await broker.register(setup.environment, { traceId: `dsh_${String(agent.session.id).replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 96)}` });
      pollController = new AbortController();
      const abortPoll = () => pollController.abort(reason(turnController.signal));
      turnController.signal.addEventListener('abort', abortPoll, { once: true });
      poller = pumpTools(token, turnOptions, agent, pollController).catch((error) => {
        if (!pollController.signal.aborted) {
          pollFailure = error;
          turnController.abort(error);
        }
      });

      const messages = [
        ...await prepareWebMessages(options.messages ?? [], setup.attachments, turnController.signal),
        { role: 'system', content: `<codex_transport_resume>\nThe task context is complete. Pass turn_token ${token} unchanged to every Codex Native call in this response, including continuations after tool results; do not expose it in the answer. Execute the latest active user request now.\n</codex_transport_resume>` },
      ];
      const response = await fetchImpl(`${root}/chat/completions`, {
        method: 'POST',
        headers: { 'content-type': 'application/json', accept: 'text/event-stream' },
        signal: turnController.signal,
        body: JSON.stringify({ model, stream: true, messages }),
      });
      if (!response.ok) throw new Error(`Codex Web GPT request failed (HTTP ${response.status})`);
      if (!response.body) throw new Error('Codex Web GPT returned an empty stream');

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let receivedDone = false;
      const emitText = (delta, final = false) => {
        pendingText += delta;
        let safeLength = final ? pendingText.length : Math.max(0, pendingText.length - token.length + 1);
        const tokenIndex = pendingText.indexOf(token);
        if (!final && tokenIndex >= 0 && tokenIndex < safeLength) safeLength = tokenIndex;
        const safeText = pendingText.slice(0, safeLength).split(token).join('[redacted Native2 token]');
        pendingText = pendingText.slice(safeLength);
        if (!safeText) return [];
        emittedText += safeText;
        if (!textStarted) {
          textStarted = true;
          return [
            { type: 'block-start', index: 0, blockType: 'text' },
            { type: 'text-delta', index: 0, text: safeText },
          ];
        }
        return [{ type: 'text-delta', index: 0, text: safeText }];
      };

      try {
        while (!receivedDone) {
          turnController.signal.throwIfAborted();
          const { value, done } = await reader.read();
          if (pollFailure) throw pollFailure;
          buffer += decoder.decode(value, { stream: !done });
          const events = buffer.split(/\r?\n\r?\n/);
          buffer = events.pop() ?? '';
          for (const event of events) {
            for (const line of event.split(/\r?\n/)) {
              if (!line.startsWith('data:')) continue;
              const data = line.slice(5).trim();
              if (data === '[DONE]') { receivedDone = true; break; }
              let payload;
              try { payload = JSON.parse(data); } catch { throw new Error('Codex Web GPT returned malformed stream data'); }
              if (payload?.error && typeof payload.error === 'object') {
                const code = typeof payload.error.code === 'string' ? `${payload.error.code}: ` : '';
                throw new Error(`Codex Web GPT turn failed: ${code}${payload.error.message ?? 'unknown error'}`);
              }
              const choice = payload?.choices?.[0];
              if (choice?.finish_reason) finishReason = choice.finish_reason;
              const content = choice?.delta?.content;
              if (typeof content === 'string' && content) {
                for (const chunk of emitText(content)) yield chunk;
              }
            }
            if (receivedDone) break;
          }
          if (done && !receivedDone) break;
        }
      } finally {
        reader.releaseLock();
      }
      if (!receivedDone) throw new Error('Codex Web GPT stream ended without a terminal marker');
      for (const chunk of emitText('', true)) yield chunk;

      pollController.abort(new DOMException('Web turn finished', 'AbortError'));
      await poller;
      if (pollFailure) throw pollFailure;
      await finishNativeTurn(token, turnOptions);
      if (textStarted) yield { type: 'block-end', index: 0, block: { type: 'text', text: emittedText } };
      yield { type: 'finish', reason: { kind: finishReason === 'length' ? 'max-tokens' : 'stop' } };
    } finally {
      options.signal?.removeEventListener('abort', abortTurn);
      if (pollController && !pollController.signal.aborted) pollController.abort(new DOMException('DSH turn ended', 'AbortError'));
      if (poller) await poller.catch(() => {});
      if (token) await broker.revoke(token).catch(() => {});
      if (!turnController.signal.aborted) turnController.abort(new DOMException('DSH turn ended', 'AbortError'));
    }
  }

  return {
    providerInfo: (provider) => ({ id: provider, name: 'Codex Web GPT' }),
    providerRetryPolicy: () => undefined,
    async listModels(provider) { return provider === 'codex-web-gpt' ? models() : []; },
    async resolveModel(provider, model, signal) {
      if (provider !== 'codex-web-gpt') throw new Error(`Unknown Codex Web GPT provider: ${provider}`);
      return (await models(signal)).find((candidate) => candidate.id === model)
        ?? (() => { throw new Error(`Codex Web GPT model is not available: ${model}`); })();
    },
    prepareCall,
    stream: (options) => stream(options, options.model),
  };
}

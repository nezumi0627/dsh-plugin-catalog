import test from 'node:test';
import assert from 'node:assert/strict';
import { createCodexWebGptAdapter } from './codex-web-gpt-adapter.js';

const token = 'turn_12345678901234567890';
const model = { id: 'gpt-6-sol-wm', web_title: 'GPT-6 Sol', max_tokens: null };

function pendingNext(signal) {
  return new Promise((resolve, reject) => {
    signal.addEventListener('abort', () => reject(signal.reason ?? new DOMException('Aborted', 'AbortError')), { once: true });
  });
}

function textResponse(text) {
  const body = `data: ${JSON.stringify({ choices: [{ delta: { content: text }, finish_reason: null }] })}\n\ndata: ${JSON.stringify({ choices: [{ delta: {}, finish_reason: 'stop' }] })}\n\ndata: [DONE]\n\n`;
  return new Response(body, { headers: { 'content-type': 'text/event-stream' } });
}

function errorResponse(message, code) {
  const body = `data: ${JSON.stringify({ error: { message, code } })}\n\ndata: [DONE]\n\n`;
  return new Response(body, { headers: { 'content-type': 'text/event-stream' } });
}

test('discovers Codex Web GPT models from the live bridge catalog', async () => {
  const adapter = createCodexWebGptAdapter({
    fetchImpl: async (url) => {
      assert.equal(url, 'http://127.0.0.1:8321/v1/models');
      return Response.json({ data: [model] });
    },
    broker: { register() {} },
    getTurnContext() {},
    executeTool() {},
  });
  assert.deepEqual(await adapter.listModels('codex-web-gpt'), [
    { provider: 'codex-web-gpt', id: model.id, name: model.web_title, inputModalities: ['text', 'image'] },
  ]);
});

test('turns durable DSH image references into inline image input for the web bridge', async () => {
  const requests = [];
  const imageReads = [];
  let poll = 0;
  const attachment = {
    attachmentId: 'sha256:image-1', mediaType: 'image/png', bytes: 5, width: 1, height: 1,
  };
  const adapter = createCodexWebGptAdapter({
    fetchImpl: async (_url, init) => {
      requests.push(JSON.parse(init.body));
      return textResponse('Image received');
    },
    broker: {
      async register() { return token; },
      async nextToolBatch(_token, signal) {
        if (poll++ === 0) return [];
        return pendingNext(signal);
      },
      async beginCompletionFence() { return 1; },
      async commitCompletionFence(_token, revision) { return revision === 1; },
      async waitForRetirement() {},
      async revoke() {},
    },
    getTurnContext: async (options) => ({
      agent: { session: { id: options.sessionId } },
      environment: { cwd: 'C:/work', roots: ['C:/work'], writableRoots: [], sandboxPolicy: { type: 'readOnly', networkAccess: false }, tools: [] },
      attachments: {
        async readImageRequest(ref, target, signal) {
          imageReads.push({ ref, target, aborted: signal.aborted });
          return { mediaType: 'image/png', data: Uint8Array.from([104, 101, 108, 108, 111]) };
        },
      },
    }),
    executeTool() {},
  });

  for await (const _chunk of adapter.stream({
    provider: 'codex-web-gpt', model: model.id, sessionId: 'session-1', tools: [],
    messages: [{ role: 'user', content: [
      { type: 'text', text: 'Describe this' },
      { type: 'image', attachment },
    ] }],
  }, model.id)) {}

  assert.equal(imageReads.length, 1, 'the adapter reads each durable image exactly once');
  assert.equal(imageReads[0].ref.attachmentId, attachment.attachmentId);
  assert.deepEqual(imageReads[0].target, { width: 1, height: 1, maxBytes: 1048576 });
  assert.deepEqual(requests[0].messages[0].content, [
    { type: 'text', text: 'Describe this' },
    { type: 'image_url', image_url: { url: 'data:image/png;base64,aGVsbG8=' } },
  ]);
});

test('runs the selected web model, passes its private Native2 turn token, and executes broker tools through DSH', async () => {
  const requests = [];
  let poll = 0;
  const seen = { body: null, context: null, execute: null, completed: null, revoked: null };
  const broker = {
    async register(environment) { seen.environment = environment; return token; },
    async nextToolBatch(_token, signal) {
      poll += 1;
      if (poll === 1) return [{ callId: 'native-call-1', wireName: 'read_file', freeform: false, arguments: { path: 'README.md' } }];
      return pendingNext(signal);
    },
    async completeTool(_token, callId, result) { seen.completed = { callId, result }; },
    async beginCompletionFence() { return 7; },
    async commitCompletionFence(_token, revision) { assert.equal(revision, 7); return true; },
    async waitForRetirement() {},
    async revoke(value) { seen.revoked = value; },
  };
  const adapter = createCodexWebGptAdapter({
    fetchImpl: async (_url, init) => {
      seen.body = JSON.parse(init.body);
      return textResponse(`Answer from the web model ${token}`);
    },
    broker,
    getTurnContext: async (options) => {
      seen.context = options.sessionId;
      return { agent: { session: { id: options.sessionId } }, environment: { cwd: 'C:/work', roots: ['C:/work'], writableRoots: [], sandboxPolicy: { type: 'readOnly', networkAccess: false }, tools: options.tools } };
    },
    executeTool: async (input) => {
      seen.execute = input;
      return { isError: false, value: { path: 'README.md' }, meta: { source: 'dsh' }, content: [{ type: 'text', text: 'file contents' }] };
    },
  });
  const tool = { name: 'read_file', description: 'Read a file', parameters: { type: 'object' } };
  const chunks = [];
  for await (const chunk of adapter.stream({
    provider: 'codex-web-gpt', model: model.id, sessionId: 'session-1',
    messages: [{ role: 'user', content: 'Read README.md' }], tools: [tool],
    signal: new AbortController().signal,
  })) chunks.push(chunk);

  assert.equal(seen.body.model, model.id);
  assert.match(seen.body.messages.at(-1).content, new RegExp(`turn_token ${token}`));
  assert.equal(seen.context, 'session-1');
  assert.equal(seen.environment.tools[0].name, 'read_file');
  assert.equal(seen.execute.name, 'read_file');
  assert.equal(seen.execute.callId, 'native-call-1');
  assert.deepEqual(seen.execute.arguments, { path: 'README.md' });
  assert.equal(seen.execute.agent.session.id, 'session-1');
  assert.equal(seen.completed.callId, 'native-call-1');
  assert.deepEqual(seen.completed.result.content, [{ type: 'text', text: 'file contents' }]);
  assert.deepEqual(seen.completed.result.structuredContent, { path: 'README.md' });
  assert.deepEqual(seen.completed.result._meta, { source: 'dsh' });
  assert.equal(seen.revoked, token);
  const answer = chunks.filter((chunk) => chunk.type === 'text-delta').map((chunk) => chunk.text).join('');
  assert.equal(answer, 'Answer from the web model [redacted Native2 token]');
  assert.equal(answer.includes(token), false);
});

test('surfaces a model-selection failure returned inside a successful SSE response', async () => {
  const broker = {
    async register() { return token; },
    async nextToolBatch(_token, signal) { return pendingNext(signal); },
    async revoke() {},
  };
  const adapter = createCodexWebGptAdapter({
    fetchImpl: async () => errorResponse('requested model could not be selected', 'MODEL_SELECTION_FAILED'),
    broker,
    getTurnContext: async (options) => ({ agent: { session: { id: options.sessionId } }, environment: {} }),
    executeTool() {},
  });
  await assert.rejects(async () => {
    for await (const _chunk of adapter.stream({ model: model.id, sessionId: 'session-1', messages: [{ role: 'user', content: 'hello' }] })) { /* consume */ }
  }, /MODEL_SELECTION_FAILED.*requested model could not be selected/);
});

test('DSH cancellation aborts the browser request, the Native2 poll, and owner lifetime', async () => {
  let startRequest;
  const requestStarted = new Promise((resolve) => { startRequest = resolve; });
  const seen = { httpAborted: false, pollAborted: false, revoked: null };
  const broker = {
    async register() { return token; },
    async nextToolBatch(_token, signal) {
      try { await pendingNext(signal); } catch { seen.pollAborted = true; throw signal.reason; }
    },
    async revoke(value) { seen.revoked = value; },
  };
  const adapter = createCodexWebGptAdapter({
    fetchImpl: async (_url, init) => new Promise((_resolve, reject) => {
      startRequest();
      init.signal.addEventListener('abort', () => {
        seen.httpAborted = true;
        reject(init.signal.reason);
      }, { once: true });
    }),
    broker,
    getTurnContext: async (options) => ({ agent: { session: { id: options.sessionId } }, environment: { cwd: 'C:/work', roots: ['C:/work'], writableRoots: [], sandboxPolicy: { type: 'readOnly', networkAccess: false }, tools: options.tools } }),
    executeTool() {},
  });
  const controller = new AbortController();
  const turn = (async () => {
    for await (const _chunk of adapter.stream({
      provider: 'codex-web-gpt', model: model.id, sessionId: 'session-1',
      messages: [{ role: 'user', content: 'cancel me' }], signal: controller.signal,
    })) { /* drain */ }
  })();
  await requestStarted;
  controller.abort();
  await assert.rejects(turn, { name: 'AbortError' });
  assert.equal(seen.httpAborted, true);
  assert.equal(seen.pollAborted, true);
  assert.equal(seen.revoked, token);
});

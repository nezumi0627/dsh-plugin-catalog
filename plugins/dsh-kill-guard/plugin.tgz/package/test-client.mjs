/**
 * Offline test for the Client bundle of `@local/dsh-kill-guard`.
 *
 * The bundle is a `window.__ModuleLoader__.load({ id, factory })` call, so this
 * test fakes the module loader, React, ReactDOM, the UI primitives, and the DOM,
 * then drives the real `factory`/`apply` pair: both slot registrations, the
 * locale dictionaries, the stylesheet, the route client, the failure translator,
 * and the graph helpers all come from the shipped bundle rather than a copy.
 *
 * Three checks here only exist for this rewrite:
 *   * every rendered string is compared against `locale/*.json`, so the shipped
 *     dictionaries and the bundle can never drift apart;
 *   * the stylesheet is asserted to be token-only (no hex colour anywhere);
 *   * the icon geometry in the bundle is asserted against `icon.svg`.
 *
 *   node test-client.mjs
 */
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// --- the browser surface the bundle touches while materializing --------------

const appended = [];
const removed = [];
const styleAttributes = [];
function createStyleStub() {
  return {
    tag: 'style',
    attrs: {},
    textContent: '',
    setAttribute(key, value) {
      this.attrs[key] = value;
      styleAttributes.push({ key, value });
    },
    remove() {
      removed.push(this);
    },
  };
}

globalThis.document = {
  createElement: () => createStyleStub(),
  head: { append: (element) => appended.push(element) },
  documentElement: { hasAttribute: () => false, dataset: {} },
  body: {},
  addEventListener: () => {},
  removeEventListener: () => {},
  visibilityState: 'visible',
};
globalThis.getComputedStyle = () => ({ getPropertyValue: (name) => (name === '--dsh-frame-chrome-top' ? '40px' : '') });
globalThis.window = {
  __DSH_AUTO_KILL__: { path: '/local/auto-kill', token: 'token-token-token-token-token-token-9' },
  addEventListener: () => {},
  removeEventListener: () => {},
  innerWidth: 1600,
  innerHeight: 900,
  localStorage: { getItem: () => null, setItem: () => {} },
};
// node 24 ships a getter-only `navigator`, so the stub is defined, not assigned.
Object.defineProperty(globalThis, 'navigator', { value: {}, configurable: true, writable: true });

const specs = [];
globalThis.window.__ModuleLoader__ = {
  load(spec) {
    specs.push(spec);
  },
};

await import('./client.js');
assert.equal(specs.length, 1, 'the bundle registers exactly one module');
const spec = specs[0];

const React = {
  createElement: (type, props, ...children) => ({ type, props: { ...(props ?? {}), children: children.length <= 1 ? children[0] : children } }),
  useState: () => [undefined, () => {}],
  useEffect: () => {},
  useMemo: (fn) => fn(),
  useRef: () => ({ current: null }),
  useCallback: (fn) => fn,
};
const ReactDOM = { createPortal: (node, target) => ({ type: 'portal', props: { children: node, target } }) };
const primitives = {
  useAnchoredPosition: () => null,
  useDismissOnOutsidePointer: () => {},
};

const required = [];
const mod = spec.factory((name) => {
  required.push(name);
  if (name === 'react') return React;
  if (name === 'react-dom') return ReactDOM;
  if (name === '@deepseek-ai/dsh-client-ui-primitives') return primitives;
  throw new Error(`unexpected require: ${name}`);
});

// ---------------------------------------------------------------------------

test('bundle: only platform-seed specifiers are required', () => {
  assert.deepEqual(required.sort(), ['@deepseek-ai/dsh-client-ui-primitives', 'react', 'react-dom']);
});

test('bundle: registers the package id and declares its client services', () => {
  assert.equal(spec.id, '@local/dsh-kill-guard');
  assert.deepEqual(mod.inject, ['slots', 'locale']);
  assert.equal(mod.__test.id, '@local/dsh-kill-guard');
  assert.equal(mod.__test.namespace, 'dshKillGuard');
  assert.equal(typeof mod.apply, 'function');
});

test('bundle: apply registers the compact indicator in the top strip and beside the composer stats', () => {
  const localeCalls = [];
  const slotWaits = [];
  const registrations = [];
  const effects = [];
  const ctx = {
    locale: {
      bind: (ns) => (key, ...args) => `${ns}:${key}${args.length > 0 ? `(${args.join(',')})` : ''}`,
      register: (ns, locale, dict) => {
        localeCalls.push({ ns, locale, dict });
        return () => {};
      },
      getLocale: () => ({ active: 'ja' }),
    },
    slots: {
      inject(name, callback) {
        slotWaits.push(name);
        return callback();
      },
      register(options, component) {
        registrations.push({ options, component });
        return () => {};
      },
    },
    effect(fn) {
      const dispose = fn();
      if (typeof dispose === 'function') effects.push(dispose);
      return dispose;
    },
  };
  mod.apply(ctx);

  assert.deepEqual(slotWaits, ['shell.overlay', 'conversation.composer.dock']);
  assert.equal(registrations.length, 2);
  assert.deepEqual(
    { ...registrations[0].options, inject: undefined },
    { name: 'shell.overlay', id: '@local/dsh-kill-guard', order: 100, locale: 'dshKillGuard', inject: undefined },
  );
  assert.deepEqual(
    { ...registrations[1].options, inject: undefined },
    { name: 'conversation.composer.dock', id: '@local/dsh-kill-guard', order: 12, locale: 'dshKillGuard', inject: undefined },
  );
  assert.equal(typeof registrations[0].options.inject, 'function');
  assert.equal(typeof registrations[1].options.inject, 'function');
  assert.equal(typeof registrations[0].component, 'function', 'one shared component serves both placements');
  assert.equal(registrations[0].component, registrations[1].component, 'the two placements reuse the same component, not a copy');

  assert.deepEqual(localeCalls.map((call) => call.locale).sort(), ['en', 'ja', 'zh']);
  assert.equal(localeCalls.every((call) => call.ns === 'dshKillGuard'), true);
  const japanese = localeCalls.find((call) => call.locale === 'ja').dict;
  assert.equal(japanese.title, 'KILLガード');
  assert.equal(typeof japanese.stoppedFlash, 'undefined', 'dictionaries are plain strings so locale/*.json is the same data');
});

test('bundle: the stylesheet is injected once and removed by its disposer', () => {
  assert.equal(appended.length, 1);
  assert.equal(appended[0].attrs['data-plugin-css'], '@local/dsh-kill-guard');
  const css = appended[0].textContent;
  assert.match(css, /\.dkg-chip\{/);
  assert.match(css, /\.dkg-panel\{[^}]*position:fixed/);
  assert.match(css, /--dsw-alias-state-error-primary/);
  assert.match(css, /data-level='hot'/);
  assert.match(css, /prefers-reduced-motion/);
  assert.match(css, /@media\(max-width:640px\)/);
  assert.match(css, /:root\[data-fullscreen\]|--dsh-frame-chrome-top/);

  const stylesheet = appended[0];
  const disposers = [];
  mod.apply({
    locale: { bind: () => (key) => key, register: () => () => {} },
    slots: { inject: (_name, callback) => callback(), register: () => () => {} },
    effect(fn) {
      const dispose = fn();
      disposers.push(dispose);
      return dispose;
    },
  });
  assert.equal(appended.length, 1, 'a second apply never injects a second stylesheet');
  assert.equal(removed.includes(stylesheet), false);
  for (const dispose of disposers.reverse()) dispose();
  assert.ok(removed.includes(stylesheet), 'unload removes the style element');
});

test('design tokens: the bundle contains no hardcoded colour', () => {
  const source = readFileSync(new URL('./client.js', import.meta.url), 'utf8');
  const hex = source.match(/#[0-9a-fA-F]{3,8}\b/g) ?? [];
  assert.deepEqual(hex, [], `hardcoded colours found: ${hex.join(', ')}`);
  assert.equal(/\bcolor:\s*(red|white|black|blue|green)\b/.test(source), false, 'no CSS colour keywords either');
  assert.equal(/\brgba?\(/.test(source), false, 'no rgba() literals either — theming is the token system');
});

test('icon: the geometry in the bundle is the shipped icon.svg', () => {
  const svg = readFileSync(new URL('./icon.svg', import.meta.url), 'utf8');
  assert.equal(svg.includes(mod.__test.iconPaths.shield), true, 'the shield path matches icon.svg');
  assert.equal(svg.includes(mod.__test.iconPaths.pulse), true, 'the pulse path matches icon.svg');
});

test('locale: the shipped JSON files and the bundle dictionaries are the same data', () => {
  const locales = ['ja', 'en', 'zh'];
  const files = {};
  for (const locale of locales) {
    files[locale] = JSON.parse(readFileSync(new URL(`./locale/${locale}.json`, import.meta.url), 'utf8'));
    assert.deepEqual(mod.__test.dicts[locale], files[locale], `locale/${locale}.json matches the bundle dictionary`);
  }
  const keys = Object.keys(files.ja).sort();
  for (const locale of ['en', 'zh']) {
    assert.deepEqual(Object.keys(files[locale]).sort(), keys, `${locale} covers exactly the same keys`);
  }
  // Every placeholder used by one locale exists in all of them.
  const placeholders = (text) => (text.match(/\{[a-z]+\}/g) ?? []).sort().join(',');
  for (const key of keys) {
    const expected = placeholders(files.ja[key]);
    for (const locale of ['en', 'zh']) {
      assert.equal(placeholders(files[locale][key]), expected, `${locale}.${key} uses the same placeholders as ja`);
    }
  }
});

test('helpers: percentages, byte sizes, clock stamps, ages, and level bands', () => {
  const { formatPercent, formatBytes, formatClockTime, formatAge, levelFor } = mod.__test;
  assert.equal(formatPercent(42.34), '42.3%');
  assert.equal(formatPercent(150), '100%');
  assert.equal(formatPercent(-3), '0%');
  assert.equal(formatPercent(undefined), '--');
  assert.equal(formatPercent(null), '--', 'an unavailable metric is never shown as 0%');
  assert.equal(formatBytes(16 * 1024 ** 3), '16 GB');
  assert.equal(formatBytes(1536), '1.5 KB');
  assert.equal(formatBytes(0), '--');
  assert.equal(formatClockTime(new Date(2026, 9, 12, 14, 32, 5).getTime()), '14:32:05');
  assert.equal(formatClockTime('nonsense'), '--:--:--');
  assert.equal(formatAge(4000), '4s', 'ages carry no locale text: the dictionary supplies the wrapper');
  assert.equal(formatAge(950_000), '15m');
  assert.equal(formatAge(3 * 3600 * 1000 + 60_000), '3h');
  assert.equal(formatAge(0), '0s');
  assert.equal(formatAge(undefined), '--');
  assert.equal(levelFor(95, 90, 70), 'hot');
  assert.equal(levelFor(75, 90, 70), 'warn');
  assert.equal(levelFor(12, 90, 70), 'ok');
  assert.equal(levelFor(50, 0, 70), 'ok', 'a disabled arm never reads as hot');
  assert.equal(levelFor(null, 90, 70), 'unknown', 'an unread metric is neither calm nor hot');
  assert.equal(levelFor(undefined, 90, 70), 'unknown');
});

test('helpers: fill substitutes named placeholders and leaves unknown ones alone', () => {
  const { fill } = mod.__test;
  assert.equal(fill('閾値 {value}%', { value: 90 }), '閾値 90%');
  assert.equal(fill('{a} と {b}', { a: 'x' }), 'x と {b}');
  assert.equal(fill(undefined, { a: 1 }), undefined);
  assert.equal(fill('no placeholders', {}), 'no placeholders');
});

test('chrome detection: a caption strip is measured, its absence means float mode', () => {
  assert.equal(mod.__test.readChromeHeight(), 40);
  globalThis.getComputedStyle = () => ({ getPropertyValue: () => '' });
  assert.equal(mod.__test.readChromeHeight(), 0);
  globalThis.getComputedStyle = () => ({ getPropertyValue: (name) => (name === '--dsh-frame-chrome-top' ? '48px' : '') });
  assert.equal(mod.__test.readChromeHeight(), 48);
  globalThis.getComputedStyle = () => ({ getPropertyValue: (name) => (name === '--dsh-frame-chrome-top' ? '40px' : '') });
});

test('bootstrap: a missing or malformed payload yields no client', () => {
  const original = globalThis.window.__DSH_AUTO_KILL__;
  globalThis.window.__DSH_AUTO_KILL__ = undefined;
  assert.equal(mod.__test.readBootstrap(), null);
  globalThis.window.__DSH_AUTO_KILL__ = { path: '', token: 'x' };
  assert.equal(mod.__test.readBootstrap(), null);
  globalThis.window.__DSH_AUTO_KILL__ = { path: '/local/auto-kill', token: '' };
  assert.equal(mod.__test.readBootstrap(), null);
  globalThis.window.__DSH_AUTO_KILL__ = original;
  assert.deepEqual(mod.__test.readBootstrap(), original);
});

test('bootstrap: a page without a global asks the token route and keeps the answer', async () => {
  const { resolveApi, tokenPath } = mod.__test;
  assert.equal(tokenPath, '/local/auto-kill-token');

  const original = globalThis.window.__DSH_AUTO_KILL__;
  globalThis.window.__DSH_AUTO_KILL__ = undefined;
  const calls = [];
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init });
    return { ok: true, status: 200, json: async () => ({ ok: true, data: { path: '/local/auto-kill', token: 'from-route' } }) };
  };
  const api = await resolveApi();
  assert.equal(calls.length, 1, 'one handshake, then the token is cached');
  assert.equal(calls[0].url, '/local/auto-kill-token');
  assert.equal(calls[0].init.credentials, 'same-origin');
  assert.equal(calls[0].init.cache, 'no-store');
  assert.deepEqual(globalThis.window.__DSH_AUTO_KILL__, { path: '/local/auto-kill', token: 'from-route' });
  assert.equal(typeof api.read, 'function');
  assert.equal(typeof api.act, 'function');

  const again = await resolveApi();
  assert.equal(calls.length, 1, 'the global short-circuits the handshake');
  assert.equal(typeof again.act, 'function');

  // Every failure keeps a machine-readable code and never an internal sentence.
  globalThis.window.__DSH_AUTO_KILL__ = undefined;
  const capture = async (stub) => {
    globalThis.fetch = stub;
    try {
      await resolveApi();
    } catch (error) {
      return error;
    }
    throw new Error('expected resolveApi to fail');
  };
  const refused = await capture(async () => ({ ok: false, status: 401, json: async () => ({ ok: false, error: 'unauthorized' }) }));
  assert.equal(refused.code, 'handshake-http');
  assert.equal(refused.status, 401);
  const empty = await capture(async () => ({ ok: true, status: 200, json: async () => ({ ok: false, error: 'nope' }) }));
  assert.equal(empty.code, 'handshake-empty');
  const offline = await capture(async () => {
    throw new Error('ECONNREFUSED');
  });
  assert.equal(offline.code, 'handshake-network');

  globalThis.window.__DSH_AUTO_KILL__ = original;
});

test('api: GET carries the token, POST carries the action, failures surface as codes', async () => {
  const calls = [];
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init });
    return { ok: true, status: 200, json: async () => ({ ok: true, data: { hello: 'world' } }) };
  };
  const api = mod.__test.createApi();
  assert.equal(api !== null, true);
  assert.deepEqual(await api.read(), { hello: 'world' });
  assert.equal(calls[0].init.method, 'GET');
  assert.equal(calls[0].init.headers['x-dsh-auto-kill-token'], globalThis.window.__DSH_AUTO_KILL__.token);
  assert.equal(calls[0].init.body, undefined);
  assert.equal(calls[0].init.cache, 'no-store');

  assert.deepEqual(await api.act('kill-now'), { hello: 'world' });
  assert.equal(calls[1].init.method, 'POST');
  assert.equal(calls[1].init.headers['content-type'], 'application/json');
  assert.equal(calls[1].init.body, JSON.stringify({ action: 'kill-now' }));

  globalThis.fetch = async () => ({ ok: false, status: 403, json: async () => ({ ok: false, error: 'forbidden' }) });
  await assert.rejects(() => api.read(), (error) => error.code === 'route-http' && error.status === 403);

  globalThis.fetch = async () => ({ ok: false, status: 400, json: async () => ({ ok: false, error: 'unknown auto-kill action: explode' }) });
  await assert.rejects(() => api.act('explode'), (error) => error.code === 'route-http' && error.status === 400);

  globalThis.fetch = async () => {
    throw new Error('network down');
  };
  await assert.rejects(() => api.read(), (error) => error.code === 'route-network');
});

test('failure translator: plain language plus a reconnect action, never an internal string', () => {
  const { describeFailure, dicts } = mod.__test;
  assert.equal(describeFailure(null, dicts.ja), null);
  const cases = [
    [{ code: 'handshake-network' }, 'connBlockedHandshakeTitle'],
    [{ code: 'handshake-empty' }, 'connBlockedHandshakeTitle'],
    [{ code: 'handshake-http', status: 401 }, 'connBlockedHandshakeTitle'],
    [{ code: 'page-no-fetch' }, 'connBlockedHandshakeTitle'],
    [{ code: 'route-http', status: 403 }, 'connBlockedExpiredTitle'],
    [{ code: 'route-http', status: 500 }, 'connBlockedUnknownTitle'],
    [{ code: 'route-network' }, 'connBlockedOfflineTitle'],
    [{ code: 'something-new' }, 'connBlockedUnknownTitle'],
  ];
  for (const [failure, key] of cases) {
    const described = describeFailure(failure, dicts.ja);
    assert.equal(described.title, dicts.ja[key], `${failure.code} maps to ${key}`);
    assert.equal(typeof described.body, 'string');
    assert.ok(described.body.length > 0);
    assert.equal(described.reconnect, true, 'every failure offers the remedy');
    // The whole point: what a user sees carries no internal identifier.
    const shown = `${described.title} ${described.body}`;
    for (const leak of ['bootstrap-missing', 'handshake-', 'route-', 'HTTP ', 'fetch', 'token']) {
      assert.equal(shown.includes(leak), false, `the panel never shows \`${leak}\``);
    }
  }
});

test('graphs: the sample ring is capped and gaps stay gaps', () => {
  const { pushSample, historyCap, sparklinePoints } = mod.__test;
  assert.equal(historyCap, 60, 'one minute at the 1 Hz floor');
  const history = [];
  for (let index = 0; index < 200; index += 1) pushSample(history, { at: index, cpu: index % 100, memory: 10 }, historyCap);
  assert.equal(history.length, historyCap);
  assert.equal(history.at(-1).cpu, 199 % 100);

  // A sample with no readable metric is not recorded at all: no fabricated zero.
  const before = history.length;
  pushSample(history, { at: 1, cpu: null, memory: null }, historyCap);
  assert.equal(history.length, before);
  pushSample(history, null, historyCap);
  assert.equal(history.length, before);

  const line = sparklinePoints(history, 'cpu', 100, 40);
  assert.equal(line.hasData, true);
  assert.equal(line.count, historyCap);
  assert.equal(line.points.split(' ').length, historyCap);
  const [firstX] = line.points.split(' ')[0].split(',');
  assert.equal(firstX, '0');
  const [lastX, lastY] = line.points.split(' ').at(-1).split(',');
  assert.equal(lastX, '100');
  assert.equal(Number(lastY) >= 0 && Number(lastY) <= 40, true, 'the y axis is clamped to the box');

  const gapped = sparklinePoints([{ cpu: 0, memory: null }, { cpu: null, memory: 5 }, { cpu: 100, memory: null }], 'cpu', 100, 40);
  assert.equal(gapped.count, 2, 'only the readable samples are plotted');
  assert.equal(gapped.points.split(' ').length, 2);
  assert.equal(gapped.points.split(' ')[0], '0,40');
  assert.equal(gapped.points.split(' ')[1], '100,0');

  const empty = sparklinePoints([], 'cpu', 100, 40);
  assert.equal(empty.hasData, false);
  assert.equal(empty.points, '');
  assert.equal(sparklinePoints([{ cpu: null, memory: null }], 'cpu', 100, 40).hasData, false);
});

test('history: the summary is derived from the host log and nothing is invented', () => {
  const { historySummary } = mod.__test;
  const empty = historySummary([], { jobs: 0, terminals: 0 });
  assert.equal(empty.total, 0);
  assert.equal(empty.first, null);
  assert.equal(empty.last, null);
  const summary = historySummary(
    [
      { at: 3000, kind: 'job', ok: true },
      { at: 2000, kind: 'terminal', ok: true },
      { at: 1000, kind: 'job', ok: false },
      { at: 500, kind: 'job', ok: true, dryRun: true },
      { at: 400, kind: 'job', ok: true, manual: true },
    ],
    { jobs: 9, terminals: 4 },
  );
  assert.equal(summary.jobs, 3);
  assert.equal(summary.terminals, 1);
  assert.equal(summary.failed, 1);
  assert.equal(summary.dryRun, 1);
  assert.equal(summary.manual, 1);
  assert.equal(summary.total, 4, 'terminal + job entries, dry runs excluded');
  assert.equal(summary.first, 400);
  assert.equal(summary.last, 3000);
});

test('settings fragment: the copyable YAML carries all ten keys and the live values', () => {
  const fragment = mod.__test.configFragment({
    enabled: true,
    cpuThreshold: 80,
    memoryThreshold: 70,
    intervalMs: 2000,
    sustainSamples: 3,
    cooldownMs: 30000,
    killJobs: true,
    jobKinds: ['bash', 'pwsh'],
    killTerminals: false,
    dryRun: true,
  });
  assert.match(fragment, /^- id: dsh-auto-kill$/m);
  assert.match(fragment, /cpuThreshold: 80/);
  assert.match(fragment, /memoryThreshold: 70/);
  assert.match(fragment, /intervalMs: 2000/);
  assert.match(fragment, /sustainSamples: 3/);
  assert.match(fragment, /cooldownMs: 30000/);
  assert.match(fragment, /killTerminals: false/);
  assert.match(fragment, /dryRun: true/);
  assert.match(fragment, /jobKinds: \[bash, pwsh\]/);
  // Every config key the host accepts appears in the fragment.
  const keys = ['enabled', 'cpuThreshold', 'memoryThreshold', 'intervalMs', 'sustainSamples', 'cooldownMs', 'killJobs', 'jobKinds', 'killTerminals', 'dryRun'];
  for (const key of keys) assert.match(fragment, new RegExp(`^\\s*${key}:`, 'm'), `${key} is in the fragment`);
});

test('settings rows: every row is drawn from the live snapshot, never a literal', () => {
  const rows = mod.__test.settingsRows({
    enabled: false,
    cpuThreshold: 55,
    memoryThreshold: 66,
    intervalMs: 2500,
    sustainSamples: 4,
    cooldownMs: 7000,
    killJobs: false,
    jobKinds: ['cmd'],
    killTerminals: true,
    dryRun: true,
  });
  const byKey = Object.fromEntries(rows.map((row) => [row.key, row.value]));
  assert.equal(byKey.cpuThreshold, '55%');
  assert.equal(byKey.memoryThreshold, '66%');
  assert.equal(byKey.intervalMs, '2500 ms');
  assert.equal(byKey.sustainSamples, '4');
  assert.equal(byKey.cooldownMs, '7000 ms');
  assert.equal(byKey.killJobs, 'false');
  assert.equal(byKey.killTerminals, 'true');
  assert.equal(byKey.enabled, 'false');
  assert.equal(byKey.dryRun, 'true');
  assert.equal(byKey.jobKinds, 'cmd');
  assert.deepEqual(rows.map((row) => row.key), ['enabled', 'cpuThreshold', 'memoryThreshold', 'intervalMs', 'sustainSamples', 'cooldownMs', 'killJobs', 'jobKinds', 'killTerminals', 'dryRun']);
  assert.equal(rows.every((row) => typeof row.rangeKey === 'string' && row.rangeKey.length > 0), true);
  assert.deepEqual(rows.find((row) => row.key === 'intervalMs').rangeParams, { min: 250, max: 600000 });
  assert.deepEqual(rows.find((row) => row.key === 'sustainSamples').rangeParams, { min: 1, max: 600 });
  assert.deepEqual(rows.find((row) => row.key === 'cpuThreshold').rangeParams, {});
});

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

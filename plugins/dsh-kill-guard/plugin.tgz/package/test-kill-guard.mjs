/**
 * Offline test for the Host half of `@local/dsh-kill-guard`.
 *
 * Everything here runs on node builtins. The monitor takes plain
 * service-shaped objects, so the whole decision path — sampling, sustains,
 * cooldown, pause, dry run, the owned-process fence, terminal closes — is
 * exercised without a harness, a browser, or a machine under load.
 *
 * The last group is the point of this rewrite: it pins the **backward
 * compatibility surface** of `@local/dsh-auto-kill` (routes, header, bootstrap
 * global, the ten config keys, the five POST actions, the snapshot field shape)
 * as literal constants, and — when the old bundle is still on disk — compares
 * the live old module against this one key by key.
 *
 *   node test-kill-guard.mjs
 */
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import {
  BOOTSTRAP_KEY,
  DEFAULT_CONFIG,
  MAX_BODY_BYTES,
  MAX_KILL_LOG,
  ROUTE_PATH,
  TOKEN_HEADER,
  TOKEN_PATH,
  VERSION,
  apply,
  authorized,
  bootstrapRow,
  createMonitor,
  createRouteHandler,
  createSampler,
  createTokenHandler,
  resolveConfig,
} from './index.js';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// ---------------------------------------------------------------------------
// the exact surface `dsh-auto-kill` published and the profile still assumes

test('compat: the route, header, and bootstrap identifiers are byte-identical', () => {
  assert.equal(ROUTE_PATH, '/local/auto-kill');
  assert.equal(TOKEN_PATH, '/local/auto-kill-token');
  assert.equal(BOOTSTRAP_KEY, '__DSH_AUTO_KILL__');
  assert.equal(TOKEN_HEADER, 'x-dsh-auto-kill-token');
  assert.equal(MAX_BODY_BYTES, 8 * 1024, 'the old body cap');
  assert.equal(MAX_KILL_LOG, 40, 'the old log cap');
});

test('compat: the ten configuration keys keep their names and defaults', () => {
  assert.deepEqual(Object.keys(DEFAULT_CONFIG).sort(), [
    'cooldownMs',
    'cpuThreshold',
    'dryRun',
    'enabled',
    'intervalMs',
    'jobKinds',
    'killJobs',
    'killTerminals',
    'memoryThreshold',
    'sustainSamples',
  ]);
  assert.equal(DEFAULT_CONFIG.enabled, true);
  assert.equal(DEFAULT_CONFIG.cpuThreshold, 90);
  assert.equal(DEFAULT_CONFIG.memoryThreshold, 90);
  assert.equal(DEFAULT_CONFIG.intervalMs, 1500);
  assert.equal(DEFAULT_CONFIG.sustainSamples, 2);
  assert.equal(DEFAULT_CONFIG.cooldownMs, 15000);
  assert.equal(DEFAULT_CONFIG.killJobs, true);
  assert.deepEqual(DEFAULT_CONFIG.jobKinds, ['bash', 'pwsh']);
  assert.equal(DEFAULT_CONFIG.killTerminals, true);
  assert.equal(DEFAULT_CONFIG.dryRun, false);
});

/** The snapshot field names `dsh-auto-kill/client.js` read; a superset is fine. */
const LEGACY_SNAPSHOT = {
  root: ['version', 'at', 'settings', 'monitor', 'sample', 'counters', 'kills', 'host'],
  settings: ['enabled', 'cpuThreshold', 'memoryThreshold', 'intervalMs', 'sustainSamples', 'cooldownMs', 'killJobs', 'jobKinds', 'killTerminals', 'dryRun'],
  monitor: ['active', 'paused', 'pausedReason', 'busy', 'ticks', 'breachStreak', 'sustainSamples', 'cooldownRemainingMs', 'lastError', 'lastKillAt'],
  sample: ['cpu', 'memory', 'totalBytes', 'freeBytes', 'at', 'ageMs'],
  counters: ['rounds', 'ticks', 'jobs', 'terminals', 'failures', 'dryRuns'],
  host: ['platform', 'arch', 'cores', 'totalBytes', 'freeBytes', 'pid', 'uptimeSec'],
};

function assertSuperset(actual, expected, label) {
  for (const key of expected) {
    assert.ok(key in actual, `${label} keeps the legacy field \`${key}\``);
  }
}

test('compat: the snapshot is a strict superset of the legacy field shape', async () => {
  const monitor = createMonitor({
    jobs: createFakeJobs(),
    agents: createFakeAgents(),
    settings: resolveConfig(),
    sampler: () => ({ cpu: 10, memory: 20, totalBytes: 16 * 1024 ** 3, freeBytes: 8 * 1024 ** 3, measured: true, at: Date.now() }),
  });
  await monitor.tick();
  const snapshot = monitor.snapshot();
  assertSuperset(snapshot, LEGACY_SNAPSHOT.root, 'snapshot');
  assertSuperset(snapshot.settings, LEGACY_SNAPSHOT.settings, 'snapshot.settings');
  assertSuperset(snapshot.monitor, LEGACY_SNAPSHOT.monitor, 'snapshot.monitor');
  assertSuperset(snapshot.sample, LEGACY_SNAPSHOT.sample, 'snapshot.sample');
  assertSuperset(snapshot.counters, LEGACY_SNAPSHOT.counters, 'snapshot.counters');
  assertSuperset(snapshot.host, LEGACY_SNAPSHOT.host, 'snapshot.host');
  assert.equal(snapshot.version, VERSION);
  assert.equal(Array.isArray(snapshot.kills), true);
  // The additions the new panel needs, and nothing that shadows a legacy name.
  assert.equal(snapshot.monitor.historyCap, MAX_KILL_LOG);
  assert.equal(snapshot.monitor.breachTotal, 0, 'a quiet sample is not a breach');
  assert.equal(snapshot.monitor.lastEvent, null, 'a sample is not an event: nothing has happened yet');
  assert.equal(snapshot.counters.manual, 0);
});

test('compat: the live old bundle, when present, uses a subset of this shape', async () => {
  const legacy = await import('../dsh-auto-kill/index.js').catch(() => null);
  if (legacy === null) {
    console.log('     (skip: ../dsh-auto-kill is no longer on disk)');
    return;
  }
  const monitor = createMonitor({
    jobs: createFakeJobs(),
    agents: createFakeAgents(),
    settings: resolveConfig(),
    sampler: () => ({ cpu: 10, memory: 20, totalBytes: 16 * 1024 ** 3, freeBytes: 8 * 1024 ** 3, at: Date.now() }),
  });
  await monitor.tick();
  const old = legacy.createMonitor({
    jobs: createFakeJobs(),
    agents: createFakeAgents(),
    settings: legacy.resolveConfig(),
    sampler: () => ({ cpu: 10, memory: 20, totalBytes: 16 * 1024 ** 3, freeBytes: 8 * 1024 ** 3, at: Date.now() }),
  });
  await old.tick();

  // Comparing to the real old module is what catches a rename nobody noticed.
  assert.deepEqual(legacy.resolveConfig(), resolveConfig(), 'config normalization is unchanged');
  assert.deepEqual(Object.keys(legacy.DEFAULT_CONFIG).sort(), Object.keys(DEFAULT_CONFIG).sort());
  const oldSnapshot = old.snapshot();
  const newSnapshot = monitor.snapshot();
  assertSuperset(newSnapshot, Object.keys(oldSnapshot), 'snapshot (live old module)');
  assertSuperset(newSnapshot.settings, Object.keys(oldSnapshot.settings), 'snapshot.settings (live old module)');
  assertSuperset(newSnapshot.monitor, Object.keys(oldSnapshot.monitor), 'snapshot.monitor (live old module)');
  assertSuperset(newSnapshot.sample, Object.keys(oldSnapshot.sample), 'snapshot.sample (live old module)');
  assertSuperset(newSnapshot.counters, Object.keys(oldSnapshot.counters), 'snapshot.counters (live old module)');
  assertSuperset(newSnapshot.host, Object.keys(oldSnapshot.host), 'snapshot.host (live old module)');
});

// ---------------------------------------------------------------------------
// config

test('resolveConfig: defaults are the shipped 90% / 90% guard', () => {
  const settings = resolveConfig();
  assert.deepEqual(settings, { ...DEFAULT_CONFIG, jobKinds: ['bash', 'pwsh'] });
});

test('resolveConfig: values are clamped and junk falls back', () => {
  const settings = resolveConfig({
    cpuThreshold: 400,
    memoryThreshold: -5,
    intervalMs: 1,
    sustainSamples: 0,
    cooldownMs: -100,
    jobKinds: ['bash', '', 7, ' pwsh '],
    dryRun: 'yes',
    killJobs: false,
  });
  assert.equal(settings.cpuThreshold, 100);
  assert.equal(settings.memoryThreshold, 0);
  assert.equal(settings.intervalMs, 250);
  assert.equal(settings.sustainSamples, 1);
  assert.equal(settings.cooldownMs, 0);
  assert.deepEqual(settings.jobKinds, ['bash', 'pwsh']);
  assert.equal(settings.dryRun, false, 'a non-boolean dryRun keeps the default');
  assert.equal(settings.killJobs, false);
  assert.equal(resolveConfig({ jobKinds: [] }).jobKinds.length, 2, 'an empty kind list keeps the defaults');
  assert.equal(resolveConfig({ intervalMs: 1e9 }).intervalMs, 600000);
});

// ---------------------------------------------------------------------------
// sampling

test('createSampler: CPU is the busy share of the counter delta, memory the used share', () => {
  const times = [
    { idle: 800, total: 1000 }, // primed at creation
    { idle: 900, total: 1200 }, // delta: 100 idle of 200 total -> 50% busy
    { idle: 1050, total: 1400 }, // delta: 150 idle of 200 total -> 25% busy
  ];
  const memory = [16 * 1024 ** 3, 8 * 1024 ** 3];
  const sample = createSampler({
    cpuTimes: () => times.shift(),
    freemem: () => memory.shift(),
    totalmem: () => 16 * 1024 ** 3,
    now: () => 1_700_000_000_000,
  });
  const first = sample();
  assert.equal(first.cpu, 50, 'the first call covers the delta since creation');
  assert.equal(first.memory, 0);
  assert.equal(first.at, 1_700_000_000_000);
  assert.equal(first.measured, true);
  const second = sample();
  assert.equal(second.cpu, 25, 'each call consumes the counters it read');
  assert.equal(second.memory, 50);
});

test('createSampler: a delta with no elapsed total reports 0%, never NaN', () => {
  const sample = createSampler({
    cpuTimes: (() => {
      const queue = [{ idle: 10, total: 10 }, { idle: 10, total: 10 }];
      return () => queue.shift();
    })(),
    freemem: () => 1,
    totalmem: () => 2,
  });
  const value = sample();
  assert.equal(value.cpu, 0);
  assert.equal(value.memory, 50);
});

test('createSampler: metrics that cannot be read are null, never a fabricated zero', () => {
  const sample = createSampler({
    cpuTimes: () => {
      throw new Error('no counters on this host');
    },
    freemem: () => {
      throw new Error('no memory counters');
    },
    totalmem: () => 0,
  });
  const value = sample();
  assert.equal(value.cpu, null);
  assert.equal(value.memory, null, 'a zero-capacity machine cannot report a used share');
  assert.equal(value.totalBytes, 0);
  assert.equal(value.freeBytes, null);
  assert.equal(value.measured, false);
  // And it recovers as soon as the counters answer again.
  const recovering = createSampler({
    cpuTimes: (() => {
      const queue = [{ idle: 0, total: 0 }, { idle: 50, total: 100 }];
      return () => queue.shift();
    })(),
    freemem: () => 0,
    totalmem: () => 100,
  });
  assert.equal(recovering().cpu, 50);
});

test('createSampler: a nonsensical counter payload is treated as unavailable', () => {
  const sample = createSampler({
    cpuTimes: (() => {
      const queue = [{ idle: 'x', total: null }, { idle: Number.NaN, total: 5 }];
      return () => queue.shift();
    })(),
    freemem: () => -1,
    totalmem: () => Number.NaN,
  });
  const value = sample();
  assert.equal(value.cpu, null);
  assert.equal(value.memory, null);
  assert.equal(value.freeBytes, null, 'a negative free value is not a reading');
});

// ---------------------------------------------------------------------------
// fakes

function createFakeJobs(seed = []) {
  const store = new Map();
  const calls = [];
  for (const view of seed) store.set(view.id, { status: 'running', ...view });
  return {
    calls,
    store,
    list(caller) {
      return [...store.values()]
        .filter((job) => job.owner === undefined || job.owner === caller)
        .map((job) => ({ ...job }));
    },
    kill(id, caller, reason) {
      calls.push({ id, caller, reason });
      const job = store.get(id);
      if (job === undefined) throw new Error(`unknown job ${id}`);
      // Mirrors dsh-jobs-local's assertAccess: owner identity is the fence.
      if (job.owner !== undefined && job.owner !== caller) throw new Error(`job ${id} belongs to another session`);
      job.status = 'stopping';
      return 'requested';
    },
  };
}

function createFakeAgents(ids = ['session-a', 'session-b']) {
  return { list: () => ids.map((id) => ({ id })) };
}

function createFakeTerminals(seed = []) {
  const closed = [];
  return {
    closed,
    list(sessionId) {
      return seed.filter((terminal) => terminal.sessionId === sessionId).map(({ sessionId: _ignored, ...info }) => ({ ...info }));
    },
    async close(agent, id) {
      closed.push({ sessionId: agent.id, id });
      const entry = seed.find((terminal) => terminal.id === id);
      if (entry?.fail === true) throw new Error('terminal refused to close');
      if (entry) entry.state = 'exited';
    },
  };
}

/** A monitor whose sampler replays a scripted list, one entry per tick. */
function scriptedMonitor(options) {
  const queue = [...options.samples];
  return createMonitor({
    ...options,
    sampler: () => {
      const next = queue.length > 1 ? queue.shift() : queue[0];
      return {
        cpu: next.cpu,
        memory: next.memory,
        totalBytes: 16 * 1024 ** 3,
        freeBytes: 8 * 1024 ** 3,
        measured: true,
        at: options.now?.() ?? Date.now(),
      };
    },
  });
}

const quiet = { cpu: 10, memory: 20 };
const hot = { cpu: 95, memory: 20 };
const memoryHot = { cpu: 10, memory: 96 };

// ---------------------------------------------------------------------------
// monitor

test('monitor: a quiet machine is never touched', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'sleep 1', owner: 'session-a' }]);
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [quiet] });
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 0);
  assert.equal(monitor.state.counters.jobs, 0);
  assert.equal(monitor.snapshot().monitor.breachTotal, 0);
});

test('monitor: a single sample over the CPU arm does not stop anything', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'ffmpeg', owner: 'session-a' }]);
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [hot] });
  await monitor.tick();
  assert.equal(jobs.calls.length, 0, 'sustainSamples defaults to 2');
  assert.equal(monitor.state.breachStreak, 1);
  assert.equal(monitor.snapshot().monitor.breachTotal, 1, 'the panel counts every over-threshold sample');
  assert.equal(monitor.snapshot().monitor.lastEvent.kind, 'breach');
  assert.equal(monitor.snapshot().monitor.lastEvent.tone, 'warn');
  assert.match(monitor.snapshot().monitor.lastEvent.text, /CPU 95% ≥ 90%/);
});

test('monitor: sustained CPU stops every shell job with its own owner as the caller', async () => {
  const jobs = createFakeJobs([
    { id: 'bash-1', kind: 'bash', label: 'ffmpeg -i a.mkv', owner: 'session-a' },
    { id: 'bash-2', kind: 'pwsh', label: 'Get-ChildItem -Recurse', owner: 'session-b' },
    { id: 'bash-3', kind: 'bash', label: 'unowned shell' },
    { id: 'subagent-1', kind: 'subagent', label: 'child agent', owner: 'session-a' },
    { id: 'bash-4', kind: 'bash', label: 'finished', owner: 'session-a', status: 'completed' },
  ]);
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [hot] });
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 3, 'two owned shells and one unowned shell');
  assert.deepEqual(jobs.calls.map((call) => call.id).sort(), ['bash-1', 'bash-2', 'bash-3']);
  assert.equal(jobs.calls.find((call) => call.id === 'bash-1').caller, 'session-a');
  assert.equal(jobs.calls.find((call) => call.id === 'bash-2').caller, 'session-b');
  assert.equal(jobs.calls.find((call) => call.id === 'bash-3').caller, undefined);
  assert.match(jobs.calls[0].reason, /CPU 95% ≥ 90%/);
  assert.equal(monitor.state.counters.jobs, 3);
  assert.equal(monitor.state.breachStreak, 0, 'a completed round resets the streak');
  assert.equal(monitor.snapshot().kills.length, 3);
  assert.equal(monitor.snapshot().kills[0].kind, 'job');
});

// ---------------------------------------------------------------------------
// the owned-process fence, pinned exactly

test('fence: only `running` jobs of a configured kind are ever cancelled', async () => {
  const jobs = createFakeJobs([
    { id: 'run-bash', kind: 'bash', label: 'running shell', owner: 'session-a', status: 'running' },
    { id: 'stopping-bash', kind: 'bash', label: 'already stopping', owner: 'session-a', status: 'stopping' },
    { id: 'done-bash', kind: 'bash', label: 'completed', owner: 'session-a', status: 'completed' },
    { id: 'failed-bash', kind: 'bash', label: 'failed', owner: 'session-a', status: 'failed' },
    { id: 'run-pwsh', kind: 'pwsh', label: 'running pwsh', owner: 'session-a', status: 'running' },
    { id: 'run-node', kind: 'node', label: 'not a shell', owner: 'session-a', status: 'running' },
    { id: 'run-agent', kind: 'subagent', label: 'child agent', owner: 'session-a', status: 'running' },
    { id: 'run-pty', kind: 'terminal', label: 'side terminal', owner: 'session-a', status: 'running' },
  ]);
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [hot] });
  await monitor.tick();
  await monitor.tick();
  assert.deepEqual(jobs.calls.map((call) => call.id).sort(), ['run-bash', 'run-pwsh']);
});

test('fence: a custom jobKinds list narrows the target set and nothing else leaks in', async () => {
  const jobs = createFakeJobs([
    { id: 'run-bash', kind: 'bash', label: 'bash', owner: 'session-a', status: 'running' },
    { id: 'run-pwsh', kind: 'pwsh', label: 'pwsh', owner: 'session-a', status: 'running' },
    { id: 'run-cmd', kind: 'cmd', label: 'cmd', owner: 'session-a', status: 'running' },
  ]);
  const monitor = scriptedMonitor({
    jobs,
    agents: createFakeAgents(),
    settings: resolveConfig({ jobKinds: ['pwsh'] }),
    samples: [hot],
  });
  await monitor.tick();
  await monitor.tick();
  assert.deepEqual(jobs.calls.map((call) => call.id), ['run-pwsh']);
  assert.match(monitor.snapshot().settings.jobKinds.join(','), /pwsh/);
});

test('fence: a foreign-owned job is never reachable with our own identity', async () => {
  // The registry only answers per caller, exactly like dsh-jobs-local. A caller
  // that is not the owner must never be used, or kill() throws.
  const store = new Map([
    ['mine', { id: 'mine', kind: 'bash', label: 'mine', owner: 'session-a', status: 'running' }],
    ['theirs', { id: 'theirs', kind: 'bash', label: 'theirs', owner: 'session-z', status: 'running' }],
  ]);
  const calls = [];
  const jobs = {
    list: (caller) => [...store.values()].filter((job) => job.owner === undefined || job.owner === caller).map((job) => ({ ...job })),
    kill(id, caller) {
      calls.push({ id, caller });
      const job = store.get(id);
      if (job.owner !== caller) throw new Error('job belongs to another session');
      job.status = 'stopping';
    },
  };
  const monitor = scriptedMonitor({
    jobs,
    agents: { list: () => [{ id: 'session-a' }, { id: 'session-z' }, { id: 'session-root' }] },
    settings: resolveConfig(),
    samples: [hot],
  });
  await monitor.tick();
  await monitor.tick();
  // `session-z` is a live Agent id, so listing per caller reaches `theirs`, but
  // the kill still passes the job's own owner back — never the enumerator.
  assert.deepEqual(calls.find((call) => call.id === 'theirs'), { id: 'theirs', caller: 'session-z' });
  assert.deepEqual(calls.find((call) => call.id === 'mine'), { id: 'mine', caller: 'session-a' });
});

test('monitor: the memory arm is independent of the CPU arm', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'leak', owner: 'session-a' }]);
  const monitor = scriptedMonitor({
    jobs,
    agents: createFakeAgents(),
    settings: resolveConfig({ cpuThreshold: 0 }),
    samples: [memoryHot],
  });
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 1);
  assert.match(jobs.calls[0].reason, /MEM 96% ≥ 90%/);
});

test('monitor: the cooldown blocks a second round, and a later breach runs again', async () => {
  let now = 1_000_000;
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'one', owner: 'session-a' }]);
  const monitor = createMonitor({
    jobs,
    agents: createFakeAgents(),
    settings: resolveConfig({ cooldownMs: 5000 }),
    now: () => now,
    sampler: () => ({ ...hot, totalBytes: 1, freeBytes: 0, measured: true, at: now }),
  });
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 1);
  now += 1000;
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 1, 'still cooling down');
  assert.ok(monitor.snapshot().monitor.cooldownRemainingMs > 0);
  now += 10_000;
  jobs.store.set('bash-2', { id: 'bash-2', kind: 'bash', label: 'two', owner: 'session-a', status: 'running' });
  await monitor.tick();
  assert.equal(jobs.calls.length, 2, 'the next breach after the cooldown stops the new shell');
  assert.equal(jobs.calls[1].id, 'bash-2');
});

test('monitor: pause blocks enforcement, resume re-arms it, and sampling keeps running', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'busy', owner: 'session-a' }]);
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [hot] });
  monitor.pause('test');
  assert.equal(monitor.snapshot().monitor.lastEvent.kind, 'pause');
  assert.equal(monitor.snapshot().monitor.lastEvent.text, 'test');
  await monitor.tick();
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 0);
  assert.equal(monitor.state.ticks, 3, 'values keep updating while paused');
  assert.equal(monitor.snapshot().sample.cpu, 95);
  assert.equal(monitor.snapshot().monitor.pausedReason, 'test');
  monitor.resume();
  assert.equal(monitor.snapshot().monitor.lastEvent.kind, 'resume');
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 1);
  assert.equal(monitor.snapshot().monitor.lastEvent.kind, 'stop');
  assert.equal(monitor.snapshot().monitor.lastEvent.tone, 'hot');
});

test('monitor: disabled stops enforcing without stopping the gauge', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'busy', owner: 'session-a' }]);
  const monitor = scriptedMonitor({
    jobs,
    agents: createFakeAgents(),
    settings: resolveConfig({ enabled: false }),
    samples: [hot],
  });
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 0);
  assert.equal(monitor.state.counters.ticks, 2);
  assert.equal(monitor.snapshot().monitor.breachTotal, 0, 'a disabled arm is not a breach');
});

test('monitor: dry run records the stop it would have made and calls nothing', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'ffmpeg', owner: 'session-a' }]);
  const monitor = scriptedMonitor({
    jobs,
    agents: createFakeAgents(),
    settings: resolveConfig({ dryRun: true }),
    samples: [hot],
  });
  await monitor.tick();
  await monitor.tick();
  assert.equal(jobs.calls.length, 0);
  assert.equal(monitor.state.counters.jobs, 0);
  assert.equal(monitor.state.counters.dryRuns, 1);
  assert.equal(monitor.snapshot().kills[0].dryRun, true);
});

test('monitor: running terminals are closed, exited ones are left alone', async () => {
  const terminals = createFakeTerminals([
    { id: 'term-1', sessionId: 'session-a', title: 'pwsh', state: 'running' },
    { id: 'term-2', sessionId: 'session-a', title: 'old shell', state: 'exited' },
    { id: 'term-3', sessionId: 'session-b', title: 'bash', state: 'running' },
  ]);
  const monitor = scriptedMonitor({
    jobs: createFakeJobs(),
    agents: createFakeAgents(),
    terminalController: terminals,
    settings: resolveConfig(),
    samples: [hot],
  });
  await monitor.tick();
  await monitor.tick();
  assert.deepEqual(terminals.closed, [
    { sessionId: 'session-a', id: 'term-1' },
    { sessionId: 'session-b', id: 'term-3' },
  ]);
  assert.equal(monitor.state.counters.terminals, 2);
});

test('monitor: a refusing terminal is a recorded failure, not a thrown tick', async () => {
  const terminals = createFakeTerminals([{ id: 'term-1', sessionId: 'session-a', title: 'pwsh', state: 'running', fail: true }]);
  const monitor = scriptedMonitor({
    jobs: createFakeJobs(),
    agents: createFakeAgents(),
    terminalController: terminals,
    settings: resolveConfig(),
    samples: [hot],
  });
  await monitor.tick();
  await monitor.tick();
  assert.equal(monitor.state.counters.failures, 1);
  const entry = monitor.snapshot().kills[0];
  assert.equal(entry.ok, false);
  assert.match(entry.error, /refused to close/);
});

test('monitor: a refusing registry is recorded and never breaks the loop', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'busy', owner: 'session-a' }]);
  jobs.kill = () => {
    throw new Error('job bash-1 is still stopping');
  };
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [hot] });
  await monitor.tick();
  await monitor.tick();
  assert.equal(monitor.state.counters.failures, 1);
  assert.match(monitor.snapshot().monitor.lastError, /still stopping/);
});

test('monitor: killNow enforces regardless of thresholds and pause, and is marked manual', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'busy', owner: 'session-a' }]);
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [quiet] });
  monitor.pause('test');
  await monitor.killNow();
  assert.equal(jobs.calls.length, 1);
  assert.match(jobs.calls[0].reason, /manual request/);
  const snapshot = monitor.snapshot();
  assert.equal(snapshot.counters.manual, 1);
  assert.equal(snapshot.kills[0].manual, true);
  assert.equal(snapshot.monitor.lastEvent.kind, 'stop');
  assert.equal(snapshot.monitor.lastEvent.manual, true);
});

test('monitor: an unavailable registry degrades instead of throwing', async () => {
  const monitor = createMonitor({
    jobs: {
      list: () => {
        throw new Error('registry offline');
      },
    },
    agents: {
      list: () => {
        throw new Error('agents offline');
      },
    },
    settings: resolveConfig(),
    sampler: () => ({ ...hot, totalBytes: 1, freeBytes: 0, measured: true, at: Date.now() }),
  });
  await monitor.tick();
  await monitor.tick();
  const snapshot = monitor.snapshot();
  assert.equal(snapshot.counters.jobs + snapshot.counters.failures, 0);
  assert.match(snapshot.monitor.lastError, /jobs\.kill is unavailable/);
  assert.equal(snapshot.counters.ticks, 2, 'the gauge keeps sampling');
  assert.equal(snapshot.monitor.lastEvent.tone, 'warn');
});

test('monitor: only the plugin’s own node timers are owned, and the log is capped', async () => {
  const jobs = createFakeJobs();
  const monitor = scriptedMonitor({ jobs, agents: createFakeAgents(), settings: resolveConfig(), samples: [hot] });
  for (let index = 0; index < 60; index += 1) {
    jobs.store.set(`bash-${index}`, { id: `bash-${index}`, kind: 'bash', label: 'x', owner: 'session-a', status: 'running' });
    await monitor.tick();
    await monitor.tick();
    monitor.state.cooldownUntil = 0;
  }
  const snapshot = monitor.snapshot();
  assert.equal(snapshot.kills.length, MAX_KILL_LOG);
  assert.equal(snapshot.counters.jobs, 60, 'the counter is cumulative even though the log is capped');
});

test('monitor: start/stop own exactly one interval', () => {
  const monitor = scriptedMonitor({
    jobs: createFakeJobs(),
    agents: createFakeAgents(),
    settings: resolveConfig({ intervalMs: 600000 }),
    samples: [quiet],
  });
  assert.equal(monitor.isRunning(), false);
  monitor.start();
  assert.equal(monitor.isRunning(), true);
  monitor.start();
  assert.equal(monitor.isRunning(), true);
  monitor.stop();
  assert.equal(monitor.isRunning(), false);
  monitor.stop();
  assert.equal(monitor.isRunning(), false);
});

test('monitor: clearLog empties the log and says so in the event line', () => {
  const monitor = scriptedMonitor({ jobs: createFakeJobs(), agents: createFakeAgents(), settings: resolveConfig(), samples: [quiet] });
  monitor.clearLog();
  assert.deepEqual(monitor.snapshot().kills, []);
  assert.equal(monitor.snapshot().monitor.lastEvent.kind, 'clear');
});

// ---------------------------------------------------------------------------
// route

test('bootstrapRow: the capability rides the structured index-injection table', () => {
  const row = bootstrapRow({ path: ROUTE_PATH, token: 'tok-1' });
  assert.deepEqual(row, { kind: 'global', name: BOOTSTRAP_KEY, value: { path: ROUTE_PATH, token: 'tok-1' } });
  assert.deepEqual(JSON.parse(JSON.stringify(row)), row, 'rows travel over the Desktop shell boot IPC, so they are pure JSON');
  assert.equal(row.name, '__DSH_AUTO_KILL__');
});

test('authorized: only the same-origin holder of the exact token passes', () => {
  const token = 'a'.repeat(48);
  assert.equal(authorized({ headers: { [TOKEN_HEADER]: token } }, token), true);
  assert.equal(authorized({ headers: { [TOKEN_HEADER]: 'b'.repeat(48) } }, token), false);
  assert.equal(authorized({ headers: { [TOKEN_HEADER]: 'short' } }, token), false);
  assert.equal(authorized({ headers: {} }, token), false);
  assert.equal(authorized({ headers: { [TOKEN_HEADER]: token, 'sec-fetch-site': 'cross-site' } }, token), false);
});

function fakeRequest(method, headers = {}, body = '') {
  const req = new EventEmitter();
  req.method = method;
  req.headers = headers;
  req.destroy = () => {};
  process.nextTick(() => {
    if (body) req.emit('data', Buffer.from(body));
    req.emit('end');
  });
  return req;
}

function fakeResponse() {
  const response = {
    status: undefined,
    headers: undefined,
    body: undefined,
    writeHead(status, headers) {
      response.status = status;
      response.headers = headers;
    },
    end(payload) {
      response.body = payload;
    },
  };
  return response;
}

function controlSpy() {
  const calls = [];
  const snapshot = { version: 'test', monitor: { active: true } };
  let paused = false;
  return {
    calls,
    snapshot: () => snapshot,
    pause: (reason) => {
      paused = true;
      calls.push(['pause', reason]);
    },
    resume: () => {
      paused = false;
      calls.push(['resume']);
    },
    killNow: async () => calls.push(['kill-now']),
    clearLog: () => calls.push(['clear-log']),
    isPaused: () => paused,
  };
}

test('route: rejects a missing token and answers an authorized GET', async () => {
  const control = controlSpy();
  const handler = createRouteHandler(control, 'token-token-token-token-token-token-1');
  const denied = fakeResponse();
  await handler(fakeRequest('GET'), denied);
  assert.equal(denied.status, 403);

  const allowed = fakeResponse();
  await handler(fakeRequest('GET', { [TOKEN_HEADER]: 'token-token-token-token-token-token-1' }), allowed);
  assert.equal(allowed.status, 200);
  assert.equal(allowed.headers['cache-control'], 'no-store');
  assert.deepEqual(JSON.parse(allowed.body), { ok: true, data: control.snapshot() });
});

test('route: POST drives all five legacy actions, `toggle` included, and rejects junk', async () => {
  const token = 'token-token-token-token-token-token-2';
  const control = controlSpy();
  const handler = createRouteHandler(control, token);
  const post = async (action) => {
    const response = fakeResponse();
    await handler(fakeRequest('POST', { [TOKEN_HEADER]: token }, JSON.stringify({ action })), response);
    return response;
  };
  for (const action of ['pause', 'resume', 'toggle', 'kill-now', 'clear-log']) {
    const response = await post(action);
    assert.equal(response.status, 200, `${action} is accepted`);
    assert.equal(JSON.parse(response.body).action, action);
  }
  assert.deepEqual(control.calls, [
    ['pause', 'panel'],
    ['resume'],
    ['pause', 'panel'],
    ['kill-now'],
    ['clear-log'],
  ], 'toggle paused the monitor because it was resumed');

  const toggledOn = await post('toggle');
  assert.equal(toggledOn.status, 200);
  assert.deepEqual(control.calls.at(-1), ['resume'], 'toggle resumes a paused monitor');

  const unknown = await post('explode');
  assert.equal(unknown.status, 400);
  assert.match(JSON.parse(unknown.body).error, /unknown auto-kill action/);

  const wrongMethod = fakeResponse();
  await handler(fakeRequest('PUT', { [TOKEN_HEADER]: token }), wrongMethod);
  assert.equal(wrongMethod.status, 405);

  const malformed = fakeResponse();
  await handler(fakeRequest('POST', { [TOKEN_HEADER]: token }, '{not json'), malformed);
  assert.equal(malformed.status, 400);
});

test('route: a body over the cap is refused instead of buffered', async () => {
  const token = 'token-token-token-token-token-token-4';
  const handler = createRouteHandler(controlSpy(), token);
  const response = fakeResponse();
  await handler(fakeRequest('POST', { [TOKEN_HEADER]: token }, 'x'.repeat(MAX_BODY_BYTES + 1)), response);
  assert.equal(response.status, 400);
  assert.match(JSON.parse(response.body).error, /too large/);
});

test('token route: hands out the capability to an authenticated same-origin page only', async () => {
  const token = 'token-token-token-token-token-token-3';
  const authenticated = (req) => req.headers.cookie === 'dsh-client-connection=ok';
  const handler = createTokenHandler(token, authenticated);

  const allowed = fakeResponse();
  await handler(fakeRequest('GET', { cookie: 'dsh-client-connection=ok' }), allowed);
  assert.equal(allowed.status, 200);
  assert.equal(allowed.headers['cache-control'], 'no-store');
  assert.deepEqual(JSON.parse(allowed.body), { ok: true, data: { path: ROUTE_PATH, token } });

  const head = fakeResponse();
  await handler(fakeRequest('HEAD', { cookie: 'dsh-client-connection=ok' }), head);
  assert.equal(head.status, 200);

  const anonymous = fakeResponse();
  await handler(fakeRequest('GET'), anonymous);
  assert.equal(anonymous.status, 401);

  const crossSite = fakeResponse();
  await handler(fakeRequest('GET', { cookie: 'dsh-client-connection=ok', 'sec-fetch-site': 'cross-site' }), crossSite);
  assert.equal(crossSite.status, 403);

  const posted = fakeResponse();
  await handler(fakeRequest('POST', { cookie: 'dsh-client-connection=ok' }), posted);
  assert.equal(posted.status, 405);

  const openRes = fakeResponse();
  await createTokenHandler(token, undefined)(fakeRequest('GET'), openRes);
  assert.equal(openRes.status, 200, 'a composition without the connection service still serves the capability');

  const thrown = fakeResponse();
  await createTokenHandler(token, () => {
    throw new Error('bad header shape');
  })(fakeRequest('GET'), thrown);
  assert.equal(thrown.status, 401);
});

// ---------------------------------------------------------------------------
// apply wiring

/** Minimal cordis-shaped context: `inject` runs when its services exist, `effect` is disposable. */
function createStubContext(services) {
  const disposers = [];
  const ctx = {
    logger: { info: [], warn: [] },
    services,
    injected: [],
    listeners: {},
    get(name) {
      return services[name];
    },
    on(event, handler) {
      const list = (ctx.listeners[event] ??= []);
      list.push(handler);
      return () => {
        const at = list.indexOf(handler);
        if (at !== -1) list.splice(at, 1);
      };
    },
    injectionTable() {
      const table = [];
      for (const handler of ctx.listeners['webserver/index-inject'] ?? []) handler(table);
      return table;
    },
    inject(names, callback) {
      ctx.injected.push(names);
      if (!names.every((name) => services[name] !== undefined)) return () => {};
      const child = {
        ...ctx,
        logger: ctx.logger,
        get: (name) => services[name],
        effect(fn) {
          const dispose = fn();
          if (typeof dispose === 'function') disposers.push(dispose);
          return dispose;
        },
      };
      for (const name of names) child[name] = services[name];
      callback(child);
      return () => {};
    },
    effect(fn) {
      const dispose = fn();
      if (typeof dispose === 'function') disposers.push(dispose);
      return dispose;
    },
  };
  ctx.logger.info = (...args) => ctx.logger.info.log.push(args);
  ctx.logger.info.log = [];
  ctx.logger.warn = (...args) => ctx.logger.warn.log.push(args);
  ctx.logger.warn.log = [];
  ctx.disposeAll = () => {
    while (disposers.length > 0) disposers.pop()();
  };
  return ctx;
}

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

test('apply: registers both routes, publishes the capability row, and owns the timer', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'busy', owner: 'session-a' }]);
  const routes = [];
  const ctx = createStubContext({
    jobs,
    agents: createFakeAgents(),
    connection: { isAuthenticated: () => true },
    webServer: {
      register(route) {
        routes.push(route);
        return () => {};
      },
    },
  });
  apply(ctx, { intervalMs: 600000 });

  assert.deepEqual(ctx.injected, [['jobs', 'agents'], ['webServer']]);
  assert.deepEqual(routes.map((route) => route.path), [ROUTE_PATH, TOKEN_PATH]);
  assert.equal(routes[0].kind, 'exact');
  assert.equal(routes[1].kind, 'exact');

  const table = ctx.injectionTable();
  assert.equal(table.length, 1);
  assert.equal(table[0].kind, 'global');
  assert.equal(table[0].name, BOOTSTRAP_KEY);
  assert.equal(table[0].value.path, ROUTE_PATH);
  const token = table[0].value.token;
  assert.equal(token.length, 48, '24 random bytes, exactly as before');

  const handed = fakeResponse();
  await routes[1].handler(fakeRequest('GET'), handed);
  assert.equal(handed.status, 200, 'the connection service authorizes the page');
  assert.deepEqual(JSON.parse(handed.body).data, { path: ROUTE_PATH, token });

  const live = fakeResponse();
  await routes[0].handler(fakeRequest('GET', { [TOKEN_HEADER]: token }), live);
  assert.equal(live.status, 200);
  const snapshot = JSON.parse(live.body).data;
  assert.equal(snapshot.monitor.active, true, 'the monitor started with the profile');
  assert.equal(snapshot.settings.cpuThreshold, 90);
  assert.equal(snapshot.host.cores > 0, true);
  assert.equal(snapshot.sample, null, 'no tick has run yet at a 10 minute interval');
  assert.equal(snapshot.monitor.historyCap, MAX_KILL_LOG);

  const paused = fakeResponse();
  await routes[0].handler(fakeRequest('POST', { [TOKEN_HEADER]: token }, JSON.stringify({ action: 'pause' })), paused);
  assert.equal(JSON.parse(paused.body).data.monitor.paused, true);

  ctx.disposeAll();
  const afterTeardown = fakeResponse();
  await routes[0].handler(fakeRequest('GET', { [TOKEN_HEADER]: token }), afterTeardown);
  assert.equal(JSON.parse(afterTeardown.body).data.monitor.active, false, 'teardown leaves no timer behind');

  assert.ok(ctx.logger.info.log.some((line) => String(line[0]).includes('[kill-guard] active')));
});

test('apply: without a webServer the guard still arms and enforces', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'busy', owner: 'session-a' }]);
  const ctx = createStubContext({ jobs, agents: createFakeAgents() });
  // The memory arm is pinned just above zero so the real sampler breaches on a
  // short timer without having to load the machine.
  apply(ctx, { intervalMs: 250, cpuThreshold: 0, memoryThreshold: 0.001 });
  assert.deepEqual(ctx.injected, [['jobs', 'agents'], ['webServer']]);
  await sleep(900);
  assert.equal(jobs.calls.length >= 1, true, 'the timer samples and enforces with no web surface at all');
  ctx.disposeAll();
  const reached = jobs.calls.length;
  jobs.store.set('bash-2', { id: 'bash-2', kind: 'bash', label: 'later', owner: 'session-a', status: 'running' });
  await sleep(700);
  assert.equal(jobs.calls.length, reached, 'teardown stops the timer');
});

test('apply: an unarmed composition reports the degraded state through the route', async () => {
  const routes = [];
  const ctx = createStubContext({
    webServer: {
      register(route) {
        routes.push(route);
        return () => {};
      },
    },
  });
  apply(ctx, { intervalMs: 600000 });
  assert.deepEqual(ctx.injected, [['jobs', 'agents'], ['webServer']]);
  assert.equal(routes.length, 2, 'both routes are mounted even without the job services');
  const token = ctx.injectionTable()[0].value.token;
  const allowed = fakeResponse();
  await routes[0].handler(fakeRequest('GET', { [TOKEN_HEADER]: token }), allowed);
  const snapshot = JSON.parse(allowed.body).data;
  assert.equal(snapshot.monitor.active, false);
  assert.equal(snapshot.monitor.degraded, 'jobs/agents unavailable');
  assert.ok(snapshot.sample.cpu === null || typeof snapshot.sample.cpu === 'number', 'the degraded panel still reports a real reading or an honest null');
  assert.equal('measured' in snapshot.sample, true);
  assert.equal(snapshot.kills.length, 0);
  // A manual stop is honestly refused rather than silently doing nothing.
  const refused = fakeResponse();
  await routes[0].handler(fakeRequest('POST', { [TOKEN_HEADER]: token }, JSON.stringify({ action: 'kill-now' })), refused);
  assert.equal(refused.status, 400);
  assert.match(JSON.parse(refused.body).error, /not armed/);
  ctx.disposeAll();
});

test('apply: a terminal-less composition still stops jobs and logs the situation', async () => {
  const jobs = createFakeJobs([{ id: 'bash-1', kind: 'bash', label: 'busy', owner: 'session-a' }]);
  const ctx = createStubContext({ jobs, agents: createFakeAgents() });
  apply(ctx, { intervalMs: 600000 });
  assert.ok(ctx.logger.info.log.some((line) => String(line[0]).includes('only shell jobs are stopped')));
  ctx.disposeAll();
});

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

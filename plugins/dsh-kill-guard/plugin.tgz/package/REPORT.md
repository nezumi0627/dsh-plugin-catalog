# Task 05 — `dsh-kill-guard` report

## Scope

Host/package and client refinements. `index.js`, `package.json`, `cordis.patch.yml`, `README.md`, and `test-host.mjs` were handled in the original host pass. The Lead subsequently corrected the generated config row id and adapted the client/render tests. The Lead also implemented adaptive client polling (5 s collapsed / 1 s while panel open) and fixed the render-test lifecycle setup.

## Pause/resume failure: root cause and correction

Baseline `node test-kill-guard.mjs` was 38/39. The failing assertion expected a stop event after resuming, but observed `breach`. While paused, `tick()` kept incrementing `breachStreak`; after resume the next sample immediately satisfied the sustain requirement and enforced, then the subsequent sample recorded a new breach event. This meant paused samples incorrectly counted toward the consecutive active-sample gate.

Changed `index.js` so paused ticks continue updating the gauge and `breachTotal`, but reset `breachStreak` and return without enforcing. Resume therefore requires a fresh sequence of `sustainSamples` unpaused breaches. Manual `kill-now` remains intentionally available while paused.

## Package/config decisions

- Package root: `@local/dsh-kill-guard`; package version `2.0.0`.
- `cordis.patch.yml` row id: `dsh-auto-kill`, with all ten legacy config keys/defaults. The Lead ruled that this id must remain because the profile override targets it; package root remains `@local/dsh-kill-guard`.
- The client settings-fragment assertion now expects `dsh-auto-kill`. Slot id `@local/dsh-auto-kill/routes` is unchanged. No profile or client UI source files were touched.

## Row-id correction verification

- `node --check index.js` and `node --check client.js`: passed.
- `node test-host.mjs`: 39/39 passed.
- Lead later corrected the generated copyable YAML row id to `dsh-auto-kill`; latest client suite is 18/18.

## Compatibility evidence

| Surface | Preserved value / shape |
|---|---|
| Data route | `/local/auto-kill` |
| Token route | `/local/auto-kill-token` |
| Token header | `x-dsh-auto-kill-token` |
| Bootstrap global | `__DSH_AUTO_KILL__` |
| Config keys | `enabled`, `cpuThreshold`, `memoryThreshold`, `intervalMs`, `sustainSamples`, `cooldownMs`, `killJobs`, `jobKinds`, `killTerminals`, `dryRun` |
| Snapshot legacy keys | root: `version, at, settings, monitor, sample, counters, kills, host`; monitor: `active, paused, pausedReason, busy, ticks, breachStreak, sustainSamples, cooldownRemainingMs, lastError, lastKillAt`; sample: `cpu, memory, totalBytes, freeBytes, at, ageMs`; counters: `rounds, ticks, jobs, terminals, failures, dryRuns`; host: `platform, arch, cores, totalBytes, freeBytes, pid, uptimeSec` |
| POST actions | `pause`, `resume`, `toggle`, `kill-now`, `clear-log` |
| Log cap | 40 entries |

The compatibility assertions passed in the host test run; new fields are additive.

## Verification commands and real output

### `node --check index.js`

```text
(no output; exit code 0)
```

### `node --check client.js` (syntax-only; file not modified here)

```text
(no output; exit code 0)
```

### `node test-host.mjs`

```text
ok   compat: the route, header, and bootstrap identifiers are byte-identical
ok   compat: the ten configuration keys keep their names and defaults
ok   compat: the snapshot is a strict superset of the legacy field shape
ok   compat: the live old bundle, when present, uses a subset of this shape
ok   resolveConfig: defaults are the shipped 90% / 90% guard
ok   resolveConfig: values are clamped and junk falls back
ok   createSampler: CPU is the busy share of the counter delta, memory the used share
ok   createSampler: a delta with no elapsed total reports 0%, never NaN
ok   createSampler: metrics that cannot be read are null, never a fabricated zero
ok   createSampler: a nonsensical counter payload is treated as unavailable
ok   monitor: a quiet machine is never touched
ok   monitor: a single sample over the CPU arm does not stop anything
ok   monitor: sustained CPU stops every shell job with its own owner as the caller
ok   fence: only `running` jobs of a configured kind are ever cancelled
ok   fence: a custom jobKinds list narrows the target set and nothing else leaks in
ok   fence: a foreign-owned job is never reachable with our own identity
ok   monitor: the memory arm is independent of the CPU arm
ok   monitor: the cooldown blocks a second round, and a later breach runs again
ok   monitor: pause blocks enforcement, resume re-arms it, and sampling keeps running
ok   monitor: disabled stops enforcing without stopping the gauge
ok   monitor: dry run records the stop it would have made and calls nothing
ok   monitor: running terminals are closed, exited ones are left alone
ok   monitor: a refusing terminal is a recorded failure, not a thrown tick
ok   monitor: a refusing registry is recorded and never breaks the loop
ok   monitor: killNow enforces regardless of thresholds and pause, and is marked manual
ok   monitor: an unavailable registry degrades instead of throwing
ok   monitor: only the plugin’s own node timers are owned, and the log is capped
ok   monitor: start/stop own exactly one interval
ok   monitor: clearLog empties the log and says so in the event line
ok   bootstrapRow: the capability rides the structured index-injection table
ok   authorized: only the same-origin holder of the exact token passes
ok   route: rejects a missing token and answers an authorized GET
ok   route: POST drives all five legacy actions, `toggle` included, and rejects junk
ok   route: a body over the cap is refused instead of buffered
ok   token route: hands out the capability to an authenticated same-origin page only
ok   apply: registers both routes, publishes the capability row, and owns the timer
ok   apply: without a webServer the guard still arms and enforces
ok   apply: an unarmed composition reports the degraded state through the route
ok   apply: a terminal-less composition still stops jobs and logs the situation

39/39 checks passed
```

### `node test-client.mjs` (separately maintained UI test)

```text
ok   bundle: only platform-seed specifiers are required
ok   bundle: registers the package id and declares its client services
ok   bundle: apply registers the compact indicator in the top strip and beside the composer stats
ok   bundle: the stylesheet is injected once and removed by its disposer
ok   design tokens: the bundle contains no hardcoded colour
ok   icon: the geometry in the bundle is the shipped icon.svg
ok   locale: the shipped JSON files and the bundle dictionaries are the same data
ok   helpers: percentages, byte sizes, clock stamps, ages, and level bands
ok   helpers: fill substitutes named placeholders and leaves unknown ones alone
ok   chrome detection: a caption strip is measured, its absence means float mode
ok   bootstrap: a missing or malformed payload yields no client
ok   bootstrap: a page without a global asks the token route and keeps the answer
ok   api: GET carries the token, POST carries the action, failures surface as codes
ok   failure translator: plain language plus a reconnect action, never an internal string
ok   graphs: the sample ring is capped and gaps stay gaps
ok   history: the summary is derived from the host log and nothing is invented
ok   settings fragment: the copyable YAML carries all ten keys and the live values
ok   settings rows: every row is drawn from the live snapshot, never a literal

18/18 checks passed
```

### `node test-render.mjs` (Lead rerun after follow-up fixes)

```text
ok   render: the compact indicator shows real numbers and stays calm when nothing is wrong
ok   render: clicking the compact indicator portals a positioned detail panel with the graphs
ok   render: a stop that happens while the page is open lights the indicator and fills the log
ok   render: pause, resume, and stop-now post the legacy action names
ok   render: a metric the host cannot read is labelled unavailable, never zero
ok   render: a broken handshake becomes a plain-language card with a reconnect action
ok   render: collapsed indicator backs off to 5 s and open panel uses 1 s polling
ok   render: hidden pages never sample, and the poll timer is cleared and restarted
ok   render: unmounting releases every timer, listener, and subscription it owns
ok   render: the threshold view lists the live values and copies a paste-ready fragment
ok   render: the history view summarizes the capped host log without inventing totals
ok   render: Escape closes the panel and takes its listener with it

12/12 checks passed
```

Latest client/render verification was run by the Lead after adaptive polling and test lifecycle fixes. Host 39/39, client 18/18, render 12/12 pass. The collapsed chip uses a 5 s poll (≤0.2 Hz), an open panel 1 s (≤1 Hz), hidden pages stop sampling, and unmount clears timers. This does not test the plugin inside a live DSH session.

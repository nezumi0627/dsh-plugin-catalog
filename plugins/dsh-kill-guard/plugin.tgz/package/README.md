# DSH Kill Guard

`@local/dsh-kill-guard` monitors system CPU and memory, and can stop only DSH-managed shell jobs (`bash`/`pwsh` by default) and DSH-managed sidebar terminals. It never searches for or terminates arbitrary operating-system processes.

## Compatibility

The legacy route and capability surfaces remain available: `/local/auto-kill`, `/local/auto-kill-token`, `x-dsh-auto-kill-token`, and `__DSH_AUTO_KILL__`. The ten settings and their defaults are preserved in `cordis.patch.yml` and `index.js`; the snapshot retains legacy fields and adds panel data. Pause keeps sampling but clears the sustained-breach streak so paused samples cannot trigger an immediate stop after resume. Manual stop deliberately overrides pause and cooldown.

The configuration row id is `dsh-auto-kill` because the profile override targets it; the package root remains `@local/dsh-kill-guard`. An override replaces the entire row config, so restate every desired key.

## Configuration

| Key | Default | Range / meaning |
|---|---:|---|
| `enabled` | `true` | Master auto-stop switch |
| `cpuThreshold` | `90` | CPU percent; `0` disables this arm |
| `memoryThreshold` | `90` | Memory percent; `0` disables this arm |
| `intervalMs` | `1500` | 250–600000 ms |
| `sustainSamples` | `2` | 1–600 consecutive active samples |
| `cooldownMs` | `15000` | 0–3600000 ms |
| `killJobs` | `true` | Include eligible jobs |
| `jobKinds` | `[bash, pwsh]` | Eligible DSH job kinds |
| `killTerminals` | `true` | Include running DSH sidebar terminals |
| `dryRun` | `false` | Record eligible targets without stopping them |

## Offline verification

From this directory run `node --check index.js`, `node --check client.js`, and `node test-host.mjs`. The host runner is dependency-free. `test-client.mjs` and `test-render.mjs` exercise the separately maintained UI half.

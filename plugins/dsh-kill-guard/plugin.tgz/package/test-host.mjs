// PLUGIN_GUIDE host-test entry point; retained legacy runner has full compatibility coverage.
import './test-kill-guard.mjs';

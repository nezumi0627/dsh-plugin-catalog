/**
 * Host half of `@local/dsh-kill-guard` — the monitoring panel that replaces
 * `@local/dsh-auto-kill`.
 *
 * What it does (every value overridable from the profile's `cordis.patch.yml`):
 *   * samples system-wide CPU and physical-memory use every `intervalMs`
 *     (`node:os` counter deltas — no native dependency, no shelling out);
 *   * when a threshold is met on `sustainSamples` consecutive samples, it stops
 *     every live shell job (`ctx.jobs.kill`, called with that job's own owner as
 *     the fenced caller) and closes every running right-sidebar terminal
 *     (`ctx.terminalController.close`), then waits `cooldownMs` before the next
 *     enforcement round;
 *   * exposes the **two exact routes the old plugin published** —
 *     `/local/auto-kill` for the live values and the pause / resume / kill-now
 *     controls, and `/local/auto-kill-token` handing a page that has no bootstrap
 *     global its per-process capability token. The token also travels as a
 *     structured index-injection row under the same global name.
 *
 * Backward compatibility is deliberate and load-bearing: the profile's existing
 * `cordis.patch.yml` override block still names the same ten config keys, and a
 * page or script written against the old bundle keeps working against this one.
 * The identifiers are pinned by `test-kill-guard.mjs`, which compares this module
 * against the old bundle key by key whenever the old bundle is still on disk.
 * Everything this rewrite adds to the snapshot is additive: `monitor.lastEvent`,
 * `monitor.breachTotal`, `monitor.historyCap`, `sample.measured`, and
 * `counters.manual`. No legacy field was renamed or removed.
 *
 * One deliberate value-level change: a metric that cannot be read is reported as
 * `null` ("未取得") instead of a fabricated `0`, per requirements §1. The legacy
 * case of a readable counter pair with no elapsed CPU time still reports `0%`,
 * exactly as before.
 *
 * Dependency-free on purpose: a profile-local bundle cannot resolve
 * `@deepseek-ai/*` packages, so this module imports node builtins only. The
 * `jobs`, `agents`, `terminalController`, and `webServer` services are taken
 * through `ctx.inject`, so a composition without one of them still loads — the
 * panel then reports the degraded state instead of the plugin failing at boot.
 *
 * Fencing facts this half depends on (verified against `dsh-jobs-local`):
 * `jobs.list(caller)` returns the caller's own jobs plus the unowned ones, and
 * `jobs.kill(id, caller)` refuses a job whose `owner.id` is not exactly
 * `caller`. So the killer enumerates every live Agent id, lists per caller, and
 * passes the job's own owner back as the caller. The stop targets stay exactly
 * this set: DSH-managed shell jobs and DSH-managed sidebar terminals. Nothing
 * else is ever reachable from here.
 */
import { randomBytes, timingSafeEqual } from 'node:crypto';
import {
  arch as osArch,
  cpus as osCpus,
  freemem as osFreemem,
  platform as osPlatform,
  totalmem as osTotalmem,
} from 'node:os';

export const name = 'dsh-kill-guard';
export const VERSION = '2.0.0';
/** Exact route the Client half calls; a named route so it wins over the SPA fallback. */
export const ROUTE_PATH = '/local/auto-kill';
/**
 * Exact route handing the page its capability. The Desktop shell serves the
 * document straight from disk (`dsh-app://app/`), so the served-index path only
 * exists for a browser window and the boot-injection table is frozen when the
 * Host starts; this route is what lets a window opened before the plugin was
 * installed — or installed live, without a restart — connect.
 */
export const TOKEN_PATH = '/local/auto-kill-token';
/** Global Client key carrying the route + per-process token into the page. */
export const BOOTSTRAP_KEY = '__DSH_AUTO_KILL__';
export const TOKEN_HEADER = 'x-dsh-auto-kill-token';
export const MAX_BODY_BYTES = 8 * 1024;
/** The old log cap, unchanged: the panel states it instead of pretending otherwise. */
export const MAX_KILL_LOG = 40;
const MAX_LABEL = 160;

/**
 * Defaults; every key is optional in the plugin config. These ten names are the
 * compatibility surface — they are byte-identical to the old plugin's, so a
 * profile override block that used to work keeps working.
 */
export const DEFAULT_CONFIG = {
  /** Master switch. `false` keeps the panel live but never stops anything. */
  enabled: true,
  /** System-wide CPU percent that arms the kill switch. `0` disables this arm. */
  cpuThreshold: 90,
  /** System memory percent that arms the kill switch. `0` disables this arm. */
  memoryThreshold: 90,
  /** Sampling period in milliseconds (minimum 250). */
  intervalMs: 1500,
  /** Consecutive over-threshold samples required before anything is stopped. */
  sustainSamples: 2,
  /** Quiet period after one enforcement round, in milliseconds. */
  cooldownMs: 15000,
  /** Stop live bash/pwsh jobs. */
  killJobs: true,
  /** Job kinds treated as shells. The bash tool uses `bash`, the pwsh tool `pwsh`. */
  jobKinds: ['bash', 'pwsh'],
  /** Close running right-sidebar terminals. */
  killTerminals: true,
  /** Log what would be stopped without stopping it. */
  dryRun: false,
};

// ---------------------------------------------------------------------------
// sampling

function clampPercent(value) {
  if (!Number.isFinite(value)) return 0;
  if (value < 0) return 0;
  if (value > 100) return 100;
  return Math.round(value * 10) / 10;
}

/** Aggregate CPU jiffies over every core. */
export function cpuTimes() {
  let idle = 0;
  let total = 0;
  for (const cpu of osCpus()) {
    const times = cpu.times;
    idle += times.idle;
    total += times.user + times.nice + times.sys + times.idle + times.irq;
  }
  return { idle, total };
}

/** Read a counter pair, or `null` when this host cannot answer. */
function readCpuTimes(read) {
  try {
    const value = read();
    if (!value || !Number.isFinite(value.idle) || !Number.isFinite(value.total)) return null;
    return { idle: value.idle, total: value.total };
  } catch {
    return null;
  }
}

/** Read a byte/percent counter, or `null` when the answer is not a reading. */
function readNumber(read) {
  try {
    const value = Number(read());
    return Number.isFinite(value) && value >= 0 ? value : null;
  } catch {
    return null;
  }
}

/**
 * Build the sampler. The first snapshot only primes the CPU counters, so the
 * first returned CPU value covers the interval since creation; a counter pair
 * with no elapsed CPU time reports `0%`, exactly as the old sampler did.
 *
 * A reading that cannot be taken is `null`, never a substituted zero: the panel
 * shows "未取得" for it (requirements §1: no fabricated metrics).
 *
 * `deps` exists for the tests: they inject fake counters so every branch is
 * deterministic and nothing has to be burned on a real machine.
 */
export function createSampler(deps = {}) {
  const readCpu = deps.cpuTimes ?? cpuTimes;
  const readFree = deps.freemem ?? osFreemem;
  const readTotal = deps.totalmem ?? osTotalmem;
  const clock = deps.now ?? (() => Date.now());
  let previous = readCpuTimes(readCpu);
  return function sample() {
    const current = readCpuTimes(readCpu);
    let cpu = null;
    if (previous !== null && current !== null) {
      const idleDelta = current.idle - previous.idle;
      const totalDelta = current.total - previous.total;
      cpu = totalDelta > 0 ? clampPercent((1 - idleDelta / totalDelta) * 100) : 0;
    }
    previous = current;
    const capacity = readNumber(readTotal);
    const free = readNumber(readFree);
    let memory = null;
    if (capacity !== null && free !== null && capacity > 0) memory = clampPercent(((capacity - free) / capacity) * 100);
    return {
      cpu,
      memory,
      totalBytes: capacity,
      freeBytes: free,
      measured: cpu !== null || memory !== null,
      at: clock(),
    };
  };
}

// ---------------------------------------------------------------------------
// config

function boundedNumber(value, fallback, minimum, maximum) {
  const number = Number(value);
  if (!Number.isFinite(number)) return fallback;
  return Math.min(maximum, Math.max(minimum, number));
}

/** Normalize the loader config into the settings object the monitor uses. */
export function resolveConfig(config = {}) {
  const kinds = Array.isArray(config.jobKinds)
    ? config.jobKinds.filter((kind) => typeof kind === 'string' && kind.trim() !== '').map((kind) => kind.trim())
    : [];
  return {
    enabled: typeof config.enabled === 'boolean' ? config.enabled : DEFAULT_CONFIG.enabled,
    cpuThreshold: boundedNumber(config.cpuThreshold, DEFAULT_CONFIG.cpuThreshold, 0, 100),
    memoryThreshold: boundedNumber(config.memoryThreshold, DEFAULT_CONFIG.memoryThreshold, 0, 100),
    intervalMs: boundedNumber(config.intervalMs, DEFAULT_CONFIG.intervalMs, 250, 600000),
    sustainSamples: Math.round(boundedNumber(config.sustainSamples, DEFAULT_CONFIG.sustainSamples, 1, 600)),
    cooldownMs: boundedNumber(config.cooldownMs, DEFAULT_CONFIG.cooldownMs, 0, 3600000),
    killJobs: typeof config.killJobs === 'boolean' ? config.killJobs : DEFAULT_CONFIG.killJobs,
    jobKinds: kinds.length > 0 ? kinds : [...DEFAULT_CONFIG.jobKinds],
    killTerminals: typeof config.killTerminals === 'boolean' ? config.killTerminals : DEFAULT_CONFIG.killTerminals,
    dryRun: typeof config.dryRun === 'boolean' ? config.dryRun : DEFAULT_CONFIG.dryRun,
  };
}

function shortLabel(value) {
  if (typeof value !== 'string') return '';
  const flat = value.replace(/\s+/g, ' ').trim();
  return flat.length > MAX_LABEL ? `${flat.slice(0, MAX_LABEL - 1)}…` : flat;
}

/** The host facts the panel shows; a host that cannot answer reports `null`. */
function hostFacts() {
  let cores = null;
  let totalBytes = null;
  let freeBytes = null;
  try {
    cores = osCpus().length;
  } catch {
    cores = null;
  }
  try {
    totalBytes = osTotalmem();
  } catch {
    totalBytes = null;
  }
  try {
    freeBytes = osFreemem();
  } catch {
    freeBytes = null;
  }
  return {
    platform: osPlatform(),
    arch: osArch(),
    cores,
    totalBytes,
    freeBytes,
    pid: process.pid,
    uptimeSec: Math.round(process.uptime()),
  };
}

// ---------------------------------------------------------------------------
// monitor

/**
 * The kill switch itself. `jobs`, `agents`, and `terminalController` are plain
 * service-shaped objects, which is what makes the whole decision path testable
 * off the harness.
 */
export function createMonitor(options) {
  const jobs = options.jobs;
  const agents = options.agents;
  const terminalController = options.terminalController;
  const logger = options.logger ?? {};
  const settings = options.settings ?? resolveConfig();
  const clock = options.now ?? (() => Date.now());
  const sample = options.sampler ?? createSampler(options.samplerDeps);

  const state = {
    running: false,
    paused: false,
    pausedReason: undefined,
    busy: false,
    ticks: 0,
    breachStreak: 0,
    breachTotal: 0,
    cooldownUntil: 0,
    lastSample: undefined,
    lastKillAt: undefined,
    lastError: undefined,
    /** The newest *notable* thing that happened; a plain sample is not an event. */
    lastEvent: null,
    counters: { rounds: 0, ticks: 0, jobs: 0, terminals: 0, failures: 0, dryRuns: 0, manual: 0 },
    kills: [],
  };
  let timer = null;

  function warn(message) {
    try {
      logger.warn?.(message);
    } catch {
      /* a broken logger must never break the guard */
    }
  }

  function note(kind, tone, text, extra) {
    state.lastEvent = { at: clock(), kind, tone, text, ...extra };
  }

  function remember(entry) {
    state.kills.unshift(entry);
    if (state.kills.length > MAX_KILL_LOG) state.kills.length = MAX_KILL_LOG;
  }

  function agentList() {
    try {
      const list = agents?.list?.();
      return Array.isArray(list) ? list.filter((agent) => agent && typeof agent.id === 'string') : [];
    } catch (error) {
      state.lastError = `agents.list: ${String(error?.message ?? error)}`;
      warn(`[kill-guard] could not list agents: ${state.lastError}`);
      return [];
    }
  }

  /** Every job visible through one of the live Agent ids, plus the unowned set. */
  function liveJobViews() {
    const views = new Map();
    const callers = [undefined, ...agentList().map((agent) => agent.id)];
    for (const caller of callers) {
      let list;
      try {
        list = jobs?.list?.(caller);
      } catch (error) {
        state.lastError = `jobs.list: ${String(error?.message ?? error)}`;
        warn(`[kill-guard] could not list jobs: ${state.lastError}`);
        continue;
      }
      if (!Array.isArray(list)) continue;
      for (const view of list) {
        if (view && typeof view.id === 'string' && !views.has(view.id)) views.set(view.id, view);
      }
    }
    return [...views.values()];
  }

  function stopJobs(reason, manual) {
    const stopped = [];
    if (!settings.killJobs) return stopped;
    if (typeof jobs?.kill !== 'function') {
      state.lastError = 'jobs.kill is unavailable';
      return stopped;
    }
    for (const view of liveJobViews()) {
      if (!settings.jobKinds.includes(view.kind)) continue;
      // `running` only: a job already in `stopping` has its cancel in flight, and
      // re-cancelling it would only repeat the same request (dsh-jobs-local's
      // killJob forwards straight to the producer's cancel hook).
      if (view.status !== 'running') continue;
      const record = {
        at: clock(),
        kind: 'job',
        id: view.id,
        label: shortLabel(view.label),
        owner: view.owner,
        reason,
        ok: true,
      };
      if (manual) record.manual = true;
      if (settings.dryRun) {
        record.dryRun = true;
        state.counters.dryRuns += 1;
        stopped.push(record);
        remember(record);
        continue;
      }
      try {
        // The fence is the caller identity: the job's own owner is passed back in,
        // so an owned job is reachable from a profile-root plugin without ever
        // widening `jobs`' per-session isolation.
        jobs.kill(view.id, view.owner, reason);
        state.counters.jobs += 1;
        stopped.push(record);
        remember(record);
      } catch (error) {
        state.counters.failures += 1;
        state.lastError = `jobs.kill(${view.id}): ${String(error?.message ?? error)}`;
        record.ok = false;
        record.error = state.lastError;
        stopped.push(record);
        remember(record);
      }
    }
    return stopped;
  }

  async function stopTerminals(reason, manual) {
    const stopped = [];
    if (!settings.killTerminals) return stopped;
    if (typeof terminalController?.list !== 'function' || typeof terminalController?.close !== 'function') {
      return stopped;
    }
    for (const agent of agentList()) {
      let list;
      try {
        list = terminalController.list(agent.id);
      } catch (error) {
        state.lastError = `terminalController.list: ${String(error?.message ?? error)}`;
        warn(`[kill-guard] could not list terminals: ${state.lastError}`);
        continue;
      }
      if (!Array.isArray(list)) continue;
      for (const terminal of list) {
        if (!terminal || typeof terminal.id !== 'string') continue;
        if (terminal.state !== undefined && terminal.state !== 'running') continue;
        const record = {
          at: clock(),
          kind: 'terminal',
          id: terminal.id,
          label: shortLabel(terminal.title ?? terminal.id),
          owner: agent.id,
          reason,
          ok: true,
        };
        if (manual) record.manual = true;
        if (settings.dryRun) {
          record.dryRun = true;
          state.counters.dryRuns += 1;
          stopped.push(record);
          remember(record);
          continue;
        }
        try {
          await terminalController.close(agent, terminal.id);
          state.counters.terminals += 1;
          stopped.push(record);
          remember(record);
        } catch (error) {
          state.counters.failures += 1;
          state.lastError = `terminalController.close(${terminal.id}): ${String(error?.message ?? error)}`;
          record.ok = false;
          record.error = state.lastError;
          stopped.push(record);
          remember(record);
        }
      }
    }
    return stopped;
  }

  /** Which thresholds the sample crosses, as human-readable clauses. */
  function breaches(current) {
    const hits = [];
    if (settings.cpuThreshold > 0 && current.cpu >= settings.cpuThreshold) {
      hits.push(`CPU ${current.cpu}% ≥ ${settings.cpuThreshold}%`);
    }
    if (settings.memoryThreshold > 0 && current.memory >= settings.memoryThreshold) {
      hits.push(`MEM ${current.memory}% ≥ ${settings.memoryThreshold}%`);
    }
    return hits;
  }

  /** One sample, one decision, at most one enforcement round. */
  async function tick() {
    if (state.busy) return state.lastSample;
    state.busy = true;
    try {
      const current = sample();
      state.ticks += 1;
      state.counters.ticks += 1;
      state.lastSample = current;
      if (!settings.enabled) {
        state.breachStreak = 0;
        return current;
      }
      const hits = breaches(current);
      if (hits.length === 0) {
        state.breachStreak = 0;
        return current;
      }
      state.breachTotal += 1;
      // Keep the gauge and breach counter live while paused, but don't let
      // paused samples satisfy the consecutive-sample gate after resume.
      if (state.paused) {
        state.breachStreak = 0;
        return current;
      }
      state.breachStreak += 1;
      // Record the moment the arm trips, not every second it stays tripped: the
      // panel's "latest event" line is a timeline, not a sample counter.
      if (state.breachStreak === 1) note('breach', 'warn', hits.join(' + '));
      if (state.breachStreak < settings.sustainSamples) return current;
      if (state.paused || clock() < state.cooldownUntil) return current;
      return await enforce(`auto-kill: ${hits.join(' + ')}`, current, {});
    } finally {
      state.busy = false;
    }
  }

  async function enforce(reason, _current, options = {}) {
    const manual = options.manual === true;
    state.counters.rounds += 1;
    if (manual) state.counters.manual += 1;
    // A stop round whose registry already failed keeps that error as the event:
    // "nothing was stopped because X" is the honest line, not "nothing needed stopping".
    const preexistingError = state.lastError;
    const stoppedJobs = stopJobs(reason, manual);
    const stoppedTerminals = await stopTerminals(reason, manual);
    const stopped = [...stoppedJobs, ...stoppedTerminals];
    state.cooldownUntil = clock() + settings.cooldownMs;
    state.breachStreak = 0;
    if (!settings.dryRun && stopped.some((entry) => entry.ok)) {
      state.lastKillAt = clock();
      warn(`[kill-guard] ${reason} — stopped ${stoppedJobs.length} job(s) and ${stoppedTerminals.length} terminal(s)`);
      note('stop', 'hot', reason, { manual, count: stopped.length });
    } else if (settings.dryRun && stopped.length > 0) {
      warn(`[kill-guard] DRY RUN ${reason} — would stop ${stopped.length} shell(s)`);
      note('stop', 'info', reason, { manual, count: stopped.length, dryRun: true });
    } else {
      const failure = state.lastError !== preexistingError ? state.lastError : undefined;
      note('stop', failure === undefined ? 'info' : 'warn', failure ?? reason, { manual, count: 0 });
    }
    return _current;
  }

  return {
    settings,
    state,
    /** One deterministic decision step; the route and the tests call it directly. */
    tick,
    /** Force one round regardless of thresholds, pause state, and cooldown. */
    async killNow(reason = 'auto-kill: manual request') {
      return await enforce(reason, undefined, { manual: true });
    },
    pause(reason = 'panel') {
      state.paused = true;
      state.pausedReason = reason;
      state.breachStreak = 0;
      note('pause', 'info', reason);
      warn(`[kill-guard] paused (${reason})`);
    },
    resume() {
      state.paused = false;
      state.pausedReason = undefined;
      note('resume', 'info', 'resumed');
      warn('[kill-guard] resumed');
    },
    clearLog() {
      state.kills.length = 0;
      note('clear', 'info', 'log cleared');
    },
    start() {
      if (timer !== null) return;
      state.running = true;
      note('start', 'info', 'monitoring started');
      timer = setInterval(() => {
        void tick().catch((error) => {
          state.lastError = String(error?.message ?? error);
          warn(`[kill-guard] tick failed: ${state.lastError}`);
        });
      }, settings.intervalMs);
      timer.unref?.();
    },
    stop() {
      if (timer !== null) {
        clearInterval(timer);
        timer = null;
      }
      state.running = false;
    },
    isRunning() {
      return timer !== null;
    },
    snapshot() {
      return {
        version: VERSION,
        at: clock(),
        settings: { ...settings, jobKinds: [...settings.jobKinds] },
        monitor: {
          active: timer !== null,
          paused: state.paused,
          pausedReason: state.pausedReason,
          busy: state.busy,
          ticks: state.ticks,
          breachStreak: state.breachStreak,
          sustainSamples: settings.sustainSamples,
          cooldownRemainingMs: Math.max(0, state.cooldownUntil - clock()),
          lastError: state.lastError,
          lastKillAt: state.lastKillAt,
          breachTotal: state.breachTotal,
          historyCap: MAX_KILL_LOG,
          lastEvent: state.lastEvent === null ? null : { ...state.lastEvent },
        },
        sample: state.lastSample
          ? {
              cpu: state.lastSample.cpu,
              memory: state.lastSample.memory,
              totalBytes: state.lastSample.totalBytes,
              freeBytes: state.lastSample.freeBytes,
              at: state.lastSample.at,
              ageMs: Math.max(0, clock() - state.lastSample.at),
              measured: state.lastSample.measured === true,
            }
          : null,
        counters: { ...state.counters },
        kills: state.kills.map((entry) => ({ ...entry })),
        host: hostFacts(),
      };
    },
  };
}

// ---------------------------------------------------------------------------
// route

/** The token is a same-origin capability: only the served index carries it. */
export function authorized(req, token) {
  const site = req?.headers?.['sec-fetch-site'];
  if (typeof site === 'string' && site === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
}

function readBody(req, limit = MAX_BODY_BYTES) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('payload too large'));
        req.destroy?.();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

/**
 * The structured index-injection row that carries the capability into a page
 * whose document the Host itself renders. Rows are the supported channel: the
 * served index renders them into the HTML, and the Desktop shell ships the same
 * rows over its boot IPC for a page-side interpreter.
 */
export function bootstrapRow(value) {
  return { kind: 'global', name: BOOTSTRAP_KEY, value };
}

/**
 * Exact-route handler handing the capability to a page that has no bootstrap
 * global: an already-open window, or a live install whose boot-injection table
 * was snapshotted before this plugin existed. The guard is the index's own —
 * the request must carry the GUI cookie (`isAuthenticated`) — plus a refusal of
 * cross-site sends. A browser page elsewhere can SEND this GET but cannot read
 * the reply (no CORS grant), and the kill route still demands the token it hands
 * out.
 */
export function createTokenHandler(token, isAuthenticated) {
  return function killGuardTokenRoute(req, res) {
    const send = (status, payload) => {
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      });
      res.end(JSON.stringify(payload));
    };
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      send(405, { ok: false, error: 'method-not-allowed' });
      return;
    }
    const site = req?.headers?.['sec-fetch-site'];
    if (typeof site === 'string' && site === 'cross-site') {
      send(403, { ok: false, error: 'forbidden' });
      return;
    }
    if (typeof isAuthenticated === 'function') {
      let authenticated = false;
      try {
        authenticated = isAuthenticated(req) === true;
      } catch {
        authenticated = false;
      }
      if (!authenticated) {
        send(401, { ok: false, error: 'unauthorized' });
        return;
      }
    }
    send(200, { ok: true, data: { path: ROUTE_PATH, token } });
  };
}

/**
 * Exact-route handler: GET reads the snapshot, POST applies one control action.
 * The action names and response envelope are the old plugin's, verbatim.
 */
export function createRouteHandler(control, token) {
  return async function killGuardRoute(req, res) {
    const send = (status, payload) => {
      res.writeHead(status, {
        'content-type': 'application/json; charset=utf-8',
        'cache-control': 'no-store',
      });
      res.end(JSON.stringify(payload));
    };
    if (!authorized(req, token)) {
      send(403, { ok: false, error: 'forbidden' });
      return;
    }
    try {
      if (req.method === 'GET' || req.method === 'HEAD') {
        send(200, { ok: true, data: control.snapshot() });
        return;
      }
      if (req.method !== 'POST') {
        send(405, { ok: false, error: 'method-not-allowed' });
        return;
      }
      const raw = await readBody(req);
      const request = raw ? JSON.parse(raw) : {};
      const action = typeof request?.action === 'string' ? request.action : '';
      if (action === 'pause') control.pause('panel');
      else if (action === 'resume') control.resume();
      else if (action === 'toggle') (control.isPaused?.() ? control.resume() : control.pause('panel'));
      else if (action === 'kill-now') await control.killNow();
      else if (action === 'clear-log') control.clearLog();
      else throw new Error(`unknown auto-kill action: ${action || '(missing)'}`);
      send(200, { ok: true, action, data: control.snapshot() });
    } catch (error) {
      send(400, { ok: false, error: error instanceof Error ? error.message : String(error) });
    }
  };
}

// ---------------------------------------------------------------------------
// plugin

export function describeSettings(settings) {
  const arms = [];
  if (settings.cpuThreshold > 0) arms.push(`CPU ≥ ${settings.cpuThreshold}%`);
  if (settings.memoryThreshold > 0) arms.push(`MEM ≥ ${settings.memoryThreshold}%`);
  const targets = [];
  if (settings.killJobs) targets.push(settings.jobKinds.join('/') + ' jobs');
  if (settings.killTerminals) targets.push('terminals');
  return `${arms.join(' + ') || 'no arm'} → ${targets.join(' + ') || 'nothing'}`;
}

export function apply(ctx, config = {}) {
  const settings = resolveConfig(config);
  const token = randomBytes(24).toString('hex');
  const fallbackSampler = createSampler();
  let monitor = null;

  /** Stable face for the route: the monitor once it exists, sampling before that. */
  const control = {
    snapshot() {
      if (monitor !== null) return monitor.snapshot();
      const current = fallbackSampler();
      return {
        version: VERSION,
        at: Date.now(),
        settings: { ...settings, jobKinds: [...settings.jobKinds] },
        monitor: {
          active: false,
          paused: false,
          ticks: 0,
          breachStreak: 0,
          sustainSamples: settings.sustainSamples,
          cooldownRemainingMs: 0,
          breachTotal: 0,
          historyCap: MAX_KILL_LOG,
          lastEvent: null,
          degraded: 'jobs/agents unavailable',
        },
        sample: {
          cpu: current.cpu,
          memory: current.memory,
          totalBytes: current.totalBytes,
          freeBytes: current.freeBytes,
          at: current.at,
          ageMs: 0,
          measured: current.measured,
        },
        counters: { rounds: 0, ticks: 0, jobs: 0, terminals: 0, failures: 0, dryRuns: 0, manual: 0 },
        kills: [],
        host: hostFacts(),
      };
    },
    pause(reason) {
      monitor?.pause(reason);
    },
    resume() {
      monitor?.resume();
    },
    isPaused() {
      return monitor?.state.paused === true;
    },
    async killNow() {
      if (monitor === null) throw new Error('auto-kill is not armed: the jobs service is unavailable');
      await monitor.killNow();
    },
    clearLog() {
      monitor?.clearLog();
    },
  };

  ctx.inject(['jobs', 'agents'], (serviceCtx) => {
    // The disposer closes over this exact instance, never over the mutable
    // `monitor` variable: teardown order is reverse registration order, so the
    // teardown effect below may already have cleared it.
    const armed = createMonitor({
      jobs: serviceCtx.jobs,
      agents: serviceCtx.agents,
      terminalController: serviceCtx.get?.('terminalController'),
      logger: serviceCtx.logger ?? ctx.logger,
      settings,
    });
    monitor = armed;
    serviceCtx.effect(() => {
      armed.start();
      return () => armed.stop();
    }, 'dsh-kill-guard: monitor');
    if (serviceCtx.get?.('terminalController') === undefined) {
      ctx.logger?.info?.('[kill-guard] no terminalController in this composition: only shell jobs are stopped');
    }
  });

  ctx.inject(['webServer'], (webCtx) => {
    webCtx.effect(
      () => webCtx.webServer.register({ kind: 'exact', path: ROUTE_PATH, handler: createRouteHandler(control, token) }),
      'dsh-kill-guard: route',
    );
    webCtx.effect(
      () =>
        webCtx.webServer.register({
          kind: 'exact',
          path: TOKEN_PATH,
          handler: createTokenHandler(token, (req) => webCtx.get?.('connection')?.isAuthenticated?.(req)),
        }),
      'dsh-kill-guard: token route',
    );
    // The supported page-side channel: rows reach both the served index and the
    // Desktop shell's boot payload. Collected fresh on every index render, so a
    // live install appears in the next browser load without a restart.
    webCtx.on?.('webserver/index-inject', (table) => {
      table.push(bootstrapRow({ path: ROUTE_PATH, token }));
    });
  });

  // Never leave a timer behind when the profile is recomposed.
  ctx.effect(() => () => {
    monitor?.stop();
    monitor = null;
  }, 'dsh-kill-guard: teardown');

  ctx.logger?.info?.(
    `[kill-guard] active — ${describeSettings(settings)} every ${Math.round(settings.intervalMs / 100) / 10}s, ${settings.sustainSamples} consecutive sample(s)${
      settings.dryRun ? ', DRY RUN' : ''
    }${settings.enabled ? '' : ', disabled'}`,
  );
}

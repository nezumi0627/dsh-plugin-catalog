/**
 * Client half of `@local/dsh-kill-guard`: the compact monitoring indicator and
 * its detail panel, replacing the always-open chip of `@local/dsh-auto-kill`.
 *
 * Placement: one compact state indicator beside the composer's existing dock
 * controls. Detailed CPU and memory readings stay in its click-open panel; the
 * shared upper row owns the single CPU and memory readouts.
 *
 * One hub, one timer. The component shares a single polling hub: one `fetch`
 * per period for the whole page. The hub
 *   * polls at most once per second — the floor requirements §15 allows;
 *   * never samples while `document.visibilityState === 'hidden'`, and clears its
 *     timer the moment the window hides, resuming (with an immediate refresh)
 *     when it shows again;
 *   * backs off to 4 s after a failure;
 *   * keeps the whole stop log and every sample the panel draws inside a bounded
 *     ring, so nothing grows without limit.
 *
 * Everything the panel shows comes from the Host route, so the panel can never
 * claim a stop that did not happen. A metric the Host reports as `null` is drawn
 * as 未取得 — never as zero — and an internal identifier such as
 * `bootstrap-missing` is mapped to a plain-language explanation plus a reconnect
 * action instead of being printed.
 *
 * Only `react`, `react-dom`, and `@deepseek-ai/dsh-client-ui-primitives` are
 * required: those are platform module-seed words. The panel is portaled to
 * `document.body` and positioned with the shared `useAnchoredPosition` /
 * `useDismissOnOutsidePointer` primitives, exactly like the composer's own
 * popovers, and the graphs are inline SVG polylines and dashed threshold lines —
 * no chart library, no canvas, no animation loop.
 */
window.__ModuleLoader__.load({
  id: '@local/dsh-kill-guard',
  factory(require) {
    const React = require('react');
    const ReactDOM = require('react-dom');
    // The panel is a portaled, fixed-position surface. The chrome strip and the
    // composer dock both live inside clipped containers, so geometry and
    // dismissal come from the shared primitives instead of an absolutely
    // positioned child.
    const { useAnchoredPosition, useDismissOnOutsidePointer } = require('@deepseek-ai/dsh-client-ui-primitives');
    const h = React.createElement;
    const { useCallback, useEffect, useRef, useState } = React;

    const ID = '@local/dsh-kill-guard';
    const NS = 'dshKillGuard';
    /** The bootstrap global the Host publishes; unchanged from the old plugin. */
    const BOOTSTRAP_KEY = '__DSH_AUTO_KILL__';
    /** The request header the Host demands; unchanged from the old plugin. */
    const TOKEN_HEADER = 'x-dsh-auto-kill-token';
    /** The route handing a page without that global its capability. */
    const TOKEN_PATH = '/local/auto-kill-token';
    /** Open-panel polling floor from requirements §15. */
    const POLL_MS = 1000;
    /** A collapsed chip refreshes at no more than 0.2 Hz. */
    const POLL_CLOSED_MS = 5000;
    /** Backoff after a failure, so a down Host costs four times less. */
    const POLL_SLOW_MS = 4000;
    /** The sparkline ring: one minute at the 1 Hz floor. */
    const HISTORY_CAP = 60;
    /** How long a fresh stop keeps the indicator emphasised. */
    const FLASH_MS = 8000;
    const GRAPH_W = 220;
    const GRAPH_H = 44;
    const VIEWS = ['overview', 'log', 'history', 'settings'];
    /** A rotated capability and a refused one look identical from here. */
    const TOKEN_REFUSED_STATUS = 403;
    const ICON_SHIELD = 'M12 2.6 4.4 5.7v6.1c0 4.52 3.08 8.7 7.6 9.8 4.52-1.1 7.6-5.28 7.6-9.8V5.7L12 2.6Z';
    const ICON_PULSE = 'M7.4 12.35h2.35l1.55-3.1 2.05 6.15 1.4-3.05h1.85';

    /**
     * Every dictionary lives inside the factory closure: a client bundle is
     * re-executed in the same page global scope by the in-page reload path, and
     * a top-level `const` would throw on the second evaluation and take the whole
     * bundle (and its registration) down with it.
     *
     * The values are plain strings and the placeholders are `{name}` tokens, so
     * this block is byte-for-byte the same data as `locale/ja.json` and friends.
     * `tools/embed-locales.mjs` regenerates it from those files and
     * `test-client.mjs` fails if the two ever drift.
     */
    /* @dicts-start */
    const DICTS = {
      ja: {
      "title": "KILLガード",
      "subtitle": "システム監視と自動停止",
      "chipHint": "CPU／メモリを監視し、閾値を超えたままなら実行中のシェルを自動停止します",
      "stateArmed": "監視中",
      "statePaused": "一時停止中",
      "stateOff": "無効",
      "stateDry": "ドライラン",
      "stateDegraded": "停止機能なし",
      "stateBreach": "閾値超過",
      "stateStopped": "停止しました",
      "connConnecting": "接続中",
      "connLive": "接続済み",
      "connOffline": "未接続",
      "connSuspended": "待機中",
      "labelCpu": "CPU",
      "labelMemory": "メモリ",
      "labelUpdated": "最終更新",
      "labelBreaches": "閾値超過",
      "labelStops": "自動停止累計",
      "labelLatest": "最新イベント",
      "labelThreshold": "閾値",
      "labelState": "監視状態",
      "labelHost": "ホスト",
      "labelConnection": "ホスト通信",
      "labelHistory": "ログ上限",
      "valueUnavailable": "未取得",
      "valueNone": "—",
      "never": "まだ何も起きていません",
      "breachesOf": "{count} / {need} 回",
      "breachesTotal": "{count} 回",
      "thresholdValue": "{value}%",
      "thresholdOff": "無効",
      "cooldown": "待機 {seconds}s",
      "updatedAgo": "{age}前",
      "stopsTotal": "累計 {count} 件",
      "stopsFlash": "停止 {count} 件",
      "cores": "{cores} コア / RAM {memory}",
      "actionPause": "一時停止",
      "actionResume": "再開",
      "actionKillNow": "今すぐ停止",
      "actionKillNowHint": "閾値に関係なく、実行中のシェル／タスクを今すぐ停止します",
      "actionWorking": "処理中…",
      "tabOverview": "概要",
      "tabLog": "ログ",
      "tabHistory": "履歴",
      "tabSettings": "閾値設定",
      "logTitle": "停止ログ",
      "logEmpty": "まだ自動停止は発生していません。",
      "logClear": "ログを消去",
      "close": "閉じる",
      "failedMark": "失敗",
      "kindJob": "ジョブ",
      "kindTerminal": "ターミナル",
      "historyTitle": "自動停止履歴",
      "historyEmpty": "自動停止の履歴はまだありません。",
      "historyNote": "ホストは直近 {cap} 件のみ保持します。累計は「{label}」を参照してください。",
      "historyJobs": "ジョブ {count} 件",
      "historyTerminals": "ターミナル {count} 件",
      "historyFailed": "失敗 {count} 件",
      "historyDry": "ドライラン {count} 件",
      "historyManual": "手動 {count} 件",
      "historyFirst": "最初の記録",
      "historyLast": "最後の記録",
      "settingsTitle": "閾値設定",
      "settingsEffective": "現在の有効値",
      "settingsNote": "値はプロファイルの cordis.patch.yml で設定します。ここには現在の有効値と、貼り付け用の設定断片を表示します（この画面からは変更しません）。",
      "settingsCopy": "設定断片をコピー",
      "settingsCopied": "コピーしました",
      "settingsRanges": "設定できる範囲",
      "settingsKey": "キー",
      "settingsDefault": "既定",
      "settingsRange": "範囲",
      "rangeToggle": "true / false",
      "rangeMs": "{min}〜{max} ms",
      "rangeSamples": "{min}〜{max} 回",
      "rangePercent": "0〜100 %",
      "rangeKinds": "ジョブ種別の一覧",
      "connBlockedHandshakeTitle": "ホストとの接続情報を受け取れませんでした",
      "connBlockedHandshakeBody": "DSH のホストが起動したあとにこのプラグインを有効化したため、このページに接続情報が配布されていません。再接続すると取得できます。",
      "connBlockedExpiredTitle": "接続情報が失効しています",
      "connBlockedExpiredBody": "ホスト側で接続情報が更新されました。再接続すると自動で取得し直します。",
      "connBlockedOfflineTitle": "ホストに接続できません",
      "connBlockedOfflineBody": "DSH のホストが応答していません。少し待ってから再接続してください。",
      "connBlockedUnknownTitle": "ホストの状態を取得できません",
      "connBlockedUnknownBody": "通信に失敗しました。再接続してください。",
      "connReconnect": "再接続",
      "connReconnecting": "再接続中…",
      "graphCpu": "CPU 使用率",
      "graphMemory": "メモリ使用率",
      "graphWindow": "直近 {count} 回のサンプル",
      "graphEmpty": "まだサンプルがありません",
      "graphThresholdLine": "閾値",
      "pollNote": "{seconds}秒間隔で更新",
      "suspended": "ウィンドウが非表示のためサンプリングを停止しています",
      "footerConfig": "設定: CPU {cpu}% / メモリ {mem}% · {interval}秒 · {kinds}",
      "lastError": "直近のエラー",
      "legendDanger": "危険",
      },
      en: {
      "title": "Kill guard",
      "subtitle": "System watch and automatic stop",
      "chipHint": "Watches CPU and memory and stops running shells automatically while a threshold stays exceeded",
      "stateArmed": "watching",
      "statePaused": "paused",
      "stateOff": "disabled",
      "stateDry": "dry run",
      "stateDegraded": "no stop service",
      "stateBreach": "over threshold",
      "stateStopped": "stopped something",
      "connConnecting": "connecting",
      "connLive": "connected",
      "connOffline": "offline",
      "connSuspended": "idle",
      "labelCpu": "CPU",
      "labelMemory": "Memory",
      "labelUpdated": "Last update",
      "labelBreaches": "Breaches",
      "labelStops": "Automatic stops",
      "labelLatest": "Latest event",
      "labelThreshold": "Threshold",
      "labelState": "State",
      "labelHost": "Host",
      "labelConnection": "Host link",
      "labelHistory": "Log cap",
      "valueUnavailable": "unavailable",
      "valueNone": "—",
      "never": "nothing has happened yet",
      "breachesOf": "{count} / {need}",
      "breachesTotal": "{count}",
      "thresholdValue": "{value}%",
      "thresholdOff": "off",
      "cooldown": "cooling {seconds}s",
      "updatedAgo": "{age} ago",
      "stopsTotal": "{count} total",
      "stopsFlash": "{count} stopped",
      "cores": "{cores} cores / RAM {memory}",
      "actionPause": "Pause",
      "actionResume": "Resume",
      "actionKillNow": "Stop now",
      "actionKillNowHint": "Stop the running shells and tasks immediately, regardless of the thresholds",
      "actionWorking": "Working…",
      "tabOverview": "Overview",
      "tabLog": "Log",
      "tabHistory": "History",
      "tabSettings": "Thresholds",
      "logTitle": "Stop log",
      "logEmpty": "Nothing has been stopped automatically yet.",
      "logClear": "Clear log",
      "close": "Close",
      "failedMark": "failed",
      "kindJob": "job",
      "kindTerminal": "terminal",
      "historyTitle": "Automatic stop history",
      "historyEmpty": "No automatic stop has been recorded yet.",
      "historyNote": "The host keeps only the most recent {cap} entries; see \"{label}\" for the cumulative count.",
      "historyJobs": "{count} jobs",
      "historyTerminals": "{count} terminals",
      "historyFailed": "{count} failed",
      "historyDry": "{count} dry-run",
      "historyManual": "{count} manual",
      "historyFirst": "First entry",
      "historyLast": "Last entry",
      "settingsTitle": "Threshold settings",
      "settingsEffective": "Effective values",
      "settingsNote": "The values come from the profile's cordis.patch.yml. This view shows the effective values and a ready-to-paste config fragment; it does not write them for you.",
      "settingsCopy": "Copy config fragment",
      "settingsCopied": "Copied",
      "settingsRanges": "Allowed ranges",
      "settingsKey": "Key",
      "settingsDefault": "Default",
      "settingsRange": "Range",
      "rangeToggle": "true / false",
      "rangeMs": "{min}–{max} ms",
      "rangeSamples": "{min}–{max}",
      "rangePercent": "0–100 %",
      "rangeKinds": "list of job kinds",
      "connBlockedHandshakeTitle": "The host connection details never arrived",
      "connBlockedHandshakeBody": "This plugin was enabled after the DSH host started, so this page was never handed its connection details. Reconnecting fetches them.",
      "connBlockedExpiredTitle": "The connection details have expired",
      "connBlockedExpiredBody": "The host rotated its connection details. Reconnecting picks up the new ones automatically.",
      "connBlockedOfflineTitle": "The host cannot be reached",
      "connBlockedOfflineBody": "The DSH host is not answering. Wait a moment, then reconnect.",
      "connBlockedUnknownTitle": "The host state could not be read",
      "connBlockedUnknownBody": "The request failed. Please reconnect.",
      "connReconnect": "Reconnect",
      "connReconnecting": "Reconnecting…",
      "graphCpu": "CPU usage",
      "graphMemory": "Memory usage",
      "graphWindow": "last {count} samples",
      "graphEmpty": "no samples yet",
      "graphThresholdLine": "threshold",
      "pollNote": "refreshed every {seconds}s",
      "suspended": "Sampling is paused while the window is hidden",
      "footerConfig": "Config: CPU {cpu}% / memory {mem}% · {interval}s · {kinds}",
      "lastError": "Last error",
      "legendDanger": "danger",
      },
      zh: {
      "title": "终止守卫",
      "subtitle": "系统监控与自动停止",
      "chipHint": "监控 CPU 与内存，超过阈值持续不降时自动停止正在运行的 shell",
      "stateArmed": "监控中",
      "statePaused": "已暂停",
      "stateOff": "已禁用",
      "stateDry": "试运行",
      "stateDegraded": "无停止服务",
      "stateBreach": "超过阈值",
      "stateStopped": "已执行停止",
      "connConnecting": "连接中",
      "connLive": "已连接",
      "connOffline": "未连接",
      "connSuspended": "待机",
      "labelCpu": "CPU",
      "labelMemory": "内存",
      "labelUpdated": "最后更新",
      "labelBreaches": "超过阈值",
      "labelStops": "自动停止累计",
      "labelLatest": "最新事件",
      "labelThreshold": "阈值",
      "labelState": "监控状态",
      "labelHost": "主机",
      "labelConnection": "主机通信",
      "labelHistory": "日志上限",
      "valueUnavailable": "未获取",
      "valueNone": "—",
      "never": "目前还没有任何事件",
      "breachesOf": "{count} / {need} 次",
      "breachesTotal": "{count} 次",
      "thresholdValue": "{value}%",
      "thresholdOff": "已禁用",
      "cooldown": "等待 {seconds}s",
      "updatedAgo": "{age}前",
      "stopsTotal": "累计 {count} 个",
      "stopsFlash": "已停止 {count} 个",
      "cores": "{cores} 核 / 内存 {memory}",
      "actionPause": "暂停",
      "actionResume": "继续",
      "actionKillNow": "立即停止",
      "actionKillNowHint": "忽略阈值，立即停止正在运行的 shell／任务",
      "actionWorking": "处理中…",
      "tabOverview": "概要",
      "tabLog": "日志",
      "tabHistory": "历史",
      "tabSettings": "阈值设置",
      "logTitle": "停止日志",
      "logEmpty": "尚未发生自动停止。",
      "logClear": "清除日志",
      "close": "关闭",
      "failedMark": "失败",
      "kindJob": "任务",
      "kindTerminal": "终端",
      "historyTitle": "自动停止历史",
      "historyEmpty": "还没有自动停止的记录。",
      "historyNote": "主机只保留最近 {cap} 条记录，累计数量请查看「{label}」。",
      "historyJobs": "任务 {count} 个",
      "historyTerminals": "终端 {count} 个",
      "historyFailed": "失败 {count} 个",
      "historyDry": "试运行 {count} 个",
      "historyManual": "手动 {count} 个",
      "historyFirst": "最早记录",
      "historyLast": "最后记录",
      "settingsTitle": "阈值设置",
      "settingsEffective": "当前有效值",
      "settingsNote": "这些值来自配置文件的 cordis.patch.yml。此处显示当前有效值与可直接粘贴的配置片段，不会代替你写入。",
      "settingsCopy": "复制配置片段",
      "settingsCopied": "已复制",
      "settingsRanges": "可设置范围",
      "settingsKey": "键",
      "settingsDefault": "默认",
      "settingsRange": "范围",
      "rangeToggle": "true / false",
      "rangeMs": "{min}〜{max} ms",
      "rangeSamples": "{min}〜{max} 次",
      "rangePercent": "0〜100 %",
      "rangeKinds": "任务类型列表",
      "connBlockedHandshakeTitle": "未能获取与主机的连接信息",
      "connBlockedHandshakeBody": "本插件是在 DSH 主机启动之后启用的，因此该页面没有收到连接信息。重新连接即可获取。",
      "connBlockedExpiredTitle": "连接信息已失效",
      "connBlockedExpiredBody": "主机已更新连接信息。重新连接会自动获取新的信息。",
      "connBlockedOfflineTitle": "无法连接主机",
      "connBlockedOfflineBody": "DSH 主机没有响应。请稍候再重新连接。",
      "connBlockedUnknownTitle": "无法获取主机状态",
      "connBlockedUnknownBody": "通信失败。请重新连接。",
      "connReconnect": "重新连接",
      "connReconnecting": "重新连接中…",
      "graphCpu": "CPU 使用率",
      "graphMemory": "内存使用率",
      "graphWindow": "最近 {count} 个采样",
      "graphEmpty": "还没有采样",
      "graphThresholdLine": "阈值",
      "pollNote": "每 {seconds} 秒刷新",
      "suspended": "窗口不可见，已停止采样",
      "footerConfig": "设置: CPU {cpu}% / 内存 {mem}% · {interval} 秒 · {kinds}",
      "lastError": "最近错误",
      "legendDanger": "危险",
      },
    };
/* @dicts-end */

    const css = `
      .dkg-chrome{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;justify-content:center;pointer-events:none;--dkg-chrome-height:var(--dsh-frame-chrome-top,0px)}
      .dkg-root{display:inline-flex;align-items:center;min-width:0}
      .dkg-chip{display:inline-flex;align-items:center;gap:6px;height:22px;padding:0 9px;border:1px solid transparent;border-radius:999px;background:transparent;color:var(--dsw-alias-label-tertiary);font:12px/1 var(--dsw-font-family,system-ui,sans-serif);font-variant-numeric:tabular-nums;cursor:pointer;-webkit-app-region:no-drag;transition:background .15s ease,color .15s ease,border-color .15s ease}
      .dkg-chip:hover,.dkg-chip[aria-expanded='true']{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-secondary)}
      .dkg-chrome[data-float='1'] .dkg-chip{margin:6px 0;border-color:var(--dsw-alias-border-l1);background:var(--dsw-specific-menu);box-shadow:var(--dsw-elevation-soft)}
      .dkg-root[data-alert='1'] .dkg-chip{border-color:var(--dsw-alias-state-error-primary);background:var(--dsw-alias-bg-overlay);color:var(--dsw-alias-label-primary)}
      .dkg-chip-icon{width:13px;height:13px;flex:none}
      .dkg-dot{width:6px;height:6px;flex:none;border-radius:50%;background:var(--dsw-alias-state-success-primary)}
      .dkg-dot[data-state='paused']{background:var(--dsw-alias-state-warn-primary)}
      .dkg-dot[data-state='off'],.dkg-dot[data-state='degraded']{background:var(--dsw-alias-state-idle-primary)}
      .dkg-dot[data-state='breach'],.dkg-dot[data-state='stopped']{background:var(--dsw-alias-state-error-primary)}
      .dkg-dot[data-state='breach']{animation:dkg-pulse 1.6s ease-in-out infinite}
      @keyframes dkg-pulse{0%,100%{opacity:1}50%{opacity:.4}}
      .dkg-metric{display:inline-flex;align-items:baseline;gap:4px}
      .dkg-metric-label{color:var(--dsw-alias-label-tertiary)}
      .dkg-metric-value{min-width:32px;text-align:right;color:var(--dsw-alias-label-primary)}
      .dkg-metric-value[data-level='hot']{color:var(--dsw-alias-state-error-primary)}
      .dkg-metric-value[data-level='warn']{color:var(--dsw-alias-state-warn-primary)}
      .dkg-sep{width:1px;height:11px;flex:none;background:var(--dsw-alias-border-l1)}
      .dkg-flash{color:var(--dsw-alias-state-error-primary);font-weight:600}
      .dkg-panel{position:fixed;z-index:1200;box-sizing:border-box;width:min(380px,calc(100vw - 24px));max-height:min(78vh,620px);overflow:auto;display:flex;flex-direction:column;gap:12px;padding:14px;border:1px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg);background:var(--dsw-specific-menu);backdrop-filter:var(--dsw-menu-backdrop-filter);-webkit-backdrop-filter:var(--dsw-menu-backdrop-filter);box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-secondary);font:12px/18px var(--dsw-font-family,system-ui,sans-serif);-webkit-app-region:no-drag}
      .dkg-head{display:flex;align-items:flex-start;gap:8px}
      .dkg-head-main{display:flex;flex-direction:column;gap:1px;min-width:0;flex:1}
      .dkg-title{color:var(--dsw-alias-label-primary);font-size:13px;font-weight:600}
      .dkg-subtitle{color:var(--dsw-alias-label-caption);font-size:11px}
      .dkg-badges{display:flex;align-items:center;gap:4px;flex-wrap:wrap;justify-content:flex-end}
      .dkg-badge{padding:2px 6px;border-radius:var(--dsw-radius-xs);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-tertiary);font-size:10px;white-space:nowrap}
      .dkg-badge[data-tone='ok']{background:var(--dsw-alias-state-success-tertiary);color:var(--dsw-alias-state-success-primary)}
      .dkg-badge[data-tone='warn']{background:var(--dsw-alias-state-warn-tertiary);color:var(--dsw-alias-state-warn-primary)}
      .dkg-badge[data-tone='hot']{background:var(--dsw-alias-state-error-secondary);color:var(--dsw-alias-state-error-primary)}
      .dkg-close{width:20px;height:20px;flex:none;padding:0;border:0;border-radius:var(--dsw-radius-xs);background:transparent;color:var(--dsw-alias-label-tertiary);font:inherit;line-height:1;cursor:pointer}
      .dkg-close:hover{background:var(--dsw-alias-interactive-bg-hover);color:var(--dsw-alias-label-primary)}
      .dkg-tabs{display:flex;gap:2px;padding:2px;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-bg-layer-1)}
      .dkg-tab{flex:1;min-height:26px;padding:0 6px;border:0;border-radius:var(--dsw-radius-xs);background:transparent;color:var(--dsw-alias-label-tertiary);font:inherit;font-size:11px;cursor:pointer}
      .dkg-tab:hover{color:var(--dsw-alias-label-primary)}
      .dkg-tab[data-active='1']{background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-primary);font-weight:600}
      .dkg-view{display:flex;flex-direction:column;gap:12px}
      .dkg-graph{display:flex;flex-direction:column;gap:4px}
      .dkg-graph-head{display:flex;align-items:baseline;justify-content:space-between;gap:8px}
      .dkg-graph-label{color:var(--dsw-alias-label-secondary);font-size:11px;font-weight:600}
      .dkg-graph-value{color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums}
      .dkg-graph-value[data-level='hot']{color:var(--dsw-alias-state-error-primary)}
      .dkg-graph-value[data-level='warn']{color:var(--dsw-alias-state-warn-primary)}
      .dkg-graph-svg{display:block;width:100%;height:44px;overflow:visible}
      .dkg-graph-area{fill:var(--dsw-alias-state-business-tertiary);stroke:none}
      .dkg-graph-line{fill:none;stroke:var(--dsw-alias-state-business-primary);stroke-width:1.5;stroke-linejoin:round;stroke-linecap:round}
      .dkg-graph[data-level='hot'] .dkg-graph-line,.dkg-graph[data-level='hot'] .dkg-graph-area{stroke:var(--dsw-alias-state-error-primary);fill:var(--dsw-alias-state-error-secondary)}
      .dkg-graph[data-level='warn'] .dkg-graph-line{stroke:var(--dsw-alias-state-warn-primary)}
      .dkg-graph-threshold{stroke:var(--dsw-alias-label-tertiary);stroke-width:1;stroke-dasharray:3 3}
      .dkg-graph-note{color:var(--dsw-alias-label-caption);font-size:10px}
      .dkg-stats{display:grid;grid-template-columns:auto minmax(0,1fr);gap:4px 10px;align-items:baseline}
      .dkg-stat-label{color:var(--dsw-alias-label-tertiary);font-size:11px}
      .dkg-stat-value{min-width:0;overflow-wrap:anywhere;color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums}
      .dkg-actions{display:flex;gap:6px;flex-wrap:wrap}
      .dkg-button{min-height:28px;padding:0 10px;border:1px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-bg-layer-1);color:var(--dsw-alias-label-primary);font:inherit;font-size:11px;cursor:pointer}
      .dkg-button:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover)}
      .dkg-button:disabled{opacity:.5;cursor:default}
      .dkg-button[data-tone='hot']{margin-left:auto;border-color:var(--dsw-alias-state-error-primary);background:var(--dsw-alias-state-error-secondary);color:var(--dsw-alias-state-error-primary);font-weight:600}
      .dkg-button[data-tone='hot']:hover:not(:disabled){background:var(--dsw-alias-interactive-bg-hover-danger)}
      .dkg-section-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
      .dkg-section-label{color:var(--dsw-alias-label-secondary);font-size:11px;font-weight:600}
      .dkg-link{padding:0;border:0;background:transparent;color:var(--dsw-alias-label-tertiary);font:inherit;font-size:10px;cursor:pointer}
      .dkg-link:hover:not(:disabled){color:var(--dsw-alias-label-primary)}
      .dkg-log{display:flex;flex-direction:column;gap:5px;max-height:190px;overflow:auto;margin:0;padding:0;list-style:none}
      .dkg-log-item{display:grid;grid-template-columns:auto auto minmax(0,1fr);gap:6px;align-items:start;padding:6px 7px;border:1px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-bg-layer-1)}
      .dkg-log-time{padding-top:1px;color:var(--dsw-alias-label-caption);font-size:10px;font-variant-numeric:tabular-nums}
      .dkg-log-kind{padding:1px 5px;border-radius:var(--dsw-radius-xs);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-tertiary);font-size:9px}
      .dkg-log-label{display:-webkit-box;min-width:0;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow-wrap:anywhere;color:var(--dsw-alias-label-secondary);font-size:10px;line-height:1.45}
      .dkg-log-item[data-ok='0'] .dkg-log-label{color:var(--dsw-alias-state-warn-primary)}
      .dkg-table{width:100%;border-collapse:collapse;font-size:11px}
      .dkg-table th{color:var(--dsw-alias-label-caption);font-weight:600;text-align:left;padding:2px 6px 2px 0}
      .dkg-table td{padding:2px 6px 2px 0;color:var(--dsw-alias-label-secondary);vertical-align:top}
      .dkg-table td.dkg-value{color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums;white-space:nowrap}
      .dkg-code{margin:0;padding:8px;max-height:150px;overflow:auto;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-markdown-code-block);color:var(--dsw-alias-label-secondary);font:11px/1.5 ui-monospace,SFMono-Regular,Menlo,monospace;white-space:pre}
      .dkg-note{margin:0;color:var(--dsw-alias-label-caption);font-size:10px;line-height:1.5}
      .dkg-bullets{display:flex;flex-direction:column;gap:4px;margin:0;padding-left:16px;color:var(--dsw-alias-label-secondary);font-size:11px}
      .dkg-error{margin:0;color:var(--dsw-alias-state-error-primary);font-size:10px;overflow-wrap:anywhere}
      .dkg-blocked{display:flex;flex-direction:column;gap:8px;padding:10px;border:1px solid var(--dsw-alias-state-warn-primary);border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-state-warn-tertiary)}
      .dkg-blocked-title{color:var(--dsw-alias-label-primary);font-size:12px;font-weight:600}
      .dkg-blocked-body{margin:0;color:var(--dsw-alias-label-secondary);font-size:11px;line-height:1.55}
      @media(max-width:640px){.dkg-panel{width:calc(100vw - 16px);padding:12px}.dkg-button[data-tone='hot']{margin-left:0}.dkg-stats{grid-template-columns:minmax(0,1fr)}}
      @media(prefers-reduced-motion:reduce){.dkg-dot[data-state='breach']{animation:none}.dkg-chip{transition:none}}
    `;

    // The Client module system claims the untagged tags a factory created during
    // materialization and removes them on teardown, so no non-baseline module
    // such as `styles` is requested: only platform seed words may be required.
    const styleElement = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = css;
      document.head.append(element);
      return element;
    })();

    // -----------------------------------------------------------------------
    // small pure helpers (all of them are exercised through `__test`)

    const clamp = (value) => {
      const number = Number(value);
      if (!Number.isFinite(number)) return 0;
      return Math.min(100, Math.max(0, number));
    };

    const isNumber = (value) => typeof value === 'number' && Number.isFinite(value);

    function formatPercent(value) {
      if (value === null || value === undefined) return '--';
      const number = Number(value);
      if (!Number.isFinite(number)) return '--';
      return `${Math.round(Math.min(100, Math.max(0, number)) * 10) / 10}%`;
    }

    function formatBytes(value) {
      const number = Number(value);
      if (value === null || value === undefined || !Number.isFinite(number) || number <= 0) return '--';
      const units = ['B', 'KB', 'MB', 'GB', 'TB'];
      let size = number;
      let unit = 0;
      while (size >= 1024 && unit < units.length - 1) {
        size /= 1024;
        unit += 1;
      }
      return `${size >= 10 || unit === 0 ? Math.round(size) : Math.round(size * 10) / 10} ${units[unit]}`;
    }

    function formatClockTime(stamp) {
      const value = Number(stamp);
      if (!Number.isFinite(value)) return '--:--:--';
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return '--:--:--';
      const pad = (part) => String(part).padStart(2, '0');
      return `${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    }

    /** A locale-free age token; the dictionary supplies the wording around it. */
    function formatAge(ms) {
      if (ms === null || ms === undefined) return '--';
      const value = Number(ms);
      if (!Number.isFinite(value) || value < 0) return '--';
      const seconds = Math.floor(value / 1000);
      if (seconds < 60) return `${seconds}s`;
      const minutes = Math.floor(seconds / 60);
      if (minutes < 60) return `${minutes}m`;
      const hours = Math.floor(minutes / 60);
      if (hours < 24) return `${hours}h`;
      return `${Math.floor(hours / 24)}d`;
    }

    /** Which tone a live value deserves against its arm. */
    function levelFor(value, threshold, softCeiling) {
      if (value === null || value === undefined) return 'unknown';
      const number = Number(value);
      if (!Number.isFinite(number)) return 'unknown';
      const arm = Number(threshold) > 0 ? Number(threshold) : 100;
      if (number >= arm) return 'hot';
      if (number >= Math.min(arm - 1, softCeiling)) return 'warn';
      return 'ok';
    }

    /** Substitute `{name}` placeholders. An unknown key is left visible on purpose. */
    function fill(template, params) {
      if (typeof template !== 'string') return template;
      if (!params) return template;
      return template.replace(/\{(\w+)\}/g, (match, key) => (key in params ? String(params[key]) : match));
    }

    /**
     * The bounded sample ring the graphs read. A sample whose metrics are both
     * unknown is not recorded at all: the panel must never draw a fabricated zero.
     */
    function pushSample(history, sample, cap = HISTORY_CAP) {
      if (!Array.isArray(history) || !sample || typeof sample !== 'object') return history;
      const cpu = isNumber(sample.cpu) ? sample.cpu : null;
      const memory = isNumber(sample.memory) ? sample.memory : null;
      if (cpu === null && memory === null) return history;
      history.push({ at: isNumber(sample.at) ? sample.at : null, cpu, memory });
      if (history.length > cap) history.splice(0, history.length - cap);
      return history;
    }

    const round2 = (value) => Math.round(value * 100) / 100;

    /**
     * Polyline points for one metric on a 0..100 vertical scale. A gap in the
     * series stays a gap: the missing sample is skipped, not plotted as zero.
     */
    function sparklinePoints(history, key, width = GRAPH_W, height = GRAPH_H) {
      const entries = Array.isArray(history) ? history : [];
      const values = entries.map((entry) => (entry && isNumber(entry[key]) ? entry[key] : null));
      const known = values.filter((value) => value !== null);
      if (known.length === 0) return { points: '', hasData: false, count: 0, min: null, max: null, thresholdY: null };
      const step = entries.length > 1 ? width / (entries.length - 1) : 0;
      const points = [];
      for (let index = 0; index < values.length; index += 1) {
        const value = values[index];
        if (value === null) continue;
        const x = entries.length > 1 ? index * step : width;
        const y = height - (clamp(value) / 100) * height;
        points.push(`${round2(x)},${round2(y)}`);
      }
      return {
        points: points.join(' '),
        hasData: true,
        count: known.length,
        min: Math.min(...known),
        max: Math.max(...known),
        thresholdY: null,
      };
    }

    /** The y coordinate of a threshold line on the same 0..100 scale. */
    function thresholdY(threshold, height = GRAPH_H) {
      const arm = Number(threshold);
      if (!Number.isFinite(arm) || arm <= 0) return null;
      return round2(height - (clamp(arm) / 100) * height);
    }

    /**
     * Aggregate the host's capped stop log. Every number here is either counted
     * from the log or read from the host's cumulative counters — nothing is
     * extrapolated, and `cap` is reported so a capped window cannot be mistaken
     * for the whole history.
     */
    function historySummary(kills, counters) {
      const entries = Array.isArray(kills) ? kills.filter((entry) => entry && typeof entry === 'object') : [];
      const counted = entries.filter((entry) => entry.dryRun !== true);
      const timestamps = counted.map((entry) => Number(entry.at)).filter((value) => Number.isFinite(value));
      const manualFromLog = entries.filter((entry) => entry.manual === true).length;
      const manualFromHost = Number(counters?.manual);
      return {
        jobs: counted.filter((entry) => entry.kind !== 'terminal').length,
        terminals: counted.filter((entry) => entry.kind === 'terminal').length,
        failed: entries.filter((entry) => entry.ok === false).length,
        dryRun: entries.filter((entry) => entry.dryRun === true).length,
        manual: Math.max(Number.isFinite(manualFromHost) ? manualFromHost : 0, manualFromLog),
        total: counted.length,
        first: timestamps.length > 0 ? Math.min(...timestamps) : null,
        last: timestamps.length > 0 ? Math.max(...timestamps) : null,
      };
    }

    /** The paste-ready override block for the panel's threshold view. */
    function configFragment(settings) {
      const value = settings ?? {};
      const kinds = Array.isArray(value.jobKinds) && value.jobKinds.length > 0 ? value.jobKinds.join(', ') : 'bash, pwsh';
      return [
        '- id: dsh-auto-kill',
        `  enabled: ${value.enabled === false ? 'false' : 'true'}`,
        `  cpuThreshold: ${isNumber(value.cpuThreshold) ? value.cpuThreshold : 90}`,
        `  memoryThreshold: ${isNumber(value.memoryThreshold) ? value.memoryThreshold : 90}`,
        `  intervalMs: ${isNumber(value.intervalMs) ? value.intervalMs : 1500}`,
        `  sustainSamples: ${isNumber(value.sustainSamples) ? value.sustainSamples : 2}`,
        `  cooldownMs: ${isNumber(value.cooldownMs) ? value.cooldownMs : 15000}`,
        `  killJobs: ${value.killJobs === false ? 'false' : 'true'}`,
        `  jobKinds: [${kinds}]`,
        `  killTerminals: ${value.killTerminals === false ? 'false' : 'true'}`,
        `  dryRun: ${value.dryRun === true ? 'true' : 'false'}`,
      ].join('\n');
    }

    /**
     * The threshold table. Values stay locale-free (numbers, units, key names)
     * so the same row can be rendered in any language, and the allowed range is
     * carried as a dictionary key plus its parameters rather than a literal.
     */
    function settingsRows(settings) {
      const value = settings ?? {};
      const toggle = (flag, fallback) => (typeof flag === 'boolean' ? String(flag) : String(fallback));
      return [
        { key: 'enabled', value: toggle(value.enabled, true), rangeKey: 'rangeToggle', rangeParams: {} },
        { key: 'cpuThreshold', value: `${isNumber(value.cpuThreshold) ? value.cpuThreshold : 90}%`, rangeKey: 'rangePercent', rangeParams: {} },
        { key: 'memoryThreshold', value: `${isNumber(value.memoryThreshold) ? value.memoryThreshold : 90}%`, rangeKey: 'rangePercent', rangeParams: {} },
        { key: 'intervalMs', value: `${isNumber(value.intervalMs) ? value.intervalMs : 1500} ms`, rangeKey: 'rangeMs', rangeParams: { min: 250, max: 600000 } },
        { key: 'sustainSamples', value: `${isNumber(value.sustainSamples) ? value.sustainSamples : 2}`, rangeKey: 'rangeSamples', rangeParams: { min: 1, max: 600 } },
        { key: 'cooldownMs', value: `${isNumber(value.cooldownMs) ? value.cooldownMs : 15000} ms`, rangeKey: 'rangeMs', rangeParams: { min: 0, max: 3600000 } },
        { key: 'killJobs', value: toggle(value.killJobs, true), rangeKey: 'rangeToggle', rangeParams: {} },
        { key: 'jobKinds', value: Array.isArray(value.jobKinds) && value.jobKinds.length > 0 ? value.jobKinds.join(', ') : 'bash, pwsh', rangeKey: 'rangeKinds', rangeParams: {} },
        { key: 'killTerminals', value: toggle(value.killTerminals, true), rangeKey: 'rangeToggle', rangeParams: {} },
        { key: 'dryRun', value: toggle(value.dryRun, false), rangeKey: 'rangeToggle', rangeParams: {} },
      ];
    }

    // -----------------------------------------------------------------------
    // capability + host client

    /** The chrome strip height, or 0 when this window has no caption strip. */
    function readChromeHeight() {
      if (typeof document === 'undefined' || typeof getComputedStyle !== 'function') return 0;
      const raw = getComputedStyle(document.documentElement).getPropertyValue('--dsh-frame-chrome-top');
      const value = Number.parseFloat(raw);
      return Number.isFinite(value) && value > 0 ? value : 0;
    }

    function readBootstrap() {
      const boot = typeof window === 'undefined' ? null : window[BOOTSTRAP_KEY];
      if (!boot || typeof boot.path !== 'string' || typeof boot.token !== 'string' || !boot.path || !boot.token) return null;
      return boot;
    }

    /** Install a `{path, token}` capability as this page's bootstrap global. */
    function storeBootstrap(payload) {
      try {
        window[BOOTSTRAP_KEY] = payload;
      } catch {
        /* a frozen global is fine: `createApi` writes nothing */
      }
    }

    /**
     * A failure the panel can translate. The `code` never reaches the screen —
     * only `describeFailure` turns it into words a user can act on.
     */
    function guardError(code, status) {
      const error = new Error(code);
      error.code = code;
      if (status !== undefined) error.status = status;
      return error;
    }

    function createApi() {
      const boot = readBootstrap();
      if (boot === null) return null;
      const request = async (action) => {
        let response;
        try {
          response = await fetch(boot.path, {
            method: action ? 'POST' : 'GET',
            headers: action
              ? { [TOKEN_HEADER]: boot.token, 'content-type': 'application/json' }
              : { [TOKEN_HEADER]: boot.token },
            body: action ? JSON.stringify({ action }) : undefined,
            cache: 'no-store',
          });
        } catch {
          throw guardError('route-network');
        }
        const payload = await response.json().catch(() => null);
        if (!response.ok || !payload || payload.ok !== true) throw guardError('route-http', response.status);
        return payload.data;
      };
      return {
        read: () => request(null),
        act: (action) => request(action),
      };
    }

    /**
     * Resolve a client for the Host route.
     *
     * The route is a same-origin capability whose token normally rides in as a
     * bootstrap global — injected by the served index, or by the Desktop shell's
     * boot payload over IPC. Both can be absent in practice: the Desktop shell
     * serves its document from disk and snapshots boot injections when the Host
     * starts, so a window opened before this plugin was installed (or a live
     * install with no restart) has no global. The Host therefore also hands the
     * capability out on `TOKEN_PATH` to any caller carrying the GUI cookie, and
     * that is what a page in that position asks for.
     *
     * `force` skips a cached global: after the plugin is re-applied the Host has
     * minted a new token, and the stale one has to be replaced rather than kept.
     */
    async function resolveApi(force = false) {
      if (!force && readBootstrap() !== null) return createApi();
      if (typeof fetch !== 'function') throw guardError('page-no-fetch');
      let response;
      try {
        response = await fetch(TOKEN_PATH, {
          method: 'GET',
          headers: { accept: 'application/json' },
          credentials: 'same-origin',
          cache: 'no-store',
        });
      } catch {
        throw guardError('handshake-network');
      }
      if (!response.ok) throw guardError('handshake-http', response.status);
      const payload = await response.json().catch(() => null);
      const data = payload?.ok === true ? payload.data : null;
      if (!data || typeof data.path !== 'string' || typeof data.token !== 'string' || !data.path || !data.token) {
        throw guardError('handshake-empty');
      }
      storeBootstrap({ path: data.path, token: data.token });
      const api = createApi();
      if (api === null) throw guardError('handshake-empty');
      return api;
    }

    /**
     * Turn a failure into plain language plus the one action that fixes it.
     * Nothing internal is passed through: a user reading this learns what
     * happened and what to press, not the name of an internal branch.
     */
    function describeFailure(failure, lookup) {
      if (!failure) return null;
      const translate = typeof lookup === 'function' ? lookup : (key) => (lookup ?? DICTS.ja)[key];
      const code = typeof failure.code === 'string' ? failure.code : '';
      let titleKey = 'connBlockedUnknownTitle';
      let bodyKey = 'connBlockedUnknownBody';
      if (code === 'route-http' && Number(failure.status) === TOKEN_REFUSED_STATUS) {
        titleKey = 'connBlockedExpiredTitle';
        bodyKey = 'connBlockedExpiredBody';
      } else if (code === 'route-network') {
        titleKey = 'connBlockedOfflineTitle';
        bodyKey = 'connBlockedOfflineBody';
      } else if (code.startsWith('handshake-') || code === 'page-no-fetch') {
        titleKey = 'connBlockedHandshakeTitle';
        bodyKey = 'connBlockedHandshakeBody';
      }
      return { title: translate(titleKey), body: translate(bodyKey), reconnect: true };
    }

    // -----------------------------------------------------------------------
    // the shared polling hub

    function isHidden() {
      return typeof document !== 'undefined' && document.visibilityState === 'hidden';
    }

    /**
     * One hub per page. Several cells can be mounted (the top strip and the
     * composer dock), and they all share this one timer, one in-flight request,
     * and one sample ring — mounting a second cell never doubles the work.
     *
     * `options` exists for the tests: they inject a fake clock and a short
     * period so the gating can be driven deterministically instead of by waiting
     * a real second.
     */
    function createHub(options = {}) {
      const setTimer = options.setTimeout ?? ((fn, ms) => setTimeout(fn, ms));
      const clearTimer = options.clearTimeout ?? ((id) => clearTimeout(id));
      const pollMs = Number(options.pollMs) > 0 ? Number(options.pollMs) : POLL_MS;
      const closedPollMs = Number(options.closedPollMs) > 0 ? Number(options.closedPollMs) : POLL_CLOSED_MS;
      const slowMs = Number(options.slowMs) > 0 ? Number(options.slowMs) : POLL_SLOW_MS;
      const openPanels = new Set();
      const clock = options.now ?? (() => Date.now());
      const listeners = new Set();
      /** The sparkline source. Read-only for consumers; replaced never, trimmed always. */
      const history = [];
      /** `undefined` = never resolved, `null` = resolution failed, object = usable. */
      let api;
      let snapshot = null;
      let failure = null;
      let timer = null;
      let inflight = false;
      let failures = 0;
      let rehandshaked = false;
      let pending = null;
      let observed = false;
      let disposed = false;
      let lastUpdateAt = 0;

      function subscriberCount() {
        return listeners.size;
      }

      function emit() {
        for (const listener of [...listeners]) {
          try {
            listener();
          } catch {
            /* a broken cell must never break the hub */
          }
        }
      }

      function connection() {
        if (listeners.size === 0) return 'connecting';
        if (isHidden()) return 'suspended';
        if (failure !== null) return 'offline';
        if (snapshot === null) return 'connecting';
        return 'live';
      }

      function state() {
        return { connection: connection(), snapshot, failure, pending, history, lastUpdateAt, pollMs };
      }

      function unschedule() {
        if (timer === null) return;
        clearTimer(timer);
        timer = null;
      }

      function schedule() {
        if (timer !== null || disposed || listeners.size === 0) return;
        // A hidden window never samples: not one request, not one timer.
        if (isHidden()) return;
        const interval = failures > 0 ? slowMs : (openPanels.size > 0 ? pollMs : closedPollMs);
        timer = setTimer(() => {
          timer = null;
          void poll();
        }, interval);
        timer?.unref?.();
      }

      async function read(force) {
        const client = force === true || api === undefined || api === null ? await resolveApi(force === true) : api;
        api = client;
        return await client.read();
      }

      /** One sampling attempt. Refuses to do anything at all while hidden. */
      async function poll(force = false) {
        if (disposed || isHidden()) return;
        if (inflight) return;
        inflight = true;
        try {
          let data;
          try {
            data = await read(force);
          } catch (error) {
            // A rotated token and a refused one look identical from here. The Host
            // mints a new token every time the plugin is re-applied, so ask for a
            // fresh capability once rather than making the user reload the window.
            if (error?.code === 'route-http' && Number(error.status) === TOKEN_REFUSED_STATUS && !rehandshaked) {
              rehandshaked = true;
              api = undefined;
              data = await read(true);
            } else {
              throw error;
            }
          }
          snapshot = data ?? null;
          failure = null;
          failures = 0;
          rehandshaked = false;
          lastUpdateAt = isNumber(Number(snapshot?.at)) ? Number(snapshot.at) : clock();
          pushSample(history, snapshot?.sample, HISTORY_CAP);
        } catch (error) {
          failures += 1;
          failure = { code: typeof error?.code === 'string' ? error.code : 'unknown', status: error?.status };
        } finally {
          inflight = false;
          schedule();
          emit();
        }
      }

      /** Apply one control action and fold the Host's answer back in. */
      async function act(action) {
        if (pending !== null) return null;
        pending = action;
        emit();
        try {
          if (api === undefined || api === null) await poll();
          if (api === undefined || api === null) return null;
          const data = await api.act(action);
          if (data) {
            snapshot = data;
            failure = null;
            lastUpdateAt = isNumber(Number(data.at)) ? Number(data.at) : clock();
            pushSample(history, data.sample, HISTORY_CAP);
          }
          return data;
        } catch (error) {
          failure = { code: typeof error?.code === 'string' ? error.code : 'unknown', status: error?.status };
          return null;
        } finally {
          pending = null;
          emit();
        }
      }

      /** Throw the cached capability away and ask for a fresh one. */
      async function reconnect() {
        api = undefined;
        rehandshaked = false;
        failure = null;
        // The old samples belong to a capability that is gone; drawing them next
        // to the new series would imply continuity that does not exist.
        history.length = 0;
        emit();
        await poll(true);
      }

      function setPanelOpen(id, open) {
        const wasOpen = openPanels.has(id);
        if (open === true) openPanels.add(id);
        else openPanels.delete(id);
        if (wasOpen === (open === true)) return;
        // Switching between collapsed and expanded cadence replaces the pending
        // timer without causing an extra immediate request.
        unschedule();
        schedule();
      }

      function onVisibilityChange() {
        if (isHidden()) unschedule();
        else void poll();
        emit();
      }

      function subscribe(listener) {
        listeners.add(listener);
        if (!observed) {
          observed = true;
          if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
            document.addEventListener('visibilitychange', onVisibilityChange);
          }
        }
        if (listeners.size === 1 && !isHidden()) void poll();
        return () => {
          listeners.delete(listener);
          if (listeners.size > 0) return;
          unschedule();
          if (!observed) return;
          observed = false;
          if (typeof document !== 'undefined' && typeof document.removeEventListener === 'function') {
            document.removeEventListener('visibilitychange', onVisibilityChange);
          }
        };
      }

      function dispose() {
        disposed = true;
        unschedule();
        listeners.clear();
        if (observed) {
          observed = false;
          if (typeof document !== 'undefined' && typeof document.removeEventListener === 'function') {
            document.removeEventListener('visibilitychange', onVisibilityChange);
          }
        }
      }

      return { subscribe, state, poll, act, reconnect, dispose, subscriberCount, setPanelOpen };
    }

    let hub = createHub();
    const currentHub = () => hub;
    function resetHub(options) {
      hub.dispose();
      hub = createHub(options);
      return hub;
    }

    // -----------------------------------------------------------------------
    // presentation

    /** Locale-bound translate function; `apply` replaces it before any render. */
    let t = (key) => key;
    const tr = (key, params) => fill(t(key), params);

    const CONNECTION_KEY = {
      connecting: 'connConnecting',
      live: 'connLive',
      offline: 'connOffline',
      suspended: 'connSuspended',
    };

    const stopTotal = (snapshot) =>
      (Number(snapshot?.counters?.jobs) || 0) + (Number(snapshot?.counters?.terminals) || 0);

    function Icon({ className }) {
      return h(
        'svg',
        { className, viewBox: '0 0 24 24', width: 13, height: 13, fill: 'none', 'aria-hidden': true, focusable: false },
        h('path', { d: ICON_SHIELD, stroke: 'currentColor', strokeWidth: 1.5, strokeLinejoin: 'round' }),
        h('path', { d: ICON_PULSE, stroke: 'currentColor', strokeWidth: 1.5, strokeLinecap: 'round', strokeLinejoin: 'round' }),
      );
    }

    function StatRow({ label, value, title }) {
      // Two cells of the stats grid. Keys are supplied because a component that
      // returns an array is a fragment to React.
      return [
        h('div', { className: 'dkg-stat-label', key: 'label', title }, label),
        h('div', { className: 'dkg-stat-value', key: 'value' }, value),
      ];
    }

    /**
     * One metric graph: an inline SVG polyline over the shared sample ring plus a
     * dashed threshold line, drawn the way the built-in context ring is drawn —
     * stroke and points only, no chart library, no canvas, no animation loop.
     */
    function Graph({ label, valueText, level, series, threshold, thresholdLabel, note, emptyLabel }) {
      const y = thresholdY(threshold);
      return h(
        'div',
        { className: 'dkg-graph', 'data-level': level },
        h(
          'div',
          { className: 'dkg-graph-head' },
          h('span', { className: 'dkg-graph-label' }, label),
          h('span', { className: 'dkg-graph-value', 'data-level': level }, valueText),
        ),
        series.hasData
          ? h(
              'svg',
              { className: 'dkg-graph-svg', viewBox: `0 0 ${GRAPH_W} ${GRAPH_H}`, preserveAspectRatio: 'none', 'aria-hidden': true, focusable: false },
              y === null ? null : h('line', { className: 'dkg-graph-threshold', x1: 0, y1: y, x2: GRAPH_W, y2: y, strokeDasharray: '3 3' }),
              h('polyline', { className: 'dkg-graph-line', points: series.points }),
            )
          : h('p', { className: 'dkg-graph-note' }, emptyLabel),
        h('p', { className: 'dkg-graph-note' }, y === null ? note : `${note} · ${thresholdLabel}`),
      );
    }

    function BlockedCard({ described, reconnecting, onReconnect }) {
      return h(
        'div',
        { className: 'dkg-blocked', role: 'status' },
        h('span', { className: 'dkg-blocked-title' }, described.title),
        h('p', { className: 'dkg-blocked-body' }, described.body),
        h(
          'div',
          { className: 'dkg-actions' },
          h('button', { type: 'button', className: 'dkg-button', disabled: reconnecting, onClick: () => void onReconnect() }, reconnecting ? tr('connReconnecting') : tr('connReconnect')),
        ),
      );
    }

    /**
     * The compact indicator plus its detail panel. Registered in two slots, so it
     * decides its own presentation from `placement` and shares the hub with any
     * sibling cell.
     */
    function KillGuardIndicator(props) {
      const placement = props?.placement === 'dock' ? 'dock' : 'chrome';
      const [version, setVersion] = useState(0);
      const [open, setOpen] = useState(false);
      const [view, setView] = useState('overview');
      const [flashUntil, setFlashUntil] = useState(0);
      const [now, setNow] = useState(() => Date.now());
      const [chromeHeight, setChromeHeight] = useState(() => placement === 'chrome' ? readChromeHeight() : 0);
      const [copied, setCopied] = useState(false);
      const [reconnecting, setReconnecting] = useState(false);
      const anchorRef = useRef(null);
      const panelRef = useRef(null);
      const seenStops = useRef(0);
      const primed = useRef(false);

      /**
       * Accept one host snapshot. Only a stop observed while this page is open
       * flashes: the counts already in the log when the page loads are history,
       * not news. Computed in the listener rather than during render, so a render
       * never schedules another render.
       */
      const onHubChange = useCallback(() => {
        const next = currentHub().state();
        const total = stopTotal(next.snapshot);
        if (primed.current && next.snapshot?.settings?.dryRun !== true && total > seenStops.current) {
          setFlashUntil(Date.now() + FLASH_MS);
        }
        primed.current = true;
        seenStops.current = total;
        setVersion((value) => value + 1);
      }, []);

      useEffect(() => {
        const active = currentHub();
        return active.subscribe(onHubChange);
      }, [onHubChange]);

      useEffect(() => {
        const active = currentHub();
        active.setPanelOpen(placement, open);
        return () => active.setPanelOpen(placement, false);
      }, [placement, open]);

      useEffect(() => {
        if (placement !== 'chrome') return undefined;
        const onResize = () => setChromeHeight(readChromeHeight());
        window.addEventListener('resize', onResize);
        return () => window.removeEventListener('resize', onResize);
      }, [placement]);

      useEffect(() => {
        if (!open) return undefined;
        const onKeyDown = (event) => {
          if (event?.key === 'Escape') setOpen(false);
        };
        document.addEventListener('keydown', onKeyDown);
        return () => document.removeEventListener('keydown', onKeyDown);
      }, [open]);

      useEffect(() => {
        if (flashUntil <= Date.now()) return undefined;
        // A one-second redraw only while a stop is fresh; it clears itself and is
        // released by the effect cleanup on the way out.
        const timer = setInterval(() => {
          const current = Date.now();
          setNow(current);
          if (current >= flashUntil) clearInterval(timer);
        }, 1000);
        return () => clearInterval(timer);
      }, [flashUntil]);

      const state = currentHub().state();
      const snapshot = state.snapshot;
      const settings = snapshot?.settings ?? null;
      const sample = snapshot?.sample ?? null;
      const monitor = snapshot?.monitor ?? null;
      const counters = snapshot?.counters ?? null;
      const kills = Array.isArray(snapshot?.kills) ? snapshot.kills : [];
      const host = snapshot?.host ?? null;

      const connection = state.connection;
      const busy = state.pending !== null;
      const totalStops = stopTotal(snapshot);
      const alarming = flashUntil > now;
      const paused = monitor?.paused === true;
      const disabled = settings?.enabled === false;
      const armed = !disabled && monitor?.active === true;
      const cpuLevel = levelFor(sample?.cpu, settings?.cpuThreshold, 70);
      const memoryLevel = levelFor(sample?.memory, settings?.memoryThreshold, 70);
      // Only genuinely dangerous states are emphasised: a metric over its arm, or
      // a stop that just happened. A quiet machine stays quiet.
      const danger = cpuLevel === 'hot' || memoryLevel === 'hot';
      const alert = alarming || danger;
      const stateKey = paused
        ? 'statePaused'
        : disabled
          ? 'stateOff'
          : settings?.dryRun === true
            ? 'stateDry'
            : armed
              ? 'stateArmed'
              : 'stateDegraded';
      const rootState = alarming ? 'stopped' : danger ? 'breach' : paused ? 'paused' : disabled ? 'off' : armed ? 'armed' : 'degraded';
      const badgeTone = alarming || danger ? 'hot' : paused ? 'warn' : armed ? 'ok' : 'idle';
      const connectionKey = CONNECTION_KEY[connection] ?? 'connConnecting';
      const connectionTone = connection === 'live' ? 'ok' : connection === 'offline' ? 'hot' : 'warn';
      const described = describeFailure(state.failure, tr);

      // Geometry and dismissal come from the composer's own primitives, so the
      // panel tracks the indicator across scroll/resize and clamps into the
      // viewport. The hook order never changes: both are called on every render.
      const position = useAnchoredPosition({ open, anchorRef, panelRef, side: placement === 'dock' ? 'top' : 'bottom', gap: 8, margin: 12 });
      useDismissOnOutsidePointer(anchorRef, open, setOpen, panelRef);

      const act = (action) => {
        void currentHub().act(action);
      };

      const reconnect = async () => {
        setReconnecting(true);
        try {
          await currentHub().reconnect();
        } finally {
          setReconnecting(false);
        }
      };

      const copyFragment = async () => {
        try {
          if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
            await navigator.clipboard.writeText(configFragment(settings));
          }
        } catch {
          /* a refused clipboard is not worth a card of its own */
        }
        setCopied(true);
      };

      const metric = (label, value, level) =>
        h(
          'span',
          { className: 'dkg-metric' },
          h('span', { className: 'dkg-metric-label' }, label),
          h('span', { className: 'dkg-metric-value', 'data-level': level }, value),
        );

      const chip = h(
        'button',
        {
          ref: anchorRef,
          type: 'button',
          className: 'dkg-chip',
          'aria-expanded': open,
          'aria-haspopup': 'dialog',
          'aria-label': `${tr('title')} — ${tr(stateKey)}`,
          title: `${tr('title')} — ${tr('chipHint')}`,
          style: { pointerEvents: 'auto' },
          onClick: () => setOpen((value) => !value),
        },
        h(Icon, { className: 'dkg-chip-icon' }),
        h('span', { className: 'dkg-dot', 'data-state': rootState }),
        placement === 'dock' ? h('span', { className: 'dkg-state' }, tr(stateKey)) : metric(tr('labelCpu'), formatPercent(sample?.cpu), cpuLevel),
        placement === 'dock' ? null : h('span', { className: 'dkg-sep' }),
        placement === 'dock' ? null : metric(tr('labelMemory'), formatPercent(sample?.memory), memoryLevel),
        alarming ? h('span', { className: 'dkg-sep' }) : null,
        alarming ? h('span', { className: 'dkg-flash' }, tr('stopsFlash', { count: totalStops })) : null,
      );

      const tabs = h(
        'div',
        { className: 'dkg-tabs', role: 'tablist' },
        VIEWS.map((name) =>
          h(
            'button',
            {
              key: name,
              type: 'button',
              role: 'tab',
              className: 'dkg-tab',
              'data-active': view === name ? '1' : '0',
              'aria-selected': view === name,
              onClick: () => setView(name),
            },
            tr(`tab${name.charAt(0).toUpperCase()}${name.slice(1)}`),
          ),
        ),
      );

      const event = monitor?.lastEvent ?? null;
      const overview = h(
        'div',
        { className: 'dkg-view' },
        h(Graph, {
          key: 'cpu',
          label: tr('graphCpu'),
          valueText: sample?.cpu === null || sample?.cpu === undefined ? tr('valueUnavailable') : formatPercent(sample.cpu),
          level: cpuLevel,
          series: sparklinePoints(state.history, 'cpu'),
          threshold: settings?.cpuThreshold,
          thresholdLabel: `${tr('graphThresholdLine')} ${settings?.cpuThreshold > 0 ? `${settings.cpuThreshold}%` : tr('thresholdOff')}`,
          note: tr('graphWindow', { count: Math.max(state.history.length, 0) }),
          emptyLabel: tr('graphEmpty'),
        }),
        h(Graph, {
          key: 'memory',
          label: tr('graphMemory'),
          valueText: sample?.memory === null || sample?.memory === undefined ? tr('valueUnavailable') : formatPercent(sample.memory),
          level: memoryLevel,
          series: sparklinePoints(state.history, 'memory'),
          threshold: settings?.memoryThreshold,
          thresholdLabel: `${tr('graphThresholdLine')} ${settings?.memoryThreshold > 0 ? `${settings.memoryThreshold}%` : tr('thresholdOff')}`,
          note: tr('graphWindow', { count: Math.max(state.history.length, 0) }),
          emptyLabel: tr('graphEmpty'),
        }),
        h(
          'div',
          { className: 'dkg-stats' },
          h(StatRow, { key: 'state', label: tr('labelState'), value: tr(stateKey) }),
          h(StatRow, { key: 'conn', label: tr('labelConnection'), value: tr(connectionKey) }),
          h(StatRow, {
            key: 'breach',
            label: tr('labelBreaches'),
            value: `${tr('breachesOf', { count: monitor?.breachStreak ?? 0, need: monitor?.sustainSamples ?? settings?.sustainSamples ?? 1 })} · ${tr('breachesTotal', { count: monitor?.breachTotal ?? 0 })}`,
          }),
          h(StatRow, {
            key: 'stops',
            label: tr('labelStops'),
            value: `${tr('stopsTotal', { count: totalStops })}${Number(counters?.manual) > 0 ? ` · ${tr('historyManual', { count: counters.manual })}` : ''}`,
          }),
          h(StatRow, {
            key: 'updated',
            label: tr('labelUpdated'),
            value: `${formatClockTime(sample?.at)} · ${tr('updatedAgo', { age: formatAge(sample?.ageMs) })}${monitor?.cooldownRemainingMs > 0 ? ` · ${tr('cooldown', { seconds: Math.ceil(monitor.cooldownRemainingMs / 1000) })}` : ''}`,
            title: tr('pollNote', { seconds: Math.round(state.pollMs / 1000) }),
          }),
          h(StatRow, {
            key: 'event',
            label: tr('labelLatest'),
            value: event === null ? tr('never') : `${formatClockTime(event.at)} · ${event.text}`,
          }),
          h(StatRow, {
            key: 'host',
            label: tr('labelHost'),
            value: `${tr('cores', { cores: host?.cores ?? '--', memory: formatBytes(host?.totalBytes) })} · pid ${host?.pid ?? '--'}`,
          }),
          h(StatRow, { key: 'cap', label: tr('labelHistory'), value: String(monitor?.historyCap ?? 0) }),
        ),
        connection === 'suspended' ? h('p', { className: 'dkg-note' }, tr('suspended')) : null,
        h(
          'div',
          { className: 'dkg-actions' },
          h(
            'button',
            { type: 'button', className: 'dkg-button', disabled: busy || monitor?.active !== true, onClick: () => act(paused ? 'resume' : 'pause') },
            busy ? tr('actionWorking') : paused ? tr('actionResume') : tr('actionPause'),
          ),
          h(
            'button',
            {
              type: 'button',
              className: 'dkg-button',
              'data-tone': 'hot',
              disabled: busy || monitor?.active !== true,
              title: tr('actionKillNowHint'),
              onClick: () => act('kill-now'),
            },
            busy ? tr('actionWorking') : tr('actionKillNow'),
          ),
        ),
      );

      const logView = h(
        'div',
        { className: 'dkg-view' },
        h(
          'div',
          { className: 'dkg-section-head' },
          h('span', { className: 'dkg-section-label' }, `${tr('logTitle')} · ${kills.length}`),
          kills.length > 0
            ? h('button', { type: 'button', className: 'dkg-link', disabled: busy, onClick: () => act('clear-log') }, tr('logClear'))
            : null,
        ),
        kills.length > 0
          ? h(
              'ul',
              { className: 'dkg-log' },
              kills.map((entry, index) =>
                h(
                  'li',
                  { key: `${entry.at}-${entry.id}-${index}`, className: 'dkg-log-item', 'data-ok': entry.ok === false ? '0' : '1' },
                  h('span', { className: 'dkg-log-time' }, formatClockTime(entry.at)),
                  h('span', { className: 'dkg-log-kind' }, entry.kind === 'terminal' ? tr('kindTerminal') : tr('kindJob')),
                  h(
                    'span',
                    { className: 'dkg-log-label', title: `${entry.reason ?? ''}${entry.error ? ` — ${entry.error}` : ''}` },
                    `${entry.label || entry.id}${entry.dryRun === true ? ` · ${tr('stateDry')}` : ''}${entry.ok === false ? ` · ${tr('failedMark')}` : ''}`,
                  ),
                ),
              ),
            )
          : h('p', { className: 'dkg-note' }, tr('logEmpty')),
      );

      const summary = historySummary(kills, counters);
      const historyView = h(
        'div',
        { className: 'dkg-view' },
        h('span', { className: 'dkg-section-label' }, tr('historyTitle')),
        kills.length === 0
          ? h('p', { className: 'dkg-note' }, tr('historyEmpty'))
          : h(
              'ul',
              { className: 'dkg-bullets' },
              h('li', { key: 'jobs' }, tr('historyJobs', { count: summary.jobs })),
              h('li', { key: 'terminals' }, tr('historyTerminals', { count: summary.terminals })),
              summary.failed > 0 ? h('li', { key: 'failed' }, tr('historyFailed', { count: summary.failed })) : null,
              summary.dryRun > 0 ? h('li', { key: 'dry' }, tr('historyDry', { count: summary.dryRun })) : null,
              summary.manual > 0 ? h('li', { key: 'manual' }, tr('historyManual', { count: summary.manual })) : null,
              h('li', { key: 'first' }, `${tr('historyFirst')}: ${formatClockTime(summary.first)}`),
              h('li', { key: 'last' }, `${tr('historyLast')}: ${formatClockTime(summary.last)}`),
            ),
        h('p', { className: 'dkg-note' }, tr('historyNote', { cap: monitor?.historyCap ?? 0, label: tr('labelStops') })),
      );

      const rows = settingsRows(settings);
      const settingsView = h(
        'div',
        { className: 'dkg-view' },
        h('span', { className: 'dkg-section-label' }, tr('settingsTitle')),
        h('p', { className: 'dkg-note' }, tr('settingsNote')),
        h(
          'table',
          { className: 'dkg-table' },
          h('thead', null, h('tr', null, h('th', null, tr('settingsKey')), h('th', null, tr('settingsEffective')), h('th', null, tr('settingsRange')))),
          h(
            'tbody',
            null,
            rows.map((row) =>
              h(
                'tr',
                { key: row.key },
                h('td', { className: 'dkg-key' }, row.key),
                h('td', { className: 'dkg-value' }, row.value),
                h('td', { className: 'dkg-range' }, tr(row.rangeKey, row.rangeParams)),
              ),
            ),
          ),
        ),
        h(
          'div',
          { className: 'dkg-actions' },
          h('button', { type: 'button', className: 'dkg-button', onClick: () => void copyFragment() }, copied ? tr('settingsCopied') : tr('settingsCopy')),
        ),
        h('pre', { className: 'dkg-code' }, configFragment(settings)),
      );

      const body =
        view === 'log' ? logView : view === 'history' ? historyView : view === 'settings' ? settingsView : overview;

      const panel = open
        ? ReactDOM.createPortal(
            h(
              'section',
              {
                ref: panelRef,
                className: 'dkg-panel',
                role: 'dialog',
                'aria-label': tr('title'),
                'data-view': view,
                style: position ?? { visibility: 'hidden', left: 0, top: 0 },
              },
              h(
                'header',
                { className: 'dkg-head' },
                h(
                  'span',
                  { className: 'dkg-head-main' },
                  h('span', { className: 'dkg-title' }, tr('title')),
                  h('span', { className: 'dkg-subtitle' }, tr('subtitle')),
                ),
                h(
                  'span',
                  { className: 'dkg-badges' },
                  h('span', { className: 'dkg-badge', 'data-tone': badgeTone }, tr(stateKey)),
                  h('span', { className: 'dkg-badge', 'data-tone': connectionTone }, tr(connectionKey)),
                  settings?.dryRun === true ? h('span', { className: 'dkg-badge', 'data-tone': 'warn' }, tr('stateDry')) : null,
                  h('span', { className: 'dkg-badge' }, tr('stopsTotal', { count: totalStops })),
                ),
                h('button', { type: 'button', className: 'dkg-close', 'aria-label': tr('close'), onClick: () => setOpen(false) }, '×'),
              ),
              described === null ? tabs : null,
              described === null ? body : h(BlockedCard, { described, reconnecting, onReconnect: reconnect }),
              monitor?.lastError ? h('p', { className: 'dkg-error' }, `${tr('lastError')}: ${monitor.lastError}`) : null,
            ),
            document.body,
          )
        : null;

      const root = h(
        'span',
        { className: 'dkg-root', 'data-alert': alert ? '1' : '0', 'data-state': rootState, 'data-placement': placement },
        chip,
        panel,
      );

      if (placement === 'dock') return root;
      return h(
        'div',
        { className: 'dkg-chrome', 'data-float': chromeHeight > 0 ? '0' : '1', style: { height: chromeHeight > 0 ? `${chromeHeight}px` : 'auto' } },
        root,
      );
    }

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        t = ctx.locale.bind(NS);

        // A re-apply gets a fresh hub: the previous one may have been disposed by
        // its own teardown, in which case its timer and listener are already gone.
        hub.dispose();
        hub = createHub();

        ctx.effect(() => () => styleElement?.remove(), 'dsh-kill-guard.styles');

        ctx.effect(() => {
          const disposers = Object.keys(DICTS).map((locale) => ctx.locale.register(NS, locale, DICTS[locale]));
          return () => {
            for (const dispose of disposers) dispose();
          };
        }, 'dsh-kill-guard.locale');

        ctx.effect(
          () => ctx.slots.inject('conversation.composer.dock', () => ctx.slots.register(
            { name: 'conversation.composer.dock', id: ID, order: 12, locale: NS, inject: () => ({ placement: 'dock' }) },
            KillGuardIndicator,
          )),
          'dsh-kill-guard.dock',
        );

        // The page owns exactly one hub; unloading the plugin releases it.
        ctx.effect(() => () => hub.dispose(), 'dsh-kill-guard.hub');
      },
      /** Test seam: the pure helpers and the cell, so the bundle is verifiable in node. */
      __test: {
        id: ID,
        namespace: NS,
        bootstrapKey: BOOTSTRAP_KEY,
        tokenHeader: TOKEN_HEADER,
        tokenPath: TOKEN_PATH,
        pollMs: POLL_MS,
        pollSlowMs: POLL_SLOW_MS,
        historyCap: HISTORY_CAP,
        flashMs: FLASH_MS,
        dicts: DICTS,
        iconPaths: { shield: ICON_SHIELD, pulse: ICON_PULSE },
        readChromeHeight,
        readBootstrap,
        storeBootstrap,
        createApi,
        resolveApi,
        describeFailure,
        fill,
        formatPercent,
        formatBytes,
        formatClockTime,
        formatAge,
        levelFor,
        pushSample,
        sparklinePoints,
        thresholdY,
        historySummary,
        configFragment,
        settingsRows,
        createHub,
        hub: () => hub,
        resetHub,
        KillGuardIndicator,
      },
    };
  },
});

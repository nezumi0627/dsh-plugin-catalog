/**
 * Render test for the Client half of `@local/dsh-kill-guard`.
 *
 * `test-client.mjs` proves the bundle registers and its helpers are right; this
 * file proves the cell actually RENDERS and behaves: a miniature React drives
 * the real `KillGuardIndicator` through mount → poll → click → action, with hooks
 * that keep identity across renders and effects that own their cleanups the way
 * React does. Nothing about the component is re-implemented here.
 *
 * Two behaviours get a first-class proof, because §15 of the requirements makes
 * them acceptance criteria:
 *   * `document.visibilityState === 'hidden'` clears the poll timer and makes
 *     sampling impossible, even when a sample is explicitly asked for;
 *   * unmounting clears every timer, listener, and subscription the cell owns.
 *
 *   node test-render.mjs
 */
import assert from 'node:assert/strict';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// --- browser surface --------------------------------------------------------

/** Document listeners, kept so the test can prove they are removed again. */
const documentListeners = new Map();
const windowListeners = new Map();
function addTo(map, type, handler) {
  const list = map.get(type) ?? [];
  list.push(handler);
  map.set(type, list);
}
function removeFrom(map, type, handler) {
  const list = map.get(type) ?? [];
  const at = list.indexOf(handler);
  if (at !== -1) list.splice(at, 1);
}
const liveListeners = () => [...documentListeners.values()].reduce((sum, list) => sum + list.length, 0) + [...windowListeners.values()].reduce((sum, list) => sum + list.length, 0);
function dispatch(map, type, event = {}) {
  for (const handler of [...(map.get(type) ?? [])]) handler(event);
}

const body = { tag: 'body' };
globalThis.document = {
  body,
  visibilityState: 'visible',
  createElement: (tag) => ({ tag, attrs: {}, textContent: '', setAttribute(k, v) { this.attrs[k] = v; }, remove() {} }),
  head: { append: () => {} },
  documentElement: { hasAttribute: () => false, dataset: {} },
  addEventListener: (type, handler) => addTo(documentListeners, type, handler),
  removeEventListener: (type, handler) => removeFrom(documentListeners, type, handler),
};
globalThis.getComputedStyle = () => ({ getPropertyValue: (name) => (name === '--dsh-frame-chrome-top' ? '40px' : '') });

const clipboardWrites = [];
globalThis.window = {
  __DSH_AUTO_KILL__: { path: '/local/auto-kill', token: 'token-token-token-token-token-token-9' },
  addEventListener: (type, handler) => addTo(windowListeners, type, handler),
  removeEventListener: (type, handler) => removeFrom(windowListeners, type, handler),
  innerWidth: 1600,
  innerHeight: 900,
  localStorage: { getItem: () => null, setItem: () => {} },
};
// node 24 ships a getter-only `navigator`, so the stub is defined, not assigned.
Object.defineProperty(globalThis, 'navigator', {
  value: { clipboard: { writeText: async (text) => clipboardWrites.push(text) } },
  configurable: true,
  writable: true,
});

/** Every timer the cell creates, so a leak is visible as a non-zero count. */
const liveTimers = new Set();
const timerDelays = new Map();
const realSetTimeout = globalThis.setTimeout;
const realClearTimeout = globalThis.clearTimeout;
const realSetInterval = globalThis.setInterval;
const realClearInterval = globalThis.clearInterval;
globalThis.setTimeout = (fn, ms, ...args) => {
  const id = realSetTimeout((...callbackArgs) => {
    liveTimers.delete(id);
    timerDelays.delete(id);
    fn(...callbackArgs);
  }, ms, ...args);
  liveTimers.add(id);
  timerDelays.set(id, ms);
  return id;
};
globalThis.clearTimeout = (id) => {
  liveTimers.delete(id);
  timerDelays.delete(id);
  return realClearTimeout(id);
};
globalThis.setInterval = (fn, ms, ...args) => {
  const id = realSetInterval(fn, ms, ...args);
  liveTimers.add(id);
  timerDelays.set(id, ms);
  return id;
};
globalThis.clearInterval = (id) => {
  liveTimers.delete(id);
  timerDelays.delete(id);
  return realClearInterval(id);
};

const specs = [];
globalThis.window.__ModuleLoader__ = { load: (spec) => specs.push(spec) };

await import('./client.js');
const spec = specs[0];

// --- miniature React --------------------------------------------------------

function depsEqual(a, b) {
  if (a === undefined || b === undefined) return false;
  if (a.length !== b.length) return false;
  return a.every((value, index) => Object.is(value, b[index]));
}

/** Hooks forward to whichever mount is currently rendering. */
let activeHooks = null;

const ReactShim = {
  createElement(type, props, ...children) {
    const full = { ...(props ?? {}), children: children.length <= 1 ? children[0] : children };
    return typeof type === 'function' ? type(full) : { type, props: full };
  },
  useState: (initial) => activeHooks.useState(initial),
  useRef: (initial) => activeHooks.useRef(initial),
  useMemo: (fn, deps) => activeHooks.useMemo(fn, deps),
  useCallback: (fn, deps) => activeHooks.useCallback(fn, deps),
  useEffect: (fn, deps) => activeHooks.useEffect(fn, deps),
};

const portalCalls = [];
const ReactDOMShim = {
  createPortal(node, target) {
    portalCalls.push(target);
    return { type: 'portal', props: { children: node, target } };
  },
};

const anchoredCalls = [];
const dismissCalls = [];
const primitivesShim = {
  useAnchoredPosition(options) {
    anchoredCalls.push(options);
    return { left: 120, top: 24, maxHeight: 480 };
  },
  useDismissOnOutsidePointer(anchorRef, open, setOpen, panelRef) {
    dismissCalls.push({ anchorRef, open, panelRef });
  },
};

// The bundle materializes once per page, so it is materialized once here too.
const instance = spec.factory((name) => {
  if (name === 'react') return ReactShim;
  if (name === 'react-dom') return ReactDOMShim;
  if (name === '@deepseek-ai/dsh-client-ui-primitives') return primitivesShim;
  throw new Error(`unexpected require: ${name}`);
});

function createUi() {
  const slots = [];
  const effects = [];
  let cursor = 0;
  let pending = [];

  const hooks = {
    useState(initial) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = typeof initial === 'function' ? initial() : initial;
      return [slots[index], (next) => {
        slots[index] = typeof next === 'function' ? next(slots[index]) : next;
      }];
    },
    useRef(initial) {
      const index = cursor++;
      if (!(index in slots)) slots[index] = { current: initial };
      return slots[index];
    },
    useMemo(fn, deps) {
      const index = cursor++;
      const previous = slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      const value = fn();
      slots[index] = { deps, value };
      return value;
    },
    useCallback(fn, deps) {
      const index = cursor++;
      const previous = slots[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return previous.value;
      slots[index] = { deps, value: fn };
      return fn;
    },
    useEffect(fn, deps) {
      const index = cursor++;
      const previous = effects[index];
      if (previous !== undefined && depsEqual(previous.deps, deps)) return;
      pending.push({ index, deps, fn, cleanup: previous?.cleanup });
    },
  };

  return {
    /** Render (or re-render) the cell, then run its pending effects. */
    render(component, props = {}) {
      cursor = 0;
      pending = [];
      activeHooks = hooks;
      let tree;
      try {
        tree = component(props);
      } finally {
        activeHooks = null;
      }
      const toRun = pending;
      pending = [];
      for (const effect of toRun) {
        effect.cleanup?.();
        effects[effect.index] = { deps: effect.deps, fn: effect.fn, cleanup: effect.fn() ?? undefined };
      }
      return tree;
    },
    unmount() {
      for (const effect of effects) effect?.cleanup?.();
      effects.length = 0;
    },
  };
}

// --- tree helpers -----------------------------------------------------------

function text(node) {
  if (node === null || node === undefined || typeof node === 'boolean') return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  if (Array.isArray(node)) return node.map(text).join(' ');
  return text(node.props?.children);
}

function findAll(node, predicate, found = []) {
  if (node === null || node === undefined || typeof node !== 'object') return found;
  if (Array.isArray(node)) {
    for (const child of node) findAll(child, predicate, found);
    return found;
  }
  if (node.type !== undefined && predicate(node)) found.push(node);
  findAll(node.props?.children, predicate, found);
  return found;
}

const byClass = (name) => (node) => typeof node.props?.className === 'string' && node.props.className.split(/\s+/).includes(name);
const byExactButton = (label) => (node) => node.type === 'button' && text(node).trim() === label;

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// --- fixtures ---------------------------------------------------------------

const NOW = Date.now();
function snapshot(overrides = {}) {
  const base = {
    version: '2.0.0',
    at: NOW,
    settings: {
      enabled: true,
      cpuThreshold: 90,
      memoryThreshold: 90,
      intervalMs: 1500,
      sustainSamples: 2,
      cooldownMs: 15000,
      killJobs: true,
      jobKinds: ['bash', 'pwsh'],
      killTerminals: true,
      dryRun: false,
    },
    monitor: {
      active: true,
      paused: false,
      pausedReason: undefined,
      busy: false,
      ticks: 42,
      breachStreak: 1,
      sustainSamples: 2,
      cooldownRemainingMs: 0,
      lastError: undefined,
      lastKillAt: undefined,
      lastEvent: null,
      breachTotal: 3,
      historyCap: 40,
    },
    sample: { cpu: 42.3, memory: 51.2, totalBytes: 34359738368, freeBytes: 16777216000, at: NOW - 250, ageMs: 250, measured: true },
    counters: { rounds: 1, ticks: 42, jobs: 1, terminals: 0, failures: 0, dryRuns: 0, manual: 0 },
    kills: [],
    host: { platform: 'win32', arch: 'x64', cores: 16, totalBytes: 34359738368, freeBytes: 2147483648, pid: 1234, uptimeSec: 100 },
  };
  const merged = { ...base, ...overrides };
  if (overrides.monitor) merged.monitor = { ...base.monitor, ...overrides.monitor };
  if (overrides.sample) merged.sample = { ...base.sample, ...overrides.sample };
  if (overrides.counters) merged.counters = { ...base.counters, ...overrides.counters };
  if (overrides.settings) merged.settings = { ...base.settings, ...overrides.settings };
  return merged;
}

const calmSnapshot = snapshot();
const hotSnapshot = snapshot({ sample: { cpu: 93.1 } });
const stoppedSnapshot = snapshot({
  counters: { jobs: 2, terminals: 1, rounds: 3, manual: 1 },
  monitor: { lastKillAt: NOW - 1000, lastEvent: { at: NOW - 1000, kind: 'stop', tone: 'hot', text: 'auto-kill: CPU 94% ≥ 90%' } },
  sample: { cpu: 30.5 },
  kills: [
    { at: NOW - 3000, id: 'job-1', kind: 'job', label: 'ffmpeg -i a.mkv out.mp4', reason: 'auto-kill: CPU 94% ≥ 90%', ok: true },
    { at: NOW - 2000, id: 'term-2', kind: 'terminal', label: 'pwsh · workspace', reason: 'auto-kill: MEM 96% ≥ 90%', ok: true },
    { at: NOW - 1000, id: 'job-3', kind: 'job', label: 'pwsh · Get-ChildItem -Recurse', reason: 'auto-kill: CPU 99% ≥ 90%', ok: false, error: 'jobs.kill(job-3): refused' },
  ],
});

/**
 * Apply the plugin with the real Japanese dictionary bound. The bundle keeps a
 * single module-level translator, which is exactly what a page has.
 */
function applyWith(onRegister) {
  instance.apply({
    locale: {
      bind: (ns) => {
        assert.equal(ns, 'dshKillGuard');
        return (key) => instance.__test.dicts.ja[key];
      },
      register: (ns, locale, dict) => {
        if (onRegister) onRegister(ns, locale, dict);
        return () => {};
      },
    },
    slots: { inject: (_name, callback) => callback(), register: () => () => {} },
    effect: (fn) => {
      const dispose = fn();
      return typeof dispose === 'function' ? dispose : () => {};
    },
  });
}

/**
 * A fetch stub answering the token handshake and the route snapshot separately.
 * Every route call advances one step through `payloads` and then saturates on
 * the last entry, so a scripted sequence of host answers is deterministic.
 */
function routeFetch(payloads, options = {}) {
  const calls = [];
  const list = Array.isArray(payloads) ? payloads : [payloads];
  const handshake = options.handshake === undefined ? { path: '/local/auto-kill', token: 'token-token-token-token-token-token-9' } : options.handshake;
  let index = -1;
  const stub = async (url, init) => {
    calls.push({ url, init });
    if (String(url).includes('auto-kill-token')) {
      if (handshake === null) return { ok: false, status: 401, json: async () => ({ ok: false, error: 'unauthorized' }) };
      return { ok: true, status: 200, json: async () => ({ ok: true, data: handshake }) };
    }
    index = Math.min(index + 1, list.length - 1);
    return { ok: true, status: 200, json: async () => ({ ok: true, data: list[index] }) };
  };
  return { calls, stub, routeCalls: () => calls.filter((call) => !String(call.url).includes('token')) };
}

/**
 * Mount the cell and let it settle. The cell resolves its Host capability
 * asynchronously first, the poll only starts once that lands, and the answer
 * needs one more render — so a settle is: render, yield, render, yield, render.
 */
async function settle(ui, rounds = 3, props = {}) {
  ui.render(instance.__test.KillGuardIndicator, props);
  for (let round = 0; round < rounds; round += 1) {
    await sleep(20);
    ui.render(instance.__test.KillGuardIndicator, props);
  }
  return ui.render(instance.__test.KillGuardIndicator, props);
}

function cleanup() {
  instance.__test.resetHub();
  for (const id of liveTimers) {
    realClearTimeout(id);
    realClearInterval(id);
  }
  liveTimers.clear();
  timerDelays.clear();
  documentListeners.clear();
  windowListeners.clear();
  portalCalls.length = 0;
  anchoredCalls.length = 0;
  dismissCalls.length = 0;
  clipboardWrites.length = 0;
  globalThis.document.visibilityState = 'visible';
  globalThis.window.__DSH_AUTO_KILL__ = { path: '/local/auto-kill', token: 'token-token-token-token-token-token-9' };
}

// ---------------------------------------------------------------------------

test('render: the compact indicator shows real numbers and stays calm when nothing is wrong', async () => {
  cleanup();
  const ui = createUi();
  const registered = [];
  applyWith((ns, locale) => registered.push(`${ns}:${locale}`));
  assert.deepEqual(registered, ['dshKillGuard:ja', 'dshKillGuard:en', 'dshKillGuard:zh']);

  const fetcher = routeFetch([calmSnapshot]);
  globalThis.fetch = fetcher.stub;

  const first = ui.render(instance.__test.KillGuardIndicator, {});
  assert.match(text(first), /CPU/);
  assert.match(text(first), /--/, 'nothing is claimed before the first poll lands');
  assert.equal(findAll(first, byClass('dkg-chip')).length, 1);
  assert.equal(findAll(first, byClass('dkg-panel')).length, 0, 'the detail panel starts closed');

  const tree = await settle(ui);
  assert.equal(fetcher.routeCalls()[0].init.method, 'GET');
  assert.equal(fetcher.routeCalls()[0].init.headers['x-dsh-auto-kill-token'], 'token-token-token-token-token-token-9');
  assert.match(text(tree), /42\.3%/);
  assert.match(text(tree), /51\.2%/);
  assert.equal(findAll(tree, byClass('dkg-chip'))[0].props['aria-expanded'], false);
  assert.equal(findAll(tree, byClass('dkg-root'))[0].props['data-alert'], '0', 'a calm machine is not emphasized');
  assert.equal(findAll(tree, byClass('dkg-root'))[0].props['data-state'], 'armed');
  assert.equal(findAll(tree, (node) => node.props?.['data-level'] === 'hot').length, 0);
  ui.unmount();
});

test('render: clicking the compact indicator portals a positioned detail panel with the graphs', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  globalThis.fetch = routeFetch([hotSnapshot]).stub;

  let tree = await settle(ui);
  assert.equal(findAll(tree, byClass('dkg-root'))[0].props['data-alert'], '1', 'an over-threshold metric is emphasized');
  assert.equal(findAll(tree, (node) => node.props?.['data-level'] === 'hot').length > 0, true);

  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});

  const panel = findAll(tree, byClass('dkg-panel'))[0];
  assert.ok(panel, 'the panel opened');
  assert.equal(portalCalls.at(-1), body, 'the panel is portaled to document.body');
  assert.equal(panel.props.role, 'dialog');
  assert.deepEqual(panel.props.style, { left: 120, top: 24, maxHeight: 480 }, 'the geometry comes from useAnchoredPosition');
  assert.equal(anchoredCalls.at(-1).open, true);
  assert.equal(anchoredCalls.at(-1).anchorRef !== undefined, true);
  assert.equal(anchoredCalls.at(-1).panelRef !== undefined, true);
  assert.equal(dismissCalls.at(-1).open, true, 'dismissal is delegated to the shared primitive');

  const svgs = findAll(tree, (node) => node.type === 'svg' && typeof node.props?.className === 'string' && node.props.className.includes('dkg-graph-svg'));
  assert.equal(svgs.length, 2, 'one graph per metric');
  for (const svg of svgs) {
    const line = findAll(svg, (node) => node.type === 'polyline')[0];
    assert.ok(line, 'the series is an SVG polyline, not a chart library');
    assert.equal(typeof line.props.points, 'string');
    const threshold = findAll(svg, (node) => node.type === 'line')[0];
    assert.ok(threshold, 'the threshold is drawn on the graph');
    assert.equal(typeof threshold.props.strokeDasharray, 'string', 'drawn with stroke-dasharray');
  }
  assert.match(text(tree), /監視中/);
  assert.match(text(tree), /閾値超過/);
  assert.match(text(tree), /自動停止累計/);
  assert.match(text(tree), /最終更新/);
  assert.match(text(tree), /最新イベント/);
  assert.match(text(tree), /接続済み/, 'the host-communication state is shown');
  ui.unmount();
});

test('render: a stop that happens while the page is open lights the indicator and fills the log', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  // apply() replaces the hub; tune the test hub only after lifecycle setup.
  instance.__test.resetHub({ pollMs: 20, slowMs: 40 });
  const fetcher = routeFetch([calmSnapshot, calmSnapshot, calmSnapshot, stoppedSnapshot]);
  globalThis.fetch = fetcher.stub;

  let tree = await settle(ui, 3);
  assert.equal(findAll(tree, byClass('dkg-root'))[0].props['data-alert'], '0', 'stops from before the page opened are history');

  // Switch the log view, then let a stop arrive through the poll.
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  findAll(tree, byExactButton('ログ'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});

  await sleep(120);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(instance.__test.hub().state().snapshot?.counters?.jobs, 2, 'the scripted stop reached the shared snapshot');
  assert.equal(findAll(tree, byClass('dkg-root'))[0].props['data-alert'], '1', 'a fresh stop emphasizes the indicator');
  assert.match(text(tree), /停止 3 件/);
  const log = text(tree);
  assert.match(log, /ffmpeg -i a\.mkv out\.mp4/);
  assert.match(log, /pwsh · workspace/);
  assert.match(log, /失敗/);
  assert.equal(findAll(tree, byClass('dkg-log-item')).length, 3);

  const clear = findAll(tree, byExactButton('ログを消去'))[0];
  clear.props.onClick();
  await sleep(30);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  const posted = fetcher.routeCalls().filter((call) => call.init.method === 'POST');
  assert.deepEqual(posted.map((call) => JSON.parse(call.init.body).action), ['clear-log']);
  ui.unmount();
});

test('render: pause, resume, and stop-now post the legacy action names', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  // A stateful host: pause/resume genuinely flip the flag the panel reads back,
  // so the button label follows the answer instead of the click.
  const calls = [];
  let paused = false;
  let kills = 0;
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init });
    if (String(url).includes('auto-kill-token')) {
      return { ok: true, status: 200, json: async () => ({ ok: true, data: { path: '/local/auto-kill', token: 'token-token-token-token-token-token-9' } }) };
    }
    const action = init?.method === 'POST' ? JSON.parse(init.body).action : null;
    if (action === 'pause') paused = true;
    if (action === 'resume') paused = false;
    if (action === 'kill-now') kills += 1;
    const body = snapshot({ monitor: { paused }, counters: { jobs: kills, manual: kills } });
    return { ok: true, status: 200, json: async () => ({ ok: true, data: body }) };
  };

  let tree = await settle(ui);
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(findAll(tree, byExactButton('一時停止')).length, 1);

  findAll(tree, byExactButton('一時停止'))[0].props.onClick();
  await sleep(30);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(findAll(tree, byExactButton('再開')).length, 1, 'a paused host offers resume');
  assert.match(text(tree), /一時停止中/);

  findAll(tree, byExactButton('再開'))[0].props.onClick();
  await sleep(30);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(findAll(tree, byExactButton('一時停止')).length, 1, 'a resumed host offers pause again');

  findAll(tree, byExactButton('今すぐ停止'))[0].props.onClick();
  await sleep(30);
  tree = ui.render(instance.__test.KillGuardIndicator, {});

  const posted = calls.filter((call) => call.init?.method === 'POST');
  assert.deepEqual(posted.map((call) => JSON.parse(call.init.body).action), ['pause', 'resume', 'kill-now']);
  assert.equal(findAll(tree, byExactButton('今すぐ停止'))[0].props.title, instance.__test.dicts.ja.actionKillNowHint);
  assert.match(text(tree), /自動停止累計/, 'a manual stop lands in the counter the host reports');
  ui.unmount();
});

test('render: a metric the host cannot read is labelled unavailable, never zero', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  const blind = snapshot({
    sample: { cpu: null, memory: null, measured: false, ageMs: 900 },
    monitor: { lastError: 'jobs.kill is unavailable' },
  });
  globalThis.fetch = routeFetch([blind]).stub;

  let tree = await settle(ui);
  assert.equal(findAll(tree, byClass('dkg-root'))[0].props['data-alert'], '0', 'an unknown metric is not a danger signal');
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.match(text(tree), /未取得/);
  const graphValues = findAll(tree, byClass('dkg-graph-value')).map(text);
  assert.deepEqual(graphValues, ['未取得', '未取得'], 'unavailable CPU and memory render no numeric reading');
  assert.match(text(tree), /直近のエラー/);
  ui.unmount();
});

test('render: a broken handshake becomes a plain-language card with a reconnect action', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  const originalBoot = globalThis.window.__DSH_AUTO_KILL__;
  globalThis.window.__DSH_AUTO_KILL__ = undefined;

  let refuseHandshake = true;
  const calls = [];
  globalThis.fetch = async (url, init) => {
    calls.push({ url, init });
    if (String(url).includes('auto-kill-token')) {
      if (refuseHandshake) return { ok: false, status: 401, json: async () => ({ ok: false, error: 'unauthorized' }) };
      return { ok: true, status: 200, json: async () => ({ ok: true, data: { path: '/local/auto-kill', token: 'fresh-token' } }) };
    }
    return { ok: true, status: 200, json: async () => ({ ok: true, data: calmSnapshot }) };
  };

  let tree = await settle(ui);
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  const shown = text(tree);
  assert.match(shown, /ホストとの接続情報を受け取れませんでした/);
  assert.match(shown, /再接続/);
  for (const leak of ['bootstrap-missing', 'handshake-', 'route-', 'HTTP 401', 'unauthorized']) {
    assert.equal(shown.includes(leak), false, `the panel never shows \`${leak}\``);
  }

  refuseHandshake = false;
  findAll(tree, byExactButton('再接続'))[0].props.onClick();
  await sleep(60);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(globalThis.window.__DSH_AUTO_KILL__.token, 'fresh-token');
  assert.match(text(tree), /42\.3%/, 'the numbers replace the blocked card');
  assert.equal(/再接続できません|接続情報を受け取れませんでした/.test(text(tree)), false);

  ui.unmount();
  globalThis.window.__DSH_AUTO_KILL__ = originalBoot;
});

test('render: collapsed indicator backs off to 5 s and open panel uses 1 s polling', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  instance.__test.resetHub();
  globalThis.fetch = routeFetch([calmSnapshot]).stub;

  let tree = await settle(ui);
  assert.equal([...timerDelays.values()].includes(5000), true, 'collapsed chip uses at most 0.2 Hz');
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal([...timerDelays.values()].includes(1000), true, 'open panel may refresh at 1 Hz');
  ui.unmount();
});

test('render: hidden pages never sample, and the poll timer is cleared and restarted', async () => {
  cleanup();
  instance.__test.resetHub({ pollMs: 5, slowMs: 10 });
  const ui = createUi();
  applyWith();
  const fetcher = routeFetch([calmSnapshot]);
  globalThis.fetch = fetcher.stub;

  let tree = await settle(ui, 3);
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  const sampled = fetcher.routeCalls().length;
  assert.equal(sampled > 0, true, 'the visible page samples');
  assert.equal(liveTimers.size > 0, true, 'and keeps a poll timer');

  // Visibility goes hidden: the timer goes away and sampling stops dead.
  globalThis.document.visibilityState = 'hidden';
  dispatch(documentListeners, 'visibilitychange');
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(liveTimers.size, 0, 'every timer is cleared while hidden');

  const hub = instance.__test.hub();
  await hub.poll();
  assert.equal(fetcher.routeCalls().length, sampled, 'an explicit sample request while hidden fetches nothing');
  await sleep(60);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(fetcher.routeCalls().length, sampled, 'and nothing samples in the background either');
  assert.match(text(tree), /待機中/, 'the panel says why it is idle');

  // Visibility comes back: the poll resumes without a reload.
  globalThis.document.visibilityState = 'visible';
  dispatch(documentListeners, 'visibilitychange');
  await sleep(60);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(fetcher.routeCalls().length > sampled, true, 'showing the window resumes sampling');
  assert.equal(liveTimers.size > 0, true, 'and the poll timer is back');
  ui.unmount();
});

test('render: unmounting releases every timer, listener, and subscription it owns', async () => {
  cleanup();
  instance.__test.resetHub({ pollMs: 5, slowMs: 10 });
  const ui = createUi();
  applyWith();
  const fetcher = routeFetch([hotSnapshot]);
  globalThis.fetch = fetcher.stub;

  let tree = await settle(ui);
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(liveListeners() > 0, true, 'the cell listens for resize and Escape while open');
  assert.equal(liveTimers.size > 0, true);
  assert.equal(instance.__test.hub().subscriberCount(), 1);

  const sampled = fetcher.routeCalls().length;
  ui.unmount();
  assert.equal(liveTimers.size, 0, 'no timer survives the unmount');
  assert.equal(liveListeners(), 0, 'no listener survives the unmount');
  assert.equal(instance.__test.hub().subscriberCount(), 0, 'the hub is left without subscribers');

  await sleep(60);
  assert.equal(fetcher.routeCalls().length, sampled, 'nothing polls after the unmount');
});

test('render: the threshold view lists the live values and copies a paste-ready fragment', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  const tuned = snapshot({ settings: { cpuThreshold: 80, memoryThreshold: 70, intervalMs: 2000 } });
  globalThis.fetch = routeFetch([tuned]).stub;

  let tree = await settle(ui);
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  findAll(tree, byExactButton('閾値設定'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  const view = text(tree);
  assert.match(view, /80%/);
  assert.match(view, /70%/);
  assert.match(view, /2000 ms/);
  assert.match(view, /cordis\.patch\.yml/);

  findAll(tree, byExactButton('設定断片をコピー'))[0].props.onClick();
  await sleep(20);
  assert.equal(clipboardWrites.length, 1, 'the fragment really reached the clipboard');
  assert.match(clipboardWrites[0], /cpuThreshold: 80/);
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.match(text(tree), /コピーしました/);
  ui.unmount();
});

test('render: the history view summarizes the capped host log without inventing totals', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  globalThis.fetch = routeFetch([stoppedSnapshot]).stub;

  let tree = await settle(ui);
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  findAll(tree, byExactButton('履歴'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  const view = text(tree);
  assert.match(view, /自動停止履歴/);
  assert.match(view, /ジョブ 2 件/);
  assert.match(view, /ターミナル 1 件/);
  assert.match(view, /失敗 1 件/);
  assert.match(view, /手動 1 件/);
  assert.match(view, /直近 40 件/, 'the cap is stated so the capped log cannot read as the whole history');
  ui.unmount();
});

test('render: Escape closes the panel and takes its listener with it', async () => {
  cleanup();
  const ui = createUi();
  applyWith();
  globalThis.fetch = routeFetch([calmSnapshot]).stub;

  let tree = await settle(ui);
  findAll(tree, byClass('dkg-chip'))[0].props.onClick();
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(findAll(tree, byClass('dkg-panel')).length, 1);
  assert.equal((documentListeners.get('keydown') ?? []).length, 1, 'Escape is wired while the panel is open');

  dispatch(documentListeners, 'keydown', { key: 'Escape' });
  tree = ui.render(instance.__test.KillGuardIndicator, {});
  assert.equal(findAll(tree, byClass('dkg-panel')).length, 0, 'Escape closes the panel');
  assert.equal((documentListeners.get('keydown') ?? []).length, 0, 'and the listener goes with it');
  ui.unmount();
});

// ---------------------------------------------------------------------------

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`ok   ${name}`);
  } catch (error) {
    failed += 1;
    console.error(`FAIL ${name}\n${error?.stack ?? error}`);
  } finally {
    cleanup();
  }
}
console.log(`\n${results.length - failed}/${results.length} checks passed`);
if (failed > 0) process.exitCode = 1;

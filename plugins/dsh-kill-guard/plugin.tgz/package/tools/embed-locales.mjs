/**
 * Regenerate the `DICTS` block inside `client.js` from `locale/*.json`.
 *
 * Why this exists: a client bundle is served to the page as one JavaScript file
 * and cannot `require` JSON, so the dictionaries have to be *in* the bundle. The
 * JSON files stay the editable source of truth, this script copies them into the
 * bundle between the `@dicts-start` / `@dicts-end` markers, and
 * `test-client.mjs` fails if the two ever drift apart.
 *
 *   node tools/embed-locales.mjs           # rewrite client.js
 *   node tools/embed-locales.mjs --check   # fail instead of writing (CI style)
 */
import { readFileSync, writeFileSync } from 'node:fs';

const LOCALES = ['ja', 'en', 'zh'];
const START = '/* @dicts-start */';
const END = '/* @dicts-end */';

const here = new URL('..', import.meta.url);
const clientPath = new URL('client.js', here);

const dictionaries = {};
for (const locale of LOCALES) {
  dictionaries[locale] = JSON.parse(readFileSync(new URL(`locale/${locale}.json`, here), 'utf8'));
}

// The key order of `ja` is the canonical order; the other locales must agree.
const keys = Object.keys(dictionaries.ja);
for (const locale of LOCALES) {
  const own = Object.keys(dictionaries[locale]);
  if (own.length !== keys.length || keys.some((key, index) => own[index] !== key)) {
    throw new Error(`locale/${locale}.json does not cover exactly the same keys in the same order as locale/ja.json`);
  }
}

const literal = (value) => JSON.stringify(value);
const block = [
  START,
  '    const DICTS = {',
  ...LOCALES.map((locale) => {
    const entries = keys.map((key) => `      ${literal(key)}: ${literal(dictionaries[locale][key])},`);
    return [`      ${locale}: {`, ...entries, '      },'].join('\n');
  }),
  '    };',
  END,
].join('\n');

const source = readFileSync(clientPath, 'utf8');
const from = source.indexOf(START);
const to = source.indexOf(END);
if (from === -1 || to === -1 || to < from) throw new Error('client.js is missing the @dicts markers');
const next = `${source.slice(0, from)}${block}${source.slice(to + END.length)}`;

if (process.argv.includes('--check')) {
  if (next !== source) {
    console.error('client.js dictionaries are out of date: run node tools/embed-locales.mjs');
    process.exitCode = 1;
  } else {
    console.log(`dictionaries in sync (${LOCALES.length} locales, ${keys.length} keys each)`);
  }
} else {
  writeFileSync(clientPath, next);
  console.log(`embedded ${LOCALES.length} locales x ${keys.length} keys into client.js`);
}

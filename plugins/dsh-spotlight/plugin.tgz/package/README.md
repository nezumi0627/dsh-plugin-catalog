# DSH Spotlight

Open the launcher with **Ctrl+Alt+P** (Windows/Linux) or **⌘+⌥+P** (macOS). Search DSH's internal browser actions, open X/Instagram/YouTube, or search the web. The launcher uses DSH's built-in Browser sidebar through the public `sidebarRight.openTab` service and does not read browser credentials or history.

Search runs only when the user chooses a result. The launcher adds no host worker, timer, polling loop, or third-party dependency.

Checks: `node --check client.js`, `node --check index.js`, `node test-spotlight.mjs`.

export const name = 'dsh-spotlight';
export function apply(ctx) {
  ctx.logger?.info?.('[dsh-spotlight] client launcher available');
}

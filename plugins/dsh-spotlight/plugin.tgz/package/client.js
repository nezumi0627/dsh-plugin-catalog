window.__ModuleLoader__.load({
  id: '@local/dsh-spotlight',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useEffect, useRef, useState, useSyncExternalStore } = React;
    const ID = '@local/dsh-spotlight';
    const NS = 'dshSpotlight';
    const dictionaries = {
      ja: {
        label: 'Spotlight ランチャー', placeholder: '検索またはコマンドを入力', empty: '一致する項目がありません',
        search: 'Web検索', browser: 'ブラウザーを開く', x: 'X を開く', instagram: 'Instagram を開く', youtube: 'YouTube を開く', google: 'Google を開く',
        unavailable: 'DSH のブラウザーを開けません。ブラウザー機能が読み込まれているか確認してください。', hint: '↑↓で選択 · Enterで実行 · Escで閉じる',
      },
      en: {
        label: 'Spotlight launcher', placeholder: 'Search or enter a command', empty: 'No matching actions',
        search: 'Search the web', browser: 'Open browser', x: 'Open X', instagram: 'Open Instagram', youtube: 'Open YouTube', google: 'Open Google',
        unavailable: 'The DSH browser could not be opened. Check that the browser feature is loaded.', hint: '↑↓ Select · Enter Run · Esc Close',
      },
      zh: {
        label: 'Spotlight 启动器', placeholder: '搜索或输入命令', empty: '没有匹配的操作',
        search: '网页搜索', browser: '打开浏览器', x: '打开 X', instagram: '打开 Instagram', youtube: '打开 YouTube', google: '打开 Google',
        unavailable: '无法打开 DSH 浏览器，请确认浏览器功能已加载。', hint: '↑↓ 选择 · Enter 执行 · Esc 关闭',
      },
    };
    const APPS = [
      { id: 'browser', labelKey: 'browser', aliases: ['browser', 'web', 'ブラウザ', '浏览器'], url: 'https://www.google.com/' },
      { id: 'x', labelKey: 'x', aliases: ['x', 'twitter', 'エックス'], url: 'https://x.com/home' },
      { id: 'instagram', labelKey: 'instagram', aliases: ['instagram', 'insta', 'インスタ'], url: 'https://instagram.com/' },
      { id: 'youtube', labelKey: 'youtube', aliases: ['youtube', 'yt', 'ユーチューブ'], url: 'https://youtube.com/' },
      { id: 'google', labelKey: 'google', aliases: ['google', 'グーグル'], url: 'https://www.google.com/' },
    ];
    const css = `
      .dshsp-backdrop{position:fixed;inset:0;z-index:2147483000;display:flex;justify-content:center;align-items:flex-start;padding:12vh 16px 24px;background:color-mix(in srgb,var(--dsw-alias-bg-base) 62%,transparent);backdrop-filter:blur(8px);-webkit-app-region:no-drag}
      .dshsp-panel{width:min(640px,100%);max-height:min(560px,76vh);overflow:hidden;border:.5px solid var(--dsw-alias-border-l3);border-radius:var(--dsw-radius-xl);background:var(--dsw-alias-bg-layer-2);box-shadow:var(--dsw-elevation-prominent);color:var(--dsw-alias-label-primary);font:var(--dsw-font-base-14);animation:dshsp-in 145ms cubic-bezier(.16,1,.3,1) both}
      .dshsp-form{display:flex;align-items:center;gap:12px;padding:18px 20px;border-bottom:.5px solid var(--dsw-alias-border-l2)}
      .dshsp-mark{color:var(--dsw-alias-state-business-primary);font:var(--dsw-font-base-16-strong);flex:none}
      .dshsp-input{min-width:0;flex:1;border:0;outline:0;background:transparent;color:var(--dsw-alias-label-primary);font:var(--dsw-font-base-16)}.dshsp-input::placeholder{color:var(--dsw-alias-label-tertiary)}
      .dshsp-list{max-height:calc(min(560px,76vh) - 104px);overflow:auto;padding:6px}
      .dshsp-item{display:flex;align-items:center;gap:12px;width:100%;padding:10px 12px;border:0;border-radius:var(--dsw-radius-md);background:transparent;color:var(--dsw-alias-label-primary);font:inherit;text-align:left;cursor:pointer}
      .dshsp-item[aria-selected=true],.dshsp-item:hover{background:var(--dsw-alias-interactive-bg-hover)}.dshsp-item:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary)}
      .dshsp-icon{width:28px;height:28px;display:grid;place-items:center;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-state-business-primary);font:var(--dsw-font-base-16-strong);flex:none}
      .dshsp-copy{min-width:0;display:grid;gap:2px}.dshsp-title{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dshsp-sub,.dshsp-hint,.dshsp-empty{color:var(--dsw-alias-label-tertiary);font:var(--dsw-font-xxs-12)}
      .dshsp-footer{display:flex;justify-content:space-between;padding:10px 18px;border-top:.5px solid var(--dsw-alias-border-l1)}
      @keyframes dshsp-in{from{opacity:0;transform:translateY(-4px) scale(.99)}to{opacity:1;transform:translateY(0) scale(1)}}
      @media(prefers-reduced-motion:reduce){.dshsp-panel{animation:none}}
    `;
    const style = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = css;
      document.head.append(element);
      return element;
    })();

    function normalize(value) {
      return String(value ?? '').normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase().replace(/[\s\p{P}\p{S}]/gu, '');
    }

    function score(query, text) {
      const needle = normalize(query);
      if (!needle) return 1;
      const haystack = normalize(text);
      if (!haystack) return 0;
      if (haystack === needle) return 100;
      if (haystack.startsWith(needle)) return 80;
      if (haystack.includes(needle)) return 60;
      let at = 0;
      for (const char of needle) {
        at = haystack.indexOf(char, at);
        if (at < 0) return 0;
        at += 1;
      }
      return 20;
    }

    function getResults(query, t = (key) => key) {
      const text = String(query ?? '').trim();
      const results = APPS.map((app) => ({ ...app, title: t(app.labelKey), searchText: `${app.aliases.join(' ')} ${app.labelKey} ${t(app.labelKey)}`, kind: 'app' }));
      if (text) {
        results.push({ id: 'web-search', labelKey: 'search', title: t('search'), searchText: `${text} search web 検索 网页`, kind: 'search', query: text, url: `https://www.google.com/search?q=${encodeURIComponent(text)}` });
      }
      return results
        .map((item) => ({ item, score: text ? score(text, item.searchText) : item.id === 'browser' ? 100 : 0 }))
        .filter(({ item, score: rank }) => item.id === 'web-search' || rank > 0 || !text)
        .sort((a, b) => b.score - a.score || a.item.title.localeCompare(b.item.title))
        .slice(0, 8)
        .map(({ item }) => item);
    }

    function createController() {
      let snapshot = { open: false, query: '', revision: 0 };
      const listeners = new Set();
      const publish = (next) => { snapshot = next; for (const listener of listeners) listener(); };
      return {
        getSnapshot: () => snapshot,
        subscribe(listener) { listeners.add(listener); return () => listeners.delete(listener); },
        open() { publish({ open: true, query: '', revision: snapshot.revision + 1 }); },
        close() { if (snapshot.open) publish({ ...snapshot, open: false, query: '' }); },
        setQuery(query) { publish({ ...snapshot, query }); },
      };
    }

    function openBrowser(sidebarRight, item) {
      if (typeof sidebarRight?.openTab !== 'function') return false;
      try {
        sidebarRight.openTab('browser', { params: { url: item.url }, revealIfOpened: true });
        return true;
      } catch {
        return false;
      }
    }

    function Launcher({ sidebarRight, controller, t }) {
      const snapshot = useSyncExternalStore(controller.subscribe, controller.getSnapshot, controller.getSnapshot);
      const [selected, setSelected] = useState(0);
      const [error, setError] = useState('');
      const input = useRef(null);
      const results = getResults(snapshot.query, t);
      useEffect(() => {
        setSelected(0);
        setError('');
        if (snapshot.open) input.current?.focus?.();
      }, [snapshot.open, snapshot.revision, snapshot.query]);
      if (!snapshot.open) return null;

      const activate = (item) => {
        if (!openBrowser(sidebarRight, item)) {
          setError(t('unavailable'));
          return;
        }
        controller.close();
      };
      const onKeyDown = (event) => {
        if (event.key === 'Escape') { event.preventDefault(); controller.close(); }
        else if (event.key === 'ArrowDown') { event.preventDefault(); setSelected((value) => Math.min(results.length - 1, value + 1)); }
        else if (event.key === 'ArrowUp') { event.preventDefault(); setSelected((value) => Math.max(0, value - 1)); }
        else if (event.key === 'Enter' && results[selected]) { event.preventDefault(); activate(results[selected]); }
      };
      return h('div', { className: 'dshsp-backdrop', onMouseDown: (event) => { if (event.target === event.currentTarget) controller.close(); } },
        h('section', { className: 'dshsp-panel', role: 'dialog', 'aria-modal': 'true', 'aria-label': t('label'), onKeyDown },
          h('div', { className: 'dshsp-form' },
            h('span', { className: 'dshsp-mark', 'aria-hidden': 'true' }, '⌕'),
            h('input', { ref: input, className: 'dshsp-input', type: 'text', value: snapshot.query, placeholder: t('placeholder'), 'aria-label': t('placeholder'), onChange: (event) => controller.setQuery(event.target.value), autoComplete: 'off', spellCheck: false }),
            h('span', { className: 'dshsp-hint' }, '⌘K')),
          h('div', { className: 'dshsp-list', role: 'listbox', 'aria-label': t('label') },
            results.length === 0 ? h('div', { className: 'dshsp-empty', role: 'status' }, t('empty')) : results.map((item, index) => h('button', {
              key: item.id, type: 'button', className: 'dshsp-item', role: 'option', 'aria-selected': selected === index ? 'true' : 'false',
              onMouseEnter: () => setSelected(index), onClick: () => activate(item),
            }, h('span', { className: 'dshsp-icon', 'aria-hidden': 'true' }, item.kind === 'search' ? '⌕' : item.id === 'youtube' ? '▶' : item.id === 'instagram' ? '◎' : item.id === 'x' ? '𝕏' : '↗'),
            h('span', { className: 'dshsp-copy' }, h('span', { className: 'dshsp-title' }, item.title), h('span', { className: 'dshsp-sub' }, item.kind === 'search' ? item.query : item.url))))),
          h('footer', { className: 'dshsp-footer' }, error ? h('span', { role: 'status' }, error) : h('span', null, t('hint')),
            h('span', { className: 'dshsp-hint' }, 'DSH'))));
    }

    return {
      name: 'dsh-spotlight',
      inject: ['slots', 'locale', 'shortcuts', 'sidebarRight'],
      apply(ctx) {
        const controller = createController();
        ctx.effect(() => () => style?.remove(), 'dsh-spotlight.styles');
        ctx.effect(() => ctx.locale.register(NS, dictionaries), 'dsh-spotlight.locale');
        ctx.effect(() => ctx.shortcuts.register({
          id: 'dsh-spotlight.open',
          label: () => 'Spotlight',
          aliases: ['spotlight', 'launcher', 'search'],
          defaults: {
            'desktop:macos': { code: 'KeyP', modifiers: ['primary', 'alt'] },
            'desktop:windows': { code: 'KeyP', modifiers: ['primary', 'alt'] },
            'desktop:linux': { code: 'KeyP', modifiers: ['primary', 'alt'] },
            'web:macos': { code: 'KeyP', modifiers: ['primary', 'alt'] },
            'web:windows': { code: 'KeyP', modifiers: ['primary', 'alt'] },
          },
          regions: ['page', 'editable', 'terminal'],
          modals: [],
          resolve: () => ({ status: 'handled', run: controller.open }),
        }), 'dsh-spotlight.shortcut');
        ctx.effect(() => ctx.slots.inject('shell.overlay', () => ctx.slots.register({
          name: 'shell.overlay', id: ID, order: 220, inject: () => ({ sidebarRight: ctx.sidebarRight, controller }),
        }, Launcher)), 'dsh-spotlight.overlay');
      },
      __test: { ID, NS, APPS, normalize, score, getResults, createController, openBrowser, Launcher, css },
    };
  },
});

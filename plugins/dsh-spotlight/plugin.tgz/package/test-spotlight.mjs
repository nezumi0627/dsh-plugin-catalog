import assert from 'node:assert/strict';

const specs = [];
globalThis.document = {
  documentElement: { lang: 'ja' }, head: { append() {} },
  createElement: () => ({ setAttribute() {}, remove() {} }),
};
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
await import('./client.js?spotlight-test');

const React = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState: (value) => [value, () => {}],
  useEffect() {},
  useRef: (current) => ({ current }),
  useSyncExternalStore: (_subscribe, getSnapshot) => getSnapshot(),
};
const mod = specs[0].factory((name) => name === 'react' ? React : (() => { throw Error(name); })());
assert.equal(mod.__test.ID, '@local/dsh-spotlight');
assert.ok(mod.__test.score('youtube', 'YouTube 動画') > 0, 'base actions should be searched by their aliases too');
assert.ok(mod.__test.score('yt', 'YouTube yt') > 0);
assert.equal(mod.__test.getResults('deep seek')[0].id, 'web-search');
assert.equal(mod.__test.getResults('')[0].id, 'browser');

const registrations = [];
let shortcut;
let runOverlay;
const ctx = {
  slots: {
    inject: (name, register) => { assert.equal(name, 'shell.overlay'); return register(); },
    register: (spec, component) => { registrations.push({ spec, component }); return () => {}; },
  },
  locale: { register: (_namespace, dictionaries) => { assert.ok(dictionaries.ja); return () => {}; } },
  shortcuts: { register: (spec) => { shortcut = spec; return () => {}; } },
  sidebarRight: { openTab: (...args) => { runOverlay?.(...args); } },
  effect: (run) => run(),
};
mod.apply(ctx);
assert.equal(registrations.length, 1);
assert.equal(registrations[0].spec.order, 220);
assert.equal(shortcut.id, 'dsh-spotlight.open');
assert.deepEqual(shortcut.defaults['desktop:windows'], { code: 'KeyP', modifiers: ['primary', 'alt'] });
assert.equal(shortcut.resolve({ target: document.body }).status, 'handled');
console.log('PASS spotlight: fuzzy search, app actions, keyboard shortcut and overlay registration');

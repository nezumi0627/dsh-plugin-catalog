# Verification report — dsh-native-windows

## Implemented

- Wi-Fi status, visible SSIDs, saved profiles, software-radio toggle, saved-profile connect, and adapter-specific disconnect.
- Network changes validate the interface GUID; connect additionally resolves the requested name against the selected adapter's saved Windows profiles immediately before calling `WlanConnect`. The plugin never accepts or exports passwords.
- Process list shows working set and CPU percentage sampled over a bounded 300 ms two-snapshot interval, normalized across logical processors. New/short-lived processes may report unavailable. Process termination still requires confirmation and ownership/protected-process checks.
- Bluetooth lists only device-level paired PnP records and present hardware adapters. GATT service child nodes are filtered out. PnP `Status=OK` is no longer treated as a connection; live connection state is reported as unknown. Radio power and pairing actions remain unavailable in this unpackaged DSH build. See `CAPABILITIES.md`.

## Checks run

```text
node --check index.js
node --check client.js
node test-host.mjs
node test-client.mjs
node test-render.mjs
Windows PowerShell 5.1 parser: wifi.ps1, wlan-api.ps1, processes.ps1
node test-bluetooth.mjs
```

All JavaScript syntax and plugin tests pass. Tests cover exact saved-profile allowlisting, adapter scoping, invalid radio payloads, client controls, sampled CPU percentage rendering, paired-device filtering, and truthful connection-state display. Existing process-owner tests still verify that a missing/failed owner query never terminates a process.

Read-only live probes:

```text
process_snapshot count=274 cpuSamples=274
{"interfaces":[],"connected":null,"profiles":[],"available":false,"radioControl":"software-only","networks":[]}
live_bluetooth available=True adapters=1 paired=6 knownConnectionStates=0
```

The local Windows WLAN API reports no interfaces, so radio/connect/disconnect were not exercised against hardware. Bluetooth PnP exposes one present adapter and six paired device records but no trustworthy active-connection signal; no radio or pairing state was changed. The feature package is a symlinked dependency in the active profile, so workspace edits map to the registered source; DSH was not restarted and the running renderer/Host has not loaded the latest files.

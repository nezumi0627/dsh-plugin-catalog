# dsh-native-windows

Windows-only DSH settings page for Wi-Fi status/network discovery, software-radio toggling, connecting to a saved Windows Wi-Fi profile, Bluetooth device status, and bounded background-process inspection. The client calls only the authenticated `/local/native-windows` route; OS operations stay in PowerShell host scripts.

Wi-Fi radio controls affect the Windows software-radio state only; a hardware switch cannot be overridden. Connect uses an already-saved profile on the selected adapter. It does not accept or export passwords. Bluetooth lists device-level paired PnP records but marks live connection state unknown; radio power and pairing controls are unavailable in this unpackaged DSH build. Process termination requires explicit confirmation. Process CPU percentage is sampled over a short 300 ms window and normalized across logical processors; new or short-lived processes may have no sample. See [CAPABILITIES.md](./CAPABILITIES.md) before use.

The host uses built-in Windows PowerShell 5.1 / `netsh` / PnP cmdlets only. It does not install modules or request elevation. Process snapshots/PowerShell invocation are bounded, but this initial implementation spawns a bounded PowerShell command per request rather than maintaining a persistent child; polling is user-triggered only, so it does not spawn repeatedly in the background.

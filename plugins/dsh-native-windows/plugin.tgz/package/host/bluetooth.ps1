param([string]$Mode='snapshot')
$ErrorActionPreference='Stop'
if($Mode -ne 'snapshot'){throw 'Bluetooth radio control is unavailable in this desktop build'}

try{
  $all=@(Get-PnpDevice -Class Bluetooth -ErrorAction Stop)
  # PnP also returns GATT services and per-service child nodes. Only the
  # device-level BTHENUM/BTHLE records represent paired remote endpoints.
  $paired=@($all|Where-Object {$_.InstanceId -match '^(BTHENUM|BTHLE)\\DEV_' }|Select-Object -First 100|ForEach-Object{
    $present=($_.Present -eq $true)
    @{name=[string]$_.FriendlyName;instanceId=[string]$_.InstanceId;paired=$true;present=$present;status=if($present){'present'}else{'paired-not-present'};connectionState='unknown'}
  })
  $adapters=@($all|Where-Object {$_.Present -eq $true -and $_.InstanceId -match '^(USB|PCI|ACPI)\\'}|Select-Object -First 32|ForEach-Object{
    @{name=[string]$_.FriendlyName;status=[string]$_.Status;present=($_.Present -eq $true);instanceId=[string]$_.InstanceId}
  })
  @{available=(@($adapters|Where-Object {$_.present}).Count -gt 0);devices=$paired;adapters=$adapters;radioControl='unsupported';connectionState='not-exposed'}|ConvertTo-Json -Depth 4 -Compress
}catch{
  @{available=$false;devices=@();adapters=@();radioControl='unsupported';connectionState='not-exposed'}|ConvertTo-Json -Compress
}

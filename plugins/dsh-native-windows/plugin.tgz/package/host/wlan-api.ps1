$ErrorActionPreference = 'Stop'

if (-not ('DshNative.WlanApi' -as [type])) {
  $source = @'
using System;
using System.Runtime.InteropServices;

namespace DshNative {
  public enum WlanOpcode : int { RadioState = 4 }

  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct WlanInterfaceInfo {
    public Guid InterfaceGuid;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Description;
    public int State;
  }

  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct WlanProfileInfo {
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Name;
    public uint Flags;
  }

  [StructLayout(LayoutKind.Sequential)]
  public struct WlanPhyRadioState {
    public uint PhyIndex;
    public uint SoftwareRadioState;
    public uint HardwareRadioState;
  }

  [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
  public struct WlanConnectionParameters {
    public int ConnectionMode;
    [MarshalAs(UnmanagedType.LPWStr)] public string ProfileName;
    public IntPtr Ssid;
    public IntPtr DesiredBssidList;
    public int BssType;
    public uint Flags;
  }

  public static class WlanApi {
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanOpenHandle(uint clientVersion, IntPtr reserved, out uint negotiatedVersion, out IntPtr clientHandle);
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanCloseHandle(IntPtr clientHandle, IntPtr reserved);
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanEnumInterfaces(IntPtr clientHandle, IntPtr reserved, out IntPtr interfaceList);
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanGetProfileList(IntPtr clientHandle, ref Guid interfaceGuid, IntPtr reserved, out IntPtr profileList);
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanQueryInterface(IntPtr clientHandle, ref Guid interfaceGuid, WlanOpcode opcode, IntPtr reserved, out uint dataSize, out IntPtr data, out int valueType);
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanSetInterface(IntPtr clientHandle, ref Guid interfaceGuid, WlanOpcode opcode, uint dataSize, IntPtr data, IntPtr reserved);
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanConnect(IntPtr clientHandle, ref Guid interfaceGuid, ref WlanConnectionParameters parameters, IntPtr reserved);
    [DllImport("wlanapi.dll", SetLastError = true)] public static extern uint WlanDisconnect(IntPtr clientHandle, ref Guid interfaceGuid, IntPtr reserved);
    [DllImport("wlanapi.dll")] public static extern void WlanFreeMemory(IntPtr memory);
  }
}
'@
  Add-Type -TypeDefinition $source -ErrorAction Stop
}

function Assert-WlanStatus([uint32]$Status, [string]$Operation) {
  if ($Status -ne 0) { throw "$Operation failed (Windows error $Status)" }
}

function Get-WlanSnapshot {
  [uint32]$negotiated = 0
  [IntPtr]$handle = [IntPtr]::Zero
  Assert-WlanStatus ([DshNative.WlanApi]::WlanOpenHandle(2, [IntPtr]::Zero, [ref]$negotiated, [ref]$handle)) 'WLAN client open'
  [IntPtr]$interfaceList = [IntPtr]::Zero
  try {
    Assert-WlanStatus ([DshNative.WlanApi]::WlanEnumInterfaces($handle, [IntPtr]::Zero, [ref]$interfaceList)) 'WLAN interface enumeration'
    $interfaceCount = [Math]::Min([Math]::Max([Runtime.InteropServices.Marshal]::ReadInt32($interfaceList), 0), 32)
    $interfaceSize = [Runtime.InteropServices.Marshal]::SizeOf([type][DshNative.WlanInterfaceInfo])
    $interfaces = for ($i = 0; $i -lt $interfaceCount; $i++) {
      $pointer = [IntPtr]::Add($interfaceList, 8 + ($i * $interfaceSize))
      $info = [Runtime.InteropServices.Marshal]::PtrToStructure($pointer, [type][DshNative.WlanInterfaceInfo])
      $radio = $null
      [IntPtr]$radioData = [IntPtr]::Zero
      try {
        [uint32]$radioSize = 0; [int]$radioValueType = 0
        Assert-WlanStatus ([DshNative.WlanApi]::WlanQueryInterface($handle, [ref]$info.InterfaceGuid, [DshNative.WlanOpcode]::RadioState, [IntPtr]::Zero, [ref]$radioSize, [ref]$radioData, [ref]$radioValueType)) 'WLAN radio query'
        $numberOfPhys = [Math]::Min([Math]::Max([Runtime.InteropServices.Marshal]::ReadInt32($radioData), 0), 64)
        if ($radioSize -lt (4 + 12 * $numberOfPhys)) { throw 'Invalid WLAN radio-state size' }
        $phys = for ($i = 0; $i -lt $numberOfPhys; $i++) {
          [Runtime.InteropServices.Marshal]::PtrToStructure([IntPtr]::Add($radioData, 4 + 12 * $i), [type][DshNative.WlanPhyRadioState])
        }
        $radio = @{
          softwareOn = ($phys.Count -gt 0 -and @($phys | Where-Object { $_.SoftwareRadioState -eq 0 }).Count -eq 0)
          hardwareOn = ($phys.Count -gt 0 -and @($phys | Where-Object { $_.HardwareRadioState -eq 0 }).Count -eq 0)
          physicalLayers = $phys.Count
        }
      } catch { $radio = $null }
      finally { if ($radioData -ne [IntPtr]::Zero) { [DshNative.WlanApi]::WlanFreeMemory($radioData) } }
      @{ id = $info.InterfaceGuid.ToString('B'); name = $info.Description; state = [int]$info.State; radio = $radio }
    }
    $profiles = @()
    foreach ($item in $interfaces) {
      $guid = [Guid]$item.id
      [IntPtr]$profileList = [IntPtr]::Zero
      try {
        $status = [DshNative.WlanApi]::WlanGetProfileList($handle, [ref]$guid, [IntPtr]::Zero, [ref]$profileList)
        if ($status -ne 0) { continue }
        $count = [Math]::Min([Math]::Max([Runtime.InteropServices.Marshal]::ReadInt32($profileList), 0), 256)
        $size = [Runtime.InteropServices.Marshal]::SizeOf([type][DshNative.WlanProfileInfo])
        for ($i = 0; $i -lt $count; $i++) {
          $profile = [Runtime.InteropServices.Marshal]::PtrToStructure([IntPtr]::Add($profileList, 8 + ($i * $size)), [type][DshNative.WlanProfileInfo])
          if (-not [string]::IsNullOrWhiteSpace($profile.Name)) { $profiles += @{ name = $profile.Name; interfaceId = $item.id } }
        }
      } finally { if ($profileList -ne [IntPtr]::Zero) { [DshNative.WlanApi]::WlanFreeMemory($profileList) } }
    }
    return @{ interfaces = @($interfaces); profiles = @($profiles | Select-Object -First 256) }
  } finally {
    if ($interfaceList -ne [IntPtr]::Zero) { [DshNative.WlanApi]::WlanFreeMemory($interfaceList) }
    [void][DshNative.WlanApi]::WlanCloseHandle($handle, [IntPtr]::Zero)
  }
}

function Set-WlanSoftwareRadio([string]$InterfaceId, [bool]$Enabled) {
  $snapshot = Get-WlanSnapshot
  $selected = @($snapshot.interfaces | Where-Object { $_.id -ieq $InterfaceId })
  if ($selected.Count -ne 1) { throw 'Wi-Fi interface is unavailable' }
  $guid = [Guid]$selected[0].id
  [uint32]$negotiated = 0; [IntPtr]$handle = [IntPtr]::Zero
  Assert-WlanStatus ([DshNative.WlanApi]::WlanOpenHandle(2, [IntPtr]::Zero, [ref]$negotiated, [ref]$handle)) 'WLAN client open'
  [IntPtr]$radioData = [IntPtr]::Zero
  try {
    [uint32]$radioSize = 0; [int]$valueType = 0
    Assert-WlanStatus ([DshNative.WlanApi]::WlanQueryInterface($handle, [ref]$guid, [DshNative.WlanOpcode]::RadioState, [IntPtr]::Zero, [ref]$radioSize, [ref]$radioData, [ref]$valueType)) 'WLAN radio query'
    $count = [Math]::Min([Math]::Max([Runtime.InteropServices.Marshal]::ReadInt32($radioData), 0), 64)
    if ($radioSize -lt (4 + 12 * $count)) { throw 'Invalid WLAN radio-state size' }
    if ($count -lt 1) { throw 'No controllable Wi-Fi radio was found' }
    $phySize = [Runtime.InteropServices.Marshal]::SizeOf([type][DshNative.WlanPhyRadioState])
    for ($i = 0; $i -lt $count; $i++) {
      $phy = [Runtime.InteropServices.Marshal]::PtrToStructure([IntPtr]::Add($radioData, 4 + 12 * $i), [type][DshNative.WlanPhyRadioState])
      if ($Enabled -and $phy.HardwareRadioState -eq 0) { continue }
      $phy.SoftwareRadioState = if ($Enabled) { 1 } else { 0 }
      $data = [Runtime.InteropServices.Marshal]::AllocHGlobal($phySize)
      try {
        [Runtime.InteropServices.Marshal]::StructureToPtr($phy, $data, $false)
        Assert-WlanStatus ([DshNative.WlanApi]::WlanSetInterface($handle, [ref]$guid, [DshNative.WlanOpcode]::RadioState, [uint32]$phySize, $data, [IntPtr]::Zero)) 'WLAN radio change'
      } finally { [Runtime.InteropServices.Marshal]::FreeHGlobal($data) }
    }
    return @{ ok = $true; interfaceId = $InterfaceId; enabled = $Enabled }
  } finally {
    if ($radioData -ne [IntPtr]::Zero) { [DshNative.WlanApi]::WlanFreeMemory($radioData) }
    [void][DshNative.WlanApi]::WlanCloseHandle($handle, [IntPtr]::Zero)
  }
}

function Invoke-WlanConnectSavedProfile([string]$InterfaceId, [string]$ProfileName) {
  $snapshot = Get-WlanSnapshot
  $selected = @($snapshot.profiles | Where-Object { $_.interfaceId -ieq $InterfaceId -and $_.name -ceq $ProfileName })
  if ($selected.Count -ne 1) { throw 'Saved Wi-Fi profile is unavailable' }
  $guid = [Guid]$selected[0].interfaceId
  [uint32]$negotiated = 0; [IntPtr]$handle = [IntPtr]::Zero
  Assert-WlanStatus ([DshNative.WlanApi]::WlanOpenHandle(2, [IntPtr]::Zero, [ref]$negotiated, [ref]$handle)) 'WLAN client open'
  try {
    $parameters = New-Object DshNative.WlanConnectionParameters
    $parameters.ConnectionMode = 0
    $parameters.ProfileName = $selected[0].name
    $parameters.Ssid = [IntPtr]::Zero
    $parameters.DesiredBssidList = [IntPtr]::Zero
    $parameters.BssType = 3
    $parameters.Flags = 0
    Assert-WlanStatus ([DshNative.WlanApi]::WlanConnect($handle, [ref]$guid, [ref]$parameters, [IntPtr]::Zero)) 'WLAN connection request'
    return @{ ok = $true; interfaceId = $InterfaceId; profileName = $selected[0].name; state = 'connecting' }
  } finally { [void][DshNative.WlanApi]::WlanCloseHandle($handle, [IntPtr]::Zero) }
}

function Disconnect-WlanInterface([string]$InterfaceId) {
  $snapshot = Get-WlanSnapshot
  $selected = @($snapshot.interfaces | Where-Object { $_.id -ieq $InterfaceId })
  if ($selected.Count -ne 1) { throw 'Wi-Fi interface is unavailable' }
  $guid = [Guid]$selected[0].id
  [uint32]$negotiated = 0; [IntPtr]$handle = [IntPtr]::Zero
  Assert-WlanStatus ([DshNative.WlanApi]::WlanOpenHandle(2, [IntPtr]::Zero, [ref]$negotiated, [ref]$handle)) 'WLAN client open'
  try {
    Assert-WlanStatus ([DshNative.WlanApi]::WlanDisconnect($handle, [ref]$guid, [IntPtr]::Zero)) 'WLAN disconnect'
    return @{ ok = $true; interfaceId = $InterfaceId }
  } finally { [void][DshNative.WlanApi]::WlanCloseHandle($handle, [IntPtr]::Zero) }
}

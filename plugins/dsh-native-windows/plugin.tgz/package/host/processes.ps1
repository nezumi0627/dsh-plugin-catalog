param([string]$Mode='list',[string]$PidText='')
$ErrorActionPreference='Stop'
if($Mode -eq 'list'){
  # A short, bounded two-sample window turns process CPU time into a real
  # normalized percentage without a long-lived watcher or performance-counter
  # service. Processes that start/change during the window report null.
  $before=Get-Process -ErrorAction Stop
  $previous=@{}
  foreach($p in $before){
    try{$previous[[int]$p.Id]=[pscustomobject]@{name=[string]$p.ProcessName;cpu=[double]$p.CPU}}catch{}
  }
  $timer=[Diagnostics.Stopwatch]::StartNew()
  Start-Sleep -Milliseconds 300
  $after=Get-Process -ErrorAction Stop | Select-Object -First 500
  $timer.Stop()
  $elapsed=[Math]::Max($timer.Elapsed.TotalSeconds,0.001)
  $logicalProcessors=[Math]::Max([Environment]::ProcessorCount,1)
  $rows=foreach($p in $after){
    $cpuSeconds=$null;$cpuPercent=$null
    try{
      $cpuSeconds=[double]$p.CPU
      $prior=$previous[[int]$p.Id]
      if($null -ne $prior -and $prior.name -eq [string]$p.ProcessName -and $cpuSeconds -ge $prior.cpu){
        $cpuPercent=[Math]::Round([Math]::Min(100,[Math]::Max(0,(($cpuSeconds-$prior.cpu)/$elapsed/$logicalProcessors)*100)),1)
      }
    }catch{}
    [pscustomobject]@{Id=[int]$p.Id;ProcessName=[string]$p.ProcessName;WorkingSet64=[long]$p.WorkingSet64;CPU=$cpuSeconds;CpuPercent=$cpuPercent}
  }
  @($rows)|ConvertTo-Json -Depth 3 -Compress
}elseif($Mode -eq 'terminate'){
  $id=0;if(-not [int]::TryParse($PidText,[ref]$id)-or$id -lt 1){throw 'invalid-pid'}
  $p=Get-Process -Id $id -ErrorAction Stop;$name=$p.ProcessName.ToLowerInvariant()
  $deny=@('system','idle','csrss','wininit','winlogon','services','lsass','smss','svchost','explorer','dwm','fontdrvhost','registry','memory compression','powershell','pwsh','node')
  if($deny -contains $name){throw 'protected-process'}
  try{
    $ownerProcess=Get-CimInstance Win32_Process -Filter "ProcessId=$id" -ErrorAction Stop
    if(-not $ownerProcess){throw 'owner query returned no process'}
    $owner=$ownerProcess.GetOwner()
    if(-not $owner-or[string]::IsNullOrWhiteSpace([string]$owner.User)-or[string]::IsNullOrWhiteSpace([string]$owner.Domain)){throw 'owner query returned incomplete identity'}
    $current=[Security.Principal.WindowsIdentity]::GetCurrent().Name
    if("$($owner.Domain)\$($owner.User)" -ne $current){throw 'process belongs to another user'}
  }catch{if($_.Exception.Message -eq 'process belongs to another user'){throw};throw 'process-owner-unavailable'}
  $confirmed=Get-Process -Id $id -ErrorAction Stop
  if($confirmed.ProcessName -ne $p.ProcessName-or$confirmed.StartTime -ne $p.StartTime){throw 'process-changed-before-termination'}
  Stop-Process -Id $id -ErrorAction Stop;@{ok=$true;pid=$id;name=$confirmed.ProcessName}|ConvertTo-Json -Compress
}else{throw 'unsupported mode'}

$caps = @(
  @{name='wifi.status.scan';status='supported-with-caveat';command='WlanEnumInterfaces/WlanQueryInterface; netsh wlan show networks mode=bssid';elevation=$false},
  @{name='wifi.disconnect';status='supported-with-caveat';command='WlanDisconnect with validated interface GUID';elevation=$false},
  @{name='wifi.connect';status='supported-with-caveat';command='WlanConnect using a revalidated saved profile only; asynchronous';elevation=$false},
  @{name='wifi.radio';status='supported-with-caveat';command='WlanQueryInterface/WlanSetInterface software radio only';elevation=$false},
  @{name='bluetooth.devices';status='supported-with-caveat';command='Get-PnpDevice -Class Bluetooth';elevation=$false},
  @{name='bluetooth.radio';status='unsupported';command='Windows.Devices.Radios.Radio WinRT not verified';elevation=$true},
  @{name='bluetooth.pair-connect';status='unsupported';command='No supported CLI';elevation=$false},
  @{name='processes.list';status='supported';command='Get-Process';elevation=$false},
  @{name='processes.terminate';status='supported-with-caveat';command='Stop-Process -Id after explicit confirmation and denylist checks';elevation=$false}
)
foreach($cap in $caps){$cap|ConvertTo-Json -Compress}

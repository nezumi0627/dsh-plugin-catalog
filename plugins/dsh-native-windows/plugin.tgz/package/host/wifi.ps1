param(
  [ValidateSet('snapshot', 'disconnect', 'radio', 'connect')]
  [string]$Mode = 'snapshot',
  [string]$InterfaceId = '',
  [string]$Value = ''
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'wlan-api.ps1')

function Get-WifiDisplaySnapshot {
  $native = Get-WlanSnapshot
  $interfaces = @($native.interfaces)
  $profiles = @($native.profiles)
  $items = @()
  $connected = $null

  try {
    $interfaceText = @(& netsh.exe wlan show interfaces 2>$null)
    $interfaceExit = $LASTEXITCODE
    if ($interfaceExit -eq 0) {
      $ssid = $null; $state = $null; $signal = $null
      foreach ($line in $interfaceText) {
        if ($line -match '^\s*SSID\s*:\s*(.+)$') { $ssid = $Matches[1].Trim() }
        elseif ($line -match '^\s*(State|状態)\s*:\s*(.+)$') { $state = $Matches[2].Trim() }
        elseif ($line -match '^\s*(Signal|シグナル)\s*:\s*(\d+)%') { $signal = [int]$Matches[2] }
      }
      if ($ssid -and $state -match 'connected|接続済み') { $connected = @{ ssid = $ssid; signal = $signal; state = $state } }
    }
  } catch { }

  try {
    $networkText = @(& netsh.exe wlan show networks mode=bssid 2>$null)
    if ($LASTEXITCODE -eq 0) {
      $connectedSsid = if ($null -ne $connected) { $connected.ssid } else { $null }
      $current = $null
      foreach ($line in $networkText) {
        if ($line -match '^\s*SSID\s+\d+\s*:\s*(.*)$') {
          if ($current) { $items += $current }
          $current = @{ ssid = $Matches[1].Trim(); signal = $null; connected = ($Matches[1].Trim() -eq $connectedSsid) }
        } elseif ($current -and $line -match '^\s*(Signal|シグナル)\s*:\s*(\d+)%') {
          $strength = [int]$Matches[2]
          if ($current.signal -eq $null -or $strength -gt $current.signal) { $current.signal = $strength }
        }
      }
      if ($current) { $items += $current }
    }
  } catch { }

  return @{
    available = ($interfaces.Count -gt 0)
    networks = @($items | Where-Object { $_.ssid } | Select-Object -First 100)
    connected = $connected
    interfaces = @($interfaces | Select-Object -First 32)
    profiles = @($profiles | Select-Object -First 256)
    radioControl = 'software-only'
  }
}

switch ($Mode) {
  'snapshot' {
    Get-WifiDisplaySnapshot | ConvertTo-Json -Depth 6 -Compress
  }
  'disconnect' {
    $snapshot = Get-WlanSnapshot
    if ([string]::IsNullOrWhiteSpace($InterfaceId)) {
      $selected = @($snapshot.interfaces | Where-Object { $_.state -eq 1 } | Select-Object -First 1)
      if ($selected.Count -eq 0) { $selected = @($snapshot.interfaces | Select-Object -First 1) }
      if ($selected.Count -eq 0) { throw 'Wi-Fi interface is unavailable' }
      $InterfaceId = $selected[0].id
    }
    Disconnect-WlanInterface -InterfaceId $InterfaceId | ConvertTo-Json -Compress
  }
  'radio' {
    if ($InterfaceId -notmatch '^\{[0-9a-fA-F-]{36}\}$' -or $Value -notin @('on', 'off')) { throw 'invalid-radio-request' }
    Set-WlanSoftwareRadio -InterfaceId $InterfaceId -Enabled ($Value -eq 'on') | ConvertTo-Json -Compress
  }
  'connect' {
    if ($InterfaceId -notmatch '^\{[0-9a-fA-F-]{36}\}$' -or [string]::IsNullOrWhiteSpace($Value) -or $Value.Length -gt 256 -or $Value -match '[\x00-\x1f\x7f]') { throw 'invalid-connect-request' }
    Invoke-WlanConnectSavedProfile -InterfaceId $InterfaceId -ProfileName $Value | ConvertTo-Json -Compress
  }
}

import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const script = fileURLToPath(new URL('./host/bluetooth.ps1', import.meta.url));
const invoke = (mode = 'snapshot') => {
  const escaped = script.replaceAll("'", "''");
  const command = `
function Get-PnpDevice {
  [CmdletBinding()] param([string]$Class)
  @(
    [pscustomobject]@{FriendlyName='USB Bluetooth Adapter';InstanceId='USB\\VID_1234\\RADIO';Status='OK';Present=$true},
    [pscustomobject]@{FriendlyName='Headphones';InstanceId='BTHENUM\\DEV_0123456789AB\\PAIR';Status='Unknown';Present=$false},
    [pscustomobject]@{FriendlyName='Phone';InstanceId='BTHLE\\DEV_0123456789AB\\PAIR';Status='OK';Present=$true},
    [pscustomobject]@{FriendlyName='GATT Service';InstanceId='BTHLEDEVICE\\{service}';Status='Unknown';Present=$false}
  )
}
try { . '${escaped}' -Mode '${mode}' } catch { 'ERROR=' + $_.Exception.Message }
`;
  return execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', command], { encoding: 'utf8' }).trim();
};

const snapshot = JSON.parse(invoke());
assert.equal(snapshot.available, true);
assert.equal(snapshot.adapters.length, 1, 'only present hardware adapters are listed');
assert.equal(snapshot.devices.length, 2, 'GATT service child nodes are not shown as paired devices');
assert.ok(snapshot.devices.every(device => device.paired === true));
assert.ok(snapshot.devices.every(device => device.connectionState === 'unknown'));
assert.ok(snapshot.devices.every(device => !Object.hasOwn(device, 'connected')), 'PnP OK must not be misreported as an active connection');
assert.match(invoke('radio'), /ERROR=Bluetooth radio control is unavailable/);
console.log('bluetooth tests: paired-device filtering, adapter presence and honest unknown connection state passed');

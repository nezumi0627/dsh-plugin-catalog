window.__ModuleLoader__.load({ id: '@local/dsh-native-windows', factory(require) {
  const React = require('react');
  const h = React.createElement;
  const { useEffect, useState } = React;
  const NS = 'dshNativeWindows';
  const ID = '@local/dsh-native-windows';
  const css = `.dnw{padding:16px;color:var(--dsw-alias-label-primary);font:var(--dsw-font-base-16)}.dnw section{margin:12px 0;padding:12px;background:var(--dsw-alias-bg-layer-1);border:1px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg)}.dnw button,.dnw input{font:inherit;color:inherit;background:var(--dsw-alias-bg-layer-2);border:1px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-sm);padding:6px}.dnw button:disabled{opacity:.55;cursor:not-allowed}.dnw li{padding:4px}.dnw .muted{color:var(--dsw-alias-label-secondary)}.dnw .wifi-device{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:8px 0;border-bottom:1px solid var(--dsw-alias-border-l1)}.dnw .wifi-device:last-child{border-bottom:0}.dnw .wifi-profiles{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}@media(max-width:480px){.dnw .wifi-device{align-items:flex-start;flex-direction:column}}@media(prefers-reduced-motion:reduce){.dnw *{scroll-behavior:auto!important;transition:none!important}}`;
  const style = typeof document === 'undefined' ? null : document.createElement('style');
  if (style) { style.setAttribute('data-plugin-css', ID); style.textContent = css; document.head.append(style); }
  const dict = {
    ja: { title: 'Windows ネイティブ', refresh: '更新', wifi: 'Wi-Fi', bt: 'Bluetooth', apps: 'バックグラウンドアプリ', unavailable: '未取得 / 非対応', terminate: '終了', confirm: 'このアプリを終了しますか？', search: '検索', unsupported: 'この操作はこの Windows API では利用できません。', radioOn: 'Wi-Fiをオン', radioOff: 'Wi-Fiをオフ', profiles: '保存済みネットワーク', connect: '接続', disconnect: '切断', noAdapter: 'Wi-Fiアダプターが見つかりません', connected: '接続済み', hardwareOff: 'ハードウェアスイッチでオフ', paired: 'ペア済み', present: '検出中', notPresent: '現在未検出', connectionUnknown: '接続状態は取得できません', noBluetooth: 'ペア済みデバイスはありません', radioUnsupported: 'Bluetooth無線の電源切替はこのDSH配布形式では利用できません' },
    en: { title: 'Windows native', refresh: 'Refresh', wifi: 'Wi-Fi', bt: 'Bluetooth', apps: 'Background apps', unavailable: 'Unavailable / unsupported', terminate: 'End process', confirm: 'End this app?', search: 'Search', unsupported: 'This operation is not available through the supported Windows API.', radioOn: 'Turn Wi-Fi on', radioOff: 'Turn Wi-Fi off', profiles: 'Saved networks', connect: 'Connect', disconnect: 'Disconnect', noAdapter: 'No Wi-Fi adapter found', connected: 'Connected', hardwareOff: 'Disabled by hardware switch', paired: 'Paired', present: 'Present', notPresent: 'Not currently present', connectionUnknown: 'Connection state unavailable', noBluetooth: 'No paired devices', radioUnsupported: 'Bluetooth radio power control is unavailable in this DSH package type' },
  };
  let t = key => dict.en[key] || key;

  async function request(action, params) {
    let boot = window.__DSH_NATIVE_WINDOWS__;
    if (!boot) {
      const response = await fetch('/local/native-windows-token', { credentials: 'same-origin', cache: 'no-store' });
      const result = await response.json();
      if (!response.ok || !result.ok) throw Error('Host unavailable');
      boot = result.data;
      window.__DSH_NATIVE_WINDOWS__ = boot;
    }
    const response = await fetch(boot.path, {
      method: action ? 'POST' : 'GET',
      headers: { 'x-dsh-native-windows-token': boot.token, ...(action ? { 'content-type': 'application/json' } : {}) },
      body: action ? JSON.stringify({ action, params }) : undefined,
      cache: 'no-store',
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw Error(result.error || 'Request failed');
    return result.data;
  }

  function Page() {
    const [data, setData] = useState(null);
    const [error, setError] = useState('');
    const [query, setQuery] = useState('');
    const [confirm, setConfirm] = useState(null);
    const [busy, setBusy] = useState('');
    const load = () => request().then(value => { setData(value); setError(''); }).catch(() => setError('Windows情報を取得できません。更新して再試行してください。'));
    const perform = async (key, action, params) => {
      setBusy(key);
      try { await request(action, params); await load(); }
      catch { setError('操作を完了できませんでした。権限、アダプター、保存済みネットワークを確認してください。'); }
      finally { setBusy(''); }
    };
    useEffect(() => { load(); }, []);
    const processes = (data?.processes || []).filter(p => p.name.toLowerCase().includes(query.toLowerCase())).sort((a, b) => a.name.localeCompare(b.name));
    const wifi = data?.wifi;
    const bluetooth = data?.bluetooth;
    const wifiPanel = !wifi?.available
      ? h('p', { className: 'muted', role: 'status' }, t('noAdapter'))
      : h('div', null,
        h('p', null, `SSID: ${wifi.connected?.ssid || t('unavailable')}`),
        h('ul', { 'aria-live': 'polite' }, (wifi.networks || []).map((network, index) => h('li', { key: `${network.ssid}-${index}` }, `${network.ssid} · ${network.signal == null ? t('unavailable') : `${network.signal}%`}${network.connected ? ` · ${t('connected')}` : ''}`))),
        h('h3', null, t('profiles')),
        ...(wifi.interfaces || []).map(adapter => {
          const profiles = (wifi.profiles || []).filter(profile => profile.interfaceId?.toLowerCase() === adapter.id.toLowerCase());
          const radio = adapter.radio;
          return h('div', { className: 'wifi-device', key: adapter.id },
            h('div', null, h('strong', null, adapter.name), h('div', { className: 'muted' }, radio ? `${t('wifi')}: ${radio.softwareOn ? 'On' : 'Off'}${radio.hardwareOn ? '' : ` · ${t('hardwareOff')}`}` : t('unavailable')),
              h('div', { className: 'wifi-profiles' }, ...profiles.map(profile => h('button', { key: `${adapter.id}:${profile.name}`, type: 'button', disabled: busy !== '', onClick: () => perform(`connect:${adapter.id}:${profile.name}`, 'wifi-connect', { interfaceId: adapter.id, profileName: profile.name }) }, `${t('connect')} · ${profile.name}`))),
            ),
            h('div', null,
              h('button', { type: 'button', disabled: busy !== '' || !radio || (!radio.hardwareOn && !radio.softwareOn), 'aria-label': radio?.softwareOn ? t('radioOff') : t('radioOn'), onClick: () => perform(`radio:${adapter.id}`, 'wifi-radio', { interfaceId: adapter.id, enabled: !radio?.softwareOn }) }, radio?.softwareOn ? t('radioOff') : t('radioOn')),
              h('button', { type: 'button', disabled: busy !== '' || adapter.state !== 1, onClick: () => perform(`disconnect:${adapter.id}`, 'wifi-disconnect', { interfaceId: adapter.id }) }, t('disconnect'))));
        }));
    return h('main', { className: 'dnw' },
      h('h1', null, t('title')),
      h('button', { type: 'button', onClick: load }, t('refresh')),
      error && h('p', { role: 'status' }, error),
      h('section', null, h('h2', null, t('wifi')), wifiPanel),
      h('section', null, h('h2', null, t('bt')),
        h('p', { className: 'muted' }, t('radioUnsupported')),
        ...(bluetooth?.adapters || []).map((adapter, index) => h('p', { className: 'muted', key: `bt-adapter-${index}` }, `${adapter.name}: ${adapter.present ? t('present') : t('notPresent')}`)),
        (bluetooth?.devices || []).length ? h('ul', null, ...bluetooth.devices.map((device, index) => h('li', { key: device.instanceId || index }, `${device.name || device.instanceId} · ${t('paired')} · ${device.present ? t('present') : t('notPresent')} · ${t('connectionUnknown')}`))) : h('p', { className: 'muted' }, t('noBluetooth'))),
      h('section', null, h('h2', null, t('apps')), h('input', { value: query, onChange: event => setQuery(event.target.value), placeholder: t('search'), 'aria-label': t('search') }),
        h('ul', null, ...processes.map(process => h('li', { key: process.pid }, `${process.name} · PID ${process.pid} · RAM ${process.memoryBytes == null ? t('unavailable') : `${Math.round(process.memoryBytes / 1048576)} MB`} · CPU ${process.cpuPercent == null ? t('unavailable') : `${process.cpuPercent.toFixed(1)}%`} `, h('button', { type: 'button', onClick: () => setConfirm(process) }, t('terminate'))))),
        confirm && h('div', { role: 'dialog', 'aria-modal': 'true' }, h('p', null, `${t('confirm')} ${confirm.name} (PID ${confirm.pid})`), h('button', { type: 'button', onClick: () => { perform(`terminate:${confirm.pid}`, 'terminate', { pid: confirm.pid, name: confirm.name }); setConfirm(null); } }, t('terminate')), h('button', { type: 'button', onClick: () => setConfirm(null) }, 'Cancel'))));
  }

  return {
    name: 'dsh-native-windows', inject: ['slots', 'locale'],
    apply(ctx) {
      ctx.effect(() => () => style?.remove(), 'native-windows.styles');
      ctx.effect(() => ctx.locale.register(NS, { ja: dict.ja, en: dict.en }), 'native-windows.locale');
      ctx.effect(() => ctx.slots.inject('settings.section', () => ctx.slots.register({ name: 'settings.section', id: 'native-windows', order: 80, label: () => t('title'), locale: NS, inject: () => ({}) }, Page)), 'native-windows.page');
    },
    __test: { Page, request, dict, id: ID, ns: NS },
  };
}});

import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { execFileSync } from 'node:child_process';
import { authorized, createRouteHandler, parseWifi, parseProcesses, isProtectedProcess, normalizeWifiProfileName, normalizeWifiRadioRequest, resolveSavedWifiProfile, createWifiActions } from './index.js';

function response(){ return { status:0, headers:{}, body:'', writeHead(s,h){this.status=s;this.headers=h;}, end(b){this.body=b??'';} }; }
function req(method='GET', token='secret', body=''){ const r=new EventEmitter(); r.method=method;r.headers={'x-dsh-native-windows-token':token};queueMicrotask(()=>{ if(body)r.emit('data',Buffer.from(body));r.emit('end');});return r; }
assert.equal(authorized({headers:{'sec-fetch-site':'cross-site','x-dsh-native-windows-token':'secret'}},'secret'),false);
assert.deepEqual(parseWifi('    SSID                   : Home\n    Signal                 : 87%\n    State                  : connected\n'),[{ssid:'Home',signal:87,connected:true}]);
assert.equal(parseProcesses('[{"Id":12,"ProcessName":"demo","WorkingSet64":2048,"CPU":null}]')[0].cpuSeconds,null);
assert.deepEqual(parseProcesses('[{"Id":13,"ProcessName":"busy","WorkingSet64":4096,"CPU":2.5,"CpuPercent":18.25}]')[0],{pid:13,name:'busy',memoryBytes:4096,cpuSeconds:2.5,cpuPercent:18.25});
assert.equal(isProtectedProcess({name:'svchost',pid:4}),true);
assert.equal(normalizeWifiProfileName(' Home Wi-Fi '),'Home Wi-Fi');
assert.equal(normalizeWifiProfileName('  '),null);
assert.equal(normalizeWifiProfileName('home\nnet'),null,'profile names cannot carry control characters');
assert.deepEqual(normalizeWifiRadioRequest({interfaceId:'{00000000-0000-0000-0000-000000000001}',enabled:false}),{interfaceId:'{00000000-0000-0000-0000-000000000001}',enabled:false});
assert.equal(normalizeWifiRadioRequest({interfaceId:'not-a-guid',enabled:true}),null);
assert.equal(normalizeWifiRadioRequest({interfaceId:'{00000000-0000-0000-0000-000000000001}',enabled:'true'}),null);
const profiles=[{name:'Home Wi-Fi',interfaceId:'{00000000-0000-0000-0000-000000000001}'},{name:'Home Wi-Fi',interfaceId:'{00000000-0000-0000-0000-000000000002}'}];
assert.equal(resolveSavedWifiProfile(profiles,'home wi-fi',profiles[0].interfaceId)?.name,'Home Wi-Fi');
assert.equal(resolveSavedWifiProfile(profiles,'Home Wi-Fi','{00000000-0000-0000-0000-000000000003}'),null,'profiles are restricted to the chosen adapter');
assert.equal(resolveSavedWifiProfile(profiles,'Unknown',profiles[0].interfaceId),null,'only an existing saved profile may be connected');
const calls=[];
const wifiAction=createWifiActions(async(script,args)=>{calls.push([script,args]);return JSON.stringify(script==='wifi.ps1'&&args[0]==='snapshot'?{profiles}: {ok:true});});
await assert.rejects(()=>wifiAction('wifi-connect',{interfaceId:profiles[0].interfaceId,profileName:'Unknown'}),/saved-profile-unavailable/);
assert.equal(calls.length,1,'an unknown profile must not issue a connect operation');
calls.length=0;
await wifiAction('wifi-connect',{interfaceId:profiles[0].interfaceId,profileName:'home wi-fi'});
assert.deepEqual(calls,[['wifi.ps1',['snapshot']],['wifi.ps1',['connect',profiles[0].interfaceId,'Home Wi-Fi']]]);
calls.length=0;
await wifiAction('wifi-radio',{interfaceId:profiles[0].interfaceId,enabled:false});
assert.deepEqual(calls,[['wifi.ps1',['radio',profiles[0].interfaceId,'off']]]);
await assert.rejects(()=>wifiAction('wifi-radio',{interfaceId:profiles[0].interfaceId,enabled:'off'}),/invalid-radio-request/);
const handler=createRouteHandler({snapshot:()=>({ok:true}),action:async()=>{throw new Error('not supported');}},'secret');
let res=response(); await handler(req('GET','bad'),res);assert.equal(res.status,403);
res=response(); await handler(req('PUT'),res);assert.equal(res.status,405);
res=response(); await handler(req('POST','secret','{'),res);assert.equal(res.status,400);
res=response(); await handler(req('GET'),res);assert.equal(res.status,200);assert.equal(res.headers['cache-control'],'no-store');
console.log('host tests: authorization, parsing, Wi-Fi profile/radio allowlists, and process guards passed');

const processScript = new URL('./host/processes.ps1', import.meta.url).pathname.replace(/^\/(\w:)/, '$1').replaceAll('/', '\\');
const powershell = `
$ErrorActionPreference = 'Stop'
$script:stopCalls = 0
function Get-Process { param([int]$Id) [pscustomobject]@{ Id=$Id; ProcessName='demo'; StartTime=[datetime]'2026-01-01T00:00:00Z' } }
function Stop-Process { $script:stopCalls++ }
$script:ownerProcess = [pscustomobject]@{}
$script:ownerProcess | Add-Member -MemberType ScriptMethod -Name GetOwner -Value { [pscustomobject]@{ Domain=''; User='' } }
function Get-CimInstance { return $script:ownerProcess }
try { . '${processScript.replaceAll("'", "''")}' -Mode terminate -PidText '4242'; 'NO_ERROR' } catch { 'ERROR=' + $_.Exception.Message }
'STOP=' + $script:stopCalls
`;
const output = execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command', powershell], { encoding: 'utf8' });
assert.match(output, /ERROR=process-owner-unavailable/, 'unknown process ownership must reject termination');
assert.match(output, /STOP=0/, 'the process must not be stopped when ownership cannot be verified');
const queryFailure = execFileSync('powershell.exe', [
  '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-Command',
  powershell.replace('function Get-CimInstance { return $script:ownerProcess }', "function Get-CimInstance { throw 'CIM unavailable' }"),
], { encoding: 'utf8' });
assert.match(queryFailure, /ERROR=process-owner-unavailable/, 'a failed owner query must reject termination');
assert.match(queryFailure, /STOP=0/, 'the process must not be stopped after a failed owner query');
console.log('host tests: process-owner failure refuses termination (missing identity + CIM error)');

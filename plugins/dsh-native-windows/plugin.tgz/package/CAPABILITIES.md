# Windows capability matrix

These capabilities are best-effort and depend on Windows edition, drivers, policy, and the current user token. No elevation is requested automatically.

| Operation | Status | API/command | Elevation |
|---|---|---|---|
| Wi-Fi interfaces/radio/profiles | Supported with caveat | `WlanEnumInterfaces`, `WlanQueryInterface`, `WlanGetProfileList` via `wlanapi.dll` | No |
| Available Wi-Fi networks | Supported with caveat; visible SSID and strongest sampled signal | `netsh wlan show networks mode=bssid` (localized output may omit fields) | No |
| Wi-Fi disconnect | Supported with caveat | `WlanDisconnect` after validating adapter GUID | Driver/policy may deny |
| Wi-Fi connect | Supported for saved profiles only | `WlanConnect`; adapter and exact saved profile are revalidated immediately before request | Driver/policy may deny; operation is asynchronous |
| Wi-Fi software radio on/off | Supported with caveat | `WlanQueryInterface` + `WlanSetInterface`; hardware radio cannot be overridden | Driver/policy may deny |
| Bluetooth paired device list | Supported with caveat | Device-level `BTHENUM\\DEV_` / `BTHLE\\DEV_` records from `Get-PnpDevice` | No |
| Bluetooth device presence | Supported with caveat | PnP `Present`; this is device presence, not a live connection state | No |
| Bluetooth connection state | Not exposed | PnP `Status=OK` does not prove a device is connected; UI reports unknown | — |
| Bluetooth radio on/off | Unsupported by this unpackaged desktop build | `Windows.Devices.Radios` requires the `radios` app capability and user permission; this DSH package has no appx capability manifest | App packaging/capability required |
| Bluetooth connect/disconnect/pair/unpair | Not supported | PnP list only; no validated supported desktop API integrated yet | — |
| Process list and memory | Supported with caveat | `Get-Process`; memory is working set; list capped at 500 | No |
| Per-process CPU | Supported with caveat | Two `Get-Process` samples 300 ms apart; CPU-time delta normalized by elapsed time and logical processor count | No; first/new processes can be unavailable |
| Process detail | Limited | Name, PID, working set, sampled CPU percentage, cumulative CPU seconds | No |
| Terminate selected process | Supported with caveat | `Stop-Process -Id` following explicit confirmation and a protected-name/current-user check | Same-user, non-elevated processes only; protected/refused processes stay running |

Bluetooth radio power and pair/connect/disconnect remain unsupported; the UI says so explicitly. The Bluetooth list filters out GATT service child nodes and never labels PnP health as a connection. The runtime capability depends on installed adapters, drivers, policy, and locale. Wi-Fi connect accepts no password and cannot add/edit profiles; it only asks Windows to use an existing profile.

import assert from 'node:assert/strict';

const specs = [];
globalThis.document = { createElement: () => ({ setAttribute() {}, remove() {} }), head: { append() {} } };
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
await import('./client.js');
const React = { createElement: (type, props, ...children) => ({ type, props: { ...props, children } }) };
const mod = specs[0].factory((name) => {
  if (name === 'react') return React;
  throw new Error(name);
});
function flattenText(node) {
  if (node == null) return '';
  if (typeof node === 'string' || typeof node === 'number') return String(node);
  return (node.props?.children ?? []).flat(Infinity).map(flattenText).join('');
}
const data = { from: { provider: 'openai', model: 'gpt-5.6' }, to: { provider: 'anthropic', model: 'claude-sonnet-4' }, fromLabel: 'openai/gpt-5.6', toLabel: 'anthropic/claude-sonnet-4' };
const view = mod.__test.ModelChangeNodeView({ node: { data }, t: (key, values) => `${values.from} → ${values.to} にモデルを変更` });
assert.equal(view.type, 'div');
assert.equal(view.props.role, 'separator');
assert.equal(flattenText(view), 'openai/gpt-5.6 → anthropic/claude-sonnet-4 にモデルを変更');
assert.equal(view.props['aria-label'], flattenText(view));
assert.equal(mod.__test.ModelChangeNodeView({ node: { data: { fromLabel: '', toLabel: '' } } }), null, 'malformed model events are not rendered');
assert.match(mod.__test.css, /--dsw-alias-state-business-primary/);
assert.match(mod.__test.css, /prefers-reduced-motion:reduce/);
assert.match(mod.__test.css, /opacity/);
assert.match(mod.__test.css, /translateY\(3px\)/);
assert.doesNotMatch(mod.__test.css, /setTimeout|setInterval/);
console.log('ok   independent event node is centered, blue, localized and accessible');
console.log('ok   malformed history records render nothing; reduced-motion is respected');
console.log('\n2/2 checks passed');

import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const specs = [], registrations = [], effects = [];
globalThis.document = { createElement: () => ({ attrs: {}, setAttribute(k, v) { this.attrs[k] = v; }, remove() {} }), head: { append() {} } };
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
await import('./client.js');
const React = { createElement: (type, props, ...children) => ({ type, props: { ...props, children } }) };
const mod = specs[0].factory((name) => {
  if (name === 'react') return React;
  throw new Error(`unexpected require ${name}`);
});

const route = (provider, model) => ({ provider, model });
const event = (id, seq, provider, model, surfaceOp = 'append') => ({
  type: 'assistant/message', seq, surfaceOp, time: seq,
  data: { turn: `turn-${id}`, step: 1, message: { id, source: route(provider, model) } },
});
const first = event('m1', 10, 'openai', 'gpt-5.6');
const firstMatch = mod.__test.modelRouteDefinition.match(first);
assert.deepEqual(firstMatch, { id: '10:m1', role: 'start' });
const firstState = mod.__test.modelRouteDefinition.start({}, { event: first, location: { kind: 'step' } }, { previous: () => undefined });
assert.deepEqual(firstState, { route: route('openai', 'gpt-5.6'), previous: null, turn: 'turn-m1', seq: 10, messageId: 'm1' });

const changed = event('m2', 20, 'anthropic', 'claude-sonnet-4');
const changedState = mod.__test.modelRouteDefinition.start({}, { event: changed, location: { kind: 'step', turn: { turn: 'turn-m2' } } }, { previous: (kind) => {
  assert.equal(kind, mod.__test.MODEL_ROUTE_KIND);
  return { state: firstState };
} });
assert.deepEqual(changedState.previous, route('openai', 'gpt-5.6'));
const node = mod.__test.modelRouteDefinition.buildViewNode({
  key: 'model-route:m2', id: 'm2', state: changedState,
  start: { event: changed, location: { kind: 'step', turn: { turn: 'turn-m2' } } },
});
assert.equal(node.kind, 'dsh-model-change');
assert.equal(node.target, 'chat');
assert.equal(node.anchorSeq, 19.9, 'the separator sorts immediately before the first assistant answer using the new model');
assert.equal(node.data.from.provider, 'openai');
assert.equal(node.data.to.model, 'claude-sonnet-4');
assert.equal(node.location.turn.turn, 'turn-m2');

const unchanged = event('m3', 30, 'anthropic', 'claude-sonnet-4');
const unchangedState = mod.__test.modelRouteDefinition.start({}, { event: unchanged, location: { kind: 'step' } }, { previous: () => ({ state: changedState }) });
assert.equal(mod.__test.modelRouteDefinition.buildViewNode({ key: 'model-route:m3', id: 'm3', state: unchangedState, start: { event: unchanged, location: { kind: 'step' } } }), null);
assert.equal(mod.__test.modelRouteDefinition.buildViewNode({ key: 'model-route:m2', id: 'm2', state: firstState, start: { event: first, location: { kind: 'step' } } }), null, 'the first loaded response does not invent a previous model');
assert.equal(mod.__test.modelRouteDefinition.match(event('m4', 40, 'openai', 'gpt-6', 'replace')), null, 'replacement/compaction surface writes do not create duplicate separators');
const bad = { ...event('bad', 41, '', ''), surfaceOp: 'append' };
const badMatch = mod.__test.modelRouteDefinition.match(bad);
const badState = mod.__test.modelRouteDefinition.start({}, { event: bad }, { previous: () => ({ state: changedState }) });
assert.equal(badMatch.id, '41:bad');
assert.equal(badState.route, null, 'invalid model routes break the comparison chain instead of guessing across them');
const afterUnknown = event('m5', 50, 'openai', 'gpt-6');
const afterUnknownState = mod.__test.modelRouteDefinition.start({}, { event: afterUnknown }, { previous: () => ({ state: badState }) });
assert.equal(mod.__test.modelRouteDefinition.buildViewNode({ key: 'model-route:m5', id: 'm5', state: afterUnknownState, start: { event: afterUnknown, location: { kind: 'step' } } }), null, 'an unknown intervening route does not fabricate a direct switch');

const unregisters = [], cleanup = [];
const ctx = {
  uiConversation: { events: { register(definition) { registrations.push(definition); return () => unregisters.push(definition.kind); } } },
  slots: { inject(name, register) { assert.equal(name, 'conversation.chat.node'); return register(); }, register(options, component) { registrations.push({ options, component }); return () => unregisters.push(options.key); } },
  locale: { register(ns, dictionaries) { assert.equal(ns, mod.__test.NS); assert.equal(dictionaries.ja !== undefined, true); return () => {}; } },
  effect(fn) { const disposer = fn(); if (typeof disposer === 'function') cleanup.push(disposer); },
};
mod.apply(ctx);
assert.equal(registrations[0].kind, mod.__test.MODEL_ROUTE_KIND);
assert.equal(registrations[0].target, 'chat');
assert.equal(registrations[1].options.name, 'conversation.chat.node');
assert.equal(registrations[1].options.key, 'dsh-model-change');
assert.equal(registrations[1].component, mod.__test.ModelChangeNodeView);
for (const dispose of cleanup.reverse()) dispose();
assert.deepEqual(unregisters, ['dsh-model-change', mod.__test.MODEL_ROUTE_KIND]);

const manifest = JSON.parse(await readFile(new URL('./package.json', import.meta.url), 'utf8'));
assert.ok(manifest.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-conversation'), 'the conversation event registry provider is declared');
assert.ok(manifest.dsh.client.inject.includes('@deepseek-ai/dsh-client-ui-layout'), 'the chat renderer/slot provider is declared');
console.log('ok   durable assistant routes produce only truthful model-change nodes');
console.log('ok   the node is ordered before the new-model response and survives history replay');
console.log('ok   event and renderer registrations dispose cleanly and declare providers');
console.log('\n3/3 checks passed');

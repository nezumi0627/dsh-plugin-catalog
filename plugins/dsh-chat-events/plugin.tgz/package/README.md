# dsh-chat-events

Adds a centered model-change divider as an independent Chat node. It reads the durable `assistant/message` route (`message.source.provider/model`) through the supported `uiConversation.events` projector, compares adjacent assistant replies within that session, and mounts a keyed `conversation.chat.node` renderer just before the first response using the new route. The divider is rebuilt from the conversation's stored event history after reload; it does not guess from the session-wide `modelSelection` projection or write a duplicate local journal.

Unknown or incomplete routes break the comparison chain, so a missing predecessor never fabricates a switch. Replacement-surface writes are ignored to avoid duplicate separators. The component uses the blue business-primary token, supports reduced motion, and degrades to no divider if its localized record is invalid.

Run `node --check client.js`, `node test-client.mjs`, and `node test-render.mjs`.

window.__ModuleLoader__.load({
  id: '@local/dsh-chat-events',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const ID = '@local/dsh-chat-events';
    const NS = 'dshChatEvents';
    const MODEL_ROUTE_KIND = 'dsh-model-route';
    const MODEL_CHANGE_NODE_KIND = 'dsh-model-change';
    const dictionaries = {
      ja: { changed: '{from} → {to} にモデルを変更' },
      en: { changed: 'Model changed: {from} → {to}' },
      zh: { changed: '模型已切换：{from} → {to}' },
    };
    const css = `.dshce-separator{display:flex;align-items:center;gap:12px;margin:12px 0;color:var(--dsw-alias-state-business-primary);font:calc(12px + var(--dsh-content-font-delta,0px))/1.4 var(--dsw-font-family);animation:dshce-in 155ms cubic-bezier(.16,1,.3,1) both}.dshce-separator:before,.dshce-separator:after{content:"";height:1px;flex:1;background:currentColor}.dshce-label{max-width:80%;text-align:center}@keyframes dshce-in{from{opacity:0;transform:translateY(3px)}to{opacity:1;transform:translateY(0)}}@media (prefers-reduced-motion:reduce){.dshce-separator{animation:none}}`;

    function readRoute(event) {
      if (event?.type !== 'assistant/message') return null;
      const source = event.data?.message?.source;
      if (!source || typeof source.provider !== 'string' || typeof source.model !== 'string') return null;
      const provider = source.provider.trim();
      const model = source.model.trim();
      if (!provider || !model || provider.length > 160 || model.length > 240 || /[\u0000-\u001f\u007f]/.test(provider + model)) return null;
      return { provider, model };
    }

    function sameRoute(a, b) {
      return a?.provider === b?.provider && a?.model === b?.model;
    }

    function routeLabel(route) {
      return route?.provider && route?.model ? `${route.provider}/${route.model}` : '';
    }

    const modelRouteDefinition = {
      kind: MODEL_ROUTE_KIND,
      target: 'chat',
      match(event) {
        if (event?.type !== 'assistant/message' || event.surfaceOp !== 'append') return null;
        const id = event.data?.message?.id;
        if (typeof id !== 'string' || id.length === 0 || id.length > 512 || !Number.isSafeInteger(event.seq) || event.seq < 0) return null;
        return { id: `${event.seq}:${id}`, role: 'start' };
      },
      start(_context, match, reader) {
        const event = match.event;
        const previous = reader.previous(MODEL_ROUTE_KIND)?.state?.route ?? null;
        return {
          route: readRoute(event),
          previous,
          turn: event.data?.turn ?? null,
          seq: event.seq,
          messageId: event.data.message.id,
        };
      },
      buildViewNode(context) {
        const state = context?.state;
        const event = context?.start?.event;
        const location = context?.start?.location;
        if (!state?.route || !state.previous || sameRoute(state.route, state.previous)) return null;
        if (!Number.isSafeInteger(event?.seq) || event.seq < 0 || location === undefined) return null;
        return {
          key: context.key,
          kind: MODEL_CHANGE_NODE_KIND,
          id: context.id,
          target: 'chat',
          anchorSeq: Math.max(0, event.seq - 0.1),
          location,
          visibility: 'visible',
          data: {
            from: state.previous,
            to: state.route,
            fromLabel: routeLabel(state.previous),
            toLabel: routeLabel(state.route),
            turn: state.turn,
            messageId: state.messageId,
          },
        };
      },
    };

    function ModelChangeNodeView({ node, t } = {}) {
      const data = node?.data;
      if (!data?.fromLabel || !data?.toLabel) return null;
      let label = `${data.fromLabel} → ${data.toLabel}`;
      try {
        const translated = t?.('changed', { from: data.fromLabel, to: data.toLabel });
        if (typeof translated === 'string' && translated.length > 0) label = translated;
      } catch {
        // A localization fault must not take down chat rendering.
      }
      return h('div', { className: 'dshce-separator', role: 'separator', 'aria-label': label },
        h('span', { className: 'dshce-label' }, label));
    }

    return {
      inject: ['slots', 'locale', 'uiConversation'],
      apply(ctx) {
        const style = typeof document === 'undefined' ? null : (() => {
          const el = document.createElement('style');
          el.setAttribute('data-plugin-css', ID);
          el.textContent = css;
          document.head.append(el);
          return el;
        })();
        ctx.effect(() => () => style?.remove(), 'dsh-chat-events.styles');
        ctx.effect(() => ctx.locale.register(NS, dictionaries), 'dsh-chat-events.locale');
        ctx.effect(() => ctx.uiConversation.events.register(modelRouteDefinition), 'dsh-chat-events.model-route');
        ctx.effect(() => ctx.slots.inject('conversation.chat.node', () => ctx.slots.register({
          name: 'conversation.chat.node',
          key: MODEL_CHANGE_NODE_KIND,
          locale: NS,
        }, ModelChangeNodeView)), 'dsh-chat-events.model-change-node');
      },
      __test: { ID, NS, MODEL_ROUTE_KIND, MODEL_CHANGE_NODE_KIND, dictionaries, readRoute, sameRoute, routeLabel, modelRouteDefinition, ModelChangeNodeView, css },
    };
  },
});

export const name = 'dsh-chat-events';
export function apply(ctx) { ctx.logger?.info?.('[dsh-chat-events] active'); }

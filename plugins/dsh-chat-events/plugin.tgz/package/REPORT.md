# dsh-chat-events implementation report

## Behavior

- Registers the supported `uiConversation.events` definition `dsh-model-route` for durable `assistant/message` append events.
- Uses the event's recorded `message.source.provider/model`; it never infers a historical model from the session-wide `modelSelection` projection.
- Reads the immediately preceding route through the event registry's `reader.previous()` dependency. An absent or malformed route breaks the comparison chain and produces no guessed transition.
- Projects a `dsh-model-change` Chat node at `assistant-message.seq - 0.1`, directly before the first response using the new route. The current keyed `conversation.chat.node` slot renders the node as a centered blue divider.
- History is restored by replaying the persisted assistant-message events, so a parallel localStorage journal is unnecessary. Replacement-surface events are ignored; identical adjacent routes do not produce separators.
- The event registry disposer and slot registration are owned by Cordis effects. The plugin is enabled in the desktop profile again after its source was replaced and preflighted.

## Verification

Executed:

```text
node dsh-chat-events/test-client.mjs   # 3/3 checks passed
node dsh-chat-events/test-render.mjs   # 2/2 checks passed
node --check dsh-chat-events/client.js # passed
node dsh-boot-guard/test-boot-guard.mjs # 48/48 checks passed
```

The tests cover adjacent and unchanged routes, unknown route breaks, append-only filtering, stable event ordering, translation/accessibility, style cleanup, and both event/slot disposers. The Boot Guard registry was checked with the plugin enabled in memory; its verdict was `level: ok`, with no signals. Re-enabling the profile removed only Boot Guard's quarantine block and wrote backup `cordis.patch.yml.bak-bootguard-20261012-171606`.

## Runtime boundary

The installed DSH process predates these edits and remains running by the user's earlier restart deferral. The model divider's live rendering and the new Host trace therefore remain pending one normal restart; no restart was initiated.

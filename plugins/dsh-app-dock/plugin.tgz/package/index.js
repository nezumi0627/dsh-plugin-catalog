export const name = 'dsh-app-dock';
export function apply(ctx) {
  ctx.logger?.info?.('[dsh-app-dock] active');
}

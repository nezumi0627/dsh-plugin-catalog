import assert from 'node:assert/strict';
const specs = [], disposers = [], registrations = [];
const manifest = JSON.parse(await (await import('node:fs/promises')).readFile(new URL('./package.json', import.meta.url), 'utf8'));
assert.ok(!manifest.dsh.client.inject.includes('@deepseek-ai/dsh-client-store'), 'module-only dependencies must not be awaited as client services');
const React = { createElement() {}, useState() {}, useEffect() {}, useRef() {} };
let storeOptions;
const store = { getSnapshot: () => null, set() {}, subscribe() { return () => {}; } };
globalThis.document = { createElement: () => ({ attrs: {}, setAttribute(k,v){ this.attrs[k]=v; }, remove(){ this.removed=true; } }), head: { append(el){ this.style=el; } } };
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
await import('./client.js');
assert.equal(specs.length, 1);
const mod = specs[0].factory((name) => name === 'react' ? React : name === '@deepseek-ai/dsh-client-store' ? { createSnapshotStore: (_init, options) => { storeOptions = options; return store; } } : (() => { throw new Error(`unexpected require: ${name}`); })());
assert.equal(mod.inject.join(','), 'slots,locale,sidebarRight');
assert.equal(storeOptions.persist.name, 'dsh.app-dock.layout');
assert.deepEqual(mod.__test.normalize({ corrupt: true }), mod.__test.DEFAULTS);
const ctx = {
  sidebarRight: {},
  effect(run) { const dispose = run(); if (typeof dispose === 'function') disposers.push(dispose); },
  locale: { register: () => () => {} },
  slots: { inject(name, callback) { assert.equal(name, 'shell.overlay'); callback(); }, register(options, Component) { registrations.push({ options, Component }); return () => {}; } },
};
mod.apply(ctx);
assert.equal(registrations.length, 1);
assert.equal(registrations[0].options.id, '@local/dsh-app-dock');
assert.equal(registrations[0].options.order, 200);
assert.equal(registrations[0].options.name, 'shell.overlay');
assert.equal(typeof registrations[0].Component, 'function');
for (const dispose of disposers.reverse()) dispose();
assert.equal(document.head.style.removed, true);
console.log('ok loader, require allowlist, persisted key, corrupt fallback, shell.overlay order 200 and disposal');

import assert from 'node:assert/strict';
const specs = [], hookState = [];
let cursor = 0;
const React = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState(initial) { const i = cursor++; if (!(i in hookState)) hookState[i] = typeof initial === 'function' ? initial() : initial; return [hookState[i], (next) => { hookState[i] = typeof next === 'function' ? next(hookState[i]) : next; }]; },
  useEffect() { cursor++; },
  useRef(initial) { const i = cursor++; return hookState[i] ??= { current: initial }; },
};
const store = { value: { version: 1, order: ['x','instagram','youtube','google','discord'], hidden: [], lastActive: 'discord', tabs: { discord: 'persisted-discord-tab' } }, getSnapshot() { return this.value; }, set(value) { this.value = value; }, subscribe() { return () => {}; } };
globalThis.document = { createElement: () => ({ setAttribute(){}, remove(){}, textContent:'' }), head: { append(el){ this.style = el; } } };
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
await import('./client.js');
const mod = specs[0].factory((name) => name === 'react' ? React : name === '@deepseek-ai/dsh-client-store' ? { createSnapshotStore: () => store } : (() => { throw new Error(`unexpected require: ${name}`); })());
const { Dock, APPS, normalize, DEFAULTS } = mod.__test;
assert.match(document.head.style.textContent, /right:max\(14px,env\(safe-area-inset-right\)\)/);
assert.match(document.head.style.textContent, /top:50%/);
assert.match(document.head.style.textContent, /flex-direction:column/);
assert.doesNotMatch(document.head.style.textContent, /left:50%|bottom:max\(14px/);
assert.deepEqual(normalize(null), DEFAULTS);
const calls = [], focused = [];
let activeTab;
const sidebarRight = {
  openTab: (...args) => { calls.push(args); activeTab = { id: `tab-${calls.length}` }; },
  active: () => activeTab,
  focus: (id) => { focused.push(id); activeTab = { id }; },
};
sidebarRight.active = () => activeTab;
sidebarRight.focus = (id) => { focused.push(id); activeTab = { id }; };
const render = () => { cursor = 0; return Dock({ sidebarRight, t: (key) => key }); };
let tree = render();
assert.equal(tree.props.role, 'toolbar');
assert.equal(tree.props.tabIndex, 0, 'toolbar must be keyboard focusable');
assert.equal(tree.children[0].props.type, 'button', 'toolbar items remain native keyboard-operable buttons');
assert.equal(tree.children.filter(Boolean).length, 5);
assert.ok(tree.children.slice(0, 5).every((child) => child.type === 'button' && child.children.length === 1 && child.children[0]?.children[0]?.type === 'svg'), 'the dock shows service icons only');
assert.equal(APPS.find((app) => app.id === 'discord')?.url, 'https://discord.com/channels/@me');
assert.doesNotMatch(document.head.style.textContent, /button:hover[^}]*transform|button\{[^}]*transition:transform/);
tree.children.find((child) => child?.props?.['aria-label'] === 'Discord').props.onClick();
await Promise.resolve();
assert.equal(calls.length, 0, 'existing persisted dock tab is reused after plugin initialization');
assert.deepEqual(focused.at(-1), 'persisted-discord-tab');
store.value = { version: 1, order: ['x','instagram','youtube','google','discord'], hidden: [], lastActive: 'x', tabs: {} };
for (const [index, app] of APPS.entries()) {
  tree = render();
  const button = tree.children.find((child) => child?.props?.['aria-label'] === app.label);
  button.props.onClick();
  await Promise.resolve();
  assert.equal(calls.at(-1)[0], 'browser');
  assert.deepEqual(calls.at(-1)[1], { params: { url: app.url }, revealIfOpened: true });
  tree = render();
  assert.equal(tree.children.find((child) => child?.props?.['aria-label'] === app.label).props['aria-current'], 'true');
  tree.children.find((child) => child?.props?.['aria-label'] === app.label).props.onClick();
  await Promise.resolve();
  assert.equal(calls.length, index + 1, 'repeated selection focuses the saved tab without creating another');
  assert.equal(focused.at(-1), `tab-${index + 1}`);
}
const google = tree.children.find((child) => child?.props?.['aria-label'] === 'Google');
google.props.onKeyDown({ altKey: true, key: 'ArrowUp', preventDefault() {} });
assert.deepEqual(store.value.order, ['x','instagram','google','youtube','discord']);
assert.match(specs[0].factory.toString(), /shell\.overlay/);
cursor = 0;
tree = Dock({ sidebarRight: {}, t: (key) => key });
tree.children[0].props.onClick();
await Promise.resolve();
cursor = 0;
tree = Dock({ sidebarRight: {}, t: (key) => key });
assert.equal(tree.children.find((child) => child?.props?.role === 'status').children[0], 'unavailable');

let resolveFirst;
const delayedCalls = [];
const delayedSidebar = { openTab: (...args) => new Promise((resolve) => { delayedCalls.push(args); if (!resolveFirst) resolveFirst = resolve; else resolve(); }) };
cursor = 0;
tree = Dock({ sidebarRight: delayedSidebar, t: (key) => key });
tree.children.find((child) => child?.props?.['aria-label'] === 'YouTube').props.onClick();
tree.children.find((child) => child?.props?.['aria-label'] === 'Google').props.onClick();
await Promise.resolve();
resolveFirst();
await Promise.resolve();
await Promise.resolve();
cursor = 0;
tree = Dock({ sidebarRight: delayedSidebar, t: (key) => key });
assert.equal(tree.children.find((child) => child?.props?.['aria-label'] === 'Google').props['aria-current'], 'true', 'late completion cannot overwrite the most recent selection');

cursor = 0;
tree = Dock({ sidebarRight: { openTab: () => Promise.reject(new Error('pane failure')) }, t: (key) => key });
tree.children.find((child) => child?.props?.['aria-label'] === 'X').props.onClick();
await Promise.resolve();
await Promise.resolve();
cursor = 0;
tree = Dock({ sidebarRight: { openTab: () => Promise.reject(new Error('pane failure')) }, t: (key) => key });
assert.equal(tree.children.find((child) => child?.props?.role === 'status').children[0], 'unavailable', 'rejected pane switches are surfaced without an unhandled rejection');
console.log('ok per-service single tabs, exact URLs, Discord, static hover, selected indicator, keyboard reorder and unavailable API');

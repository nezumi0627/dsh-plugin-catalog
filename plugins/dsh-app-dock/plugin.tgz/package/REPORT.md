# dsh-app-dock verification report

## Commands and exact output

Run from `dsh-app-dock`:

```text
> node --check index.js
(no output; exit 0)
> node --check client.js
(no output; exit 0)
> node test-client.mjs
ok loader, require allowlist, persisted key, corrupt fallback, shell.overlay order 200 and disposal
> node test-render.mjs
ok browser switching, exact URLs, selected indicator, duplicate-safe reveal, keyboard reorder and unavailable API
> Select-String -Path client.js -Pattern '<webview|<iframe'
(no matches; exit 0)
```

The dependency-free tests exercise the actual loaded component against recording platform stubs. They verify all four URL targets, active state, duplicate-safe reveal calls, keyboard reorder persistence, store key/default fallback, shell registration and style disposal. They do not exercise a real DSH/browser pane.

## Findings and limits

- Dock slot: `shell.overlay`, `id: '@local/dsh-app-dock'`, `order: 200`; placed at the right edge, above columns. Icons are 34×34 px; 7 px inset padding and 6 px gaps yield an approximately 48×168 px four-item dock.
- Browser routing uses the shipped `sidebarRight.openTab('browser', { params: { url }, revealIfOpened: true })`. The exact `revealIfOpened` option is used by the shipped sidebar-right implementation (`sidebar-right.js`, `place()` around lines 6135–6140), which forwards it to `navigator.openTabIn`. It is intended to reveal an already-open matching tab rather than opening duplicates. This activation/reveal option was found in shipped source; no separate `activateTab` method or tab lookup is relied upon.
- Browser-page state preservation is owned by the shipped browser pane. Its source sets `keepMounted` only when its Desktop browser carrier is available (`sidebar-browser.js` around line 1605); cross-platform preservation is not guaranteed by the verified API.
- Web-profile frame restrictions documented for X home (`SAMEORIGIN`/`frame-ancestors`), Instagram home (`DENY`), and YouTube home (`SAMEORIGIN`) prevent embedding those pages. Instagram captioned post embed, YouTube nocookie embed, and X post embed require a specific post/video ID; this dock does not invent one or create an iframe fallback. Desktop's shipped browser pane hosts the webview. Web-profile refusal rendering/open-external fallback is the shipped pane's responsibility and was not verifiable here; the dock displays an unavailable state if `openTab` is missing or throws.
- No verified DSH-internal action API is exposed by injected services (`slots`, `locale`, `sidebarRight`), so no speculative internal URL/action is registered. Four web apps are in client defaults and the bundle row config, but the client does not consume row-provided app configuration. Internal entries/config-driven list remain an integration gap for the Lead.
- Storage key is `dsh.app-dock.layout`; corrupt/old-version state normalizes to defaults; keyboard Alt+↑/Alt+↓ updates and persists order. Teardown removes injected styles and registration effects. No custom `<webview>` or `<iframe>` exists in `client.js`.

## Keyboard access follow-up (2026-10-12)

The toolbar container was not itself focusable, despite the dock being a keyboard-operated surface. Added `tabIndex: 0`; regression test observed `undefined` before the fix and now asserts it is focusable while its children remain native buttons. Fresh verification: both syntax checks exit 0, client suite reports `ok loader, require allowlist, persisted key, corrupt fallback, shell.overlay order 200 and disposal`, and render suite reports `ok browser switching, exact URLs, selected indicator, duplicate-safe reveal, keyboard reorder and unavailable API`.

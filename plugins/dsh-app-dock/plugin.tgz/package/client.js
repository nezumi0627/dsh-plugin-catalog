window.__ModuleLoader__.load({
  id: '@local/dsh-app-dock',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useState, useEffect, useRef } = React;
    const { createSnapshotStore } = require('@deepseek-ai/dsh-client-store');
    const ID = '@local/dsh-app-dock', NS = 'dshAppDock', KEY = 'dsh.app-dock.layout';
    const DEFAULTS = { version: 1, order: ['x', 'instagram', 'youtube', 'google', 'discord'], hidden: [], size: 'standard', lastActive: 'x', tabs: {} };
    const APPS = [
      { id: 'x', label: 'X', url: 'https://x.com/home' },
      { id: 'instagram', label: 'Instagram', url: 'https://instagram.com/' },
      { id: 'youtube', label: 'YouTube', url: 'https://youtube.com/' },
      { id: 'google', label: 'Google', url: 'https://www.google.com/' },
      { id: 'discord', label: 'Discord', url: 'https://discord.com/channels/@me' },
    ];
    const CSS = `.dshadock{position:absolute;z-index:20;right:max(14px,env(safe-area-inset-right));top:50%;transform:translateY(-50%);display:flex;flex-direction:column;align-items:center;gap:6px;max-height:calc(100% - 28px);overflow-y:auto;padding:8px 10px;background:color-mix(in srgb,var(--dsw-alias-bg-layer-2) 82%,transparent);border:1px solid color-mix(in srgb,var(--dsw-alias-border-l2) 72%,transparent);border-radius:24px;pointer-events:none;backdrop-filter:blur(24px) saturate(1.45);-webkit-backdrop-filter:blur(24px) saturate(1.45);box-shadow:0 10px 34px rgb(0 0 0/.22),inset 0 1px 0 rgb(255 255 255/.12)}.dshadock button{position:relative;pointer-events:auto;-webkit-app-region:no-drag;width:42px;height:42px;padding:0;display:grid;place-items:center;border:0;border-radius:13px;background:transparent;color:var(--dsw-alias-label-secondary);cursor:pointer}.dshadock button:hover{background:rgb(255 255 255/.1)}.dshadock button[aria-current=true]{background:rgb(255 255 255/.12)}.dshadock button:focus-visible{outline:2px solid var(--dsw-alias-state-business-primary);outline-offset:2px}.dshadock .dshadock-icon{width:32px;height:32px;display:grid;place-items:center;overflow:hidden;border-radius:10px;box-shadow:0 2px 7px rgb(0 0 0/.2)}.dshadock svg{display:block;width:22px;height:22px}.dshadock [data-app=x] .dshadock-icon{background:#080808;color:#fff}.dshadock [data-app=instagram] .dshadock-icon{background:linear-gradient(135deg,#833ab4 0%,#fd1d1d 52%,#fcb045 100%);color:white}.dshadock [data-app=youtube] .dshadock-icon{background:#fff;color:#ff0033}.dshadock [data-app=google] .dshadock-icon{background:#fff;color:#4285f4}.dshadock [data-app=discord] .dshadock-icon{background:#5865f2;color:white}.dshadock [data-app=discord] svg{fill:currentColor}.dshadock .dshadock-label{display:none}.dshadock [role=status]{position:absolute;right:calc(100% + 10px);top:50%;transform:translateY(-50%);white-space:nowrap;padding:6px 10px;border-radius:10px;background:var(--dsw-alias-bg-layer-3);color:var(--dsw-alias-label-secondary);font:var(--dsw-font-xxs-12);box-shadow:var(--dsw-elevation-soft)}@media(max-width:420px){.dshadock{gap:3px;padding:7px 8px}}`;
    const style = typeof document === 'undefined' ? null : (() => { const el = document.createElement('style'); el.setAttribute('data-plugin-css', ID); el.textContent = CSS; document.head.append(el); return el; })();
    function normalize(raw) {
      if (!raw || raw.version !== 1) return { ...DEFAULTS };
      const ids = APPS.map((app) => app.id);
      const order = Array.isArray(raw.order) ? [...new Set(raw.order.filter((id) => ids.includes(id)))].concat(ids.filter((id) => !raw.order.includes(id))) : [...ids];
      const tabs = raw.tabs && typeof raw.tabs === 'object' && !Array.isArray(raw.tabs) ? Object.fromEntries(Object.entries(raw.tabs).filter(([id, tabId]) => ids.includes(id) && typeof tabId === 'string' && tabId.length > 0)) : {};
      return { ...DEFAULTS, order, hidden: Array.isArray(raw.hidden) ? raw.hidden.filter((id) => ids.includes(id)) : [], lastActive: ids.includes(raw.lastActive) ? raw.lastActive : DEFAULTS.lastActive, tabs };
    }
    let store;
    try { store = createSnapshotStore(() => ({ ...DEFAULTS }), { flush: 'raf', persist: { name: KEY } }); } catch { store = null; }
    let memory = { ...DEFAULTS };
    const getState = () => { try { return normalize(store ? store.getSnapshot() : memory); } catch { return normalize(memory); } };
    memory = getState();
    const setState = (next) => { memory = normalize(next); try { store?.set(memory); } catch { store = null; } };
    function Dock({ sidebarRight: getSidebarRight, t }) {
      const [state, set] = useState(getState);
      const [error, setError] = useState('');
      const activation = useRef(0);
      useEffect(() => {
        const unsubscribe = store?.subscribe(() => { memory = getState(); set(memory); });
        return () => { activation.current++; unsubscribe?.(); };
      }, []);
      const move = (id, delta) => {
        const order = [...state.order], at = order.indexOf(id), to = Math.max(0, Math.min(order.length - 1, at + delta));
        if (at !== to) { order.splice(at, 1); order.splice(to, 0, id); const next = { ...state, order }; setState(next); set(next); }
      };
      const activate = async (app) => {
        let right = null;
        try { right = typeof getSidebarRight === 'function' ? getSidebarRight() : null; } catch {}
        if (!right || typeof right.openTab !== 'function') { setError(t('unavailable')); return; }
        const request = ++activation.current;
        try {
          const current = getState();
          memory = current;
          const existingTabId = current.tabs?.[app.id];
          if (existingTabId && typeof right.focus === 'function') {
            right.focus(existingTabId);
            if (right.active?.()?.id === existingTabId) {
              if (request !== activation.current) return;
              setError('');
              const next = { ...memory, lastActive: app.id }; setState(next); set(next);
              return;
            }
          }
          const opened = right.openTab('browser', { params: { url: app.url }, revealIfOpened: true });
          if (opened && typeof opened.then === 'function') await opened;
        } catch {
          if (request === activation.current) setError(t('unavailable'));
          return;
        }
        if (request !== activation.current) return;
        setError('');
        const tabId = right.active?.()?.id;
        const tabs = tabId ? { ...memory.tabs, [app.id]: tabId } : memory.tabs;
        const next = { ...memory, lastActive: app.id, tabs }; setState(next); set(next);
      };
      const shown = state.order.map((id) => APPS.find((app) => app.id === id)).filter((app) => app && !state.hidden.includes(app.id));
      return h('div', { className: 'dshadock dock-tray', role: 'toolbar', tabIndex: 0, 'aria-label': t('dockLabel') },
        ...shown.map((app) => h('button', { key: app.id, type: 'button', title: app.label, 'aria-label': app.label, 'data-app': app.id, 'aria-current': state.lastActive === app.id ? 'true' : undefined, onClick: () => activate(app), onKeyDown: (event) => { if (event.altKey && event.key === 'ArrowUp') { event.preventDefault(); move(app.id, -1); } if (event.altKey && event.key === 'ArrowDown') { event.preventDefault(); move(app.id, 1); } } }, h('span', { className: 'dshadock-icon', 'aria-hidden': 'true' }, serviceIcon(h, app.id)))),
        error ? h('span', { role: 'status' }, error) : null);
    }
    function serviceIcon(h, id) {
      const svg = (children, viewBox = '0 0 24 24') => h('svg', { viewBox, fill: 'none', 'aria-hidden': 'true' }, ...children);
      if (id === 'x') return svg([h('path', { d: 'M18.9 1.15h3.68l-8.04 9.19L24 22.85h-7.4l-5.8-7.58-6.64 7.58H.48l8.6-9.83L0 1.15h7.59l5.24 6.93L18.9 1.15Zm-1.29 19.6h2.04L6.48 3.14H4.29L17.61 20.75Z', fill: 'currentColor' })]);
      if (id === 'instagram') return svg([h('rect', { x: '3.2', y: '3.2', width: '17.6', height: '17.6', rx: '5.2', stroke: 'currentColor', strokeWidth: '2' }), h('circle', { cx: '12', cy: '12', r: '4.1', stroke: 'currentColor', strokeWidth: '2' }), h('circle', { cx: '17.7', cy: '6.5', r: '1.15', fill: 'currentColor' })]);
      if (id === 'youtube') return svg([h('path', { d: 'M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2 31 31 0 0 0 0 12a31 31 0 0 0 .5 5.8 3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1A31 31 0 0 0 24 12a31 31 0 0 0-.5-5.8Z', fill: 'currentColor' }), h('path', { d: 'm9.6 15.6 6.2-3.6-6.2-3.6v7.2Z', fill: '#fff' })]);
      if (id === 'discord') return svg([h('path', { d: 'M19.73 5.21a18.2 18.2 0 0 0-4.48-1.39l-.55 1.12a16.9 16.9 0 0 0-5.4 0l-.56-1.12a18.3 18.3 0 0 0-4.48 1.4C1.42 9.4.65 13.48 1.03 17.5a18.1 18.1 0 0 0 5.5 2.78l1.18-1.92a11.8 11.8 0 0 1-1.86-.9l.46-.36a12.9 12.9 0 0 0 11.38 0l.46.36c-.6.36-1.22.66-1.87.9l1.18 1.92a18.1 18.1 0 0 0 5.5-2.78c.45-4.66-.77-8.7-3.23-12.29ZM8.53 14.96c-1.1 0-2-.99-2-2.2s.88-2.2 2-2.2 2.01.99 2 2.2c0 1.21-.88 2.2-2 2.2Zm6.94 0c-1.1 0-2-.99-2-2.2s.88-2.2 2-2.2 2.01.99 2 2.2c0 1.21-.88 2.2-2 2.2Z' })]);
      return h('svg', { viewBox: '0 0 48 48', 'aria-hidden': 'true' }, h('path', { fill: '#4285F4', d: 'M43.6 24.5c0-1.4-.1-2.8-.4-4.1H24v7.8h11a9.4 9.4 0 0 1-4.1 6.2v5.1h6.6c3.9-3.6 6.1-8.8 6.1-15Z' }), h('path', { fill: '#34A853', d: 'M24 44c5.5 0 10.1-1.8 13.5-4.8l-6.6-5.1c-1.8 1.2-4.1 2-6.9 2-5.3 0-9.8-3.6-11.4-8.4H5.8v5.3A20 20 0 0 0 24 44Z' }), h('path', { fill: '#FBBC05', d: 'M12.6 27.7a12 12 0 0 1 0-7.4V15H5.8a20 20 0 0 0 0 18l6.8-5.3Z' }), h('path', { fill: '#EA4335', d: 'M24 11.9c3 0 5.7 1 7.8 3.1l5.9-5.9C34.1 5.8 29.5 4 24 4A20 20 0 0 0 5.8 15l6.8 5.3c1.6-4.8 6.1-8.4 11.4-8.4Z' }));
    }
    return {
      name: 'dsh-app-dock', inject: ['slots', 'locale'],
      apply(ctx) {
        ctx.effect(() => () => style?.remove(), 'dsh-app-dock.styles');
        ctx.effect(() => ctx.locale.register(NS, { en: { dockLabel: 'App dock', unavailable: 'Browser tab is unavailable' }, ja: { dockLabel: 'アプリDock', unavailable: 'ブラウザタブを利用できません' } }), 'dsh-app-dock.locale');
        ctx.effect(() => ctx.slots.inject('shell.overlay', () => ctx.slots.register({ name: 'shell.overlay', id: ID, order: 200, locale: NS, inject: () => ({ sidebarRight: () => ctx.get?.('sidebarRight') }) }, Dock)), 'dsh-app-dock.widget');
      },
      __test: { ID, NS, KEY, DEFAULTS, APPS, normalize, Dock },
    };
  },
});

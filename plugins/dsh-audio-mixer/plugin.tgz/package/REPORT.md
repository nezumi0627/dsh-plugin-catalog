# dsh-audio-mixer verification report

Verified on Windows in this workspace. No profile registration was performed.

## Commands and output

`node --check index.js` and `node --check client.js`: no output, exit 0.

`node test-host.mjs`:

```text
26/26 host checks passed
```

`node test-client.mjs`:

```text
13/13 client checks passed
```

`node test-render.mjs`:

```text
17/17 render checks passed
```

`pwsh -NoProfile -File host/mixer.ps1 -Probe`:

```json
{"capability":"master","caveat":"","status":"supported"}
{"capability":"per-app","caveat":"no readable active sessions","status":"unsupported"}
{"capability":"mute","caveat":"endpoint mute control","status":"supported"}
{"capability":"output select","caveat":"IPolicyConfig is undocumented and not implemented; unsupported","status":"unsupported"}
{"capability":"input","caveat":"capture endpoint volume and mute controls","status":"supported"}
{"capability":"read-back","caveat":"values read from Core Audio after each operation","status":"supported"}
```

## Verified limits

- Live endpoint master volume, mute and post-operation read-back are supported by this probe.
- There were no readable active per-application audio sessions at probe time, so per-app session changes are not live-verified.
- Output-device selection is not implemented; `IPolicyConfig` is undocumented and deliberately not claimed as working.
- Active capture endpoint volume and mute use `IAudioEndpointVolume`, with endpoint-flow and active-state revalidation before every write. A device that does not expose the endpoint-volume interface remains read-only.
- UI polling is 1 Hz only while the settings page is mounted and visible; hiding or unmounting stops it.
- No live device change, input-level operation, or app-session volume change was demonstrated. This is separate from media-session playback/volume in Dynamic Hub.

## Capture endpoint controls (2026-10-12)

Added input endpoint volume/mute actions, strict endpoint-ID validation at the route boundary, active capture endpoint revalidation in the Windows host, and accessible per-device controls. Default-device switching remains explicitly unsupported. Regression tests exercise action validation, JSONL command routing, input slider/mute rendering, and unsupported output-selection rejection. The live probe is read-only; no microphone setting was changed.

## Invalid snapshot guard (2026-10-12)

When the host labels master audio control supported but returns a null/non-finite volume, the UI previously exposed an enabled range input backed by fallback value 0 and rendered `null%`. Added a regression test; it failed on the enabled slider. Range controls now disable on invalid samples and show an em dash with accessible `Unavailable` value text. Fresh syntax, host 23/23, client 13/13, and render 12/12 checks passed.

import assert from 'node:assert/strict';
import { ROUTE_PATH, TOKEN_PATH, BOOTSTRAP_KEY, validateAction, createRouteHandler, startAudioHost } from './index.js';

assert.equal(ROUTE_PATH, '/local/audio-mixer');
assert.equal(TOKEN_PATH, '/local/audio-mixer-token');
assert.equal(BOOTSTRAP_KEY, '__DSH_AUDIO_MIXER__');
assert.throws(() => validateAction({ action: 'nope' }), /invalid action/);
assert.equal(validateAction({ action: 'set-master', params: { volume: 150 } }).params.volume, 100);
assert.equal(validateAction({ action: 'set-app', params: { pid: 4, volume: -1 } }).params.volume, 0);
assert.deepEqual(validateAction({ action: 'set-app-id', params: { appId: 'Spotify.Player', volume: 42 } }), {
  action: 'set-app-id', params: { appId: 'Spotify.Player', volume: 42 },
});
assert.throws(() => validateAction({ action: 'set-app-id', params: { appId: '', volume: 40 } }), /invalid app id/);
assert.throws(() => validateAction({ action: 'set-app-id', params: { appId: 'x'.repeat(513), volume: 40 } }), /invalid app id/);
assert.deepEqual(validateAction({ action: 'set-input', params: { id: 'endpoint-capture-1', volume: 130 } }), { action: 'set-input', params: { id: 'endpoint-capture-1', volume: 100 } });
assert.throws(() => validateAction({ action: 'set-input-mute', params: { id: 'bad\nendpoint', muted: true } }), /invalid device id/);
assert.throws(() => validateAction({ action: 'set-default-output', params: { id: 'endpoint-render-1' } }), /invalid action/);

const childEvents = [];
let outputText = '';
const child = {
  done: new Promise(() => {}),
  collected: { stdout: { readFrom: () => ({ text: outputText, nextOffset: outputText.length }) } },
  stdin: { write: async (line) => { childEvents.push(JSON.parse(line)); outputText += JSON.stringify({ id: JSON.parse(line).id, snapshot: { master: { volume: 41, supported: true }, apps: [], outputs: [], inputs: [] } }) + '\n'; } },
  terminate: () => childEvents.push('terminated'),
};
let spawnCount = 0;
const subprocess = {
  resolveExecutable: async (bin) => bin,
  spawn: (options) => { spawnCount++; childEvents.push(options); return child; },
};
const host = await startAudioHost(subprocess, { platform: 'win32' });
const response = await host.command({ action: 'set-master', params: { volume: 41 } });
await host.command({ action: 'set-app-id', params: { appId: 'Spotify.Player', volume: 42 } });
await host.command({ action: 'set-input', params: { id: 'endpoint-capture-1', volume: 61 } });
await host.command({ action: 'set-input-mute', params: { id: 'endpoint-capture-1', muted: true } });
assert.equal(spawnCount, 1);
assert.equal(childEvents.filter((event) => typeof event === 'object' && event.action).length, 4);
assert.deepEqual(childEvents.find((event) => event?.action === 'set-app-id'), { id: '2', action: 'set-app-id', params: { appId: 'Spotify.Player', volume: 42 } });
assert.deepEqual(childEvents.find((event) => event?.action === 'set-input'), { id: '3', action: 'set-input', params: { id: 'endpoint-capture-1', volume: 61 } });
assert.deepEqual(childEvents.find((event) => event?.action === 'set-input-mute'), { id: '4', action: 'set-input-mute', params: { id: 'endpoint-capture-1', muted: true } });
assert.equal(response.master.volume, 41);
host.dispose();
assert.ok(childEvents.includes('terminated'));

const audio = await startAudioHost({ spawn: () => { throw new Error('unavailable'); }, resolveExecutable: async () => 'pwsh.exe' }, { platform: 'win32' });
const route = createRouteHandler(audio, 'secret');
async function request(method, headers = {}, body = '') {
  const chunks = body ? [Buffer.from(body)] : [];
  const req = { method, headers, async *[Symbol.asyncIterator]() { yield* chunks; } };
  return new Promise((resolve) => { const res = { writeHead(status) { this.status = status; }, end(text) { resolve({ status: this.status, data: JSON.parse(text) }); } }; route(req, res); });
}
assert.equal((await request('GET')).status, 403);
assert.equal((await request('GET', { 'x-dsh-audio-mixer-token': 'secret', 'sec-fetch-site': 'cross-site' })).status, 403);
assert.equal((await request('DELETE', { 'x-dsh-audio-mixer-token': 'secret' })).status, 405);
assert.equal((await request('POST', { 'x-dsh-audio-mixer-token': 'secret' }, '{bad')).status, 400);
assert.equal((await request('GET', { 'x-dsh-audio-mixer-token': 'secret' })).status, 200);
const disposed = [];
const registeredRoutes = new Map();
let authenticated = false;
let indexInject;
const ctx = {
  inject: (services, fn) => { assert.deepEqual(services, ['webServer', 'subprocess']); fn({
    webServer: { register: (route) => { registeredRoutes.set(route.path, route); disposed.push(route.path); return () => disposed.push(`off:${route.path}`); },
      },
    on: (event, fn) => { assert.equal(event, 'webserver/index-inject'); indexInject = fn; },
    effect: (fn) => fn(), get: () => ({ isAuthenticated: () => authenticated }), subprocess,
  }); },
  effect: (fn) => fn(), logger: { info() {} },
};
const { apply } = await import('./index.js');
apply(ctx);
const rows = []; indexInject(rows);
assert.equal(rows[0].name, BOOTSTRAP_KEY);
assert.deepEqual(disposed.slice(0, 2), [ROUTE_PATH, TOKEN_PATH]);
const tokenRoute=registeredRoutes.get(TOKEN_PATH);
const tokenStatus=await new Promise((resolve)=>tokenRoute.handler({method:'GET',headers:{}},{writeHead(status){this.status=status},end(){resolve(this.status)}}));
assert.equal(tokenStatus,401,'unauthenticated token request is refused');
authenticated=true;
const tokenOk=await new Promise((resolve)=>tokenRoute.handler({method:'GET',headers:{}},{writeHead(status){this.status=status},end(){resolve({status:this.status,headers:this.headers})}}));
assert.equal(tokenOk.status,200,'authenticated token handshake succeeds');
assert.equal((await request('POST',{ 'x-dsh-audio-mixer-token':'secret'},'x'.repeat(8193))).status,400,'oversized request body is bounded');
console.log('26/26 host checks passed');

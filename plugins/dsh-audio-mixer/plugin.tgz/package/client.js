window.__ModuleLoader__.load({
  id: '@local/dsh-audio-mixer',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useState, useEffect, useCallback } = React;
    const { IconMicrophoneOutlineRegular, IconSlidersTwoOutlineRegular } = require('@deepseek-ai/dsh-client-ui-primitives');
    const ID = '@local/dsh-audio-mixer', NS = 'dshAudioMixer';
    function createCoalescer(send, delay = 100, schedule = setTimeout, cancel = clearTimeout) {
      let timer = null, latest = null;
      const flush = () => { timer = null; if (latest) { const value = latest; latest = null; send(...value); } };
      const push = (...value) => { latest = value; if (timer !== null) cancel(timer); timer = schedule(flush, Math.max(80, delay)); };
      push.cancel = () => { if (timer !== null) cancel(timer); timer = null; latest = null; };
      return push;
    }
    const css = `
      .dsham-page{max-width:760px;margin:0 auto;padding:24px;color:var(--dsw-alias-label-primary);font-family:var(--dsw-font-family)}
      .dsham-head{display:flex;align-items:center;gap:12px;margin-bottom:22px}.dsham-head svg{color:var(--dsw-alias-state-business-primary)}
      .dsham-title{font:var(--dsw-font-s-14-strong);margin:0}.dsham-updated{margin-left:auto;color:var(--dsw-alias-label-caption);font:var(--dsw-font-xxs-12);font-variant-numeric:tabular-nums}
      .dsham-card{padding:18px;margin:12px 0;background:var(--dsw-alias-bg-layer-1);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-lg)}
      .dsham-section{font:var(--dsw-font-xs-13-strong);margin:0 0 16px;color:var(--dsw-alias-label-secondary)}
      .dsham-slider{display:grid;grid-template-columns:20px minmax(0,1fr) 44px;align-items:center;gap:10px;font:var(--dsw-font-xxs-12);color:var(--dsw-alias-label-secondary);margin:12px 0}
      .dsham-slider input[type=range]{-webkit-appearance:none;appearance:none;width:100%;height:4px;border-radius:999px;background:var(--dsw-alias-interactive-bg-hover);outline-offset:2px}
      .dsham-slider input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:12px;height:12px;border-radius:50%;background:var(--dsw-alias-label-primary);border:.5px solid var(--dsw-alias-border-l3);cursor:pointer}
      .dsham-num{width:44px;text-align:right;color:var(--dsw-alias-label-primary);font-variant-numeric:tabular-nums}
      .dsham-row{display:flex;align-items:center;gap:10px;min-height:34px}.dsham-name{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}
      .dsham-glyph{width:20px;height:20px;display:grid;place-items:center;border-radius:var(--dsw-radius-sm);background:var(--dsw-alias-bg-layer-2);color:var(--dsw-alias-label-secondary);font:var(--dsw-font-xxs-12-strong)}
      .dsham-mute{border:.5px solid var(--dsw-alias-border-l2);border-radius:var(--dsw-radius-sm);background:transparent;color:var(--dsw-alias-label-secondary);padding:5px 9px;cursor:pointer;font:var(--dsw-font-xxs-12)}
      .dsham-mute:hover{background:var(--dsw-alias-interactive-bg-hover)}.dsham-muted{color:var(--dsw-alias-state-warn-primary)}
      .dsham-note{color:var(--dsw-alias-label-secondary);font:var(--dsw-font-xxs-12);padding:8px 0}.dsham-device{display:flex;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:.5px solid var(--dsw-alias-border-l1);font:var(--dsw-font-xxs-12)}
      .dsham-device:last-child{border:0}.dsham-default{color:var(--dsw-alias-state-success-primary)}
      @media (prefers-reduced-motion:reduce){.dsham-page *{scroll-behavior:auto!important;transition:none!important}}
    `;
    const style = typeof document === 'undefined' ? null : (() => { const el=document.createElement('style');el.setAttribute('data-plugin-css',ID);el.textContent=css;document.head.append(el);return el; })();
    let locale = (key) => key;
    const text = { ja: { title:'オーディオミキサー', master:'マスター', apps:'アプリ別音量', outputs:'出力デバイス', inputs:'入力デバイス', unsupported:'この操作は現在のデバイスで非対応です', unavailable:'オーディオ情報を取得できません', updated:'最終更新', mute:'ミュート', unmute:'ミュート解除', default:'既定', noapps:'音量を調整できるアプリセッションがありません', devicesUnsupported:'デバイス切替は非対応です', retry:'再接続' }, en: { title:'Audio Mixer', master:'Master', apps:'Application volume', outputs:'Output devices', inputs:'Input devices', unsupported:'This control is not supported by the current device', unavailable:'Audio information is unavailable', updated:'Last updated', mute:'Mute', unmute:'Unmute', default:'Default', noapps:'No controllable application sessions', devicesUnsupported:'Device switching is unsupported', retry:'Retry' } };
    const t = (key) => text[(locale('locale') || 'en').slice(0,2)]?.[key] ?? text.en[key] ?? key;
    let bootstrap = window.__DSH_AUDIO_MIXER__;
    async function handshake() {
      if (!bootstrap?.token) {
        const r = await fetch('/local/audio-mixer-token', { cache:'no-store' });
        if (!r.ok) throw new Error('Audio mixer connection unavailable');
        bootstrap = (await r.json()).data;
      }
      return bootstrap;
    }
    async function request(action, params) {
      const b = await handshake();
      const options={ method: action ? 'POST' : 'GET', cache:'no-store', headers:{ 'x-dsh-audio-mixer-token':b.token, ...(action ? {'content-type':'application/json'} : {}) }, body:action ? JSON.stringify({action,params}) : undefined };
      let r = await fetch(b.path, options);
      if (r.status === 403) { bootstrap = null; const retry = await handshake(); options.headers['x-dsh-audio-mixer-token']=retry.token; r=await fetch(retry.path,options); }
      const data=await r.json(); if(!r.ok||!data.ok)throw new Error(data.error||'Audio mixer request failed'); return data.data;
    }
    function MixerPage(props = {}) {
      const [snapshot,setSnapshot]=useState(props.snapshot ?? null), [error,setError]=useState(''), [stamp,setStamp]=useState(0);
      const refresh=useCallback(async()=>{try{const next=await request();setSnapshot(next);setStamp(Date.now());setError('')}catch{setError(t('unavailable'))}},[]);
      useEffect(()=>{let active=true,timer=null;const tick=()=>{if(active&&document.visibilityState==='visible')refresh()};const stop=()=>{if(timer!==null){clearInterval(timer);timer=null}};const start=()=>{if(active&&document.visibilityState==='visible'&&timer===null){tick();timer=setInterval(tick,1000)}};const vis=()=>document.visibilityState==='visible'?start():stop();document.addEventListener('visibilitychange',vis);start();return()=>{active=false;stop();document.removeEventListener('visibilitychange',vis)}},[refresh]);
      const mutate=async(action,params)=>{try{const next=await request(action,params);setSnapshot(next);setStamp(Date.now());setError('')}catch{setError(t('unsupported'))}};
      const [queueChange]=useState(()=>createCoalescer((action,params)=>mutate(action,params),100));
      useEffect(()=>()=>queueChange.cancel(),[queueChange]);
      const range=(label,value,onChange,enabled=true)=>h('div',{className:'dsham-slider'},h('span',null,''),h('input',{type:'range',min:0,max:100,step:1,value:Number.isFinite(value)?value:0,disabled:!enabled||!Number.isFinite(value),'aria-label':label,'aria-valuetext':Number.isFinite(value)?`${value}%`:'Unavailable',onChange:(e)=>onChange(Number(e.target.value))}),h('span',{className:'dsham-num'},Number.isFinite(value)?`${value}%`:'—'));
      const master=snapshot?.master;
      return h('main',{className:'dsham-page'},h('header',{className:'dsham-head'},h(IconSlidersTwoOutlineRegular,{size:20,stroke:'currentColor'}),h('h1',{className:'dsham-title'},t('title')),h('span',{className:'dsham-updated'},stamp?`${t('updated')} ${new Date(stamp).toLocaleTimeString()}`:'')),error?h('p',{role:'status',className:'dsham-note'},error,' ',h('button',{type:'button',className:'dsham-mute',onClick:refresh},t('retry'))):null,
        h('section',{className:'dsham-card'},h('h2',{className:'dsham-section'},t('master')),master?.supported ? h(React.Fragment,null,range(t('master'),master.volume,(volume)=>queueChange('set-master',{volume})),h('button',{type:'button',className:`dsham-mute${master.muted?' dsham-muted':''}`,'aria-pressed':!!master.muted,'aria-label':master.muted?t('unmute'):t('mute'),onClick:()=>mutate('set-mute',{muted:!master.muted})},master.muted?t('unmute'):t('mute'))) : h('p',{className:'dsham-note'},master?.reason||t('unavailable'))),
        h('section',{className:'dsham-card'},h('h2',{className:'dsham-section'},t('apps')),snapshot?.apps?.length?snapshot.apps.map((app)=>h('div',{key:app.pid,className:'dsham-row'},h('span',{className:'dsham-glyph','aria-hidden':true},h('svg',{width:14,height:14,viewBox:'0 0 16 16',fill:'none',stroke:'currentColor','stroke-width':1.4},h('rect',{x:2,y:3,width:12,height:10,rx:2}),h('path',{d:'M2 6h12M5 4.5h.1'})) ),h('span',{className:'dsham-name'},app.name),app.supported?range(app.name,app.volume,(volume)=>queueChange('set-app',{pid:app.pid,volume})):h('span',{className:'dsham-note'},t('unsupported')),app.supported?h('button',{type:'button',className:`dsham-mute${app.muted?' dsham-muted':''}`,'aria-pressed':!!app.muted,'aria-label':`${app.muted?t('unmute'):t('mute')} ${app.name}`,onClick:()=>mutate('set-app-mute',{pid:app.pid,muted:!app.muted})},app.muted?t('unmute'):t('mute')):null)):h('p',{className:'dsham-note'},snapshot?t('noapps'):t('unavailable'))),
        h('section',{className:'dsham-card'},h('h2',{className:'dsham-section'},t('outputs')),snapshot?.outputs?.length?snapshot.outputs.map((device)=>h('div',{className:'dsham-device',key:device.id},h('span',null,device.name),h('span',{className:device.isDefault?'dsham-default':''},device.isDefault?t('default'):''))):h('p',{className:'dsham-note'},t('unavailable')),h('p',{className:'dsham-note'},t('devicesUnsupported'))),
        h('section',{className:'dsham-card'},h('h2',{className:'dsham-section'},h(IconMicrophoneOutlineRegular,{size:16,stroke:'currentColor'}),' ',t('inputs')),snapshot?.inputs?.length?snapshot.inputs.map((device)=>h('div',{className:'dsham-input',key:device.id},h('div',{className:'dsham-device'},h('span',null,device.name),h('span',{className:device.isDefault?'dsham-default':''},device.isDefault?t('default'):'')),device.volumeSupported===true?h(React.Fragment,null,range(device.name,device.volume,(volume)=>queueChange('set-input',{id:device.id,volume})),typeof device.muted==='boolean'?h('button',{type:'button',className:`dsham-mute${device.muted?' dsham-muted':''}`,'aria-pressed':device.muted,'aria-label':`${device.muted?t('unmute'):t('mute')} ${device.name}`,onClick:()=>mutate('set-input-mute',{id:device.id,muted:!device.muted})},device.muted?t('unmute'):t('mute')):h('span',{className:'dsham-note'},t('unsupported'))):h('p',{className:'dsham-note'},t('unsupported')))):h('p',{className:'dsham-note'},t('unavailable'))));
    }
    return { name:'dsh-audio-mixer', inject:['slots','locale'], apply(ctx) { locale=(key)=>{try{return ctx.locale.getLocale()?.active}catch{return undefined}}; ctx.effect(()=>()=>style?.remove(),'dsh-audio-mixer.styles'); ctx.effect(()=>ctx.locale.register(NS,{ja:text.ja,en:text.en}),'dsh-audio-mixer.locale'); ctx.effect(()=>ctx.slots.inject('settings.section',()=>ctx.slots.register({name:'settings.section',id:'audio-mixer',order:90,label:()=>t('title')},MixerPage)),'dsh-audio-mixer.page'); }, __test:{ MixerPage, request, createCoalescer, rangeText:(value)=>`${value}%`, css } };
  },
});

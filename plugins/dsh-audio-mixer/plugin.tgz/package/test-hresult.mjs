import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

const shell = process.env.PWSH_EXE || 'pwsh';
const script = fileURLToPath(new URL('./host/mixer.ps1', import.meta.url));
const output = execFileSync(shell, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, '-TestHResult'], { encoding: 'utf8' });
assert.match(output, /HRESULT policy passed/);
const appIdOutput = execFileSync(shell, ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', script, '-TestAppId'], { encoding: 'utf8' });
assert.match(appIdOutput, /AppUserModelId matching policy passed/);
const source = readFileSync(script, 'utf8');
const volumeCalls = [...source.matchAll(/\b(?:v|volume)\.(GetMasterVolumeLevelScalar|GetMasterVolume|GetMute|SetMasterVolumeLevelScalar|SetMasterVolume|SetMute)\s*\(/g)];
for (const call of volumeCalls) {
  const statementStart = source.lastIndexOf(';', call.index) + 1;
  assert.match(source.slice(statementStart, call.index), /CheckHResult\s*\($/, `${call[1]} must check its HRESULT`);
}
console.log('HRESULT policy: S_OK accepted; E_FAIL throws');

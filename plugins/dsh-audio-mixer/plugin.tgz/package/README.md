# DSH Audio Mixer

Windows Core Audio (WASAPI/COM) control surface, separate from Dynamic Hub's Windows media-session transport. The settings page reports endpoint master level/mute and readable application audio sessions with read-back. Sessions include the Windows AppUserModelId when Windows exposes one; the `set-app-id` action changes all matching sessions and never guesses from a process name. Active capture endpoints expose their own volume and mute controls when `IAudioEndpointVolume` is available; each write rechecks that the endpoint is still an active capture endpoint. Default output/input device switching remains unsupported and is not presented as working.

The host keeps one PowerShell 5.1 process for JSONL requests. The settings view polls at 1 Hz only while mounted and the page is visible. Each slider uses keyboard-accessible native range input and posts a confirmed read-back rather than optimistic animation. Unsupported endpoints/sessions are shown as unavailable.

## Verification
Run `node --check index.js`, `node --check client.js`, `pwsh -NoProfile -File host/mixer.ps1 -Probe`, `node test-host.mjs`, `node test-client.mjs`, and `node test-render.mjs`. The PowerShell checks also cover exact AppUserModelId matching. Real probe output and limitations are recorded in `REPORT.md`.

No dependencies. Not registered in any profile; the Lead owns profile wiring.

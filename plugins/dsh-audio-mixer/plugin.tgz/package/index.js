import { randomBytes, timingSafeEqual } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

export const name = 'dsh-audio-mixer';
export const ROUTE_PATH = '/local/audio-mixer';
export const TOKEN_PATH = '/local/audio-mixer-token';
export const BOOTSTRAP_KEY = '__DSH_AUDIO_MIXER__';
export const TOKEN_HEADER = 'x-dsh-audio-mixer-token';
const MAX_BODY = 8 * 1024;
const MAX_OUTPUT = 1024 * 1024;
const SCRIPT = resolve(dirname(fileURLToPath(import.meta.url)), 'host/mixer.ps1');
const ACTIONS = new Set(['set-master', 'set-app', 'set-app-id', 'set-mute', 'set-app-mute', 'set-input', 'set-input-mute', 'refresh']);

export function clampPercent(value) {
  const number = Number(value);
  if (!Number.isFinite(number)) throw new Error('invalid volume');
  return Math.min(100, Math.max(0, Math.round(number)));
}

export function validateAction(input) {
  if (!input || typeof input !== 'object' || !ACTIONS.has(input.action)) throw new Error('invalid action');
  const params = input.params && typeof input.params === 'object' ? { ...input.params } : {};
  if (['set-master', 'set-app', 'set-app-id', 'set-input'].includes(input.action)) params.volume = clampPercent(params.volume);
  if (['set-mute', 'set-app-mute', 'set-input-mute'].includes(input.action) && typeof params.muted !== 'boolean') throw new Error('invalid muted value');
  if (input.action === 'set-app' || input.action === 'set-app-mute') {
    params.pid = Number(params.pid);
    if (!Number.isSafeInteger(params.pid) || params.pid <= 0) throw new Error('invalid pid');
  }
  if (input.action === 'set-app-id') {
    if (typeof params.appId !== 'string' || params.appId.length === 0 || params.appId.length > 512 || /[\u0000-\u001f]/.test(params.appId)) throw new Error('invalid app id');
  }
  if (input.action === 'set-input' || input.action === 'set-input-mute') {
    if (typeof params.id !== 'string' || params.id.length === 0 || params.id.length > 512 || /[\u0000-\u001f\u007f]/u.test(params.id)) throw new Error('invalid device id');
  }
  return { action: input.action, params };
}

export function authorized(req, token) {
  if (req?.headers?.['sec-fetch-site'] === 'cross-site') return false;
  const supplied = req?.headers?.[TOKEN_HEADER];
  if (typeof supplied !== 'string' || supplied.length !== token.length) return false;
  return timingSafeEqual(Buffer.from(supplied), Buffer.from(token));
}

export async function startAudioHost(subprocess, options = {}) {
  let child;
  let outputOffset = 0;
  let pending = '';
  let nextId = 0;
  const waiting = new Map();
  const platform = options.platform ?? process.platform;
  const unavailable = { master: { supported: false, reason: platform !== 'win32' ? 'Windows only' : 'Audio service unavailable' }, apps: [], outputs: [], inputs: [], updatedAt: Date.now() };
  if (platform === 'win32' && subprocess?.spawn && subprocess?.resolveExecutable) {
    try {
      const exe = await subprocess.resolveExecutable('powershell.exe');
      child = subprocess.spawn({ argv: [exe, '-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', SCRIPT], cwd: dirname(SCRIPT), stdio: { stdin: 'pipe', stdout: { maxBytes: MAX_OUTPUT }, stderr: { maxBytes: 32 * 1024 } }, graceMs: 500 });
      child.done.catch((error) => { for (const waiter of waiting.values()) waiter.reject(error); waiting.clear(); });
    } catch { child = null; }
  }
  const readLoop = async () => {
    while (child && waiting.size) {
      const output = child.collected.stdout?.readFrom(outputOffset);
      if (output?.text) {
        outputOffset = output.nextOffset;
        pending += output.text;
        if (pending.length > MAX_OUTPUT) throw new Error('audio host output limit exceeded');
        const lines = pending.split(/\r?\n/); pending = lines.pop() ?? '';
        for (const line of lines) {
          if (!line) continue;
          let message;
          try { message = JSON.parse(line); } catch { continue; }
          const waiter = waiting.get(message.id);
          if (waiter) { waiting.delete(message.id); message.error ? waiter.reject(new Error(message.error)) : waiter.resolve(message.snapshot); }
        }
      }
      if (waiting.size) await new Promise((resolve) => setTimeout(resolve, 35));
    }
  };
  let pumping = false;
  async function command(input = { action: 'refresh', params: {} }) {
    const validated = validateAction(input);
    if (!child) return structuredClone(unavailable);
    const id = String(++nextId);
    const result = new Promise((resolve, reject) => waiting.set(id, { resolve, reject }));
    const line = JSON.stringify({ id, ...validated }) + '\n';
    try {
      await child.stdin.write(line);
    } catch (error) {
      waiting.delete(id);
      throw error;
    }
    if (!pumping) {
      pumping = true;
      readLoop().catch((error) => { for (const waiter of waiting.values()) waiter.reject(error); waiting.clear(); }).finally(() => { pumping = false; });
    }
    return result;
  }
  return { command, snapshot: () => command({ action: 'refresh', params: {} }), dispose: () => child?.terminate?.() };
}

async function readBody(req) {
  let body = '', bytes = 0;
  for await (const chunk of req) {
    bytes += Buffer.byteLength(chunk);
    if (bytes > MAX_BODY) throw new Error('request body too large');
    body += chunk;
  }
  return body;
}

export function createRouteHandler(audio, token) {
  return async (req, res) => {
    const send = (status, payload) => {
      try { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(payload)); } catch { /* peer disconnected */ }
    };
    if (!authorized(req, token)) return send(403, { ok: false, error: 'forbidden' });
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'POST') return send(405, { ok: false, error: 'method-not-allowed' });
    try {
      const snapshot = req.method === 'GET' || req.method === 'HEAD' ? await audio.snapshot() : await audio.command(JSON.parse(await readBody(req)));
      send(200, { ok: true, data: snapshot });
    } catch (error) { send(400, { ok: false, error: error instanceof Error ? error.message : String(error) }); }
  };
}

export function apply(ctx) {
  ctx.inject(['webServer', 'subprocess'], (webCtx) => {
    const token = randomBytes(24).toString('hex');
    webCtx.effect(() => {
      let audio;
      let stopped = false;
      const ready = startAudioHost(webCtx.subprocess).then((host) => { audio = host; if (stopped) host.dispose(); });
      const handler = async (req, res) => {
        await ready;
        return createRouteHandler(audio, token)(req, res);
      };
      const offRoute = webCtx.webServer.register({ kind: 'exact', path: ROUTE_PATH, handler });
      const offToken = webCtx.webServer.register({ kind: 'exact', path: TOKEN_PATH, handler: (req, res) => {
        const send = (status, data) => { res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }); res.end(JSON.stringify(data)); };
        if (req.method !== 'GET') return send(405, { ok: false, error: 'method-not-allowed' });
        if (req.headers?.['sec-fetch-site'] === 'cross-site') return send(403, { ok: false, error: 'forbidden' });
        if (!webCtx.get?.('connection')?.isAuthenticated?.(req)) return send(401, { ok: false, error: 'unauthorized' });
        send(200, { ok: true, data: { path: ROUTE_PATH, token } });
      } });
      webCtx.on?.('webserver/index-inject', (table) => table.push({ kind: 'global', name: BOOTSTRAP_KEY, value: { path: ROUTE_PATH, token } }));
      return () => { stopped = true; offRoute?.(); offToken?.(); audio?.dispose(); };
    }, 'dsh-audio-mixer: host');
  });
  ctx.logger?.info?.('[audio-mixer] Windows Core Audio mixer active');
}

param([switch]$Probe, [switch]$TestHResult, [switch]$TestAppId)
$ErrorActionPreference = 'Stop'
if (-not $IsWindows -and $PSVersionTable.PSVersion.Major -ge 6) { throw 'Windows only' }

$source = @'
using System;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

public static class AudioCore {
  public static void CheckHResult(int result) { Marshal.ThrowExceptionForHR(result); }
  public static bool MatchesAppId(string candidate, string requested) { return !String.IsNullOrEmpty(candidate) && !String.IsNullOrEmpty(requested) && String.Equals(candidate, requested, StringComparison.OrdinalIgnoreCase); }
  [DllImport("kernel32.dll", SetLastError=true)] static extern IntPtr OpenProcess(uint access, bool inherit, uint processId);
  [DllImport("kernel32.dll", CharSet=CharSet.Unicode, ExactSpelling=true)] static extern int GetApplicationUserModelId(IntPtr process, ref uint length, StringBuilder appId);
  [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr handle);
  static string ApplicationId(uint pid) {
    IntPtr process=OpenProcess(0x1000, false, pid);
    if(process==IntPtr.Zero) return null;
    try {
      uint length=0;
      if(GetApplicationUserModelId(process, ref length, null)!=122 || length==0 || length>512) return null;
      var value=new StringBuilder((int)length);
      return GetApplicationUserModelId(process, ref length, value)==0 ? value.ToString() : null;
    } catch { return null; } finally { CloseHandle(process); }
  }
  const int CLSCTX_ALL = 23;
  static readonly Guid EnumeratorClsid = new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E");
  static readonly Guid IidEnumerator = new Guid("A95664D2-9614-4F35-A746-DE8DB63617E6");
  static readonly Guid IidEndpointVolume = new Guid("5CDF2C82-841E-4546-9722-0CF74078229A");
  static readonly Guid IidSessionManager2 = new Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F");
  static readonly Guid IidSessionEnumerator = new Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8");
  static readonly Guid IidSessionControl2 = new Guid("BFB7FF88-7239-4FC9-8FA2-07C950BE9C6D");
  static readonly Guid IidSimpleVolume = new Guid("87CE5498-68D6-44E5-9215-6DA47EF883D8");
  [ComImport, Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IMMDeviceEnumerator {
    int EnumAudioEndpoints(int flow, int mask, out IMMDeviceCollection devices);
    int GetDefaultAudioEndpoint(int flow, int role, out IMMDevice device);
    int GetDevice([MarshalAs(UnmanagedType.LPWStr)] string id, out IMMDevice device);
    int RegisterEndpointNotificationCallback(IntPtr callback); int UnregisterEndpointNotificationCallback(IntPtr callback);
  }
  [ComImport, Guid("0BD7A1BE-7A1A-44DB-8397-C0A9A4B5A5A1"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IMMDeviceCollection { int GetCount(out uint count); int Item(uint index, out IMMDevice device); }
  [ComImport, Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IMMDevice {
    int Activate(ref Guid iid, int clsctx, IntPtr activation, [MarshalAs(UnmanagedType.IUnknown)] out object instance);
    int OpenPropertyStore(int access, out IntPtr store); int GetId(out IntPtr id); int GetState(out int state);
  }
  [ComImport, Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IAudioEndpointVolume {
    int RegisterControlChangeNotify(IntPtr notify); int UnregisterControlChangeNotify(IntPtr notify); int GetChannelCount(out uint count);
    int SetMasterVolumeLevel(float db, ref Guid context); int SetMasterVolumeLevelScalar(float level, ref Guid context);
    int GetMasterVolumeLevel(out float db); int GetMasterVolumeLevelScalar(out float level);
    int SetChannelVolumeLevel(uint channel, float db, ref Guid context); int SetChannelVolumeLevelScalar(uint channel, float level, ref Guid context);
    int GetChannelVolumeLevel(uint channel, out float db); int GetChannelVolumeLevelScalar(uint channel, out float level);
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid context); int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
    int GetVolumeStepInfo(out uint step, out uint count); int VolumeStepUp(ref Guid context); int VolumeStepDown(ref Guid context);
    int QueryHardwareSupport(out uint mask); int GetVolumeRange(out float min, out float max, out float increment);
  }
  [ComImport, Guid("77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IAudioSessionManager2 {
    int GetAudioSessionControl(IntPtr guid, int flags, out IntPtr control); int GetSimpleAudioVolume(IntPtr guid, int flags, out IntPtr volume);
    int GetSessionEnumerator(out IAudioSessionEnumerator sessions); int RegisterSessionNotification(IntPtr notification); int UnregisterSessionNotification(IntPtr notification); int RegisterDuckNotification(IntPtr notification); int UnregisterDuckNotification(IntPtr notification);
  }
  [ComImport, Guid("E2F5BB11-0570-40CA-ACDD-3AA01277DEE8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IAudioSessionEnumerator { int GetCount(out int count); int GetSession(int index, out IntPtr control); }
  [ComImport, Guid("BFB7FF88-7239-4FC9-8FA2-07C950BE9C6D"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface IAudioSessionControl2 {
    int GetState(out int state); int GetDisplayName(out IntPtr name); int SetDisplayName([MarshalAs(UnmanagedType.LPWStr)] string name, ref Guid context); int GetIconPath(out IntPtr path); int SetIconPath([MarshalAs(UnmanagedType.LPWStr)] string path, ref Guid context); int GetGroupingParam(out Guid group); int SetGroupingParam(ref Guid group, ref Guid context); int RegisterAudioSessionNotification(IntPtr notification); int UnregisterAudioSessionNotification(IntPtr notification); int GetSessionIdentifier(out IntPtr id); int GetSessionInstanceIdentifier(out IntPtr id); int GetProcessId(out uint pid); int IsSystemSoundsSession(); int SetDuckingPreference([MarshalAs(UnmanagedType.Bool)] bool optOut);
  }
  [ComImport, Guid("87CE5498-68D6-44E5-9215-6DA47EF883D8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)] interface ISimpleAudioVolume { int SetMasterVolume(float level, ref Guid context); int GetMasterVolume(out float level); int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid context); int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute); }
  static IMMDeviceEnumerator Enum() { return (IMMDeviceEnumerator)Activator.CreateInstance(Type.GetTypeFromCLSID(EnumeratorClsid)); }
  static IMMDevice Device(int flow, string id) { var e=Enum(); IMMDevice d; if(String.IsNullOrEmpty(id)) CheckHResult(e.GetDefaultAudioEndpoint(flow,1,out d)); else CheckHResult(e.GetDevice(id,out d)); return d; }
  static IAudioEndpointVolume Endpoint(int flow, string id) { var d=Device(flow,id); var iid=IidEndpointVolume; object o; CheckHResult(d.Activate(ref iid,CLSCTX_ALL,IntPtr.Zero,out o)); return (IAudioEndpointVolume)o; }
  static string Id(IMMDevice d) { IntPtr p; CheckHResult(d.GetId(out p)); string s=Marshal.PtrToStringUni(p); Marshal.FreeCoTaskMem(p); return s; }
  static string Name(IMMDevice d) { return Id(d); }
  public static object Snapshot() {
    var master=new Dictionary<string,object>(); try { var v=Endpoint(0,null); float f; bool m; CheckHResult(v.GetMasterVolumeLevelScalar(out f)); CheckHResult(v.GetMute(out m)); master["supported"]=true; master["volume"]=(int)Math.Round(f*100); master["muted"]=m; } catch(Exception ex) { master["supported"]=false; master["reason"]=ex.Message; }
    var outputs=Endpoints(0); var inputs=Endpoints(1); var apps=Sessions();
    return new { master=master, apps=apps, outputs=outputs, inputs=inputs, updatedAt=DateTimeOffset.UtcNow.ToUnixTimeMilliseconds() };
  }
  static object[] Endpoints(int flow) {
    var list=new List<object>();
    try {
      IMMDeviceCollection c; CheckHResult(Enum().EnumAudioEndpoints(flow,1,out c)); uint n; CheckHResult(c.GetCount(out n));
      for(uint i=0;i<n;i++) {
        IMMDevice d; CheckHResult(c.Item(i,out d)); string id=Id(d); bool def=false;
        try { IMMDevice x; CheckHResult(Enum().GetDefaultAudioEndpoint(flow,1,out x)); def=String.Equals(id,Id(x),StringComparison.Ordinal); } catch {}
        var item=new Dictionary<string,object>{{"id",id},{"name",Name(d)},{"isDefault",def},{"volumeSupported",false},{"supported",true}};
        if(flow==1) try { var v=Endpoint(flow,id); float level; bool muted; CheckHResult(v.GetMasterVolumeLevelScalar(out level)); CheckHResult(v.GetMute(out muted)); item["volumeSupported"]=true; item["volume"]=(int)Math.Round(level*100); item["muted"]=muted; } catch {}
        list.Add(item);
      }
    } catch {}
    if(list.Count==0) try {
      IMMDevice d; CheckHResult(Enum().GetDefaultAudioEndpoint(flow,1,out d)); string id=Id(d);
      var item=new Dictionary<string,object>{{"id",id},{"name",Name(d)},{"isDefault",true},{"volumeSupported",false},{"supported",true}};
      if(flow==1) try { var v=Endpoint(flow,id); float level; bool muted; CheckHResult(v.GetMasterVolumeLevelScalar(out level)); CheckHResult(v.GetMute(out muted)); item["volumeSupported"]=true; item["volume"]=(int)Math.Round(level*100); item["muted"]=muted; } catch {}
      list.Add(item);
    } catch {}
    return list.ToArray();
  }
  static IAudioEndpointVolume ActiveEndpoint(int flow,string id) {
    if(String.IsNullOrEmpty(id)) throw new Exception("Audio endpoint unavailable");
    IMMDeviceCollection c; CheckHResult(Enum().EnumAudioEndpoints(flow,1,out c)); uint n; CheckHResult(c.GetCount(out n)); bool found=false;
    for(uint i=0;i<n;i++){IMMDevice d;CheckHResult(c.Item(i,out d));if(String.Equals(Id(d),id,StringComparison.Ordinal)){found=true;break;}}
    if(!found) throw new Exception("Audio endpoint unavailable");
    return Endpoint(flow,id);
  }
  static object[] Sessions() {
    var list=new Dictionary<uint,Dictionary<string,object>>();
    try {
      var d=Device(0,null); var iid=IidSessionManager2; object o;
      CheckHResult(d.Activate(ref iid,CLSCTX_ALL,IntPtr.Zero,out o));
      IAudioSessionEnumerator e; CheckHResult(((IAudioSessionManager2)o).GetSessionEnumerator(out e));
      int n; CheckHResult(e.GetCount(out n));
      for(int i=0;i<n;i++) {
        IntPtr ptr; CheckHResult(e.GetSession(i,out ptr));
        try {
          var control=(IAudioSessionControl2)Marshal.GetObjectForIUnknown(ptr); uint pid;
          CheckHResult(control.GetProcessId(out pid)); if(pid==0) continue;
          string label; try { label=Process.GetProcessById((int)pid).ProcessName; } catch { label="Process "+pid; }
          var app=new Dictionary<string,object>{{"pid",pid},{"name",label},{"appId",ApplicationId(pid)},{"volume",null},{"muted",null},{"supported",false}};
          try {
            var volume=(ISimpleAudioVolume)Marshal.GetObjectForIUnknown(ptr); float level; bool muted;
            CheckHResult(volume.GetMasterVolume(out level)); CheckHResult(volume.GetMute(out muted));
            app["volume"]=(int)Math.Round(level*100); app["muted"]=muted; app["supported"]=true;
          } catch {}
          if(!list.ContainsKey(pid) || Convert.ToBoolean(app["supported"])) list[pid]=app;
        } catch {} finally { Marshal.Release(ptr); }
      }
    } catch {}
    return new List<Dictionary<string,object>>(list.Values).ToArray();
  }
  public static object Execute(string action, Dictionary<string,object> p) {
    if(action=="refresh") return Snapshot();
    if(action=="set-master" || action=="set-mute") { var v=Endpoint(0,null); var g=Guid.Empty; if(action=="set-master")CheckHResult(v.SetMasterVolumeLevelScalar(Convert.ToSingle(p["volume"])/100f,ref g)); else CheckHResult(v.SetMute(Convert.ToBoolean(p["muted"]),ref g)); }
    else if(action=="set-input" || action=="set-input-mute") { var v=ActiveEndpoint(1,Convert.ToString(p["id"])); var g=Guid.Empty; if(action=="set-input")CheckHResult(v.SetMasterVolumeLevelScalar(Convert.ToSingle(p["volume"])/100f,ref g)); else CheckHResult(v.SetMute(Convert.ToBoolean(p["muted"]),ref g)); }
    else if(action=="set-app" || action=="set-app-mute") { var snap=Snapshot(); var apps=(object[])snap.GetType().GetProperty("apps").GetValue(snap); object app=null; foreach(var a in apps) if(Convert.ToInt32(a.GetType().GetProperty("pid").GetValue(a))==Convert.ToInt32(p["pid"])) app=a; if(app==null) throw new Exception("Application session unavailable"); var d=Device(0,null); var iid=IidSessionManager2; object o; CheckHResult(d.Activate(ref iid,CLSCTX_ALL,IntPtr.Zero,out o)); IAudioSessionEnumerator e; CheckHResult(((IAudioSessionManager2)o).GetSessionEnumerator(out e)); int n; CheckHResult(e.GetCount(out n)); for(int i=0;i<n;i++){IntPtr ptr; CheckHResult(e.GetSession(i,out ptr)); try{var c=(IAudioSessionControl2)Marshal.GetObjectForIUnknown(ptr);uint pid;CheckHResult(c.GetProcessId(out pid));if(pid==Convert.ToUInt32(p["pid"])){var v=(ISimpleAudioVolume)Marshal.GetObjectForIUnknown(ptr);var g=Guid.Empty;if(action=="set-app")CheckHResult(v.SetMasterVolume(Convert.ToSingle(p["volume"])/100f,ref g));else CheckHResult(v.SetMute(Convert.ToBoolean(p["muted"]),ref g));}}finally{Marshal.Release(ptr);}} }
    else if(action=="set-app-id") {
      string wanted=Convert.ToString(p["appId"]); var d=Device(0,null); var iid=IidSessionManager2; object o;
      CheckHResult(d.Activate(ref iid,CLSCTX_ALL,IntPtr.Zero,out o)); IAudioSessionEnumerator e;
      CheckHResult(((IAudioSessionManager2)o).GetSessionEnumerator(out e)); int n; CheckHResult(e.GetCount(out n)); int changed=0;
      for(int i=0;i<n;i++){IntPtr ptr; CheckHResult(e.GetSession(i,out ptr)); try{var c=(IAudioSessionControl2)Marshal.GetObjectForIUnknown(ptr);uint pid;CheckHResult(c.GetProcessId(out pid));if(pid!=0 && MatchesAppId(ApplicationId(pid),wanted)){var v=(ISimpleAudioVolume)Marshal.GetObjectForIUnknown(ptr);var g=Guid.Empty;CheckHResult(v.SetMasterVolume(Convert.ToSingle(p["volume"])/100f,ref g));changed++;}}finally{Marshal.Release(ptr);}}
      if(changed==0) throw new Exception("No controllable audio session matches the media application");
    }
    else throw new Exception(action+" is unsupported by this Windows Core Audio host");
    return Snapshot();
  }
}
'@

try { Add-Type -TypeDefinition $source -Language CSharp -ErrorAction Stop } catch { }
if ($TestHResult) {
  [AudioCore]::CheckHResult(0)
  try { [AudioCore]::CheckHResult(-2147467259); throw 'E_FAIL was accepted' }
  catch [System.Runtime.InteropServices.COMException] { }
  [Console]::Out.WriteLine('HRESULT policy passed')
  exit 0
}
if ($TestAppId) {
  if (-not [AudioCore]::MatchesAppId('Spotify.Player', 'spotify.player')) { throw 'case-insensitive app id match failed' }
  if ([AudioCore]::MatchesAppId('Spotify.Player', 'Spotify')) { throw 'partial app id match was accepted' }
  if ([AudioCore]::MatchesAppId($null, 'Spotify.Player')) { throw 'missing app id was accepted' }
  [Console]::Out.WriteLine('AppUserModelId matching policy passed')
  exit 0
}
if ($Probe) {
  $checks = @('master','per-app','mute','output select','input','read-back')
  try { $s=[AudioCore]::Snapshot(); $master=$s.master.supported; $apps=@($s.apps | Where-Object { $_.supported }).Count -gt 0; $outs=$s.outputs.Count -gt 0; $ins=@($s.inputs | Where-Object { $_.volumeSupported }).Count -gt 0 } catch { $master=$false;$apps=$false;$outs=$false;$ins=$false }
  foreach($cap in $checks){
    $supported=$false; $caveat='';
    switch($cap){ 'master' {$supported=$master;if(!$supported){$caveat='endpoint volume unavailable'}} 'per-app' {$supported=$apps;$caveat=if($apps){'sessions listed; per-session volume is available only for readable sessions'}else{'no readable active sessions'}} 'mute' {$supported=$master;$caveat=if($master){'endpoint mute control'}else{'endpoint volume unavailable'}} 'output select' {$caveat='IPolicyConfig is undocumented and not implemented; unsupported'} 'input' {$supported=$ins;$caveat=if($ins){'capture endpoint volume and mute controls'}else{'no active capture endpoint exposes IAudioEndpointVolume'}} 'read-back' {$supported=$master;$caveat=if($master){'values read from Core Audio after each operation'}else{'endpoint volume unavailable'}} }
    [Console]::Out.WriteLine((ConvertTo-Json -Compress @{capability=$cap;status=if($supported){'supported'}else{'unsupported'};caveat=$caveat}))
  }
  exit 0
}
while($line=[Console]::In.ReadLine()) {
  try {
    $request=ConvertFrom-Json $line
    $parameters=@{}; if($request.params){ $request.params.PSObject.Properties | ForEach-Object { $parameters[$_.Name]=$_.Value } }
    $result=[AudioCore]::Execute([string]$request.action,$parameters)
    [Console]::Out.WriteLine((ConvertTo-Json -Compress -Depth 8 @{id=$request.id;snapshot=$result}))
  } catch { [Console]::Out.WriteLine((ConvertTo-Json -Compress @{id=$request.id;error=$_.Exception.Message})) }
}

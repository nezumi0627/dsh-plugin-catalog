/**
 * Offline check for the Browser-tab persistence patch.
 *
 *   node test-browser-persist.mjs
 *
 * Runs against a throwaway copy of the installed app.asar: no installed file is
 * touched. Needs `dsh-locale-ja` next door for the composition check.
 */
import { copyFileSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { ensurePersistentPartition, HOST_EXIT_TRACE_DATA_URL, locateArchive, LEGACY_PATCHED, migrateLegacyPartition, ORIGINAL, PATCHED } from './index.js';
import { closeArchive, findEntry, openArchive, readEntryBuffer, replaceEntries, snapshotEntries } from './lib/asar.js';
import { transformDesktopShell } from '../dsh-locale-ja/desktop/transform.js';

const failures = [];
const check = (label, ok, detail = '') => {
  console.log(`${ok ? 'ok  ' : 'FAIL'}  ${label}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failures.push(label);
};

const real = locateArchive();
if (!real) {
  console.log('SKIP the installed app.asar is absent');
  process.exit(0);
}
check('locates the installed desktop archive', true, real);

const dir = mkdtempSync(join(tmpdir(), 'dsh-browser-persist-'));
const copy = join(dir, 'app.asar');
copyFileSync(real, copy);

/** Read `lib/main.js` of an archive. */
function mainText(path) {
  const handle = openArchive(path);
  try {
    return readEntryBuffer(handle, findEntry(handle.header, ['lib', 'main.js'])).toString('utf8');
  } finally {
    closeArchive(handle);
  }
}

/** Every entry as `path -> offset:size:integrity:unpacked`. */
function snapshot(path) {
  const handle = openArchive(path);
  try {
    return snapshotEntries(handle.header);
  } finally {
    closeArchive(handle);
  }
}

try {
  // Put the copy back into the shipped state, so the apply path is exercised
  // whether or not the installed archive already carries the patch.
  const installed = mainText(copy);
  const shipped = installed.replace(PATCHED, ORIGINAL).replace(LEGACY_PATCHED, ORIGINAL);
  if (shipped !== installed) replaceEntries(copy, [{ parts: ['lib', 'main.js'], content: Buffer.from(shipped, 'utf8') }]);
  check('the copy starts with the shipped partition line', mainText(copy).includes(ORIGINAL));
  check('the persistent browser profile has one stable app-wide partition', PATCHED === 'partition = `persist:dsh-sidebar-browser`;');

  const before = snapshot(copy);
  const applied = ensurePersistentPartition(copy);
  check('applies to a shipped archive', applied.status === 'applied', applied.status);

  const patched = mainText(copy);
  check('the persistent partition line is in place', patched.includes(PATCHED) && !patched.includes(ORIGINAL));
  check('host deprecation warnings include their originating stack', patched.includes('"--trace-deprecation"'));
  check('host failures report the child termination signal', patched.includes('signal=${String(signal)}'));
  check('stderr is labeled diagnostic context rather than asserted as the cause', patched.includes('stderr tail (cause not established):'));
  check('Host starts with the pre-import process-exit tracer', patched.includes(HOST_EXIT_TRACE_DATA_URL));
  const tracedExit = spawnSync(process.execPath, [HOST_EXIT_TRACE_DATA_URL, '-e', 'process.exit(-1)'], { encoding: 'utf8' });
  check('negative process.exit records its synchronous caller stack', tracedExit.status === 0xffffffff && tracedExit.stderr.includes('[dsh-host-exit-trace] process.exit(-1)') && tracedExit.stderr.includes('[eval]'));
  const tracedException = spawnSync(process.execPath, [HOST_EXIT_TRACE_DATA_URL, '-e', 'throw new Error("host-boom")'], { encoding: 'utf8' });
  check('uncaught exceptions are recorded without suppressing Node fatal handling', tracedException.status !== 0 && /\[dsh-host-uncaught\] origin=(uncaughtException|unhandledRejection)/.test(tracedException.stderr) && tracedException.stderr.includes('host-boom') && tracedException.stderr.includes('[eval]'));

  const after = snapshot(copy);
  const changed = [...before].filter(([path, value]) => after.get(path) !== value).map(([path]) => path);
  check('only lib/main.js changed', changed.length === 1 && changed[0] === 'lib/main.js', changed.join(', '));
  check('entry count is unchanged', before.size === after.size);

  // The locale pack rewrites the same file on the same start; that must not undo this.
  const dictionary = JSON.parse(readFileSync(new URL('../dsh-locale-ja/desktop/ja.json', import.meta.url), 'utf8'));
  check('the locale transform keeps the persistent line', transformDesktopShell(patched, dictionary).code.includes(PATCHED));

  check('a second run is a no-op', ensurePersistentPartition(copy).status === 'already-applied');

  const legacyDir = mkdtempSync(join(tmpdir(), 'dsh-browser-persist-legacy-'));
  const legacyCopy = join(legacyDir, 'app.asar');
  copyFileSync(real, legacyCopy);
  const legacySource = mainText(legacyCopy);
  if (legacySource.includes(PATCHED)) replaceEntries(legacyCopy, [{ parts: ['lib', 'main.js'], content: Buffer.from(legacySource.replace(PATCHED, LEGACY_PATCHED), 'utf8') }]);
  const migrated = ensurePersistentPartition(legacyCopy);
  check('migrates an existing workspace-scoped profile to the stable shared profile', migrated.status === 'migrated' && mainText(legacyCopy).includes(PATCHED), migrated.status);
  rmSync(legacyDir, { recursive: true, force: true });

  const profileDir = mkdtempSync(join(tmpdir(), 'dsh-browser-profile-migration-'));
  const legacyProfile = join(profileDir, `dsh-sidebar-browser-${'a'.repeat(64)}`);
  mkdirSync(legacyProfile);
  writeFileSync(join(legacyProfile, 'marker'), 'keep');
  const profileMove = migrateLegacyPartition(profileDir);
  check('moves an existing profile without reading or rewriting its contents', profileMove.status === 'migrated' && readFileSync(join(profileDir, 'dsh-sidebar-browser', 'marker'), 'utf8') === 'keep');
  check('does not overwrite an existing shared profile', migrateLegacyPartition(profileDir).status === 'already-present');
  rmSync(profileDir, { recursive: true, force: true });
} finally {
  rmSync(dir, { recursive: true, force: true });
}

console.log(`\n${failures.length === 0 ? 'ALL CHECKS PASSED' : `${failures.length} FAILURE(S): ${failures.join('; ')}`}`);
process.exitCode = failures.length === 0 ? 0 : 1;

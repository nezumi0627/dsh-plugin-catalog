# dsh-browser-persist

DSH デスクトップシェルの **Browser タブのログインを再起動後も残す** ためだけの Host プラグイン。

## 何をするか

出荷時の `lib/main.js` は Browser タブの保存領域を
`partition = \`dsh-sidebar-browser-${randomUUID()}\`;` と命名する。`persist:` が付かない
Chromium パーティションはメモリ上だけなので、そこで行ったサインイン（通知パネルの埋め込み
ページも同じ領域を共有する）は終了時に消える。また、workspace由来の名前ではセッションや
workspaceの切り替えで保存領域が変わる。この1行をアプリ共通の安定名
`persist:dsh-sidebar-browser` に書き換え、Browserタブ間・workspace間・再起動後で同じ領域を使う。
次回Host起動時に旧workspace別プロファイルがあれば最終更新された1つを新領域へ移動する。
移動に失敗した場合は旧領域をそのまま残し、上書き・削除はしない。

## いつ動くか

Host の起動ごと（`apply(ctx)`）。アプリ更新で `app.asar` が置き換わっても、次回起動時に
自動で再適用される。起動時点でシェルは既に `main.js` を読み終えているため、**反映は次の
起動から**（更新直後の1回はパッチ前の状態で動く）。Host 子プロセスには
`--trace-deprecation` と終了診断プリロードを付け、明示的な異常終了と Node の未捕捉例外を
同期的に stderr へ記録し、終了ログには終了シグナルも残す。これにより警告を原因と誤認せず、
次回の異常終了で発生元スタックを Boot Guard が確認できる。プリロードは終了動作を抑止しない。

## 安全策

- asar のデータ末尾に新しい `main.js` を追記し、ヘッダの該当1件だけを差し替える。他の
  全ファイルはオフセットもバイトも不変なので、起動中のアプリの遅延読み込みを壊さない。
- 書き込み後に全エントリを検証し、対象外のファイルが1つでも変われば例外にして中断する
  （`lib/asar.js`）。
- `package.json` の `name` が `@deepseek-ai/dsh-desktop` のアーカイブ以外は触らない。
- 想定外のレイアウト（対象行が0個/2個以上、`createHash` 未 import など）では書かずに警告。
- 旧セッション領域はファイル単位で読み込まずディレクトリ移動する。複数ある場合は最新の1つだけ採用し、残りは保持する。
- 失敗しても例外を飲み、Host の起動は止めない。

## 使い方

診断と確認:

```
node test-browser-persist.mjs      # 実アーカイブのコピーに対して適用/冪等/非破壊を検証
```

戻したいとき:

1. プロファイル（`dsh.profile.bundles`）から `@local/dsh-browser-persist` を外す。
2. `node _dsh/patch-shell-browser-partition.mjs --restore` で `app.asar.orig-*` から戻す。

外さずに 2 だけ実行しても、次回起動でこのプラグインが再適用する。

## 前提と限界

- asar の完全性検証フューズ（`EnableEmbeddedAsarIntegrityValidation`）が無効であることが前提。
  これは既存の日本語シェルパッチ（`dsh-locale-ja`）と同じ前提で、このプラグイン固有の追加
  リスクではない。
- `lib/asar.js` は `dsh-locale-ja/desktop/asar.js` のコピー（プラグイン単体で完結させるため）。
  書き込み方式を変えるときは両方を直す。
- `_dsh/patch-shell-browser-partition.mjs`（手動版）と `_dsh/apply-shell-patch.cmd` は
  このプラグイン導入後は不要。書き込む内容は同一。

/**
 * Keeps DSH Browser profiles stable across workspaces and improves Host diagnostics.
 *
 * The shipped shell names that storage account
 * `dsh-sidebar-browser-<random uuid>` (lib/main.js, `DesktopBrowserGuests.acquire`).
 * Chromium keeps a partition without the `persist:` prefix in memory only, so
 * every sign-in in the Browser tab - and in the notify panel's embedded page,
 * which deliberately shares that account - dies when the app quits. This host
 * half rewrites that one line to a stable, app-wide name on every start, so an
 * application update cannot silently lose the patch. The same guarded edit
 * traces Host deprecations and records the child exit signal for diagnosis.
 *
 * It writes the way `dsh-locale-ja`'s desktop patch does: the new payload is
 * appended past the end of the data section and that one header entry is
 * repointed, so every other file keeps its exact byte offset and an
 * already-running app keeps reading the bytes it expects.
 *
 * The Host starts after the shell has loaded main.js, so the rewrite takes
 * effect on the next start - the update case included.
 */
import { existsSync, readdirSync, renameSync, statSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { closeArchive, findEntry, openArchive, readEntryBuffer, replaceEntries } from './lib/asar.js';

const FILE = ['lib', 'main.js'];
export const HOST_EXIT_TRACE_SOURCE = 'import { writeSync } from "node:fs"; const trace = (label, detail) => { try { writeSync(2, label + "\\n" + detail + "\\n"); } catch {} }; const exit = process.exit; process.exit = function (...args) { const code = args[0]; if (code !== 0 && code !== undefined) trace("[dsh-host-exit-trace] process.exit(" + String(code) + ")", new Error().stack ?? ""); return Reflect.apply(exit, process, args); }; process.on("uncaughtExceptionMonitor", (error, origin) => trace("[dsh-host-uncaught] origin=" + String(origin), error?.stack ?? String(error)));';
export const HOST_EXIT_TRACE_DATA_URL = `--import=data:text/javascript,${encodeURIComponent(HOST_EXIT_TRACE_SOURCE)}`;
/** The line as shipped. */
export const ORIGINAL = 'partition = `dsh-sidebar-browser-${randomUUID()}`;';
/** Previous workspace-scoped persistent patch, migrated to the shared profile. */
export const LEGACY_PATCHED = 'partition = `persist:dsh-sidebar-browser-${createHash("sha256").update(workspace).digest("hex")}`;';
/** Byte-identical to what `_dsh/patch-shell-browser-partition.mjs` writes. */
export const PATCHED = 'partition = `persist:dsh-sidebar-browser`;';
const SHELL_PACKAGE_NAME = '@deepseek-ai/dsh-desktop';
const SHARED_PARTITION = 'dsh-sidebar-browser';
const HOST_DIAGNOSTIC_REWRITES = [
  [
    'const child = spawn(this.node, [\n\t\t\t"--expose-internals",',
    'const child = spawn(this.node, [\n\t\t\t"--trace-deprecation",\n\t\t\t"--expose-internals",',
  ],
  [
    '\t\t\t"--trace-deprecation",\n\t\t\t"--expose-internals",',
    `\t\t\t"--trace-deprecation",\n\t\t\t${JSON.stringify(HOST_EXIT_TRACE_DATA_URL)},\n\t\t\t"--expose-internals",`,
  ],
  ['child.once("close", (code) => {', 'child.once("close", (code, signal) => {'],
  [
    'const suffix = this.stderr.trim() === "" ? "" : `: ${this.stderr.trim()}`;',
    'const stderrTail = this.stderr.trim();\n\t\t\t\tconst suffix = stderrTail === "" ? "" : `; stderr tail (cause not established): ${stderrTail}`;',
  ],
  [
    'dsh desktop host exited with ${String(code)}${suffix}',
    'dsh desktop host exited with ${String(code)} (signal=${String(signal)})${suffix}',
  ],
];

function addHostDiagnostics(source) {
  let output = source;
  let changed = false;
  const oldPreloads = output.match(/^[\t ]*"--import=data:text\/javascript,[^"\r\n]*",?$/gm) ?? [];
  if (!output.includes(HOST_EXIT_TRACE_DATA_URL) && oldPreloads.length > 0) {
    if (oldPreloads.length !== 1) return { ok: false, error: `expected at most one existing Host preloader, found ${oldPreloads.length}` };
    const indent = oldPreloads[0].match(/^[\t ]*/)?.[0] ?? '';
    output = output.replace(oldPreloads[0], `${indent}${JSON.stringify(HOST_EXIT_TRACE_DATA_URL)},`);
    changed = true;
  }
  for (const [index, [before, after]] of HOST_DIAGNOSTIC_REWRITES.entries()) {
    if (index === 0 && output.includes('const child = spawn(this.node, [\n\t\t\t"--trace-deprecation",')) continue;
    if (index === 1 && output.includes(HOST_EXIT_TRACE_DATA_URL)) continue;
    if (output.includes(after)) continue;
    const occurrences = output.split(before).length - 1;
    if (occurrences !== 1) return { ok: false, error: `expected one Host diagnostic anchor, found ${occurrences}` };
    output = output.replace(before, after);
    changed = true;
  }
  return { ok: true, source: output, changed };
}

/** Move the most recently used legacy workspace profile without reading its contents. */
export function migrateLegacyPartition(partitionsPath) {
  if (!existsSync(partitionsPath)) return { status: 'no-profile' };
  const destination = join(partitionsPath, SHARED_PARTITION);
  if (existsSync(destination)) return { status: 'already-present' };
  const candidates = readdirSync(partitionsPath, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && /^dsh-sidebar-browser-[a-f0-9]{64}$/.test(entry.name))
    .map((entry) => ({ path: join(partitionsPath, entry.name), modified: statSync(join(partitionsPath, entry.name)).mtimeMs }))
    .sort((a, b) => b.modified - a.modified);
  if (candidates.length === 0) return { status: 'no-profile' };
  const source = candidates[0].path;
  try {
    renameSync(source, destination);
    return { status: 'migrated', source, destination, unusedProfiles: candidates.length - 1 };
  } catch (error) {
    return { status: 'deferred', detail: error?.code ?? 'rename-failed' };
  }
}

/** Candidate `app.asar` locations, most specific first. */
function candidates() {
  const paths = [process.env.DSH_DESKTOP_ASAR];
  if (process.resourcesPath) paths.push(join(process.resourcesPath, 'app.asar'));
  if (typeof process.execPath === 'string') paths.push(join(dirname(process.execPath), 'resources', 'app.asar'));
  if (process.env.LOCALAPPDATA) paths.push(join(process.env.LOCALAPPDATA, 'Programs', 'DeepSeek Harness', 'resources', 'app.asar'));
  for (const base of [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.ProgramW6432]) {
    if (base) paths.push(join(base, 'DeepSeek Harness', 'resources', 'app.asar'));
  }
  return paths.filter((path) => typeof path === 'string' && path.length > 0).map((path) => resolve(path));
}

/** The first candidate that really is the DSH desktop shell archive. */
export function locateArchive() {
  for (const candidate of candidates()) {
    if (!existsSync(candidate)) continue;
    let handle;
    try {
      handle = openArchive(candidate);
      if (!findEntry(handle.header, ['lib', 'main.js'])) continue;
      const manifest = JSON.parse(readEntryBuffer(handle, findEntry(handle.header, ['package.json'])).toString('utf8'));
      if (manifest.name === SHELL_PACKAGE_NAME) return candidate;
    } catch {
      /* a candidate we cannot read is simply not ours */
    } finally {
      if (handle) closeArchive(handle);
    }
  }
  return null;
}

/**
 * Make the Browser tab's partition persistent in `archivePath`.
 * Exported for `test-browser-persist.mjs`; never throws for a layout it does not
 * recognise, so a failed patch cannot keep the Host from starting.
 */
export function ensurePersistentPartition(archivePath) {
  const handle = openArchive(archivePath);
  let source;
  try {
    const entry = findEntry(handle.header, FILE);
    if (!entry) return { status: 'unexpected-layout', detail: 'lib/main.js is not in the archive' };
    source = readEntryBuffer(handle, entry).toString('utf8');
  } finally {
    closeArchive(handle);
  }
  let next = source;
  let partitionStatus = 'already-applied';
  const oldCount = source.split(LEGACY_PATCHED).length - 1;
  if (oldCount === 1) {
    next = source.replace(LEGACY_PATCHED, PATCHED);
    partitionStatus = 'migrated';
  } else if (oldCount > 1) {
    return { status: 'unexpected-layout', detail: `expected at most one old persistent partition line, found ${oldCount}` };
  } else if (!source.includes(PATCHED)) {
    const occurrences = source.split(ORIGINAL).length - 1;
    if (occurrences !== 1) return { status: 'unexpected-layout', detail: `expected one Browser-tab partition line, found ${occurrences}` };
    if (!source.includes('from "node:crypto"') || !source.includes('createHash')) {
      return { status: 'unexpected-layout', detail: 'lib/main.js does not import createHash' };
    }
    next = source.replace(ORIGINAL, PATCHED);
    partitionStatus = 'applied';
  }
  if (partitionStatus !== 'already-applied' && !source.includes('from "node:crypto"')) {
    return { status: 'unexpected-layout', detail: 'lib/main.js does not import createHash' };
  }
  const diagnostics = addHostDiagnostics(next);
  if (!diagnostics.ok) return { status: 'unexpected-layout', detail: diagnostics.error };
  if (next !== source || diagnostics.changed) replaceEntries(archivePath, [{ parts: FILE, content: Buffer.from(diagnostics.source, 'utf8') }]);
  if (partitionStatus !== 'already-applied') return { status: partitionStatus, archivePath };
  return { status: diagnostics.changed ? 'diagnostics-applied' : 'already-applied', archivePath };
}

export function apply(ctx) {
  const report = (level, message) => {
    try {
      ctx?.logger?.[level]?.(message);
    } catch {
      /* a logger is not guaranteed in every Host */
    }
    if (level === 'warn' || level === 'error') console[level](`[dsh-browser-persist] ${message}`);
  };

  try {
    const partitionsPath = process.env.DSH_BROWSER_PARTITIONS_DIR
      ?? (process.env.APPDATA ? join(process.env.APPDATA, '@deepseek-ai', 'dsh-desktop', 'Partitions') : null);
    if (partitionsPath) {
      const migration = migrateLegacyPartition(partitionsPath);
      if (migration.status === 'migrated') report('info', `Migrated the latest existing Browser profile to shared storage (${migration.unusedProfiles} other profile(s) retained)`);
      else if (migration.status === 'deferred') report('warn', `Browser profile migration deferred (${migration.detail})`);
    }
    const archivePath = locateArchive();
    if (!archivePath) {
      report('info', 'skipped: no DSH desktop app.asar found');
      return;
    }
    const result = ensurePersistentPartition(archivePath);
    switch (result.status) {
      case 'applied':
        report('info', `Browser-tab partition is now persistent in ${archivePath}; restart DSH to use it`);
        break;
      case 'migrated':
        report('info', `Browser-tab partition is now shared across workspaces in ${archivePath}; restart DSH to use it`);
        break;
      case 'diagnostics-applied':
        report('info', `Host deprecation traces and exit signals are now captured in ${archivePath}; restart DSH to use diagnostics`);
        break;
      case 'already-applied':
        report('info', 'Browser-tab partition is already persistent');
        break;
      default:
        report('warn', `Browser-tab persistence skipped: ${result.detail}`);
    }
  } catch (error) {
    report('warn', `Browser-tab persistence failed: ${error?.message ?? error}`);
  }
}

# プロファイル登録の断片（task-7 / Lead 統合用）

本ファイルは **登録用の断片のみ** をまとめたものです。`~/.dsh/profiles/desktop/` 配下は
task-3 では一切変更していません（読み取りのみ）。適用は Lead が task-7 で単独実行します。

作業ディレクトリ（`WS`）= `C:\Users\ren11\Documents\deepseek-harness\default-workspace`
プロファイル（`PROFILE`）= `C:\Users\ren11\.dsh\profiles\desktop`

---

## 1. 現在の登録状態（読み取りで確認した事実）

`PROFILE/package.json`:

```json
{
  "dependencies": {
    "@local/codex-plus-usage": "link:.../default-workspace/codex-plus-usage",
    "@local/dsh-locale-ja": "link:.../default-workspace/dsh-locale-ja"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "@deepseek-ai/dsh-experimental-agent-team-profile",
        "@local/codex-plus-usage",
        "@local/dsh-locale-ja"
      ]
    }
  }
}
```

- `PROFILE/node_modules/@local/` には `codex-plus-usage` と `dsh-locale-ja` の symlink が存在。
- ローカルプラグインの Loader 行は、プロファイルの `cordis.patch.yml` 直書きではなく
  **各パッケージの `dsh.bundle.patch`（= そのパッケージの `cordis.patch.yml`）から供給**されています
  （`@local/codex-plus-usage` の行 `id: codex-plus-usage` はプロファイルの patch には無く、
  マテリアライズ済みの `PROFILE/cordis.yml` にだけ存在するため）。
- `PROFILE/cordis.yml` は 2026-10-11 16:37:01 の生成物で、`dsh-locale-ja/cordis.patch.yml` の
  最終更新（17:01）より**古い**スナップショットです。登録変更の反映には DSH の再起動が必要です。

---

## 2. 今回分離した新プラグイン（登録が必要）

| パッケージ | ディレクトリ | 役割 |
|---|---|---|
| `@local/dsh-youtube-player` | `WS/dsh-youtube-player` | 右サイドバーの YouTube プレイヤー |
| `@local/dsh-trajectory-ui` | `WS/dsh-trajectory-ui` | 実行履歴（Trajectory）の読みやすさ（CSS のみ） |

どちらも `dsh.bundle.patch` と `dsh.client` を持ち、単独で検証済みです
（`node verify-plugins.mjs` が緑）。

---

## 3. `PROFILE/package.json` への追記（この差分をそのまま適用）

```json
  "dependencies": {
    "@local/codex-plus-usage": "link:C:/Users/ren11/Documents/deepseek-harness/default-workspace/codex-plus-usage",
    "@local/dsh-locale-ja": "link:C:/Users/ren11/Documents/deepseek-harness/default-workspace/dsh-locale-ja",
    "@local/dsh-youtube-player": "link:C:/Users/ren11/Documents/deepseek-harness/default-workspace/dsh-youtube-player",
    "@local/dsh-trajectory-ui": "link:C:/Users/ren11/Documents/deepseek-harness/default-workspace/dsh-trajectory-ui"
  },
  "dsh": {
    "profile": {
      "bundles": [
        "@deepseek-ai/dsh-base",
        "@deepseek-ai/dsh-web-app",
        "@deepseek-ai/dsh-experimental-agent-team-profile",
        "@local/codex-plus-usage",
        "@local/dsh-locale-ja",
        "@local/dsh-youtube-player",
        "@local/dsh-trajectory-ui"
      ]
    }
  }
```

### 補足: Loader 行をプロファイル patch に直書きする場合（任意・どちらか一方）

`dsh.profile.bundles` に入れる方式（上記）では、各パッケージの `cordis.patch.yml` の行が
自動で適用されるため、`PROFILE/cordis.patch.yml` に追記する必要はありません。
**両方を併用すると id が重複するので、必ずどちらか一方にしてください。**

直書きする場合の断片（`PROFILE/cordis.patch.yml` の末尾に追加）:

```yaml
- insert:
    - id: dsh-youtube-player
      name: '@local/dsh-youtube-player'

    - id: dsh-trajectory-ui
      name: '@local/dsh-trajectory-ui'
```

---

## 4. `pnpm link`（symlink 作成）の要否 — **必要**

`link:` を `dependencies` に書いただけでは `PROFILE/node_modules/@local/<name>` の symlink は
作られません。`dsh.profile.bundles` の名前解決は `node_modules` 経由なので、symlink の作成が必須です。

この環境では `pnpm` は PATH に無く、バンドル版を使います。

```powershell
cd C:\Users\ren11\.dsh\profiles\desktop
$node = "C:\Users\ren11\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
$pnpm = "C:\Users\ren11\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\pnpm\bin\pnpm.mjs"
& $node $pnpm install            # 依存は全て link: なのでネットワーク不要
& $node $pnpm install --offline  # ネットワークを完全に避けたい場合（失敗時は上を使う）
```

- 実行前に `PROFILE/package.json` と `PROFILE/pnpm-lock.yaml` をバックアップしてください
  （pnpm が整形・書き換えを行う可能性があります）。
- `pnpm` を使わない場合の代替（管理者権限不要のジャンクション）:

```powershell
$local = "C:\Users\ren11\.dsh\profiles\desktop\node_modules\@local"
New-Item -ItemType Junction -Path "$local\dsh-youtube-player"   -Target "C:\Users\ren11\Documents\deepseek-harness\default-workspace\dsh-youtube-player"
New-Item -ItemType Junction -Path "$local\dsh-trajectory-ui"    -Target "C:\Users\ren11\Documents\deepseek-harness\default-workspace\dsh-trajectory-ui"
```

作成後、`PROFILE/node_modules/@local/` に 4 エントリ（codex-plus-usage / dsh-locale-ja /
dsh-youtube-player / dsh-trajectory-ui）が並ぶことを確認してください。

---

## 5. 削除対象リスト（memory の移設 — 統合時に Lead が同時に実施）

`dsh-locale-ja` には共有メモリの実装が**暫定で**残っています。現プロファイルが
`@local/dsh-locale-ja/memory` `/memory-ui` を参照しているため、task-3 では削除していません。
正典は `WS/dsh-shared-memory/`（`@local/dsh-shared-memory`、task-4 管轄）です。

### 5-1. 削除するもの（`WS/dsh-locale-ja/` 内）

| 種別 | 対象 |
|---|---|
| ファイル実体 | `memory.js`, `memory-ui.js`, `test-shared-memory.mjs` |
| `package.json` の `exports` | `"./memory"`, `"./memory-ui"` の 2 行 |
| `package.json` の `files` | `"memory.js"`, `"memory-ui.js"`, `"test-shared-memory.mjs"` の 3 行 |
| `cordis.patch.yml` | `id: dsh-shared-memory`（`name: '@local/dsh-locale-ja/memory'`）と<br>`id: dsh-shared-memory-ui`（`name: '@local/dsh-locale-ja/memory-ui'`）の 2 行<br>※ ファイル内で `TRANSITIONAL` と明記済み |

### 5-2. 置き換え（新参照）

`@local/dsh-shared-memory` は Host 半分（`index.js`）と Client 半分（`client.js`）が
**同一パッケージ名**なので、Loader 行は **1 行** で足ります。旧登録は 2 行
（`dsh-shared-memory` + `dsh-shared-memory-ui`）だったため、**2 行 → 1 行**への置き換えになります。
`id: dsh-shared-memory` は新旧で同じなので、**先に旧 2 行を削除してから**新行を入れてください
（同時に残すと id が重複します）。

task-4（ws4-memory）が用意した `WS/dsh-shared-memory/package.json` と
`WS/dsh-shared-memory/cordis.patch.yml` を読み取りで確認済み（2026-10-11 17:24 時点）:
`exports` は `".": "./index.js"` / `"./client": "./client.js"`、patch は下記 1 行、
`dsh.client.inject` は `@deepseek-ai/dsh-client-locale` と `@deepseek-ai/dsh-client-ui-sidebar-right`。

```json
  "dependencies": {
    "@local/dsh-shared-memory": "link:C:/Users/ren11/Documents/deepseek-harness/default-workspace/dsh-shared-memory"
  },
  "dsh": { "profile": { "bundles": [ "...", "@local/dsh-shared-memory" ] } }
```

`dsh-shared-memory` 側の `cordis.patch.yml`（task-4 が用意済み・そのまま使えます）:

```yaml
- insert:
    - id: dsh-shared-memory
      name: '@local/dsh-shared-memory'
```

> この 1 行方式は「Host 行 + `dsh.client` 宣言」で成立します。`dsh-shared-memory/client.js` の
> module id は `@local/dsh-shared-memory` に統一済みです（task-3 で確認）。
> なお `dsh-shared-memory/` の `locale/` `icon.svg` `README.md` `REGISTRATION.md` も整備済みです
> （task-4 管轄・task-3 は未変更）。

### 5-3. task-3 で実施済みの削除（参考）

- `WS/dsh-locale-ja/youtube-player.js` — 削除済み（`dsh-youtube-player/client.js` が後継）
- `WS/dsh-locale-ja/trajectory-ui-overrides.css` — 削除済み（`dsh-trajectory-ui/` に同一内容が正典）
- `dsh-locale-ja/package.json` の `exports["./youtube-player"]` と `files` の該当 2 行 — 削除済み

---

## 6. 適用後の検証（Lead が実行）

```powershell
cd C:\Users\ren11\Documents\deepseek-harness\default-workspace
node build-pack.mjs          # locale バンドル再生成（差分が出ないことを確認）
node verify-bundle.mjs       # 言語パックの契約・全キー・プレースホルダー
node verify-plugins.mjs      # 3 プラグインのマニフェスト・契約・分離
node test-youtube-player.mjs # YouTube URL 解析・3 言語キー揃い
```

期待値（task-3 実行時点の実測）:

| スクリプト | 結果 |
|---|---|
| `build-pack.mjs` | `wrote dsh-locale-ja/client.js (160026 bytes)` / 実行前後でハッシュ不変 |
| `verify-bundle.mjs` | `namespaces: 56 / 56`, `keys: 2338`, `ALL CHECKS PASSED` |
| `verify-plugins.mjs` | `locale-ja: 56 namespaces, 57 effects, display-only` / `youtube: 7 effects, 3 locales x 19 keys` / `trajectory: 1031 bytes` / `ALL PLUGIN CHECKS PASSED` |
| `test-youtube-player.mjs` | `all YouTube player tests passed` |

### DSH 再起動後の確認項目

1. 設定 → 一般 → 言語 が「日本語」のままであること（`ja` 辞書がロードされている）。
2. 右サイドバーのガイドに「YouTubeプレイヤー」があり、`Ctrl+Alt+U` で開けること（当初 `Alt+Y` としていたが、`KeyY` は primary 併用で予約キーのため起動失敗した）。
   動画 URL を入れて「再生」を押すまで iframe が生成されないこと。
3. 実行履歴（Trajectory）で行ホバーのハイライトとターン区切り線が効いていること。
4. 共有メモリは `@local/dsh-shared-memory` が正典です（`dsh-locale-ja` からは移設済みで、
   旧 `memory.js` / `memory-ui.js` は統合時に削除）。右サイドバーのガイドから開けること。
5. 通知（`@local/dsh-notify`）のパネル上部に **X / Instagram / Discord / YouTube** の
   「ブラウザ版を開く」ボタンがあり、押すと**そのパネル内に本物のサイト**が表示されること
   （iframe ではなく Electron ゲスト。4 サイトとも iframe は拒否）。ログインもそこで行う。
6. そのログインが **DSH を再起動しても残っていること**（シェル側のパーティション永続化。
   `_dsh/INTEGRATION_REPORT.md` §9 を参照。アプリ更新後は `_dsh/apply-shell-patch.cmd` で再適用）。

---

## 7. ロールバック

- `PROFILE/package.json` / `PROFILE/cordis.patch.yml` / `PROFILE/pnpm-lock.yaml` を
  バックアップから戻し、`PROFILE/node_modules/@local/` の追加ジャンクションを削除する。
- `dsh-locale-ja` から削除した 2 ファイルは git 管理外です。復元が必要な場合は
  `dsh-youtube-player/client.js` と `dsh-trajectory-ui/trajectory-ui-overrides.css` が正典です
  （`client.js` は分離時に `styles` 依存を `<style data-plugin-css>` 方式へ直した修正版です）。

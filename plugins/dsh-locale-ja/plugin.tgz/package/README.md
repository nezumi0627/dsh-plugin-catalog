# @local/dsh-locale-ja

DeepSeek Harness (DSH) Web GUI の日本語 (ja) 言語パックプラグイン。

DSH 本体は `en` / `zh` の 2 言語しか同梱しておらず、日本語は未対応です。公式の拡張点である
Client locale サービス（`ctx.locale.addLanguage` / `ctx.locale.register`）を使って、日本語を
1 言語として追加し、GUI の文言を日本語に差し替えます。

**このパッケージは「日本語表示のみ」です。** 右サイドバーの YouTube プレイヤーと実行履歴の
表示調整は、それぞれ `@local/dsh-youtube-player` と `@local/dsh-trajectory-ui` に分離しました
（下記「分離したプラグイン」を参照）。

## 収録内容

| 項目 | 値 |
|---|---|
| 言語 ID | `ja`（ラベル `日本語`、フォールバック `en`） |
| Web 名前空間 | 56 |
| Web 翻訳キー | 2,338（本体同梱の英語辞書と 1:1 対応） |
| Client バンドル | `client.js`（約 157 KiB、生成物） |
| デスクトップシェル辞書 | 165 キー（英語・中国語に加えて日本語を追加） |

未訳のキーは `ja` → `en` のフォールバック連鎖で英語表示になるため、部分的な欠落でも
表示は壊れません。

## 構成

| ファイル | 役割 |
|---|---|
| `package.json` | バンドルマニフェスト。`dsh.bundle.patch` と `dsh.client` を宣言 |
| `cordis.patch.yml` | Loader 行 `locale-ja` を挿入するバンドルパッチ |
| `index.js` | Host 側。Web 言語パックを登録するほか、起動時にデスクトップシェルの日本語パッチを再適用 |
| `client.js` | **生成物**。言語定義と 56 名前空間の辞書を登録する（手で編集しない） |
| `desktop/ja.json` | デスクトップシェル用 165 メッセージの日本語辞書 |
| `desktop/patcher.js` / `desktop/asar.js` / `desktop/transform.js` | DSH の更新後も `app.asar` の日本語パッチを再適用する処理 |
| `locale/en.json` / `locale/ja.json` | Plugin Manager カード用の表示メタデータ |
| `icon.svg` | プラグイン一覧のアイコン |
| `memory.js` / `memory-ui.js` / `test-shared-memory.mjs` | **移設予定（暫定）**。共有メモリの Host / Client 実装。正典は `dsh-shared-memory/`（`@local/dsh-shared-memory`）で、統合時に参照を付け替えてから削除します |

## 分離したプラグイン

| 旧 | 新 | 内容 |
|---|---|---|
| `youtube-player.js` | `@local/dsh-youtube-player` | 右サイドバーの YouTube プレイヤー（タブ・ガイド・`Ctrl+Alt+U` ショートカット・再生スタイル） |
| `trajectory-ui-overrides.css` | `@local/dsh-trajectory-ui` | 実行履歴（Trajectory）の読みやすさだけを担う表示レイヤー |

どちらも独立した `package.json` / `cordis.patch.yml` / `client.js` を持ち、単独で検証できます。
本パッケージには両者のコードも CSS も残っていません。

## インストール

プロファイルにリンクインストール済みです（`plugin_manager` の `install_bundle`）。

```
$DSH_PROFILE_DIR/package.json
  dependencies: { "@local/dsh-locale-ja": "link:<このディレクトリ>" }
  dsh.profile.bundles: [ ..., "@local/dsh-locale-ja" ]
```

`link:` インストールなので、ローカルファイルはプロファイルから参照されます。
Client プラグインの変更を HMR で反映するには `pnpm run dev:web` の再ビルド監視が必要です。
デスクトップシェルの日本語パッチは Host 起動時に再適用されるため、アプリ更新で
`app.asar` が置き換わっても、次回起動時に復元されます。

分離した 2 プラグイン（`@local/dsh-youtube-player` / `@local/dsh-trajectory-ui`）の登録は
まだ済んでいません。プロファイルへ追加する正確な断片と削除対象の一覧は
`REGISTRATION.md` にあります。

## 言語の選択

- GUI: 設定 → 一般 → 言語 で「日本語」を選択（恒久的に保存されます）。
- または `$DSH_PROFILE_DIR/cordis.patch.yml` の `locale` 行を `preference: ja` にする。

## 再生成（DSH 更新時など）

翻訳の正は `work/ja/*.json`（グループ別）と `work/TRANSLATION-GUIDE.md`（訳語集・規約）です。
DSH が更新されて英語辞書が変わったら、次の順で再生成します。

```powershell
# 1. インストール済み asar から英語辞書を再抽出
node scan-locale-sites.mjs      # locale.register を持つファイルを列挙
node collect-locale.mjs         # -> locale-dicts.json（英語辞書の正）
node prepare-translation.mjs    # -> work/en/*.json, work/groups/g*.json

# 2. work/ja/*.json を新しいキー集合に合わせて更新（未訳キーは英語へフォールバック）

# 3. 検証してビルド
node fix-escapes.mjs            # JS エスケープの残骸を点検（--fix で修正）
node normalize-punctuation.mjs  # 文末の句点を統一（--fix で修正）
node consistency-check.mjs      # 訳語ゆれの点検
node build-pack.mjs             # -> dsh-locale-ja/client.js
node verify-bundle.mjs          # バンドルの契約とプレースホルダーを機械検証
node verify-plugins.mjs         # 3 プラグインのマニフェスト・契約・分離をまとめて検証
```

## デスクトップシェルパッチについて

Electron 本体には公式の言語パック拡張点がないため、Host プラグインが起動時に
`resources/app.asar` の辞書を差し替えます。既存ファイルのデータは移動せず、置換した 3 ファイルを
アーカイブ末尾に追加し、ヘッダーだけを更新します。元のヘッダーは
`$DSH_HOME/desktop-ja/asar-header-*.json` に保存します。更新で `app.asar` が入れ替わると、
次回起動時に再パッチします。パッチ処理に失敗しても Host の起動は妨げません。

これは非公式な変更です。DSH の内部形式が変わった場合は安全のため適用をスキップします。
バックアップしたヘッダーから戻す CLI は作業領域の `patch-desktop-shell.mjs` を使います。

## 既知の制約

- **Host 側が登録する文言は英語のまま** — スラッシュコマンドの説明（`CommandDefinition.description`）や
  同梱プラグインの表示メタデータ（各パッケージの `locale/en.json`）は Host 側の持ち物で、
  Client locale サービスに接続されていません。本パックからは差し替えできません。
- **モデル向けテキストは対象外** — locale サービスはブラウザー側 UI 専用です。システムプロンプトや
  ツール定義などモデルが読むテキストは英語のままです。
- **`i18n` の検証ツールは本体に同梱されていない** — 本体の `verify-client-ui-i18n` に相当する検査は
  `verify-bundle.mjs` が代替します（キー集合・プレースホルダー・空値・バンドル契約）。

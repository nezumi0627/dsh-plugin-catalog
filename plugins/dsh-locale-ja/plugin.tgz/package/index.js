/**
 * Host half of the Japanese language pack.
 *
 * The Web GUI half lives in `client.js`: it registers the `ja` language and one
 * dictionary per namespace through the Client locale service.
 *
 * This half exists for a second reason. The Electron desktop shell ships its own
 * `en`/`zh` message dictionary compiled into `app.asar`, which no plugin can
 * reach; it draws the caption menu bar, the tray, the native dialogs and the
 * Windows context menu. `desktop/patcher.js` rewrites those three shell files in
 * place, and running it on every start means a freshly downloaded application
 * update is re-patched the next time Harness boots.
 */
import { readFileSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { applyDesktopLocalePatch } from './desktop/patcher.js';

const DICTIONARY = JSON.parse(readFileSync(new URL('./desktop/ja.json', import.meta.url), 'utf8'));

export function apply(ctx) {
  const report = (level, message) => {
    try {
      ctx?.logger?.[level]?.(message);
    } catch {
      /* a logger is not guaranteed in every Host */
    }
    if (level === 'warn' || level === 'error') console[level](`[dsh-locale-ja] ${message}`);
  };

  try {
    const home = process.env.DSH_HOME ?? join(homedir(), '.dsh');
    const result = applyDesktopLocalePatch({
      dictionary: DICTIONARY,
      backupDir: join(home, 'desktop-ja'),
    });
    switch (result.status) {
      case 'applied':
        report('info', `desktop shell localized: ${result.files.map((f) => f.path).join(', ')}`);
        break;
      case 'already-applied':
        report('info', `desktop shell already localized (${result.detail})`);
        break;
      case 'not-desktop':
      case 'unexpected-layout':
        report('info', `desktop shell localization skipped: ${result.detail}`);
        break;
      default:
        report('info', `desktop shell localization: ${result.status}`);
    }
  } catch (error) {
    // A failed shell patch must never keep the Host from starting.
    report('warn', `desktop shell localization failed: ${error?.message ?? error}`);
  }
}

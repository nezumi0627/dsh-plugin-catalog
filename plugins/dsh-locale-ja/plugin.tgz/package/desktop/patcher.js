/**
 * Re-applies the Japanese dictionary to the Electron desktop shell inside the
 * installed `app.asar`.
 *
 * The desktop shell ships only `en` and `zh` message dictionaries, so its
 * caption menu, tray, native dialogs and Windows context menu stay English no
 * matter what the Web locale is. This module rewrites those three shell files
 * in place; the Host half calls it on every start, which is what makes the
 * Japanese shell survive an application update.
 */
import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync, unlinkSync, writeFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { closeArchive, findEntry, openArchive, readEntryBuffer, replaceEntries, restoreArchive } from './asar.js';
import { TRANSFORM_VERSION, transformDesktopShell } from './transform.js';

/** Shell files that carry a copy of the desktop message dictionary. */
export const SHELL_FILES = ['lib/main.js', 'lib/preload-app.cjs', 'lib/preload-welcome.cjs'];
export const SHELL_PACKAGE_NAME = '@deepseek-ai/dsh-desktop';

/** Candidate `app.asar` locations, most specific first. */
function candidateArchives() {
  const out = [];
  const add = (path) => {
    if (typeof path === 'string' && path.length > 0 && !out.includes(path)) out.push(resolve(path));
  };
  add(process.env.DSH_DESKTOP_ASAR);
  if (process.resourcesPath) add(join(process.resourcesPath, 'app.asar'));
  if (typeof process.execPath === 'string') add(join(dirname(process.execPath), 'resources', 'app.asar'));
  // The Host always runs from the desktop install, but fall back to the usual
  // per-user and machine-wide locations if it was launched some other way.
  if (process.env.LOCALAPPDATA) add(join(process.env.LOCALAPPDATA, 'Programs', 'DeepSeek Harness', 'resources', 'app.asar'));
  for (const base of [process.env.ProgramFiles, process.env['ProgramFiles(x86)'], process.env.ProgramW6432]) {
    if (base) add(join(base, 'DeepSeek Harness', 'resources', 'app.asar'));
  }
  return out;
}

/** The first candidate that really is the DSH desktop shell archive. */
export function locateDesktopArchive(candidates = candidateArchives()) {
  for (const candidate of candidates) {
    if (!existsSync(candidate)) continue;
    let handle;
    try {
      handle = openArchive(candidate);
      const manifest = findEntry(handle.header, ['package.json']);
      const main = findEntry(handle.header, ['lib', 'main.js']);
      if (!manifest || !main) continue;
      const name = JSON.parse(readEntryBuffer(handle, manifest).toString('utf8')).name;
      if (name !== SHELL_PACKAGE_NAME) continue;
      return candidate;
    } catch {
      continue;
    } finally {
      if (handle) closeArchive(handle);
    }
  }
  return null;
}

function revisionOf(dictionary) {
  return createHash('sha256')
    .update(JSON.stringify(dictionary))
    .update(String(TRANSFORM_VERSION))
    .digest('hex')
    .slice(0, 16);
}

function pruneBackups(directory, keep) {
  try {
    const files = readdirSync(directory)
      .filter((name) => name.startsWith('asar-header-') && name.endsWith('.json'))
      .map((name) => ({ name, time: statSync(join(directory, name)).mtimeMs }))
      .sort((a, b) => b.time - a.time);
    for (const file of files.slice(keep)) unlinkSync(join(directory, file.name));
  } catch {
    /* pruning is best effort */
  }
}

/**
 * @param options.dictionary - the Japanese desktop message dictionary.
 * @param options.backupDir - where header backups and the fast-path state live.
 * @param options.dryRun - compute the patch and report, but write nothing.
 * @returns a report; never throws for the "not a desktop install" case.
 */
export function applyDesktopLocalePatch(options = {}) {
  const { dictionary, backupDir, dryRun = false, archivePath } = options;
  if (!dictionary) throw new Error('a Japanese desktop dictionary is required');

  const asarPath = archivePath ?? locateDesktopArchive();
  if (!asarPath) return { status: 'not-desktop', detail: 'no DSH desktop app.asar found' };

  const revision = revisionOf(dictionary);
  const statePath = backupDir ? join(backupDir, 'state.json') : null;
  const stats = statSync(asarPath);
  if (!dryRun && statePath && existsSync(statePath)) {
    try {
      const state = JSON.parse(readFileSync(statePath, 'utf8'));
      if (state.archiveSize === stats.size && state.mtimeMs === stats.mtimeMs && state.revision === revision) {
        return { status: 'already-applied', archivePath: asarPath, detail: 'unchanged since the last patch' };
      }
    } catch {
      /* a damaged state file only costs one extra verification */
    }
  }

  const handle = openArchive(asarPath);
  const replacements = [];
  try {
    for (const file of SHELL_FILES) {
      const entry = findEntry(handle.header, file.split('/'));
      if (!entry) return { status: 'unexpected-layout', archivePath: asarPath, detail: `missing ${file}` };
      const source = readEntryBuffer(handle, entry).toString('utf8');
      const result = transformDesktopShell(source, dictionary);
      if (result.unchanged) return { status: 'already-applied', archivePath: asarPath, detail: `${file} already carries ja` };
      replacements.push({ parts: file.split('/'), content: Buffer.from(result.code, 'utf8'), report: result });
    }
  } finally {
    closeArchive(handle);
  }

  const summary = replacements.map((r) => ({
    path: r.parts.join('/'),
    from: r.previous?.size ?? null,
    to: r.content.length,
    edits: r.report.applied,
    skipped: r.report.skipped,
  }));

  if (dryRun) return { status: 'would-apply', archivePath: asarPath, byteDelta: replacements.reduce((n, r) => n + r.content.length, 0), files: summary };

  if (backupDir) {
    mkdirSync(backupDir, { recursive: true });
    const pristine = openArchive(asarPath);
    try {
      const headerHash = createHash('sha256').update(pristine.headerBuffer).digest('hex').slice(0, 12);
      const backupPath = join(backupDir, `asar-header-${stats.size}-${headerHash}.json`);
      if (!existsSync(backupPath)) {
        writeFileSync(
          backupPath,
          JSON.stringify({
            archivePath: asarPath,
            archiveSize: stats.size,
            headerSize: pristine.headerSize,
            savedAt: new Date().toISOString(),
            prefix: pristine.prefix.toString('base64'),
            header: pristine.headerBuffer.toString('base64'),
          }),
        );
      }
      pruneBackups(backupDir, 3);
    } finally {
      closeArchive(pristine);
    }
  }

  const outcome = replaceEntries(asarPath, replacements);
  if (statePath) {
    const after = statSync(asarPath);
    writeFileSync(
      statePath,
      JSON.stringify({
        revision,
        archivePath: asarPath,
        archiveSize: after.size,
        mtimeMs: after.mtimeMs,
        appliedAt: new Date().toISOString(),
      }),
    );
  }
  return { status: 'applied', archivePath: asarPath, changed: outcome.changed, files: summary };
}

/** Put a previously saved header back and drop the appended payloads. */
export function revertDesktopLocalePatch(backupPath, archivePath) {
  const backup = JSON.parse(readFileSync(backupPath, 'utf8'));
  restoreArchive(archivePath ?? backup.archivePath, {
    prefix: Buffer.from(backup.prefix, 'base64'),
    archiveSize: backup.archiveSize,
  });
  return { restored: backup.archivePath, archiveSize: backup.archiveSize };
}

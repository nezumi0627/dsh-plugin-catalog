/**
 * Minimal, reversible writer for an Electron ASAR archive.
 *
 * The only operation offered is "replace these file entries": the new payloads
 * are appended past the end of the existing data section and the header's
 * `offset` / `size` / `integrity` for those entries is rewritten in place. No
 * existing byte is moved and no entry is added or removed, so an interrupted
 * run can only leave an unreferenced tail — never a broken archive.
 */
import { createHash } from 'node:crypto';
import { closeSync, ftruncateSync, openSync, readSync, statSync, writeSync } from 'node:fs';

const DATA_OFFSET_BASE = 16;
const INTEGRITY_BLOCK_SIZE = 4194304;

/** Read the pickle prefix and the JSON header. */
export function openArchive(archivePath) {
  const fd = openSync(archivePath, 'r');
  const prefix = Buffer.alloc(DATA_OFFSET_BASE);
  readSync(fd, prefix, 0, prefix.length, 0);
  const headerSize = prefix.readUInt32LE(12);
  const headerBuffer = Buffer.alloc(headerSize);
  readSync(fd, headerBuffer, 0, headerSize, DATA_OFFSET_BASE);
  return {
    fd,
    prefix,
    headerSize,
    headerBuffer,
    header: JSON.parse(headerBuffer.toString('utf8')),
    dataOffset: DATA_OFFSET_BASE + headerSize,
    archiveSize: statSync(archivePath).size,
  };
}

export function closeArchive(handle) {
  closeSync(handle.fd);
}

export function findEntry(header, parts) {
  let current = header;
  for (const part of parts) {
    current = current?.files?.[part];
    if (!current) return null;
  }
  return current;
}

/** Every file entry as `path -> offset:size:integrityHash`, for untouched-entry checks. */
export function snapshotEntries(header) {
  const map = new Map();
  (function walk(node, prefix) {
    for (const [name, value] of Object.entries(node.files ?? {})) {
      const path = prefix ? `${prefix}/${name}` : name;
      if (value.files) walk(value, path);
      else map.set(path, `${value.offset}:${value.size}:${value.integrity?.hash ?? ''}:${value.unpacked ? 1 : 0}`);
    }
  })(header, '');
  return map;
}

export function readEntryBuffer(handle, entry) {
  const buffer = Buffer.alloc(entry.size);
  readSync(handle.fd, buffer, 0, entry.size, handle.dataOffset + Number(entry.offset));
  return buffer;
}

/** The archive's own per-entry integrity record (SHA-256, 4 MiB blocks). */
export function integrityOf(buffer) {
  const blocks = [];
  for (let offset = 0; offset < buffer.length; offset += INTEGRITY_BLOCK_SIZE) {
    blocks.push(createHash('sha256').update(buffer.subarray(offset, offset + INTEGRITY_BLOCK_SIZE)).digest('hex'));
  }
  if (blocks.length === 0) blocks.push(createHash('sha256').update(Buffer.alloc(0)).digest('hex'));
  return { algorithm: 'SHA256', hash: blocks[0], blockSize: INTEGRITY_BLOCK_SIZE, blocks };
}

function serializeHeader(header, headerSize) {
  const json = JSON.stringify(header);
  const bytes = Buffer.byteLength(json);
  if (bytes > headerSize) throw new Error(`patched header needs ${bytes} bytes but only ${headerSize} are available`);
  const out = Buffer.alloc(headerSize, 0x20);
  out.write(json, 0, 'utf8');
  return out;
}

/**
 * Append `replacements` and repoint their header entries.
 * @param archivePath - archive to modify in place.
 * @param replacements - `[{ parts, content, expectedHash }]`, matched by path parts.
 */
export function replaceEntries(archivePath, replacements) {
  const handle = openArchive(archivePath);
  try {
    const before = snapshotEntries(handle.header);
    for (const replacement of replacements) {
      const entry = findEntry(handle.header, replacement.parts);
      if (!entry) throw new Error(`archive entry not found: ${replacement.parts.join('/')}`);
      const current = readEntryBuffer(handle, entry);
      replacement.previous = { offset: entry.offset, size: entry.size, integrity: entry.integrity };
      replacement.previousSha256 = createHash('sha256').update(current).digest('hex');
      replacement.nextSha256 = createHash('sha256').update(replacement.content).digest('hex');
    }

    // Nothing to do when the archive already carries exactly these payloads.
    const upToDate = replacements.every((r) => r.previousSha256 === r.nextSha256);
    if (upToDate) return { changed: false, entries: replacements.map((r) => r.parts.join('/')) };

    const writable = openSync(archivePath, 'r+');
    let position = handle.archiveSize;
    try {
      for (const replacement of replacements) {
        const relativeOffset = position - handle.dataOffset;
        const entry = findEntry(handle.header, replacement.parts);
        entry.offset = String(relativeOffset);
        entry.size = replacement.content.length;
        entry.integrity = integrityOf(replacement.content);
        writeSync(writable, replacement.content, 0, replacement.content.length, position);
        position += replacement.content.length;
      }
      // The header is written last: a crash before this leaves the old offsets intact.
      writeSync(writable, serializeHeader(handle.header, handle.headerSize), 0, handle.headerSize, DATA_OFFSET_BASE);
    } finally {
      closeSync(writable);
    }

    const after = openArchive(archivePath);
    try {
      const patched = snapshotEntries(after.header);
      for (const [path, value] of before) {
        const replaced = replacements.some((r) => r.parts.join('/') === path);
        if (replaced) {
          if (patched.get(path) === value) throw new Error(`entry ${path} was not repointed`);
          continue;
        }
        if (patched.get(path) !== value) throw new Error(`unrelated entry ${path} changed`);
      }
      if (patched.size !== before.size) throw new Error('archive entry count changed');
      for (const replacement of replacements) {
        const entry = findEntry(after.header, replacement.parts);
        const read = readEntryBuffer(after, entry);
        if (!read.equals(replacement.content)) throw new Error(`verification failed for ${replacement.parts.join('/')}`);
      }
    } finally {
      closeArchive(after);
    }

    return {
      changed: true,
      entries: replacements.map((r) => ({
        path: r.parts.join('/'),
        from: r.previous.size,
        to: r.content.length,
        appendedAt: Number(findEntry(handle.header, r.parts).offset),
      })),
    };
  } finally {
    closeArchive(handle);
  }
}

/** Restore a header prefix written by `backupHeader` and drop the appended tail. */
export function restoreArchive(archivePath, backup) {
  const fd = openSync(archivePath, 'r+');
  try {
    writeSync(fd, backup.prefix, 0, backup.prefix.length, 0);
    writeSync(fd, backup.header, 0, backup.header.length, DATA_OFFSET_BASE);
    ftruncateSync(fd, backup.archiveSize);
  } finally {
    closeSync(fd);
  }
}

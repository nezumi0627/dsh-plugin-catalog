/**
 * Pure text transformation that teaches one Electron shell file the Japanese
 * dictionary. Kept free of I/O so it can be validated against the real shell
 * sources before anything on disk is touched.
 *
 * Three edits per file:
 *   1. a `const ja = { ... }` dictionary next to the shipped `const zh`,
 *   2. a `ja` branch in `resolveDesktopLocale` (which otherwise maps every
 *      non-Chinese locale to English),
 *   3. in the main process only, `ja` in the two `resolveDesktopStartupLocale`
 *      acceptance checks.
 */

/** Bump when the edit strategy changes, so an already-patched install re-applies. */
export const TRANSFORM_VERSION = 1;

const JA_DECL_MARKER = 'const ja = {';
const LOCALE_BRANCH_FIND = 'locale.toLowerCase().startsWith("zh") ? {';
const LOCALE_BRANCH_REPLACE =
  'locale.toLowerCase().startsWith("ja") ? { id: "ja", messages: ja } : locale.toLowerCase().startsWith("zh") ? {';
const STARTUP_FINDS = [
  ['if (selected === "zh" || selected === "en")', 'if (selected === "zh" || selected === "en" || selected === "ja")'],
  ['if (primary === "zh" || primary === "en")', 'if (primary === "zh" || primary === "en" || primary === "ja")'],
];

/** Index of the `}` matching the `{` at `openAt`, skipping strings and comments. */
function matchBrace(code, openAt) {
  let depth = 0;
  for (let i = openAt; i < code.length; i++) {
    const ch = code[i];
    if (ch === '"' || ch === "'" || ch === '`') {
      const quote = ch;
      i++;
      while (i < code.length && code[i] !== quote) {
        if (code[i] === '\\') i++;
        i++;
      }
      continue;
    }
    if (ch === '/' && code[i + 1] === '/') {
      while (i < code.length && code[i] !== '\n') i++;
      continue;
    }
    if (ch === '/' && code[i + 1] === '*') {
      const end = code.indexOf('*/', i + 2);
      i = end === -1 ? code.length : end + 1;
      continue;
    }
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}

/** Declaration text for the Japanese dictionary, matching the file's indentation. */
function japaneseDeclaration(dictionary, indent) {
  const body = JSON.stringify(dictionary, null, '\t')
    .split('\n')
    .map((line, index) => (index === 0 ? line : indent + '\t' + line))
    .join('\n');
  return `${indent}const ja = ${body};`;
}

/**
 * @param code - one shell source file.
 * @param dictionary - the Japanese message dictionary.
 * @returns transformed source plus a per-edit report.
 */
export function transformDesktopShell(code, dictionary) {
  const applied = [];
  const skipped = [];

  if (code.includes(JA_DECL_MARKER)) {
    return { code, applied, skipped: ['already-patched'], unchanged: true };
  }

  const zhMatch = /const\s+zh\s*=\s*\{/.exec(code);
  const localeAt = code.indexOf(LOCALE_BRANCH_FIND);
  if (!zhMatch || localeAt === -1) {
    throw new Error('desktop shell source does not match the expected Electron shell shape');
  }

  // 1. the dictionary, inserted right after the shipped Chinese one.
  const braceAt = code.indexOf('{', zhMatch.index);
  const closeAt = matchBrace(code, braceAt);
  if (closeAt === -1) throw new Error('unterminated Chinese dictionary literal');
  let insertAt = closeAt + 1;
  if (code[insertAt] === ';') insertAt++;
  const lineStart = code.lastIndexOf('\n', zhMatch.index) + 1;
  const indent = /^[\t ]*/.exec(code.slice(lineStart, zhMatch.index))[0];

  // 2. and 3. the locale branches.
  let next = code.slice(0, insertAt) + '\n' + japaneseDeclaration(dictionary, indent) + code.slice(insertAt);
  applied.push('dictionary');

  const branchCount = next.split(LOCALE_BRANCH_FIND).length - 1;
  if (branchCount !== 1) throw new Error(`expected exactly one resolveDesktopLocale branch, found ${branchCount}`);
  next = next.replace(LOCALE_BRANCH_FIND, LOCALE_BRANCH_REPLACE);
  applied.push('resolveDesktopLocale');

  for (const [find, replace] of STARTUP_FINDS) {
    const count = next.split(find).length - 1;
    if (count === 0) {
      skipped.push(find);
      continue;
    }
    if (count !== 1) throw new Error(`expected at most one "${find}", found ${count}`);
    next = next.replace(find, replace);
    applied.push(`resolveDesktopStartupLocale:${find.includes('selected') ? 'preference' : 'os'}`);
  }

  return { code: next, applied, skipped, unchanged: false };
}

import { existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const name = 'dsh-native-tools';
export const inject = ['tools', 'subprocess'];

const here = dirname(fileURLToPath(import.meta.url));
const binaryName = process.platform === 'win32' ? 'dnt.exe' : 'dnt';
const fastBinary = resolve(here, '..', 'dnt', 'target', 'release-fast', binaryName);
const releaseBinary = resolve(here, '..', 'dnt', 'target', 'release', binaryName);
const output = {
  schema: {
    type: 'object', additionalProperties: false,
    properties: { json: { type: 'string' } },
    required: ['json'],
  },
  render: (_args, value) => [{ type: 'text', text: value.json }],
};

function objectParameters(properties, required = []) {
  return { type: 'object', additionalProperties: false, properties, required };
}

function defineNative(ctx, binary, { name, method, description, parameters }) {
  ctx.tools.register({
    name, description, parameters, output,
    isConcurrencySafe: () => true,
    async execute(args, exec) {
      const cwd = exec.agent?.session?.header?.cwd;
      if (typeof cwd !== 'string' || cwd.length === 0) throw new Error('DNT requires an active session workspace directory.');
      if (!existsSync(binary)) throw new Error(`DNT binary not found at ${binary}. Build it with .\\build.ps1 in the dnt directory, or set DNT_BIN.`);
      const request = JSON.stringify({ id: `${Date.now()}-${Math.random().toString(16).slice(2)}`, method, params: { root: cwd, ...args } }) + '\n';
      const executable = await ctx.subprocess.resolveExecutable(binary, undefined, exec.signal);
      const child = ctx.subprocess.spawn({
        argv: [executable, '--stdio'], cwd,
        stdio: { stdin: { data: request }, stdout: { maxBytes: 2 * 1024 * 1024 }, stderr: { maxBytes: 64 * 1024 } },
        graceMs: 500, signal: exec.signal,
      });
      const outcome = await child.done;
      const stdout = child.collected.stdout?.readFrom(0).text ?? '';
      const stderr = child.collected.stderr?.readFrom(0).text ?? '';
      if (outcome.exitCode !== 0) throw new Error(`DNT exited with code ${outcome.exitCode}${stderr ? `: ${stderr.slice(0, 2000)}` : ''}`);
      let response;
      try { response = JSON.parse(stdout.trim()); }
      catch { throw new Error(`DNT returned invalid JSON${stderr ? `: ${stderr.slice(0, 2000)}` : ''}`); }
      if (!response.ok) throw new Error(response.error ?? 'DNT operation failed');
      return { json: JSON.stringify(response.result) };
    },
  });
}

export function apply(ctx) {
  const binary = process.env.DNT_BIN || (existsSync(fastBinary) ? fastBinary : releaseBinary);
  defineNative(ctx, binary, {
    name: 'native_search', method: 'search',
    description: 'Fast Rust literal text search inside the active workspace. Respects ignore files; returns bounded paths, line numbers, and snippets. This is literal, not regex search.',
    parameters: objectParameters({
      pattern: { type: 'string', description: 'Literal text to find.' },
      path: { type: 'string', description: 'Workspace-relative directory or file. Defaults to workspace root.' },
      limit: { type: 'number', description: 'Maximum matches (1–2000; defaults to 100).' },
    }, ['pattern']),
  });
  defineNative(ctx, binary, {
    name: 'native_files', method: 'files',
    description: 'List files in the active workspace with Rust traversal and ignore-file handling.',
    parameters: objectParameters({
      path: { type: 'string', description: 'Workspace-relative directory. Defaults to workspace root.' },
      limit: { type: 'number', description: 'Maximum files (1–5000; defaults to 500).' },
    }),
  });
  defineNative(ctx, binary, {
    name: 'native_read', method: 'read',
    description: 'Read a bounded line window from a UTF-8 file in the active workspace using the Rust native engine.',
    parameters: objectParameters({
      path: { type: 'string', description: 'Workspace-relative file path.' },
      offset: { type: 'number', description: '1-based first line; defaults to 1.' },
      limit: { type: 'number', description: 'Maximum lines (1–2000; defaults to 300).' },
    }, ['path']),
  });
}

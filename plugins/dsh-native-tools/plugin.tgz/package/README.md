# DSH Native Tools (DNT bridge)

This bundle exposes three read-only model tools backed by the Rust `dnt` executable:

- `native_search`: bounded literal content search
- `native_files`: ignore-aware workspace file enumeration
- `native_read`: bounded UTF-8 line-window read

## Build

From the workspace root:

```powershell
cd dnt
cargo build --release
```

The default executable path is `dnt/target/release/dnt.exe` on Windows and `dnt/target/release/dnt` elsewhere. Override with `DNT_BIN` or the plugin's `binaryPath` config. The bridge obtains the active session's workspace root and uses DSH's managed subprocess service; Rust path resolution rejects absolute paths, `..`, and symlink/junction escapes.

The initial release deliberately does not expose edit, copy, shell, or network operations as DSH tools. Those need explicit integration with DSH authorization/sandbox semantics before they are safe to expose. Search is literal (not regex); unsupported functionality is reported by capabilities rather than claimed as implemented.

/**
 * Host half of @local/dsh-trajectory-ui.
 *
 * The readability layer is browser-only. The Loader row exists so the Client
 * module system can compose the package's client bundle into the boot graph:
 * rows are keyed by package name, so this package is addressable as
 * `@local/dsh-trajectory-ui` and contributes `client.js` as its client half.
 */
export function apply(ctx) {
  ctx.logger?.debug?.('[dsh-trajectory-ui] host half active (browser-only plugin)');
}

/**
 * Trajectory ledger readability layer for the DeepSeek Harness web GUI.
 *
 * Generated file - do not edit by hand; run `node build.mjs` after editing
 * trajectory-ui-overrides.css.
 *
 * The Client module system keys boot rows by package name, so this bundle must
 * register exactly @local/dsh-trajectory-ui. Styles are injected as a plain <style> element:
 * the module system claims the untagged tags a factory created during
 * materialization (data-plugin) and removes them again on teardown, and only
 * platform seed words may be required.
 */
window.__ModuleLoader__.load({
  id: "@local/dsh-trajectory-ui",
  factory() {
    const ID = "@local/dsh-trajectory-ui";
    const css = "/* Readability layer for the shipped DSH Trajectory ledger. */\n@media(prefers-reduced-motion:no-preference){.haSm5q_table tr{transition:background-color .12s ease}}\n.haSm5q_table tbody tr:hover td{background-color:color-mix(in srgb,var(--dsw-alias-interactive-bg-hover) 65%,transparent)}\n.haSm5q_tablePane{background:var(--dsw-alias-bg-base);scrollbar-gutter:stable}\n.haSm5q_table{--trajectory-turn-accent:color-mix(in srgb,var(--dsw-static-blue-500) 11%,var(--dsw-alias-bg-layer-1))}\n.haSm5q_table td{padding-top:9px;padding-bottom:9px}\n.haSm5q_table tr[data-turn-start=true] td{border-top:2px solid color-mix(in srgb,var(--dsw-static-blue-500) 38%,var(--dsw-alias-border-l2))}\n.haSm5q_kindTag{padding:3px 8px;border-radius:999px;font-weight:600;letter-spacing:.01em}\n.haSm5q_contentText{line-height:1.65}\n.haSm5q_turnLabel{font-weight:650}\n.haSm5q_requestBoundaryControl{border-radius:8px}\n.haSm5q_tablePane:focus-visible{outline:2px solid var(--dsw-focus-ring-color,var(--dsw-alias-state-business-primary));outline-offset:-2px}\n";

    const styleElement = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = css;
      document.head.append(element);
      return element;
    })();

    return {
      apply(ctx) {
        ctx.effect(() => () => styleElement?.remove(), 'dsh-trajectory-ui: styles');
      },
    };
  },
});

// Generate the installable Client bundle (client.js) from the readability layer.
//
// The stylesheet is the source of truth; the bundle is a generated artifact:
//   node build.mjs
import { readFileSync, writeFileSync } from 'node:fs';

const ROOT = new URL('.', import.meta.url);
const PKG_NAME = '@local/dsh-trajectory-ui';
const css = readFileSync(new URL('./trajectory-ui-overrides.css', import.meta.url), 'utf8');

const body = `/**
 * Trajectory ledger readability layer for the DeepSeek Harness web GUI.
 *
 * Generated file - do not edit by hand; run \`node build.mjs\` after editing
 * trajectory-ui-overrides.css.
 *
 * The Client module system keys boot rows by package name, so this bundle must
 * register exactly ${PKG_NAME}. Styles are injected as a plain <style> element:
 * the module system claims the untagged tags a factory created during
 * materialization (data-plugin) and removes them again on teardown, and only
 * platform seed words may be required.
 */
window.__ModuleLoader__.load({
  id: ${JSON.stringify(PKG_NAME)},
  factory() {
    const ID = ${JSON.stringify(PKG_NAME)};
    const css = ${JSON.stringify(css)};

    const styleElement = typeof document === 'undefined' ? null : (() => {
      const element = document.createElement('style');
      element.setAttribute('data-plugin-css', ID);
      element.textContent = css;
      document.head.append(element);
      return element;
    })();

    return {
      apply(ctx) {
        ctx.effect(() => () => styleElement?.remove(), 'dsh-trajectory-ui: styles');
      },
    };
  },
});
`;

writeFileSync(new URL('./client.js', ROOT), body);
console.log(`wrote client.js (${Buffer.byteLength(body)} bytes)`);

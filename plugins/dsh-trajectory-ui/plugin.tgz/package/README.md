# @local/dsh-trajectory-ui

DSH Web GUI の**実行履歴（Trajectory）を読みやすくする表示レイヤー**だけを収録したプラグインです。
`@local/dsh-locale-ja` に混在していた表示調整（旧 `trajectory-ui-overrides.css`）を、
日本語表示プラグインから切り離して独立させたものです。

## 機能

同梱の Trajectory 台帳に対して、読み取り専用のスタイルを追加します。

- 行ホバーのハイライトとトランジション
- ターン先頭行の区切り線（`tr[data-turn-start=true]`）
- セル余白・行間・種別タグの整形
- ペインのスクロールバー余白（`scrollbar-gutter`）とフォーカスリング

本体の Trajectory UI は上書きせず、CSS を追加するだけです。したがって本体更新で
CSS クラス名（`.haSm5q_*` のハッシュ部分）が変わると効かなくなることがあります。
その場合は `trajectory-ui-overrides.css` のセレクターを更新し、再生成してください。

## 構成

| ファイル | 役割 |
|---|---|
| `trajectory-ui-overrides.css` | **正**。追加するスタイルシート |
| `build.mjs` | `client.js` を生成する（手で編集しない） |
| `client.js` | 生成物。`<style data-plugin-css>` を1つ挿入する Client バンドル |
| `index.js` | Host 側。ブラウザー専用のため何もせず、ログのみ |
| `cordis.patch.yml` | Loader 行 `dsh-trajectory-ui` を挿入するバンドルパッチ |
| `locale/en.json` / `locale/ja.json` | Plugin Manager カード用の表示メタデータ |
| `icon.svg` | プラグイン一覧のアイコン |

## スタイルの当て方

Client モジュールシステムには `styles` という名前のモジュールは無く、要求できるのは
プラットフォームの seed（`react` など）だけです。そのためバンドルは factory の実行時に
自前で `<style>` 要素を作って `document.head` に追加します。モジュールシステムは
factory が生成した未タグの `<style>` を `data-plugin` で自身の所有として claim し、
プラグイン無効化・HMR のときに取り除きます。`apply()` は effect の破棄関数で同じ要素を
確実に外します。

## ビルドと検証

```powershell
node dsh-trajectory-ui/build.mjs     # CSS -> client.js
node verify-plugins.mjs              # 契約（id・style 挿入・破棄）を機械検証
```

## インストール

プロファイルにリンクインストール済みです（`$DSH_PROFILE_DIR/package.json` の
`dependencies` と `dsh.profile.bundles`）。バンドル一覧の変更は再起動で反映されます。

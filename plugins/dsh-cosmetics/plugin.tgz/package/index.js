/**
 * Host half of `@local/dsh-cosmetics`.
 *
 * Renaming is Host work, but not *this* plugin's Host work: a Workspace title
 * belongs to the durable workspace registry (`ctx.remote.workspace.rename`) and
 * a Session title belongs to the session log pointed at by the SessionTitle
 * service (`session/title` events). Both are already reachable from the page
 * through the shipped Client services, so this half registers no service and
 * owns no state of its own.
 *
 * It exists because a profile bundle row must resolve a package root:
 * `dsh-client-modules` keys the browser boot graph by the package a row names,
 * and a row whose module cannot be imported would fail the whole composition.
 * Keeping the host half trivial (and side-effect free) is what lets the whole
 * feature ship as one bundle.
 */
export const name = 'dsh-cosmetics';
export const VERSION = '1.0.0';

export function apply(ctx) {
  ctx.logger?.info?.('[cosmetics] active — Workspace/Session names, icons and colours from Settings → 外観');
}

/**
 * Offline verification for `@local/dsh-cosmetics`.
 *
 * The real Client bundle runs unchanged against a stubbed browser surface: a
 * `window.__ModuleLoader__` that hands back the factory, a `localStorage` that
 * records writes, a `document` that records listeners, and a miniature React
 * whose hooks support exactly one render pass per component. Nothing about the
 * bundle is re-implemented here.
 *
 *   node test-cosmetics.mjs
 */
import assert from 'node:assert/strict';

const results = [];
function test(name, fn) {
  results.push({ name, fn });
}

// ── browser surface ─────────────────────────────────────────────────────────

const writes = [];
let stored = null;
const docListeners = new Map();

globalThis.document = {
  createElement: () => ({
    attrs: {},
    textContent: '',
    setAttribute(key, value) {
      this.attrs[key] = value;
    },
    remove() {}
  }),
  head: { append: () => {} },
  body: {},
  documentElement: { setAttribute: () => {}, removeAttribute: () => {}, style: { setProperty: () => {}, removeProperty: () => {} } },
  addEventListener: (type, fn, options) => {
    const list = docListeners.get(type) ?? [];
    list.push(fn);
    docListeners.set(type, list);
    if (type === 'contextmenu') globalThis.document.contextmenuCapture = options === true;
  },
  removeEventListener: (type, fn) => {
    docListeners.set(type, (docListeners.get(type) ?? []).filter((entry) => entry !== fn));
  },
  querySelector: () => null
};
globalThis.window = {
  innerWidth: 1280,
  innerHeight: 800,
  localStorage: {
    getItem: () => stored,
    setItem: (key, value) => {
      writes.push([key, value]);
      stored = value;
    }
  },
  addEventListener: () => {},
  removeEventListener: () => {}
};

/** Deliver a document event to whatever the bundle registered for it. */
function dispatch(type, event) {
  for (const fn of docListeners.get(type) ?? []) fn(event);
}

let factory = null;
globalThis.window.__ModuleLoader__ = {
  load: (definition) => {
    assert.equal(definition.id, '@local/dsh-cosmetics');
    factory = definition.factory;
  }
};

// ── miniature React ─────────────────────────────────────────────────────────

const hookState = [];
let hookIndex = 0;

const ReactShim = {
  createElement(type, props, ...children) {
    return { type, props: props ?? {}, children: children.flat(Infinity).filter((child) => child !== null && child !== undefined && child !== false) };
  },
  useState(initial) {
    const index = hookIndex++;
    if (!(index in hookState)) hookState[index] = typeof initial === 'function' ? initial() : initial;
    return [hookState[index], (next) => {
      hookState[index] = typeof next === 'function' ? next(hookState[index]) : next;
    }];
  },
  useEffect(fn) {
    hookIndex++;
    fn();
  },
  useLayoutEffect(fn) {
    hookIndex++;
    fn();
  },
  useCallback(fn) {
    hookIndex++;
    return fn;
  },
  useRef(value) {
    hookIndex++;
    return { current: value };
  }
};

const modules = {
  react: ReactShim,
  'react-dom': { createPortal: (node) => node }
};
const requireShim = (name) => {
  assert.ok(name in modules, `unexpected require('${name}')`);
  return modules[name];
};

await import('./client.js');
assert.equal(typeof factory, 'function', 'the bundle registered its factory');
const cosmetic = factory(requireShim);
const T = cosmetic.__test;

// ── a miniature renderer ────────────────────────────────────────────────────
//
// One pass per component: hooks are positional and reset for each component
// call, which is enough to catch a typo, a missing prop or a thrown component.

const text = [];
function walk(node) {
  if (node === null || node === undefined || typeof node === 'boolean') return;
  if (typeof node === 'string' || typeof node === 'number') {
    text.push(String(node));
    return;
  }
  if (Array.isArray(node)) {
    for (const child of node) walk(child);
    return;
  }
  const { type, props, children } = node;
  if (typeof type === 'function') {
    hookState.length = 0;
    hookIndex = 0;
    walk(type({ ...props, children }));
    return;
  }
  for (const child of children) walk(child);
}

function render(element) {
  text.length = 0;
  // A fresh hook slot table per render keeps sibling components independent.
  hookState.length = 0;
  walk(element);
  return text.join('\n');
}

/** Every element node in a tree, without expanding function components. */
function collect(node, out = []) {
  if (node === null || node === undefined || typeof node !== 'object') return out;
  if (Array.isArray(node)) {
    for (const child of node) collect(child, out);
    return out;
  }
  out.push(node);
  for (const child of node.children ?? []) collect(child, out);
  return out;
}

/** Expand every component call into host elements, for prop assertions. */
function tree(element) {
  const expand = (node) => {
    if (node === null || node === undefined) return null;
    if (typeof node !== 'object') return node;
    if (Array.isArray(node)) return node.map(expand);
    if (typeof node.type === 'function') {
      hookState.length = 0;
      hookIndex = 0;
      return expand(node.type({ ...node.props, children: node.children }));
    }
    return { ...node, children: node.children.map(expand) };
  };
  return expand(element);
}

/** The rendered host elements of one component, components expanded. */
function nodesOf(element) {
  return collect(tree(element));
}

/** One host node by class name, or null. */
function byClass(nodes, className) {
  return nodes.find((node) => typeof node.props?.className === 'string'
    && node.props.className.split(' ').includes(className)) ?? null;
}

// ── a fake Host/Client context ──────────────────────────────────────────────

function makeContext(services = {}) {
  const injections = [];
  const effects = [];
  const registrations = [];
  const context = {
    logger: { info: () => {}, warn: () => {} },
    locale: {
      register: () => () => {},
      getLocale: () => ({ active: 'ja' })
    },
    slots: {
      inject: (key, callback) => {
        injections.push(key);
        const disposer = callback();
        return () => disposer?.();
      },
      register: (options, component) => {
        registrations.push({ options, component });
        return () => {};
      }
    },
    effect: (fn, label) => {
      effects.push(label);
      return fn();
    },
    get: (name) => services[name]
  };
  return { context, injections, effects, registrations };
}

/** A workspace store shaped like `ClientWorkspaceModel`. */
function workspaceStore(items) {
  const listeners = new Set();
  return {
    snapshot: { items, state: 'idle' },
    getSnapshot() {
      return this.snapshot;
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    set(next) {
      this.snapshot = next;
      for (const listener of listeners) listener();
    }
  };
}

/** A session store shaped like `ClientSessions.list`. */
function sessionStore(snapshot) {
  const listeners = new Set();
  return {
    snapshot,
    getSnapshot() {
      return this.snapshot;
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    set(next) {
      this.snapshot = next;
      for (const listener of listeners) listener();
    }
  };
}

// ── right-click fixtures ────────────────────────────────────────────────────

/** A row element carrying a `data-row-key`, as the shipped rows do. */
function fakeRow(key) {
  const rowElement = { getAttribute: (name) => (name === 'data-row-key' ? key : null) };
  return {
    closest: (selector) => (selector === '[data-row-key]' ? rowElement : null)
  };
}

/** A right-click inside the plugin's own panel. */
function fakePanelHit() {
  return {
    closest: (selector) => (selector === `[${T.panelAttr}]` ? { kind: 'session' } : null)
  };
}

/** A right-click on the sidebar's brand row (its class names carry `brand`). */
function fakeBrandHit() {
  return {
    closest: (selector) => (selector === '[class*="brand"]' ? { className: '_x_brand' } : null)
  };
}

/** A live Client application: services in place, bundle applied. */
function appContext(options = {}) {
  const workspaces = workspaceStore(options.workspaces ?? [
    { workspaceId: 'w1', title: 'default-workspace', path: 'C:\\work', sessionIds: ['s1'] }
  ]);
  const sessions = sessionStore(options.sessions ?? {
    ids: ['s1'],
    byId: {
      s1: { id: 's1', displayTitle: 'First chat', title: 'First chat', updatedAt: 5, retainedBy: { mainView: 1 } }
    }
  });
  const calls = [];
  const built = makeContext({
    workspaces: {
      list: workspaces,
      rename: options.rename ?? (async (id, title) => {
        calls.push(['workspace', id, title]);
        return { workspaceId: id, title };
      })
    },
    sessions: {
      list: sessions,
      using: options.using ?? (async (target, config, operation) => {
        calls.push(['retain', target, config.source]);
        return operation({
          binding: {
            session: {
              rename: async (title) => {
                calls.push(['rename', title]);
                return { ok: true };
              }
            }
          }
        });
      })
    }
  });
  cosmetic.apply(built.context);
  return { ...built, workspaces, sessions, calls };
}

/** Settle the promises a save chains. */
const settled = () => new Promise((resolve) => setTimeout(resolve, 0));

// ── store ───────────────────────────────────────────────────────────────────

test('normalize keeps real choices and drops empty ones', () => {
  const next = T.normalize({
    version: 1,
    brand: { name: '  My App  ', icon: '\u{1F680}' },
    workspaces: {
      a: { icon: '\u{1F4C1}', color: '#FF0000' },
      b: { icon: '', color: '' },
      c: { color: 'not-a-colour' }
    },
    sessions: { s1: { color: '#3d9be5' } }
  });
  assert.deepEqual(next.brand, { name: '  My App  ', icon: '\u{1F680}' });
  assert.deepEqual(next.workspaces.a, { icon: '\u{1F4C1}', color: '#ff0000' });
  assert.equal('b' in next.workspaces, false);
  assert.equal('c' in next.workspaces, false);
  assert.deepEqual(next.sessions.s1, { icon: '', color: '#3d9be5' });
});

test('normalize survives garbage', () => {
  for (const raw of [null, undefined, 42, 'x', [], { workspaces: 7, sessions: 'no', brand: [] }]) {
    assert.deepEqual(T.normalize(raw), T.emptyState());
  }
});

test('safeColor accepts only the bundle\u2019s own colour grammar', () => {
  assert.equal(T.safeColor('#abc'), '#abc');
  assert.equal(T.safeColor('#AABBCC'), '#aabbcc');
  assert.equal(T.safeColor('red'), '');
  assert.equal(T.safeColor('rgb(0,0,0)'), '');
  assert.equal(T.safeColor('#fff;background:url(x)'), '');
  assert.equal(T.safeColor(''), '');
});

test('safeIcon cannot escape a CSS string literal', () => {
  assert.equal(T.safeIcon('\u{1F3A8}'), '\u{1F3A8}');
  assert.equal(T.safeIcon('a"b\\c'), 'ab');
  assert.equal(T.safeIcon('{}\n'), '');
  assert.equal(T.safeIcon(undefined), '');
  assert.equal(T.safeIcon('\u{1F468}\u200D\u{1F469}'), '\u{1F468}\u200D', 'two code points at most');
});

test('patchTable writes, merges and removes entries', () => {
  T.resetAll();
  T.patchTable('workspaces', 'w1', { color: '#e5484d' });
  assert.deepEqual(T.state().workspaces.w1, { icon: '', color: '#e5484d' });
  T.patchTable('workspaces', 'w1', { icon: '\u{1F525}' });
  assert.deepEqual(T.state().workspaces.w1, { icon: '\u{1F525}', color: '#e5484d' });
  T.patchTable('workspaces', 'w1', { color: '' });
  assert.deepEqual(T.state().workspaces.w1, { icon: '\u{1F525}', color: '' });
  T.patchTable('workspaces', 'w1', { icon: '' });
  assert.equal('w1' in T.state().workspaces, false, 'an all-empty entry is dropped');
});

test('patchBrand and resetAll round-trip through localStorage', () => {
  T.resetAll();
  writes.length = 0;
  T.patchBrand({ name: 'Harness', icon: '\u{1F41F}' });
  T.patchTable('sessions', 's1', { color: '#7b61ff' });
  assert.equal(writes.length, 2);
  assert.equal(writes[0][0], T.storeKey);
  const restored = T.readPersisted();
  assert.deepEqual(restored.brand, { name: 'Harness', icon: '\u{1F41F}' });
  assert.deepEqual(restored.sessions.s1, { icon: '', color: '#7b61ff' });
  T.resetAll();
  assert.deepEqual(T.readPersisted(), T.emptyState());
});

test('subscribe notifies every listener and survives one broken listener', () => {
  T.resetAll();
  let good = 0;
  const offBroken = T.subscribe(() => {
    throw new Error('boom');
  });
  const offGood = T.subscribe(() => {
    good += 1;
  });
  T.patchBrand({ name: 'x' });
  offBroken();
  offGood();
  T.patchBrand({ name: 'y' });
  assert.equal(good, 1);
});

// ── the generated stylesheet ────────────────────────────────────────────────

test('renderDynamicCss emits nothing until something is configured', () => {
  assert.equal(T.renderDynamicCss(T.emptyState()), '');
});

test('renderDynamicCss scopes Workspace rules to the shipped row key', () => {
  const css = T.renderDynamicCss(
    T.normalize({ workspaces: { 'w 1': { icon: '\u{1F4C1}', color: '#3fb950' } } })
  );
  assert.match(css, /\[data-row-key="workspace:w 1"\] > span:nth-child\(1\)\{color:#3fb950\}/);
  assert.match(css, /\[data-row-key="workspace:w 1"\] > span:nth-child\(3\) > span\{color:#3fb950\}/);
  assert.match(css, /content:"\u{1F4C1}"/u);
  assert.match(css, /box-shadow:inset 2px 0 0 0 #3fb950/);
  assert.doesNotMatch(css, /data-row-key="session:/);
});

test('renderDynamicCss scopes Session rules to the shipped row key', () => {
  const css = T.renderDynamicCss(T.normalize({ sessions: { 's-1': { color: '#d6409f' } } }));
  assert.equal(css, '[data-row-key="session:s-1"] > span:nth-child(2){color:#d6409f}');
});

test('a quote in an id is escaped, never a second declaration', () => {
  const css = T.renderDynamicCss(T.normalize({ sessions: { 's"]{color:red}': { color: '#abcdef' } } }));
  assert.match(css, /^\[data-row-key="session:s\\"\]\{color:red\}"\] > span:nth-child\(2\)\{color:#abcdef\}$/);
});

// ── right-click resolution ──────────────────────────────────────────────────

test('parseRowKey reads the two editable row kinds and nothing else', () => {
  assert.deepEqual(T.parseRowKey('workspace:w1'), { kind: 'workspace', id: 'w1' });
  assert.deepEqual(T.parseRowKey('session:s:1'), { kind: 'session', id: 's:1' });
  assert.equal(T.parseRowKey('terminal:t1'), null, 'another panel\u2019s rows are left alone');
  assert.equal(T.parseRowKey('workspace:'), null);
  assert.equal(T.parseRowKey(':x'), null);
  assert.equal(T.parseRowKey('nonsense'), null);
  assert.equal(T.parseRowKey(undefined), null);
});

test('resolveTarget names the row, the brand row, or nothing', () => {
  assert.deepEqual(T.resolveTarget(fakeRow('workspace:w1')), { kind: 'workspace', id: 'w1' });
  assert.deepEqual(T.resolveTarget(fakeRow('session:s1')), { kind: 'session', id: 's1' });
  assert.deepEqual(T.resolveTarget(fakeBrandHit()), { kind: 'brand', id: '' });
  assert.equal(T.resolveTarget(fakeRow('terminal:t1')), null, 'an unknown row kind is not ours');
  assert.equal(T.resolveTarget(fakePanelHit()), null, 'a click inside the panel is not a new target');
  assert.equal(T.resolveTarget({}), null, 'a node that cannot be walked is ignored');
  assert.equal(T.resolveTarget(null), null);
});

test('menuFromEvent carries the pointer position and defers to an earlier claim', () => {
  assert.deepEqual(T.menuFromEvent({ target: fakeRow('session:s1'), clientX: 12, clientY: 34 }), {
    kind: 'session',
    id: 's1',
    x: 12,
    y: 34
  });
  assert.equal(T.menuFromEvent({ target: fakeRow('session:s1'), defaultPrevented: true }), null);
  assert.equal(T.menuFromEvent({ target: fakeBrandHit() }).kind, 'brand');
  assert.equal(T.menuFromEvent(undefined), null);
});

// ── apply() against the fake context ────────────────────────────────────────

test('apply mounts the right-click overlay and the Session row seat, and follows brand overrides', () => {
  T.resetAll();
  const { injections, registrations, effects } = appContext();

  assert.deepEqual(injections.filter((key) => !key.startsWith('sidebar.brand')), [
    'shell.overlay',
    'sidebar.session.row.leading'
  ]);
  const overlay = registrations.find((entry) => entry.options.name === 'shell.overlay');
  assert.equal(overlay.options.id, T.overlayId);
  assert.equal(typeof overlay.component, 'function');
  assert.equal(
    registrations.find((entry) => entry.options.name === 'sidebar.session.row.leading').options.order,
    100
  );
  assert.ok(effects.length >= 5, 'every resource is an effect');

  // No brand override yet → the shipped logo and wordmark keep their seats.
  assert.equal(injections.includes('sidebar.brand.mark'), false);
  assert.equal(injections.includes('sidebar.brand.name'), false);

  T.patchBrand({ icon: '\u{1F3A8}' });
  assert.equal(injections.includes('sidebar.brand.mark'), true);
  assert.equal(injections.includes('sidebar.brand.name'), false);

  T.patchBrand({ name: 'Cosmos' });
  assert.equal(injections.includes('sidebar.brand.name'), true);

  T.resetAll();
  const mark = registrations.find((entry) => entry.options.name === 'sidebar.brand.mark');
  assert.equal(mark.options.id, '@local/dsh-cosmetics:mark');
  assert.equal(
    mark.options.priority,
    -1,
    'the shipped brand bundle occupies this single seat at priority 0, so shadowing is the only legal registration'
  );
});

test('the overlay registers one document contextmenu listener and opens a menu from it', () => {
  appContext();
  docListeners.clear();
  render(ReactShim.createElement(cosmetic.__test.components.CosmeticsOverlay));
  assert.equal((docListeners.get('contextmenu') ?? []).length, 1, 'exactly one listener');
  assert.equal(document.contextmenuCapture, true, 'capture runs before app row handlers can claim the event');

  let prevented = 0;
  dispatch('contextmenu', {
    target: fakeRow('session:s1'),
    clientX: 3,
    clientY: 4,
    preventDefault: () => {
      prevented += 1;
    }
  });
  assert.equal(prevented, 1, 'the native menu is suppressed for our rows');

  dispatch('contextmenu', { target: {}, clientX: 0, clientY: 0, preventDefault: () => {
    prevented += 1;
  } });
  assert.equal(prevented, 1, 'an unrelated right-click is left to the app');
});

// ── the panel ───────────────────────────────────────────────────────────────

test('the panel names its target and shows the current choices', () => {
  T.resetAll();
  appContext();
  T.patchTable('workspaces', 'w1', { icon: '\u{1F4C1}', color: '#3fb950' });

  const workspace = render(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'workspace', id: 'w1', x: 10, y: 10 },
    onClose: () => {}
  }));
  assert.match(workspace, /ワークスペース/);
  assert.match(workspace, /default-workspace/);
  assert.match(workspace, /色/);
  assert.match(workspace, /この行をリセット/);

  const session = render(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'session', id: 's1', x: 10, y: 10 },
    onClose: () => {}
  }));
  assert.match(session, /セッション/);
  assert.match(session, /First chat/);
  assert.match(session, /通常/, 'a Session offers the Default chip its Workspace does not');

  const brand = render(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'brand', id: '', x: 10, y: 10 },
    onClose: () => {}
  }));
  assert.match(brand, /アプリ名とマーク/);
  assert.match(brand, /空にすると元のロゴ表示に戻ります/);
  assert.match(brand, /元のロゴ/, 'the header names what is shown now');
  assert.doesNotMatch(brand, /通常|dshcx-picker/, 'the brand panel has no colour row');
  assert.doesNotMatch(brand, /この行をリセット/, 'nothing is configured, so there is nothing to reset');
});

test('the panel writes a colour from a swatch and clears it with the chip', () => {
  T.resetAll();
  appContext();
  const panel = () => nodesOf(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'session', id: 's1', x: 10, y: 10 },
    onClose: () => {}
  }));

  const swatches = panel().filter((node) => node.props.className === 'dshcx-swatch');
  assert.equal(swatches.length, T.colorPresets.length);
  swatches[4].props.onClick();
  assert.equal(T.state().sessions.s1.color, T.colorPresets[4]);

  const normal = panel().find((node) => node.props.className === 'dshcx-chip' && node.children.includes('通常'));
  assert.ok(normal, 'a Session offers the Default chip');
  normal.props.onClick();
  assert.equal('s1' in T.state().sessions, false, 'Default removes the override entirely');

  const picker = byClass(panel(), 'dshcx-picker');
  picker.props.onChange({ target: { value: '#ABCDEF' } });
  assert.equal(T.state().sessions.s1.color, '#abcdef');
});

test('the panel writes a mark from a preset and from free text', () => {
  T.resetAll();
  appContext();
  const panel = () => nodesOf(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'workspace', id: 'w1', x: 10, y: 10 },
    onClose: () => {}
  }));

  const glyphs = panel().filter((node) => node.props.className === 'dshcx-glyph');
  assert.equal(glyphs.length, T.iconPresets.length);
  glyphs[3].props.onClick();
  assert.equal(T.state().workspaces.w1.icon, T.iconPresets[3]);

  const free = byClass(panel(), 'dshcx-free');
  free.props.onChange({ target: { value: '\u{1F984}x' } });
  assert.equal(T.state().workspaces.w1.icon, '\u{1F984}x', 'free text is sanitized, not rejected');

  const chips = panel().filter((node) => node.props.className === 'dshcx-chip');
  assert.equal(chips.length, 2, 'one clear chip for the mark, one for the colour');
  chips[0].props.onClick();
  assert.equal('w1' in T.state().workspaces, false, 'clearing the only choice drops the entry');
});

test('the panel\u2019s reset clears only its own row', () => {
  T.resetAll();
  appContext();
  T.patchTable('workspaces', 'w1', { icon: '\u2B50', color: '#3fb950' });
  T.patchTable('workspaces', 'w2', { color: '#e5484d' });
  T.patchTable('sessions', 's1', { color: '#7b61ff' });

  const nodes = nodesOf(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'workspace', id: 'w1', x: 10, y: 10 },
    onClose: () => {}
  }));
  const reset = nodes.filter((node) => String(node.props.className).split(' ').includes('dshcx-reset'))[0];
  assert.ok(reset, 'a configured row offers a reset');
  reset.props.onClick();

  assert.equal('w1' in T.state().workspaces, false);
  assert.deepEqual(T.state().workspaces.w2, { icon: '', color: '#e5484d' });
  assert.deepEqual(T.state().sessions.s1, { icon: '', color: '#7b61ff' });
});

test('the panel\u2019s rename goes through the shipped Workspace and Session calls', async () => {
  T.resetAll();
  const app = appContext();
  const saveButton = (menu) => byClass(nodesOf(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu,
    onClose: () => {}
  })), 'dshcx-primary');

  saveButton({ kind: 'workspace', id: 'w1', x: 1, y: 1 }).props.onClick();
  await settled();
  saveButton({ kind: 'session', id: 's1', x: 1, y: 1 }).props.onClick();
  await settled();

  assert.deepEqual(app.calls, [
    ['workspace', 'w1', 'default-workspace'],
    ['retain', 's1', 'cosmetics'],
    ['rename', 'First chat']
  ]);
});

test('a refused or impossible rename is reported, never thrown', async () => {
  T.resetAll();
  const { context } = makeContext({
    workspaces: { list: workspaceStore([]), rename: async () => ({}) },
    sessions: {
      list: sessionStore({ ids: ['s1'], byId: { s1: { id: 's1', displayTitle: 'x', updatedAt: 1 } } }),
      using: async (target, config, operation) =>
        operation({ binding: { session: { rename: async () => ({ ok: false, error: { message: 'nope' } }) } } })
    }
  });
  cosmetic.apply(context);

  assert.deepEqual(await T.saveTitle({ kind: 'session', id: 's1' }, 'New chat'), { ok: false, error: 'nope' });
  assert.equal((await T.saveTitle({ kind: 'session', id: 's1' }, '   ')).error, 'empty');

  const bare = makeContext({});
  cosmetic.apply(bare.context);
  assert.equal((await T.saveTitle({ kind: 'workspace', id: 'w1' }, 'x')).error, 'unavailable');
  assert.equal(T.saveStatusText((key) => T.en[key] ?? key, { ok: false, error: 'nope' }), 'Rename refused: nope');
  assert.equal(T.saveStatusText((key) => T.en[key] ?? key, { ok: false, error: 'empty' }), 'A name is required');
  assert.equal(T.saveStatusText((key) => T.en[key] ?? key, { ok: true }), 'Renamed');
});

test('the brand panel renames this bundle\u2019s own text and resets back to nothing', async () => {
  T.resetAll();
  appContext();
  const panel = () => nodesOf(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'brand', id: '', x: 1, y: 1 },
    onClose: () => {}
  }));

  assert.deepEqual(await T.saveTitle({ kind: 'brand', id: '' }, '  Cosmos  '), { ok: true });
  assert.equal(T.state().brand.name, 'Cosmos', 'the brand name is local, so no Host round trip');
  T.patchBrand({ icon: '\u{1F680}' });
  assert.deepEqual(T.state().brand, { name: 'Cosmos', icon: '\u{1F680}' });

  const reset = panel().filter((node) => String(node.props.className).split(' ').includes('dshcx-reset'))[0];
  assert.ok(reset, 'a configured brand offers a reset');
  reset.props.onClick();
  assert.deepEqual(T.state().brand, { name: '', icon: '' });
  assert.deepEqual(T.state(), T.emptyState(), 'and the whole document is empty again');
});

test('the panel renders with no Client services at all', () => {
  T.resetAll();
  const { context } = makeContext({});
  cosmetic.apply(context);
  const html = render(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'session', id: 'missing', x: 1, y: 1 },
    onClose: () => {}
  }));
  assert.equal(typeof html, 'string');
  assert.match(html, /missing/, 'an unknown Session falls back to its id');
});

test('the panel clamps itself into the viewport', () => {
  T.resetAll();
  appContext();
  const nodes = nodesOf(ReactShim.createElement(cosmetic.__test.components.Panel, {
    menu: { kind: 'brand', id: '', x: 5000, y: 5000 },
    onClose: () => {}
  }));
  const panel = byClass(nodes, 'dshcx-panel');
  assert.equal(panel.props.style.visibility, 'hidden', 'the first frame is measured, not shown misplaced');
  const clamp = (value, extent, size) => Math.min(Math.max(value, 12), Math.max(12, extent - size - 12));
  assert.equal(clamp(5000, 1280, 320), 948);
  assert.equal(clamp(-40, 1280, 320), 12);
});

// ── the decorations ─────────────────────────────────────────────────────────

test('the Session row seat draws the Session colour, then its Workspace colour, then nothing', () => {
  const app = appContext();
  const Leading = cosmetic.__test.components.SessionLeading;
  const seat = (sessionId) => tree(ReactShim.createElement(Leading, { sessionId }));

  T.resetAll();
  assert.equal(seat('s1'), null);

  T.patchTable('workspaces', 'w1', { color: '#3fb950' });
  assert.equal(seat('s1').props.style.background, '#3fb950');
  assert.equal(seat('other'), null, 'a Session outside the coloured Workspace is untouched');

  T.patchTable('sessions', 's1', { color: '#e5484d' });
  assert.equal(seat('s1').props.style.background, '#e5484d', 'the Session colour wins');

  T.patchTable('sessions', 's1', { icon: '\u2B50' });
  assert.equal(seat('s1').props.className, 'dshcx-dot', 'a mark never takes the row\u2019s indicator cell');
  assert.equal(seat('s1').props.style.background, '#e5484d', 'and the colour dot stays');

  assert.equal(app.workspaces.getSnapshot().items.length, 1, 'the Workspace store is untouched');
});

test('a Session mark rides the title, beside the row\u2019s own indicator', () => {
  T.resetAll();
  appContext();
  const Leading = cosmetic.__test.components.SessionLeading;

  T.patchTable('sessions', 's1', { icon: '\u2B50' });
  assert.equal(tree(ReactShim.createElement(Leading, { sessionId: 's1' })), null,
    'an icon-only Session leaves the 16px cell to the row\u2019s status dot');
  const css = T.renderCss();
  assert.ok(
    css.includes('[data-row-key="session:s1"] > span:nth-child(2)::before{content:"\u2B50"'),
    `the mark is drawn beside the title instead: ${css}`
  );

  T.patchTable('sessions', 's1', { color: '#e5484d' });
  assert.ok(T.renderCss().includes('[data-row-key="session:s1"] > span:nth-child(2){color:#e5484d}'),
    'the colour keeps colouring the title, independently of the mark');
});

test('the brand cells render their override and nothing otherwise', () => {
  const Mark = cosmetic.__test.components.BrandMark;
  const Name = cosmetic.__test.components.BrandName;
  T.resetAll();
  assert.equal(render(ReactShim.createElement(Mark, { size: 24 })), '');
  assert.equal(render(ReactShim.createElement(Name, {})), '');
  T.patchBrand({ name: 'Cosmos', icon: '\u{1F680}' });
  assert.match(render(ReactShim.createElement(Mark, { size: 24 })), /\u{1F680}/u);
  assert.equal(render(ReactShim.createElement(Name, {})), 'Cosmos');
});

test('the panel follows the active locale', () => {
  assert.equal(T.en.colour, 'Colour');
  assert.equal(T.ja.colour, '色');
  assert.equal(Object.keys(T.en).sort().join(), Object.keys(T.ja).sort().join(), 'both dictionaries carry the same keys');
});

test('every class the bundle renders has a rule in its own stylesheet', () => {
  T.resetAll();
  appContext();
  T.patchTable('workspaces', 'w1', { icon: '\u{1F4C1}', color: '#3fb950' });
  T.patchTable('sessions', 's1', { icon: '\u2B50', color: '#e5484d' });
  T.patchBrand({ name: 'Cosmos', icon: '\u{1F680}' });
  const parts = cosmetic.__test.components;
  const nodes = [
    ...nodesOf(ReactShim.createElement(parts.Panel, { menu: { kind: 'workspace', id: 'w1', x: 1, y: 1 }, onClose: () => {} })),
    ...nodesOf(ReactShim.createElement(parts.Panel, { menu: { kind: 'session', id: 's1', x: 1, y: 1 }, onClose: () => {} })),
    ...nodesOf(ReactShim.createElement(parts.Panel, { menu: { kind: 'brand', id: '', x: 1, y: 1 }, onClose: () => {} })),
    ...nodesOf(ReactShim.createElement(parts.SessionLeading, { sessionId: 's1' })),
    ...nodesOf(ReactShim.createElement(parts.BrandMark, { size: 24 })),
    ...nodesOf(ReactShim.createElement(parts.BrandName, {}))
  ];
  const used = new Set();
  for (const node of nodes) {
    if (typeof node.props?.className !== 'string') continue;
    for (const name of node.props.className.split(' ')) if (name.startsWith('dshcx-')) used.add(name);
  }
  assert.ok(used.size >= 12, `the panel really renders styled parts: ${[...used].sort().join(', ')}`);
  assert.deepEqual([...used].filter((name) => !T.css.includes(`.${name}`)), [], 'a rendered class has no rule');
});

test('the stylesheet is balanced, so a broken rule cannot silently swallow the panel', () => {
  const css = T.css;
  assert.equal((css.match(/\{/g) ?? []).length, (css.match(/\}/g) ?? []).length, 'braces balance');
  assert.ok(!/;;/.test(css), 'no stray double semicolon');
  assert.ok(!/\{\s*\}/.test(css), 'no empty rule');
  assert.ok(!/var\(\s*\)/.test(css), 'no empty var()');
  for (const rule of css.split('}')) {
    if (!rule.includes('{')) continue;
    assert.match(rule.slice(0, rule.indexOf('{')).trim(), /^[@.\w][^{}]*$/, `selector: ${rule.slice(0, 40)}`);
  }
});

test('every theme token the stylesheet names is one the app publishes', () => {
  // The live Theme inspect provider's list, verbatim: a token that is not here
  // does not exist, and the panel would fall back to a hard-coded dark colour
  // that ignores the light theme.
  const known = new Set([
    '--dsw-alias-bg-base',
    '--dsw-alias-bg-layer-1',
    '--dsw-alias-bg-layer-2',
    '--dsw-alias-bg-overlay',
    '--dsw-alias-border-l1',
    '--dsw-alias-border-l2',
    '--dsw-alias-brand-primary',
    '--dsw-alias-label-primary',
    '--dsw-alias-label-secondary',
    '--dsw-alias-state-error-primary',
    '--dsw-alias-state-idle-primary',
    '--dsw-alias-state-success-primary',
    '--dsw-alias-state-warn-primary',
    '--dsw-specific-sidebar-fill'
  ]);
  const used = [...T.css.matchAll(/var\((--dsw-[a-z0-9-]+)/g)].map((match) => match[1]);
  assert.ok(used.length >= 5, 'the panel is themed rather than hard-coded');
  assert.deepEqual([...new Set(used)].filter((name) => !known.has(name)), [], 'unknown theme token');
});

// ── report ──────────────────────────────────────────────────────────────────

let failed = 0;
for (const { name, fn } of results) {
  try {
    await fn();
    console.log(`  ok  ${name}`);
  } catch (error) {
    failed += 1;
    console.log(`FAIL  ${name}`);
    console.log(`      ${error?.message ?? error}`);
  }
}
console.log(`\n${results.length - failed}/${results.length} passed`);
process.exit(failed === 0 ? 0 : 1);

/**
 * `@local/dsh-cosmetics` — Client half.
 *
 * Right-click a Workspace row, a Session row, or the app's brand row in the
 * sidebar and a small panel opens at the pointer:
 *
 *   workspace / session   the real name, an icon, a colour (and `通常` for a
 *                         Session that should keep its Workspace's colour)
 *   brand                 the app name and mark beside the sidebar's logo
 *
 * Names are Host state: a rename goes through `workspaces.rename` or the same
 * `sessions.using(...)` retainer + `session.rename` pair the shipped sidebar's
 * own rename action uses, so search, copy and the hover card all agree.
 * Icons and colours have no Host field in this build (no `*Icon` / `*Color`
 * exists on a Workspace or Session anywhere), so they live in
 * `window.localStorage` under `dsh-cosmetics:v1` — the same choice the
 * `@local/dsh-toast-tune` bundle makes for its preferences.
 *
 * Two shipped DOM facts this bundle reads, both implementation details rather
 * than slot contracts, both failing soft:
 *
 *   `data-row-key="workspace:<id>" | "session:<id>"` — identifies which row a
 *   right-click landed on, and scopes the generated colours to it.
 *   `[class*="brand"]` — the sidebar's brand row, whose class names are
 *   `<module hash>_brand*`.
 *
 * If either changes in a future build, the corresponding cosmetic stops
 * appearing and nothing throws.
 */
window.__ModuleLoader__.load({
  id: '@local/dsh-cosmetics',
  factory(require) {
    const React = require('react');
    const ReactDOM = require('react-dom');
    const h = React.createElement;
    const { useCallback, useEffect, useLayoutEffect, useState, useRef } = React;

    const ID = '@local/dsh-cosmetics';
    const NS = 'dshCosmetics';
    /** One document, one version; a future shape gets its own key. */
    const STORE_KEY = 'dsh-cosmetics:v1';
    /** The `shell.overlay` cell this bundle owns. */
    const OVERLAY_ID = `${ID}:menu`;
    /** Marked on the panel so a pointerdown inside it never dismisses it. */
    const PANEL_ATTR = 'data-dshcx-panel';

    /** Glyphs offered beside the free-text field. */
    const ICON_PRESETS = [
      '\u{1F4C1}', '\u{1F4C2}', '\u{1F9E9}', '\u{1F680}', '\u2699\uFE0F', '\u{1F3A8}',
      '\u{1F525}', '\u2B50', '\u{1F9E0}', '\u{1F4E6}', '\u{1F41F}', '\u{1F48E}'
    ];
    /** Colours offered beside the OS picker. */
    const COLOR_PRESETS = [
      { value: '#e5484d', en: 'Red', ja: '赤' },
      { value: '#e57f3d', en: 'Orange', ja: '橙' },
      { value: '#e5b93d', en: 'Yellow', ja: '黄' },
      { value: '#3fb950', en: 'Green', ja: '緑' },
      { value: '#3d9be5', en: 'Blue', ja: '青' },
      { value: '#7b61ff', en: 'Violet', ja: '紫' },
      { value: '#d6409f', en: 'Pink', ja: '桃' },
      { value: '#8b949e', en: 'Gray', ja: '灰' }
    ];

    const en = {
      kindWorkspace: 'Workspace',
      kindSession: 'Session',
      kindBrand: 'App name and mark',
      name: 'Name',
      namePlaceholder: 'Type a name',
      icon: 'Icon',
      iconFree: 'Type a character',
      colour: 'Colour',
      none: 'None',
      normal: 'Default',
      custom: 'Pick a colour',
      save: 'Rename',
      saving: 'Renaming…',
      saved: 'Renamed',
      saveFailed: 'Rename refused',
      reset: 'Reset this row',
      emptyName: 'A name is required',
      unavailable: 'The Host service is unavailable',
      brandHint: 'Clearing the name restores the shipped wordmark.',
      brandUnset: 'Shipped wordmark',
      close: 'Close'
    };
    const ja = {
      kindWorkspace: 'ワークスペース',
      kindSession: 'セッション',
      kindBrand: 'アプリ名とマーク',
      name: '名前',
      namePlaceholder: '名前を入力',
      icon: 'アイコン',
      iconFree: '文字を入力',
      colour: '色',
      none: 'なし',
      normal: '通常',
      custom: '色を選ぶ',
      save: '変更',
      saving: '変更中…',
      saved: '変更しました',
      saveFailed: '変更できませんでした',
      reset: 'この行をリセット',
      emptyName: '名前を入力してください',
      unavailable: '本体のサービスを利用できません',
      brandHint: '空にすると元のロゴ表示に戻ります。',
      brandUnset: '元のロゴ',
      close: '閉じる'
    };
    const DICTS = { en, ja };

    // ── store ───────────────────────────────────────────────────────────────
    //
    //   { version: 1,
    //     brand: { name: '', icon: '' },
    //     workspaces: { [workspaceId]: { icon: '', color: '' } },
    //     sessions:   { [sessionId]:   { icon: '', color: '' } } }
    //
    // An entry with nothing left in it is dropped, so "configured" is exactly
    // "present" and the generated stylesheet stays empty until asked.

    /** The state of a document that has never been edited. */
    function emptyState() {
      return { version: 1, brand: { name: '', icon: '' }, workspaces: {}, sessions: {} };
    }

    function mapOf(value) {
      return value !== null && typeof value === 'object' && !Array.isArray(value) ? value : {};
    }

    /** One table entry, keeping only choices this bundle can render. */
    function entry(raw) {
      const source = mapOf(raw);
      return { icon: safeIcon(source.icon), color: safeColor(source.color) };
    }

    function isEmptyEntry(value) {
      return value.icon === '' && value.color === '';
    }

    /** Coerce anything read or written into the documented shape. */
    function normalize(raw) {
      const source = mapOf(raw);
      const brand = mapOf(source.brand);
      const next = {
        version: 1,
        brand: { name: typeof brand.name === 'string' ? brand.name : '', icon: safeIcon(brand.icon) },
        workspaces: {},
        sessions: {}
      };
      for (const table of ['workspaces', 'sessions']) {
        for (const [key, value] of Object.entries(mapOf(source[table]))) {
          if (key === '') continue;
          const cleaned = entry(value);
          if (!isEmptyEntry(cleaned)) next[table][key] = cleaned;
        }
      }
      return next;
    }

    /** The document as persisted, or a fresh one. */
    function readPersisted() {
      try {
        const raw = window.localStorage?.getItem(STORE_KEY);
        if (typeof raw !== 'string' || raw === '') return emptyState();
        return normalize(JSON.parse(raw));
      } catch {
        return emptyState();
      }
    }

    let state = emptyState();
    const listeners = new Set();

    function persist() {
      try {
        window.localStorage?.setItem(STORE_KEY, JSON.stringify(state));
      } catch {
        // A full or blocked storage loses the edit, never the session.
      }
    }

    function subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }

    function commit(next) {
      state = normalize(next);
      persist();
      for (const listener of Array.from(listeners)) {
        try {
          listener();
        } catch {
          // One broken listener must not stop the rest.
        }
      }
      return state;
    }

    /** Write one field of one table entry, dropping the entry when it empties. */
    function patchTable(table, id, patch) {
      if (typeof id !== 'string' || id === '') return state;
      const current = entry(state[table]?.[id]);
      const merged = { icon: patch.icon ?? current.icon, color: patch.color ?? current.color };
      const rows = { ...state[table] };
      if (isEmptyEntry(merged)) delete rows[id];
      else rows[id] = merged;
      return commit({ ...state, [table]: rows });
    }

    function patchBrand(patch) {
      return commit({ ...state, brand: { ...state.brand, ...patch } });
    }

    function resetAll() {
      return commit(emptyState());
    }

    // ── sanitizers ──────────────────────────────────────────────────────────

    /** The only colour grammar this bundle emits: `#rgb` or `#rrggbb`. */
    function safeColor(value) {
      if (typeof value !== 'string') return '';
      const text = value.trim().toLowerCase();
      if (/^#[0-9a-f]{3}$/.test(text) || /^#[0-9a-f]{6}$/.test(text)) return text;
      return '';
    }

    /**
     * A mark short enough for a 16px cell and safe inside the CSS string
     * literal it is emitted into: no quote, backslash, brace, angle bracket,
     * line break or line separator, at most two code points.
     */
    function safeIcon(value) {
      if (typeof value !== 'string') return '';
      const text = value.replace(/["\\{}<>\n\r\u2028\u2029]/g, '').trim();
      return Array.from(text).slice(0, 2).join('');
    }

    /** A string as a CSS declaration value, or `''` when it must not be one. */
    function cssValue(value) {
      return typeof value === 'string' && !/["\\{}<>;]/.test(value) ? value : '';
    }

    /** A string as a CSS string literal, quotes and backslashes escaped. */
    function cssString(value) {
      return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/[\n\r]/g, '');
    }

    /**
     * Every configured colour and mark as one stylesheet. Rules are emitted
     * only for entries that exist, so nothing configured means no CSS at all
     * and the sidebar renders exactly as shipped.
     *
     * Workspace rows have no slot to occupy, so their colour and mark ride the
     * row key the shipped component publishes:
     *   child 1 = folder mark, child 2 = chevron, child 3 = title (nested span).
     * A Session row's title is its second child; its own mark is rendered by
     * the real `sidebar.session.row.leading` seat instead.
     */
    function renderDynamicCss(source) {
      const out = [];
      for (const id of Object.keys(source.workspaces ?? {}).sort()) {
        const settings = source.workspaces[id];
        const row = `[data-row-key="workspace:${cssString(id)}"]`;
        if (settings.color !== '') {
          out.push(`${row} > span:nth-child(1){color:${cssValue(settings.color)}}`);
          out.push(`${row} > span:nth-child(3) > span{color:${cssValue(settings.color)}}`);
          out.push(`${row}{box-shadow:inset 2px 0 0 0 ${cssValue(settings.color)}}`);
        }
        if (settings.icon !== '') {
          out.push(
            `${row} > span:nth-child(3)::before{content:"${cssString(settings.icon)}";margin-right:6px;font-size:12px;line-height:1}`
          );
        }
      }
      for (const id of Object.keys(source.sessions ?? {}).sort()) {
        const settings = source.sessions[id];
        const title = `[data-row-key="session:${cssString(id)}"] > span:nth-child(2)`;
        // The mark rides the title, not the 16px cell before it. That cell
        // belongs to the row's own indicator, which the row renders instead of
        // the leading seat whenever it is running, unread or archived — a mark
        // placed there would vanish exactly while the row is busy and crowd the
        // indicator while it is not.
        if (settings.icon !== '') {
          out.push(`${title}::before{content:"${cssString(settings.icon)}";margin-right:6px;font-size:12px;line-height:1}`);
        }
        if (settings.color !== '') out.push(`${title}{color:${cssValue(settings.color)}}`);
      }
      return out.join('');
    }

    // ── right-click target resolution ───────────────────────────────────────

    /**
     * The kind and id a row key stands for, or null when it is not a row this
     * bundle edits (a panel's own rows use other kinds).
     * @param value - a `data-row-key` attribute value.
     */
    function parseRowKey(value) {
      if (typeof value !== 'string') return null;
      const separator = value.indexOf(':');
      if (separator <= 0 || separator === value.length - 1) return null;
      const kind = value.slice(0, separator);
      const id = value.slice(separator + 1);
      if (kind !== 'workspace' && kind !== 'session') return null;
      return { kind, id };
    }

    /** The nearest ancestor the event target sits in, when it can be walked. */
    function closestOf(node, selector) {
      const element = node !== null && typeof node === 'object' ? node : null;
      if (element === null || typeof element.closest !== 'function') return null;
      try {
        return element.closest(selector);
      } catch {
        return null;
      }
    }

    /**
     * What a right-click landed on, or null to leave the event alone.
     * @param node - the event target.
     */
    function resolveTarget(node) {
      if (closestOf(node, `[${PANEL_ATTR}]`) !== null) return null;
      const row = closestOf(node, '[data-row-key]');
      if (row !== null) {
        const key = typeof row.getAttribute === 'function' ? row.getAttribute('data-row-key') : undefined;
        const parsed = parseRowKey(key);
        if (parsed !== null) return parsed;
      }
      if (closestOf(node, '[class*="brand"]') !== null) return { kind: 'brand', id: '' };
      return null;
    }

    /** The menu a contextmenu event asks for, or null when the event is not ours. */
    function menuFromEvent(event) {
      if (event === null || typeof event !== 'object') return null;
      if (event.defaultPrevented === true) return null;
      const target = resolveTarget(event.target);
      if (target === null) return null;
      return { kind: target.kind, id: target.id, x: Number(event.clientX) || 0, y: Number(event.clientY) || 0 };
    }

    // ── helpers over the live Client services ───────────────────────────────

    let clientCtx = null;
    let translate = (key) => (ja[key] ?? en[key] ?? key);

    /** Stable stand-ins so a page without the Client services still renders. */
    const EMPTY_SNAPSHOT = Object.freeze({ items: [], state: 'idle' });
    const EMPTY_STORE = Object.freeze({
      getSnapshot: () => EMPTY_SNAPSHOT,
      subscribe: () => () => {}
    });

    function workspaceStore() {
      const service = clientCtx?.get?.('workspaces');
      return service?.list !== undefined ? service.list : EMPTY_STORE;
    }

    function sessionStore() {
      const service = clientCtx?.get?.('sessions');
      return service?.list !== undefined ? service.list : EMPTY_STORE;
    }

    /** Render on every change of a snapshot store. */
    function useStore(store) {
      const [snapshot, setSnapshot] = useState(() => store.getSnapshot());
      useEffect(() => {
        setSnapshot(store.getSnapshot());
        return store.subscribe(() => setSnapshot(store.getSnapshot()));
      }, [store]);
      return snapshot;
    }

    /** Render on every change of the cosmetics document. */
    function useCosmetics() {
      const [, bump] = useState(0);
      useEffect(() => subscribe(() => bump((value) => value + 1)), []);
      return state;
    }

    /** Which Workspace a Session belongs to, so its colour can be inherited. */
    let workspaceIndex = null;
    let workspaceIndexSource = null;

    function workspaceOf(sessionId) {
      const items = workspaceStore().getSnapshot()?.items;
      if (!Array.isArray(items)) return '';
      if (workspaceIndex === null || workspaceIndexSource !== items) {
        const index = new Map();
        for (const workspace of items) {
          for (const id of workspace?.sessionIds ?? []) index.set(id, workspace.workspaceId);
        }
        workspaceIndex = index;
        workspaceIndexSource = items;
      }
      return workspaceIndex.get(sessionId) ?? '';
    }

    function workspaceEntry(id) {
      return state.workspaces[id] ?? { icon: '', color: '' };
    }

    function sessionEntry(id) {
      return state.sessions[id] ?? { icon: '', color: '' };
    }

    /** A Session's own colour, else its Workspace's, else none. */
    function sessionColor(id) {
      const own = sessionEntry(id).color;
      if (own !== '') return own;
      const owner = workspaceOf(id);
      return owner === '' ? '' : workspaceEntry(owner).color;
    }

    /** The name a row currently shows, from whichever table owns it. */
    function currentTitle(menu, workspaces, sessions) {
      if (menu?.kind === 'brand') return state.brand.name;
      if (menu?.kind === 'workspace') {
        const items = Array.isArray(workspaces?.items) ? workspaces.items : [];
        const found = items.find((item) => item?.workspaceId === menu.id);
        return typeof found?.title === 'string' ? found.title : '';
      }
      const row = sessions?.byId?.[menu?.id];
      const title = row?.displayTitle ?? row?.title;
      return typeof title === 'string' ? title : '';
    }

    /** A short sentence for a refusal or a thrown failure. */
    function reasonOf(error) {
      if (typeof error === 'string') return error;
      if (error !== null && typeof error === 'object' && typeof error.message === 'string') return error.message;
      return String(error ?? '');
    }

    /**
     * Rename whatever the menu points at. A brand name is this bundle's own
     * text; the other two are Host state, written through exactly the calls the
     * shipped sidebar makes, and a refusal is reported rather than swallowed.
     * @returns a promise of `{ok}` so the panel can say what happened.
     */
    function saveTitle(menu, value) {
      const title = typeof value === 'string' ? value.trim() : '';
      if (menu?.kind === 'brand') {
        patchBrand({ name: title });
        return Promise.resolve({ ok: true });
      }
      if (title === '') return Promise.resolve({ ok: false, error: 'empty' });
      if (menu.kind === 'workspace') {
        const service = clientCtx?.get?.('workspaces');
        if (!service || typeof service.rename !== 'function') return Promise.resolve({ ok: false, error: 'unavailable' });
        return Promise.resolve(service.rename(menu.id, title)).then(
          () => ({ ok: true }),
          (error) => ({ ok: false, error: reasonOf(error) })
        );
      }
      const service = clientCtx?.get?.('sessions');
      if (!service || typeof service.using !== 'function') return Promise.resolve({ ok: false, error: 'unavailable' });
      // The shipped action's own pair: retain the Session for the write, then
      // ask its binding to rename it. The retention label is this bundle's own
      // — only `mainView` names the current Session, so a private label never
      // inflates another writer's count.
      return Promise.resolve()
        .then(() => service.using(menu.id, { source: 'cosmetics' }, (reference) => reference.binding.session.rename(title)))
        .then(
          (result) => (result !== null && typeof result === 'object' && result.ok === false
            ? { ok: false, error: reasonOf(result.error) }
            : { ok: true }),
          (error) => ({ ok: false, error: reasonOf(error) })
        );
    }

    // ── components ──────────────────────────────────────────────────────────

    /** One colour choice. */
    function Swatch({ value, current, onPick, size }) {
      return h('button', {
        type: 'button',
        className: 'dshcx-swatch',
        style: { background: value, width: `${size}px`, height: `${size}px` },
        title: value,
        'aria-label': value,
        'data-on': current === value ? '1' : '0',
        onClick: () => onPick(value)
      });
    }

    /** The "no override" chip, parked in its section's head. */
    function NoneChip({ label, on, onPick }) {
      return h('button', {
        type: 'button',
        className: 'dshcx-chip',
        'data-on': on ? '1' : '0',
        onClick: () => onPick('')
      }, label);
    }

    /** A section heading with its own trailing control. */
    function SectionHead({ label, children }) {
      return h('div', { className: 'dshcx-sec-head' },
        h('span', { className: 'dshcx-label' }, label),
        children
      );
    }

    /** The icon section: presets, a clear chip, and a free-text field. */
    function IconRow({ t, value, onPick }) {
      const [free, setFree] = useState('');
      return h('div', { className: 'dshcx-sec' },
        h(SectionHead, { label: t('icon') }, h(NoneChip, { label: t('none'), on: value === '', onPick })),
        h('div', { className: 'dshcx-grid' },
          ICON_PRESETS.map((glyph) => h('button', {
            key: glyph,
            type: 'button',
            className: 'dshcx-glyph',
            'data-on': value === glyph ? '1' : '0',
            'aria-pressed': value === glyph ? 'true' : 'false',
            'aria-label': glyph,
            onClick: () => onPick(glyph)
          }, glyph)),
          h('input', {
            type: 'text',
            className: 'dshcx-free',
            value: free,
            placeholder: '\u270E',
            title: t('iconFree'),
            'aria-label': t('iconFree'),
            onChange: (event) => {
              const text = event.target.value;
              setFree(text);
              const safe = safeIcon(text);
              if (safe !== '') onPick(safe);
            }
          })
        )
      );
    }

    /** The colour section: presets, the clear chip, and the OS picker. */
    function ColorRow({ t, value, onPick, noneLabel }) {
      return h('div', { className: 'dshcx-sec' },
        h(SectionHead, { label: t('colour') }, h(NoneChip, { label: noneLabel, on: value === '', onPick })),
        h('div', { className: 'dshcx-row' },
          COLOR_PRESETS.map((preset) => h(Swatch, {
            key: preset.value,
            value: preset.value,
            current: value,
            size: 26,
            onPick
          })),
          h('input', {
            type: 'color',
            className: 'dshcx-picker',
            value: value === '' ? '#3d9be5' : value,
            title: t('custom'),
            'aria-label': t('custom'),
            onChange: (event) => onPick(safeColor(event.target.value))
          })
        )
      );
    }

    /** The sentence one save outcome shows. */
    function saveStatusText(t, result) {
      if (result !== null && typeof result === 'object' && result.ok === true) return t('saved');
      if (result?.error === 'empty') return t('emptyName');
      if (result?.error === 'unavailable') return t('unavailable');
      return `${t('saveFailed')}: ${result?.error ?? ''}`.trim();
    }

    /**
     * The name field. Workspace and Session names are Host state, so this one
     * needs an explicit commit and can be refused.
     */
    function NameField({ t, current, onSave }) {
      const [draft, setDraft] = useState(null);
      const [status, setStatus] = useState(null);
      const value = draft ?? current;
      const save = () => {
        const title = (draft ?? current).trim();
        if (title === '') {
          setStatus({ text: t('emptyName'), tone: 'bad' });
          return;
        }
        setStatus({ text: t('saving'), tone: 'idle' });
        Promise.resolve(onSave(title)).then((result) => {
          const ok = result !== null && typeof result === 'object' && result.ok === true;
          if (ok) setDraft(null);
          setStatus({ text: saveStatusText(t, result), tone: ok ? 'good' : 'bad' });
        });
      };
      return h('div', { className: 'dshcx-sec' },
        h(SectionHead, { label: t('name') },
          status === null ? null : h('span', { className: 'dshcx-status', 'data-tone': status.tone }, status.text)),
        h('div', { className: 'dshcx-row' },
          h('input', {
            type: 'text',
            className: 'dshcx-input',
            value,
            placeholder: t('namePlaceholder'),
            maxLength: 120,
            'aria-label': t('name'),
            onChange: (event) => setDraft(event.target.value),
            onFocus: (event) => event.target.select(),
            onKeyDown: (event) => {
              if (event.key === 'Enter') {
                event.preventDefault();
                save();
              } else if (event.key === 'Escape' && draft !== null) {
                event.preventDefault();
                event.stopPropagation();
                setDraft(null);
                setStatus(null);
              }
            }
          }),
          h('button', {
            type: 'button',
            className: 'dshcx-btn dshcx-primary',
            disabled: draft === null || draft.trim() === '',
            onClick: save
          }, t('save'))
        )
      );
    }

    /**
     * Place the panel at the pointer, clamped into the viewport and kept put
     * while the page scrolls. The panel measures itself, so the first frame is
     * rendered hidden rather than jumping.
     * @param x - pointer x in viewport coordinates.
     * @param y - pointer y in viewport coordinates.
     * @param panelRef - ref to the panel element.
     */
    function usePanelPosition(x, y, panelRef) {
      const [position, setPosition] = useState(null);
      useLayoutEffect(() => {
        const place = () => {
          const panel = panelRef.current;
          if (panel === null || panel === undefined) return;
          const margin = 12;
          const width = panel.offsetWidth || 320;
          const height = panel.offsetHeight || 360;
          const left = Math.min(Math.max(x, margin), Math.max(margin, window.innerWidth - width - margin));
          const top = Math.min(Math.max(y, margin), Math.max(margin, window.innerHeight - height - margin));
          setPosition((current) => (current !== null && current.left === left && current.top === top
            ? current
            : { left, top }));
        };
        place();
        window.addEventListener('scroll', place, true);
        window.addEventListener('resize', place);
        return () => {
          window.removeEventListener('scroll', place, true);
          window.removeEventListener('resize', place);
        };
      }, [x, y, panelRef]);
      return position;
    }

    /** The right-click panel itself. Mounted only while a menu is open. */
    function Panel({ menu, onClose }) {
      const t = translate;
      useCosmetics();
      const workspaces = useStore(workspaceStore());
      const sessions = useStore(sessionStore());
      const panelRef = useRef(null);
      const position = usePanelPosition(menu.x, menu.y, panelRef);

      const current = currentTitle(menu, workspaces, sessions);
      const stored = menu.kind === 'brand'
        ? { icon: state.brand.icon, color: '' }
        : menu.kind === 'workspace'
          ? workspaceEntry(menu.id)
          : sessionEntry(menu.id);
      const kindLabel = menu.kind === 'brand' ? t('kindBrand') : menu.kind === 'workspace' ? t('kindWorkspace') : t('kindSession');
      const noneLabel = menu.kind === 'session' ? t('normal') : t('none');
      const shown = menu.kind === 'brand'
        ? (state.brand.name === '' ? t('brandUnset') : state.brand.name)
        : (current === '' ? menu.id : current);
      // What the row will actually look like: the mark if there is one, else the
      // colour it resolves to — a Session falls back to its Workspace's colour.
      const tint = stored.color !== ''
        ? stored.color
        : (menu.kind === 'session' ? sessionColor(menu.id) : '');
      const configured = menu.kind === 'brand'
        ? (state.brand.name !== '' || state.brand.icon !== '')
        : (stored.icon !== '' || stored.color !== '');

      const patch = useCallback((next) => {
        if (menu.kind === 'brand') patchBrand(next);
        else patchTable(menu.kind === 'workspace' ? 'workspaces' : 'sessions', menu.id, next);
      }, [menu.kind, menu.id]);

      return h('section', {
        ref: panelRef,
        className: 'dshcx-panel',
        role: 'dialog',
        'aria-label': `${kindLabel}: ${shown}`,
        [PANEL_ATTR]: menu.kind,
        style: position === null
          ? { visibility: 'hidden', left: 0, top: 0 }
          : { left: `${position.left}px`, top: `${position.top}px` }
      },
        h('div', { className: 'dshcx-head' },
          h('span', {
            className: 'dshcx-preview',
            'data-tone': tint === '' ? '0' : '1',
            style: tint === '' ? undefined : { '--dshcx-tint': tint }
          }, stored.icon !== ''
            ? stored.icon
            : (tint === ''
              ? '+'
              : h('span', { className: 'dshcx-preview-dot', style: { background: tint } }))),
          h('span', { className: 'dshcx-heading' },
            h('span', { className: 'dshcx-kind' }, kindLabel),
            h('span', { className: 'dshcx-title', title: shown }, shown)
          ),
          h('button', {
            type: 'button',
            className: 'dshcx-close',
            'aria-label': t('close'),
            onClick: onClose
          }, '\u00D7')
        ),
        h(NameField, {
          t,
          current: menu.kind === 'brand' ? state.brand.name : current,
          onSave: (title) => saveTitle(menu, title)
        }),
        menu.kind === 'brand' ? h('p', { className: 'dshcx-hint' }, t('brandHint')) : null,
        h(IconRow, { t, value: stored.icon, onPick: (icon) => patch({ icon: safeIcon(icon) }) }),
        menu.kind === 'brand' ? null : h(ColorRow, {
          t,
          value: stored.color,
          noneLabel,
          onPick: (color) => patch({ color })
        }),
        configured ? h('div', { className: 'dshcx-foot' },
          h('button', {
            type: 'button',
            className: 'dshcx-btn dshcx-reset',
            onClick: () => {
              patch({ icon: '', color: '' });
              if (menu.kind === 'brand') patchBrand({ name: '' });
            }
          }, t('reset'))
        ) : null
      );
    }

    /**
     * The always-mounted overlay cell: it listens for right-clicks on the two
     * row kinds and the brand row, and portals the panel to the body so no
     * sidebar scroll container can clip it.
     */
    function CosmeticsOverlay() {
      const [menu, setMenu] = useState(null);
      const seq = useRef(0);

      useEffect(() => {
        const onContextMenu = (event) => {
          const next = menuFromEvent(event);
          if (next === null) return;
          event.preventDefault();
          seq.current += 1;
          setMenu({ ...next, token: seq.current });
        };
        // Capture before the app's row handlers: some shipped handlers
        // preventDefault for their own native-menu behavior, which otherwise
        // makes the cosmetics panel miss the same right-click.
        document.addEventListener('contextmenu', onContextMenu, true);
        return () => document.removeEventListener('contextmenu', onContextMenu, true);
      }, []);

      useEffect(() => {
        if (menu === null) return;
        const onKeyDown = (event) => {
          if (event.key === 'Escape') setMenu(null);
        };
        const onPointerDown = (event) => {
          const panel = document.querySelector(`[${PANEL_ATTR}]`);
          if (panel !== null && typeof panel.contains === 'function' && panel.contains(event.target)) return;
          setMenu(null);
        };
        document.addEventListener('keydown', onKeyDown);
        document.addEventListener('pointerdown', onPointerDown);
        return () => {
          document.removeEventListener('keydown', onKeyDown);
          document.removeEventListener('pointerdown', onPointerDown);
        };
      }, [menu]);

      if (menu === null) return null;
      return ReactDOM.createPortal(
        h(Panel, { key: menu.token, menu, onClose: () => setMenu(null) }),
        document.body
      );
    }

    /**
     * The 16px cell before a Session's title: the configured colour, as a dot.
     * The row renders this seat only while it has no indicator of its own, and
     * the mark lives beside the title instead, so nothing here can crowd the
     * row's status dot.
     */
    function SessionLeading(props) {
      useCosmetics();
      const sessionId = typeof props?.sessionId === 'string' ? props.sessionId : '';
      if (sessionId === '') return null;
      const color = sessionColor(sessionId);
      if (color === '') return null;
      return h('span', { className: 'dshcx-dot', style: { background: color }, 'aria-hidden': true });
    }

    /** The brand mark, only while an override exists. */
    function BrandMark(props) {
      useCosmetics();
      const icon = state.brand.icon;
      if (icon === '') return null;
      const size = Number.isFinite(props?.size) ? props.size : 24;
      return h('span', { className: 'dshcx-mark', style: { fontSize: `${size}px` }, 'aria-hidden': true }, icon);
    }

    /** The brand name, only while an override exists. */
    function BrandName() {
      useCosmetics();
      const name = state.brand.name;
      if (name === '') return null;
      return h('span', { className: 'dshcx-appname', title: name }, name);
    }

    const css = `
      .dshcx-dot{display:block;width:8px;height:8px;margin:0 auto;border-radius:999px}
      .dshcx-mark{display:block;text-align:center;line-height:1}
      .dshcx-appname{display:block;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .dshcx-panel{position:fixed;z-index:1100;width:320px;max-height:calc(100vh - 24px);overflow-y:auto;box-sizing:border-box;padding:14px;border-radius:12px;pointer-events:auto;
        background:var(--dsw-alias-bg-layer-1,#fff);
        border:1px solid var(--dsw-alias-border-l2,#3a3a40);
        box-shadow:0 18px 48px rgb(0 0 0 / 42%),0 0 0 1px rgb(0 0 0 / 12%);
        color:var(--dsw-alias-label-primary,#eaeaea);font-size:12px;line-height:1.4;
        animation:dshcx-in 120ms ease-out}
      @keyframes dshcx-in{from{opacity:0;transform:translateY(-4px) scale(.985)}to{opacity:1;transform:none}}
      @media (prefers-reduced-motion:reduce){.dshcx-panel{animation:none}}
      .dshcx-panel *{box-sizing:border-box}
      .dshcx-head{display:flex;align-items:center;gap:10px;padding-bottom:10px;border-bottom:1px solid var(--dsw-alias-border-l1,#3a3a40)}
      .dshcx-preview{flex:none;display:flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:10px;
        font-size:16px;line-height:1;border:1px solid var(--dsw-alias-border-l1,#3a3a40);
        background:color-mix(in srgb,var(--dsw-alias-label-primary) 7%,transparent)}
      .dshcx-preview[data-tone="1"]{background:color-mix(in srgb,var(--dshcx-tint) 24%,transparent);
        border-color:color-mix(in srgb,var(--dshcx-tint) 45%,transparent)}
      .dshcx-preview-dot{display:block;width:12px;height:12px;border-radius:999px}
      .dshcx-heading{flex:1;min-width:0;display:flex;flex-direction:column;gap:1px}
      .dshcx-kind{flex:none;color:var(--dsw-alias-label-secondary,#9a9aa2);font-size:10px;letter-spacing:.04em}
      .dshcx-title{font-weight:600;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      .dshcx-close{flex:none;width:24px;height:24px;padding:0;border:0;border-radius:7px;background:transparent;color:var(--dsw-alias-label-secondary,#9a9aa2);
        font:inherit;font-size:15px;line-height:1;cursor:pointer}
      .dshcx-close:hover{color:inherit;background:color-mix(in srgb,var(--dsw-alias-label-primary) 12%,transparent)}
      .dshcx-sec{padding-top:10px}
      .dshcx-sec-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:6px}
      .dshcx-label{color:var(--dsw-alias-label-primary,#eaeaea);font-size:12px;font-weight:600}
      .dshcx-status{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;
        color:var(--dsw-alias-label-secondary,#9a9aa2)}
      .dshcx-status[data-tone="good"]{color:var(--dsw-alias-state-success-primary,#3fb950)}
      .dshcx-status[data-tone="bad"]{color:var(--dsw-alias-state-error-primary,#ff6b6b)}
      .dshcx-row{display:flex;align-items:center;gap:5px}
      .dshcx-grid{display:flex;flex-wrap:wrap;gap:5px;align-items:center}
      .dshcx-input{flex:1;min-width:0;height:30px;padding:0 10px;border-radius:8px;font:inherit;
        background:var(--dsw-alias-bg-layer-2,rgb(255 255 255 / 7%));border:1px solid var(--dsw-alias-border-l1,#3a3a40);color:inherit}
      .dshcx-input:focus{outline:none;border-color:var(--dsw-alias-brand-primary,#4d8dff);
        box-shadow:0 0 0 3px color-mix(in srgb,var(--dsw-alias-brand-primary) 24%,transparent)}
      .dshcx-free{width:32px;height:30px;padding:0;border-radius:8px;font:inherit;text-align:center;color:inherit;
        border:1px dashed var(--dsw-alias-border-l2,#3a3a40);background:transparent;
        transition:width 120ms ease}
      .dshcx-free::placeholder{color:var(--dsw-alias-label-secondary,#9a9aa2)}
      .dshcx-free:focus{width:76px;outline:none;border-style:solid;border-color:var(--dsw-alias-brand-primary,#4d8dff)}
      .dshcx-btn{display:inline-flex;align-items:center;height:30px;padding:0 13px;border-radius:8px;font:inherit;cursor:pointer;color:inherit;
        white-space:nowrap;background:transparent;border:1px solid var(--dsw-alias-border-l1,#3a3a40)}
      .dshcx-btn:hover{background:color-mix(in srgb,var(--dsw-alias-label-primary) 12%,transparent)}
      .dshcx-btn:disabled{opacity:.4;cursor:default;background:transparent}
      .dshcx-primary{border-color:transparent;background:var(--dsw-alias-brand-primary,#4d8dff);color:#fff;font-weight:600}
      .dshcx-primary:hover:not(:disabled){background:var(--dsw-alias-brand-primary,#4d8dff);filter:brightness(1.08)}
      .dshcx-glyph{width:32px;height:32px;display:flex;align-items:center;justify-content:center;padding:0;border-radius:9px;
        border:1px solid transparent;background:color-mix(in srgb,var(--dsw-alias-label-primary) 7%,transparent);
        color:inherit;font-size:14px;line-height:1;cursor:pointer}
      .dshcx-glyph:hover{background:color-mix(in srgb,var(--dsw-alias-label-primary) 15%,transparent)}
      .dshcx-glyph[data-on="1"]{border-color:var(--dsw-alias-brand-primary,#4d8dff);
        background:color-mix(in srgb,var(--dsw-alias-brand-primary) 20%,transparent)}
      .dshcx-chip{height:24px;padding:0 10px;border-radius:999px;font:inherit;font-size:11px;cursor:pointer;color:var(--dsw-alias-label-secondary,#9a9aa2);
        border:1px solid transparent;background:transparent;white-space:nowrap}
      .dshcx-chip:hover{color:inherit;background:color-mix(in srgb,var(--dsw-alias-label-primary) 12%,transparent)}
      .dshcx-chip[data-on="1"]{color:inherit;border-color:var(--dsw-alias-border-l2,#3a3a40);
        background:color-mix(in srgb,var(--dsw-alias-label-primary) 9%,transparent)}
      .dshcx-swatch{border:0;border-radius:999px;cursor:pointer;padding:0;box-shadow:inset 0 0 0 1px rgb(0 0 0 / 18%);
        transition:transform 90ms ease}
      .dshcx-swatch:hover{transform:scale(1.09)}
      .dshcx-swatch[data-on="1"]{box-shadow:inset 0 0 0 1px rgb(0 0 0 / 18%),0 0 0 2px var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-layer-2,#1b1b1f)),0 0 0 3.5px var(--dsw-alias-brand-primary,#4d8dff)}
      .dshcx-picker{flex:none;width:24px;height:24px;padding:3px;border:0;border-radius:999px;cursor:pointer;
        appearance:none;-webkit-appearance:none;
        background:conic-gradient(from 210deg,#e5484d,#e5b93d,#3fb950,#3d9be5,#7b61ff,#d6409f,#e5484d)}
      .dshcx-picker::-webkit-color-swatch-wrapper{padding:0}
      .dshcx-picker::-webkit-color-swatch{border:2px solid var(--dsw-alias-bg-overlay,var(--dsw-alias-bg-layer-2,#1b1b1f));border-radius:999px}
      .dshcx-hint{margin:6px 0 0;color:var(--dsw-alias-label-secondary,#9a9aa2);font-size:11px}
      .dshcx-foot{display:flex;justify-content:flex-end;margin-top:12px;padding-top:10px;border-top:1px solid var(--dsw-alias-border-l1,#3a3a40)}
      .dshcx-reset{border-color:transparent;color:var(--dsw-alias-label-secondary,#9a9aa2)}
      .dshcx-reset:hover{color:var(--dsw-alias-state-error-primary,#ff6b6b);
        background:color-mix(in srgb,var(--dsw-alias-state-error-primary) 12%,transparent)}
    `;

    return {
      inject: ['slots', 'locale'],
      apply(ctx) {
        clientCtx = ctx;
        state = readPersisted();

        translate = (key, params) => {
          let dict = ja;
          try {
            const active = ctx.locale.getLocale()?.active;
            const base = typeof active === 'string' ? active.split('-')[0].toLowerCase() : '';
            dict = DICTS[base] ?? en;
          } catch {
            dict = en;
          }
          const raw = dict[key] ?? en[key] ?? key;
          if (typeof raw !== 'string' || params === undefined) return raw;
          return raw.replace(/\{(\w+)\}/g, (match, name) => (name in params ? String(params[name]) : match));
        };

        ctx.effect(() => ctx.locale.register(NS, DICTS), 'dsh-cosmetics: dictionaries');

        const styleElement = typeof document === 'undefined' ? null : (() => {
          const element = document.createElement('style');
          element.setAttribute('data-plugin-css', ID);
          element.textContent = css;
          document.head.append(element);
          return element;
        })();
        ctx.effect(() => () => styleElement?.remove(), 'dsh-cosmetics: styles');

        // The generated rules are one element rewritten in place, so a colour
        // change costs one text assignment rather than a stylesheet teardown.
        // The guard matters: every keystroke in a name field publishes, and an
        // identical assignment would still invalidate the document's styles.
        const dynamicElement = typeof document === 'undefined' ? null : (() => {
          const element = document.createElement('style');
          element.setAttribute('data-plugin-css', `${ID}:generated`);
          document.head.append(element);
          return element;
        })();
        const paint = () => {
          if (dynamicElement === null) return;
          const next = renderDynamicCss(state);
          if (dynamicElement.textContent !== next) dynamicElement.textContent = next;
        };
        const unsubscribePaint = subscribe(paint);
        paint();
        ctx.effect(() => () => {
          unsubscribePaint();
          dynamicElement?.remove();
        }, 'dsh-cosmetics: generated styles');

        // One always-mounted cell in the frame-wide overlay: it owns the
        // right-click listener and portals the panel above every column.
        ctx.effect(() => ctx.slots.inject('shell.overlay', () => ctx.slots.register({
          name: 'shell.overlay',
          id: OVERLAY_ID,
          order: 90,
          inject: () => ({})
        }, CosmeticsOverlay)), 'dsh-cosmetics: right-click menu');

        // The Session row's own 16px cell.
        ctx.effect(() => ctx.slots.inject('sidebar.session.row.leading', () => ctx.slots.register({
          name: 'sidebar.session.row.leading',
          id: `${ID}:leading`,
          order: 100,
          inject: () => ({})
        }, SessionLeading)), 'dsh-cosmetics: session row marks');

        // The brand row is two `single` seats already occupied by
        // `@deepseek-ai/dsh-client-ui-brand-official` at priority 0, where an
        // equal-priority registration throws and a lower priority shadows.
        // Shadowing is the intent, and it is reversible: an entry exists only
        // while an override does, so clearing it hands the seat back.
        const brand = { mark: null, name: null, markOn: false, nameOn: false };
        const occupy = (slot, id, component) => {
          try {
            return ctx.slots.inject(slot, () => ctx.slots.register({
              name: slot,
              id,
              priority: -1,
              inject: () => ({})
            }, component));
          } catch (error) {
            ctx.logger?.warn?.(`[cosmetics] could not occupy ${slot}: ${error?.message ?? error}`);
            return null;
          }
        };
        // Only the presence of an override moves the registration: the occupant
        // reads the live value itself, so editing the text does not churn the
        // seat.
        const syncBrand = () => {
          const markOn = state.brand.icon !== '';
          if (brand.markOn !== markOn) {
            brand.markOn = markOn;
            brand.mark?.();
            brand.mark = null;
            if (markOn) brand.mark = occupy('sidebar.brand.mark', `${ID}:mark`, BrandMark);
          }
          const nameOn = state.brand.name !== '';
          if (brand.nameOn !== nameOn) {
            brand.nameOn = nameOn;
            brand.name?.();
            brand.name = null;
            if (nameOn) brand.name = occupy('sidebar.brand.name', `${ID}:name`, BrandName);
          }
        };
        const unsubscribeBrand = subscribe(syncBrand);
        syncBrand();
        ctx.effect(() => () => {
          unsubscribeBrand();
          brand.mark?.();
          brand.name?.();
          brand.mark = null;
          brand.name = null;
        }, 'dsh-cosmetics: brand row');
      },
      /** Test seam: the pure helpers and every component, so the bundle is verifiable in node. */
      __test: {
        id: ID,
        namespace: NS,
        storeKey: STORE_KEY,
        overlayId: OVERLAY_ID,
        panelAttr: PANEL_ATTR,
        iconPresets: ICON_PRESETS,
        colorPresets: COLOR_PRESETS.map((preset) => preset.value),
        en,
        ja,
        css,
        emptyState,
        normalize,
        safeColor,
        safeIcon,
        cssValue,
        cssString,
        renderDynamicCss,
        parseRowKey,
        resolveTarget,
        menuFromEvent,
        currentTitle,
        saveTitle,
        saveStatusText,
        readPersisted,
        commit,
        patchTable,
        patchBrand,
        resetAll,
        subscribe,
        state: () => state,
        setState: (next) => {
          state = normalize(next);
        },
        renderCss: () => renderDynamicCss(state),
        components: {
          Panel,
          CosmeticsOverlay,
          SessionLeading,
          BrandMark,
          BrandName,
          NameField,
          IconRow,
          ColorRow,
          Swatch,
          NoneChip,
          SectionHead
        }
      }
    };
  }
});

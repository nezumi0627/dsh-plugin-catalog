import assert from 'node:assert/strict';
import { normalizeState, normalizeUrl, saveFavorite, removeFavorite, moveFavorite, recordRecent } from './state.js';

assert.equal(normalizeUrl('example.com/search?q=dsh'), 'https://example.com/search?q=dsh');
assert.equal(normalizeUrl('http://localhost:3000'), 'http://localhost:3000/');
assert.equal(normalizeUrl('javascript:alert(1)'), null);
assert.equal(normalizeUrl('https://user:pass@example.com'), null);
assert.equal(normalizeUrl('https://example.com/' + 'x'.repeat(2050)), null);

const defaults = normalizeState(null);
assert.deepEqual(defaults, { version: 1, favorites: [], recent: [] });
const first = saveFavorite(defaults, { id: 'a', title: '', url: 'example.com' });
assert.equal(first.favorites[0].title, 'example.com');
const updated = saveFavorite(first, { id: 'b', title: 'Example', url: 'https://example.com/' });
assert.equal(updated.favorites.length, 1, 'duplicate normalized URLs update one saved item');
assert.equal(updated.favorites[0].id, 'a');
assert.equal(updated.favorites[0].title, 'Example');
const second = saveFavorite(updated, { id: 'b', title: 'Local', url: 'http://localhost:3000' });
assert.equal(moveFavorite(second, 'b', -1).favorites[0].id, 'b');
assert.equal(removeFavorite(second, 'a').favorites.length, 1);
const recent = recordRecent(recordRecent(defaults, { title: 'Site', url: 'https://example.com' }), { title: 'Site 2', url: 'https://example.com/' });
assert.equal(recent.recent.length, 1, 'recent URLs are de-duplicated');
assert.equal(recent.recent[0].title, 'Site 2');
assert.equal(normalizeState({ version: 99, favorites: [1], recent: [] }).favorites.length, 0);
assert.equal(normalizeState({ version: 1, favorites: Array.from({ length: 120 }, (_, i) => ({ id: String(i), title: `S${i}`, url: `https://site${i}.example` })), recent: [] }).favorites.length, 100);

console.log('browser favorites URL policy, persistence normalization, upsert, ordering, removal and bounded recent list passed');

import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const manifest = JSON.parse(await readFile(new URL('./package.json', import.meta.url), 'utf8'));
assert.equal(manifest.name, '@local/dsh-browser');
assert.deepEqual(manifest.dsh.client.inject, ['@deepseek-ai/dsh-client-ui-layout', '@deepseek-ai/dsh-client-locale', '@deepseek-ai/dsh-client-ui-sidebar-right']);
assert.ok(!manifest.dsh.client.inject.includes('@deepseek-ai/dsh-client-store'), 'the store package is a require seed, not an activation service');

const specs = [];
const hookState = [];
let hookCursor = 0;
const React = {
  createElement: (type, props, ...children) => ({ type, props: props ?? {}, children }),
  useState(initial) { const index = hookCursor++; if (!(index in hookState)) hookState[index] = typeof initial === 'function' ? initial() : initial; return [hookState[index], (value) => { hookState[index] = typeof value === 'function' ? value(hookState[index]) : value; }]; },
  useEffect() {},
};
globalThis.document = {
  createElement: () => ({ attrs: {}, setAttribute(key, value) { this.attrs[key] = value; }, remove() { this.removed = true; } }),
  head: { append(element) { this.style = element; } },
};
globalThis.window = { __ModuleLoader__: { load: (spec) => specs.push(spec) } };
let storeOptions;
let storeValue = { version: 1, favorites: [], recent: [] };
const store = {
  getSnapshot: () => storeValue,
  set: (value) => { storeValue = value; },
  subscribe: () => () => {},
};
await import('./client.js');
assert.equal(specs.length, 1);
const mod = specs[0].factory((name) => {
  if (name === 'react') return React;
  if (name === '@deepseek-ai/dsh-client-store') return { createSnapshotStore: (_initial, options) => { storeOptions = options; return store; } };
  throw new Error(`unexpected require: ${name}`);
});
assert.equal(storeOptions.persist.name, 'dsh.browser.favorites.v1');
const registrations = [];
const tabRegistry = [];
const disposers = [];
const ctx = {
  effect(run) { const dispose = run(); if (typeof dispose === 'function') disposers.push(dispose); },
  locale: { register: () => () => {}, bind: () => (key) => key },
  sidebarRightTabs: { register: (definition) => { tabRegistry.push(definition); return () => {}; } },
  slots: {
    inject(name, callback) { callback(); },
    register(definition, component) { registrations.push({ definition, component }); return () => {}; },
  },
};
mod.apply(ctx);
assert.equal(tabRegistry[0].kind, 'browser-favorites');
assert.ok(registrations.some(({ definition }) => definition.name === 'sidebar.right.tab.guide.entry'));
assert.ok(registrations.some(({ definition }) => definition.name === 'sidebar.right.pane.tab'));
assert.ok(registrations.some(({ definition }) => definition.name === 'sidebar.right.pane.tab.title'));
const navigation = [];
mod.__test.openInBrowser({ actions: { openTab: (...args) => navigation.push(args) } }, { url: 'https://example.com' });
assert.deepEqual(navigation, [['browser', { params: { url: 'https://example.com' }, replaceTab: true }]]);
assert.equal(mod.__test.normalizeUrl('javascript:alert(1)'), null);
assert.equal(mod.__test.normalizeUrl('https://user:pass@example.com'), null);
assert.equal(mod.__test.normalizeState({ version: 8 }).favorites.length, 0);
const item = { id: 'discord', title: 'Discord', url: 'https://discord.com/channels/@me' };
storeValue = { version: 1, favorites: [item], recent: [] };
const findByClass = (node, className) => {
  if (!node || typeof node !== 'object') return null;
  if (node.props?.className === className) return node;
  for (const child of node.children ?? []) { const found = findByClass(child, className); if (found) return found; }
  return null;
};
let rejectNavigation = true;
const tab = { actions: { openTab: () => rejectNavigation ? Promise.reject(new Error('pane rejected')) : Promise.resolve() } };
hookCursor = 0;
let panel = mod.__test.BrowserFavorites({ title: 'Favorites', useTabInfo: () => ({ tab }), t: (key) => key });
await findByClass(panel, 'dshbf-open').props.onClick();
assert.equal(storeValue.recent.length, 0, 'a rejected tab switch is handled without claiming the link opened');
rejectNavigation = false;
hookCursor = 0;
panel = mod.__test.BrowserFavorites({ title: 'Favorites', useTabInfo: () => ({ tab }), t: (key) => key });
await findByClass(panel, 'dshbf-open').props.onClick();
assert.equal(storeValue.recent[0].url, item.url, 'successful Browser navigation is recorded');
for (const dispose of disposers.reverse()) dispose();
assert.equal(document.head.style.removed, true);
console.log('browser tools manifest, shared-store persistence, sidebar registration, Browser navigation and teardown passed');

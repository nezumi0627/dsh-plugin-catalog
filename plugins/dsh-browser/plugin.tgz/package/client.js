function openInBrowser(tab, { url }) {
  return tab.actions.openTab('browser', { params: { url }, replaceTab: true });
}

window.__ModuleLoader__.load({
  id: '@local/dsh-browser',
  factory(require) {
    const React = require('react');
    const h = React.createElement;
    const { useEffect, useState } = React;
    const { createSnapshotStore } = require('@deepseek-ai/dsh-client-store');
    const ID = '@local/dsh-browser';
    const KIND = 'browser-favorites';
    const NS = 'dshBrowser';
    const KEY = 'dsh.browser.favorites.v1';
    const normalizeUrl = (value) => {
      const raw = String(value ?? '').trim();
      if (!raw || raw.length > 2048) return null;
      try {
        const parsed = new URL(/^[a-z][a-z\d+.-]*:/i.test(raw) ? raw : `https://${raw}`);
        return (parsed.protocol === 'http:' || parsed.protocol === 'https:') && parsed.hostname && !parsed.username && !parsed.password && parsed.href.length <= 2048 ? parsed.href : null;
      } catch { return null; }
    };
    const normalizeState = (raw) => {
      if (!raw || typeof raw !== 'object' || Array.isArray(raw) || raw.version !== 1) return { version: 1, favorites: [], recent: [] };
      const clean = (list, limit) => {
        const seen = new Set(), result = [];
        for (const item of Array.isArray(list) ? list : []) {
          const url = normalizeUrl(item?.url), id = String(item?.id ?? '').trim().slice(0, 80);
          if (!url || !id || seen.has(url)) continue;
          seen.add(url);
          const title = String(item?.title ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 80);
          result.push({ id, title: title || new URL(url).hostname, url });
          if (result.length >= limit) break;
        }
        return result;
      };
      return { version: 1, favorites: clean(raw.favorites, 100), recent: clean(raw.recent, 40) };
    };
    const saveFavorite = (state, { id, title, url }) => {
      const next = normalizeState(state), safeUrl = normalizeUrl(url);
      if (!safeUrl) throw new TypeError('Enter a valid HTTP or HTTPS URL.');
      const existing = next.favorites.find((item) => item.url === safeUrl);
      const safeTitle = String(title ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 80) || new URL(safeUrl).hostname;
      const favorite = { id: existing?.id ?? String(id ?? '').trim().slice(0, 80), title: safeTitle, url: safeUrl };
      if (!favorite.id) throw new TypeError('Favorite id is required.');
      return { ...next, favorites: existing ? next.favorites.map((item) => item.id === existing.id ? favorite : item) : [...next.favorites, favorite].slice(-100) };
    };
    const removeFavorite = (state, id) => { const next = normalizeState(state); return { ...next, favorites: next.favorites.filter((item) => item.id !== id) }; };
    const moveFavorite = (state, id, delta) => {
      const next = normalizeState(state), list = [...next.favorites], from = list.findIndex((item) => item.id === id);
      if (from < 0 || !Number.isFinite(delta)) return next;
      const to = Math.max(0, Math.min(list.length - 1, from + Math.trunc(delta)));
      if (to !== from) { const [item] = list.splice(from, 1); list.splice(to, 0, item); }
      return { ...next, favorites: list };
    };
    const recordRecent = (state, { id, title, url }) => {
      const next = normalizeState(state), safeUrl = normalizeUrl(url);
      if (!safeUrl) return next;
      const safeTitle = String(title ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 80) || new URL(safeUrl).hostname;
      return { ...next, recent: [{ id: String(id).slice(0, 80), title: safeTitle, url: safeUrl }, ...next.recent.filter((item) => item.url !== safeUrl)].slice(0, 40) };
    };
    const CSS = `.dshbf-root{box-sizing:border-box;width:100%;height:100%;min-height:0;overflow:auto;padding:14px;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-base);font:13px/1.45 var(--dsw-font-family,system-ui,sans-serif)}.dshbf-head{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:12px}.dshbf-title{font-size:15px;font-weight:650}.dshbf-form{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:7px;margin-bottom:16px}.dshbf-input,.dshbf-button{box-sizing:border-box;min-height:34px;border:1px solid var(--dsw-alias-border-l1);border-radius:var(--dsw-radius-sm,7px);color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-1);font:inherit}.dshbf-input{min-width:0;padding:0 9px}.dshbf-button{padding:0 10px;cursor:pointer}.dshbf-button:hover:not(:disabled){background:var(--dsw-alias-bg-layer-2)}.dshbf-button:disabled{opacity:.45;cursor:default}.dshbf-list{display:grid;gap:6px}.dshbf-section{margin:14px 0 7px;color:var(--dsw-alias-label-secondary);font-size:11px;font-weight:600}.dshbf-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:center;gap:6px;padding:6px;border:1px solid var(--dsw-alias-border-l1);border-radius:9px;background:var(--dsw-alias-bg-layer-1)}.dshbf-open{min-width:0;padding:3px 5px;border:0;background:transparent;color:inherit;text-align:left;cursor:pointer;font:inherit}.dshbf-name,.dshbf-url{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.dshbf-name{font-weight:550}.dshbf-url{color:var(--dsw-alias-label-tertiary);font-size:11px}.dshbf-actions{display:flex;gap:3px}.dshbf-actions .dshbf-button{min-width:30px;padding:0 7px}.dshbf-empty,.dshbf-error{color:var(--dsw-alias-label-secondary)}.dshbf-error{margin:7px 0;color:var(--dsw-alias-state-error-primary)}.dshbf-guide{all:unset;box-sizing:border-box;position:relative;width:100%;min-height:56px;display:flex;align-items:center;gap:14px;padding:12px 18px;text-align:left;color:var(--dsw-alias-label-primary);background:var(--dsw-alias-bg-layer-1);border:.5px solid var(--dsw-alias-border-l1);border-radius:var(--dsl-guide-entry-radius,16px);cursor:pointer;font:inherit}.dshbf-guide-icon{width:26px;height:26px;display:grid;place-items:center;color:#2787f5}.dshbf-guide-icon svg{width:23px;height:23px}@media(prefers-reduced-motion:reduce){.dshbf-root *{scroll-behavior:auto}}`;
    const style = typeof document === 'undefined' ? null : (() => { const el = document.createElement('style'); el.setAttribute('data-plugin-css', ID); el.textContent = CSS; document.head.append(el); return el; })();
    let store;
    try { store = createSnapshotStore(() => ({ version: 1, favorites: [], recent: [] }), { flush: 'raf', persist: { name: KEY } }); } catch { store = null; }
    let memory = { version: 1, favorites: [], recent: [] };
    const read = () => { try { return normalizeState(store?.getSnapshot() ?? memory); } catch { return normalizeState(memory); } };
    const write = (next) => { memory = normalizeState(next); try { store?.set(memory); } catch { store = null; } };

    function BrowserFavorites({ title, useTabInfo, t }) {
      const [state, setState] = useState(read);
      const [name, setName] = useState('');
      const [url, setUrl] = useState('');
      const [error, setError] = useState('');
      const { tab } = useTabInfo();
      useEffect(() => {
        const unsubscribe = store?.subscribe(() => setState(read()));
        return () => unsubscribe?.();
      }, []);
      const persist = (next) => { write(next); setState(read()); };
      const open = async (item) => {
        try {
          const normalized = normalizeUrl(item.url);
          if (!normalized) throw new TypeError(t('invalid'));
          await openInBrowser(tab, { url: normalized });
          persist(recordRecent(read(), { id: `recent-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, title: item.title, url: normalized }));
          setError('');
        } catch (cause) { setError(cause?.message || t('openFailed')); }
      };
      const submit = (event) => {
        event.preventDefault();
        try {
          const next = saveFavorite(read(), { id: `favorite-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, title: name, url });
          persist(next); setName(''); setUrl(''); setError('');
        } catch (cause) { setError(cause?.message || t('invalid')); }
      };
      const row = (item, recent = false, index = 0) => h('div', { key: `${recent ? 'r' : 'f'}-${item.id}`, className: 'dshbf-row' },
        h('button', { className: 'dshbf-open', type: 'button', title: item.url, onClick: () => open(item) }, h('span', { className: 'dshbf-name' }, item.title), h('span', { className: 'dshbf-url' }, item.url)),
        recent ? null : h('span', { className: 'dshbf-actions' },
          h('button', { className: 'dshbf-button', type: 'button', title: t('moveUp'), 'aria-label': `${t('moveUp')}: ${item.title}`, disabled: index === 0, onClick: () => persist(moveFavorite(read(), item.id, -1)) }, '↑'),
          h('button', { className: 'dshbf-button', type: 'button', title: t('moveDown'), 'aria-label': `${t('moveDown')}: ${item.title}`, disabled: index === state.favorites.length - 1, onClick: () => persist(moveFavorite(read(), item.id, 1)) }, '↓'),
          h('button', { className: 'dshbf-button', type: 'button', title: t('delete'), 'aria-label': `${t('delete')}: ${item.title}`, onClick: () => persist(removeFavorite(read(), item.id)) }, '×'),
        ),
      );
      return h('main', { className: 'dshbf-root' },
        h('div', { className: 'dshbf-head' }, h('strong', { className: 'dshbf-title' }, title)),
        h('form', { className: 'dshbf-form', onSubmit: submit },
          h('input', { className: 'dshbf-input', value: name, maxLength: 80, placeholder: t('name'), 'aria-label': t('name'), onChange: (event) => setName(event.currentTarget.value) }),
          h('input', { className: 'dshbf-input', value: url, type: 'url', inputMode: 'url', maxLength: 2048, placeholder: t('url'), 'aria-label': t('url'), onChange: (event) => setUrl(event.currentTarget.value) }),
          h('button', { className: 'dshbf-button', type: 'submit', disabled: state.favorites.length >= 100 && !state.favorites.some((item) => item.url === normalizeUrl(url)) }, t('save')),
        ),
        error ? h('p', { className: 'dshbf-error', role: 'alert' }, error) : null,
        h('h2', { className: 'dshbf-section' }, `${t('favorites')} · ${state.favorites.length}`),
        state.favorites.length ? h('div', { className: 'dshbf-list' }, ...state.favorites.map((item, index) => row(item, false, index))) : h('p', { className: 'dshbf-empty' }, t('empty')),
        h('h2', { className: 'dshbf-section' }, t('recent')),
        state.recent.length ? h('div', { className: 'dshbf-list' }, ...state.recent.map((item) => row(item, true))) : h('p', { className: 'dshbf-empty' }, t('recentEmpty')),
      );
    }

    function BrowserIcon() {
      return h('svg', { viewBox: '0 0 24 24', fill: 'none', 'aria-hidden': 'true' },
        h('circle', { cx: '12', cy: '12', r: '9.25', stroke: 'currentColor', strokeWidth: '1.6' }),
        h('path', { d: 'M3 10h18M12 2.75a14 14 0 0 1 0 18.5M12 2.75a14 14 0 0 0 0 18.5', stroke: 'currentColor', strokeWidth: '1.4' }),
      );
    }
    function Guide({ title, description, kind, useTabInfo }) {
      const { tab } = useTabInfo();
      return h('button', { className: 'dshbf-guide', type: 'button', 'data-sidebar-right-guide-entry': kind, onClick: () => tab.actions.openTab(kind, { replaceTab: true }) },
        h('span', { className: 'dshbf-guide-icon' }, h(BrowserIcon)), h('span', null, h('strong', null, title), h('br'), h('small', null, description)),
      );
    }
    function Title({ title }) { return h('span', null, title); }

    return {
      inject: ['slots', 'locale', 'sidebarRightTabs'],
      apply(ctx) {
        const t = ctx.locale.bind(NS);
        ctx.effect(() => () => style?.remove(), 'dsh-browser.styles');
        ctx.effect(() => ctx.locale.register(NS, {
          ja: { title: 'ブラウザお気に入り', description: '保存したサイトをBrowserで開く', name: '名前（任意）', url: 'https://example.com', save: '保存', favorites: 'お気に入り', empty: '保存したサイトはありません', recent: 'お気に入りから最近開いたサイト', recentEmpty: 'このパネルから開いたサイトはまだありません', moveUp: '上へ移動', moveDown: '下へ移動', delete: '削除', invalid: 'HTTPまたはHTTPSの有効なURLを入力してください', openFailed: 'Browserでサイトを開けませんでした' },
          en: { title: 'Browser favorites', description: 'Open saved sites in Browser', name: 'Name (optional)', url: 'https://example.com', save: 'Save', favorites: 'Favorites', empty: 'No saved sites yet.', recent: 'Recently opened from favorites', recentEmpty: 'No links opened from this panel yet.', moveUp: 'Move up', moveDown: 'Move down', delete: 'Delete', invalid: 'Enter a valid HTTP or HTTPS URL.', openFailed: 'Could not open the site in Browser.' },
        }), 'dsh-browser.locale');
        ctx.effect(() => ctx.sidebarRightTabs.register({ id: ID, kind: KIND, title: () => t('title'), guide: [{ id: 'favorites', order: 41, icon: BrowserIcon, title: () => t('title'), description: () => t('description') }] }), 'dsh-browser.type');
        ctx.effect(() => ctx.slots.inject('sidebar.right.tab.guide.entry', () => ctx.slots.register({ name: 'sidebar.right.tab.guide.entry', key: ID, locale: NS, inject: () => ({}) }, Guide)), 'dsh-browser.guide');
        ctx.effect(() => ctx.slots.inject('sidebar.right.pane.tab', () => ctx.slots.register({ name: 'sidebar.right.pane.tab', key: ID, locale: NS, inject: () => ({}) }, BrowserFavorites)), 'dsh-browser.body');
        ctx.effect(() => ctx.slots.inject('sidebar.right.pane.tab.title', () => ctx.slots.register({ name: 'sidebar.right.pane.tab.title', key: ID, locale: NS, inject: () => ({}) }, Title)), 'dsh-browser.title');
      },
      __test: { ID, KIND, NS, KEY, BrowserFavorites, openInBrowser, normalizeUrl, normalizeState, saveFavorite, removeFavorite, moveFavorite, recordRecent },
    };
  },
});

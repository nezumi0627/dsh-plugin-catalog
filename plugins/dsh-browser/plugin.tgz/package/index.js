/** Host half is intentionally empty: this plugin adds tools to the shipped Browser pane. */
export function apply(ctx) {
  ctx.logger?.debug?.('[dsh-browser] host half active (client-only tools)');
}

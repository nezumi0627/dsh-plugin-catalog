# DSH Browser favorites

Adds saved links and a bounded list of links opened from this panel to the shipped right-sidebar Browser. Favorites persist through `dsh-client-store`, can be renamed/reordered/deleted, and replace the favorites pane with the selected URL in the built-in Browser.

The shipped Browser owns web rendering, cookies, navigation, and history. This plugin does not scrape browser state, import credentials, or claim to capture general browsing history. The recent list records only URLs launched from the favorites panel.

export const STATE_VERSION = 1;
export const FAVORITE_LIMIT = 100;
export const RECENT_LIMIT = 40;
export const TITLE_LIMIT = 80;
export const URL_LIMIT = 2048;

export function normalizeUrl(value) {
  const raw = String(value ?? '').trim();
  if (!raw || raw.length > URL_LIMIT) return null;
  const hasHttpScheme = /^https?:\/\//i.test(raw);
  const hostPort = /^[^/?#]+:\d+(?:[/?#]|$)/.test(raw);
  if (!hasHttpScheme && /^[a-z][a-z\d+.-]*:/i.test(raw) && !hostPort) return null;
  try {
    const parsed = new URL(hasHttpScheme ? raw : `https://${raw}`);
    if ((parsed.protocol !== 'https:' && parsed.protocol !== 'http:') || !parsed.hostname || parsed.username || parsed.password) return null;
    const url = parsed.href;
    return url.length <= URL_LIMIT ? url : null;
  } catch {
    return null;
  }
}

function cleanTitle(value, url) {
  const title = String(value ?? '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, TITLE_LIMIT);
  if (title) return title;
  try { return new URL(url).hostname.slice(0, TITLE_LIMIT); } catch { return url.slice(0, TITLE_LIMIT); }
}

function normalizeItems(input, limit) {
  if (!Array.isArray(input)) return [];
  const found = new Set();
  const output = [];
  for (const raw of input) {
    if (!raw || typeof raw !== 'object') continue;
    const url = normalizeUrl(raw.url);
    if (!url || found.has(url)) continue;
    const id = String(raw.id ?? '').trim().slice(0, 80);
    if (!id) continue;
    found.add(url);
    output.push({ id, title: cleanTitle(raw.title, url), url });
    if (output.length >= limit) break;
  }
  return output;
}

export function normalizeState(raw) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw) || raw.version !== STATE_VERSION) {
    return { version: STATE_VERSION, favorites: [], recent: [] };
  }
  return {
    version: STATE_VERSION,
    favorites: normalizeItems(raw.favorites, FAVORITE_LIMIT),
    recent: normalizeItems(raw.recent, RECENT_LIMIT),
  };
}

export function saveFavorite(rawState, { id, title, url }) {
  const state = normalizeState(rawState);
  const normalizedUrl = normalizeUrl(url);
  if (!normalizedUrl) throw new TypeError('Enter a valid HTTP or HTTPS address without credentials.');
  const existing = state.favorites.find((item) => item.url === normalizedUrl);
  const favorite = {
    id: existing?.id ?? String(id ?? '').trim().slice(0, 80),
    title: cleanTitle(title, normalizedUrl),
    url: normalizedUrl,
  };
  if (!favorite.id) throw new TypeError('Favorite id is required.');
  const favorites = existing
    ? state.favorites.map((item) => item.id === existing.id ? favorite : item)
    : [...state.favorites, favorite].slice(-FAVORITE_LIMIT);
  return { ...state, favorites };
}

export function removeFavorite(rawState, id) {
  const state = normalizeState(rawState);
  return { ...state, favorites: state.favorites.filter((item) => item.id !== id) };
}

export function moveFavorite(rawState, id, delta) {
  const state = normalizeState(rawState);
  const favorites = [...state.favorites];
  const from = favorites.findIndex((item) => item.id === id);
  if (from < 0 || !Number.isFinite(delta)) return state;
  const to = Math.max(0, Math.min(favorites.length - 1, from + Math.trunc(delta)));
  if (from === to) return state;
  const [item] = favorites.splice(from, 1);
  favorites.splice(to, 0, item);
  return { ...state, favorites };
}

export function recordRecent(rawState, { title, url, id = 'recent' }) {
  const state = normalizeState(rawState);
  const normalizedUrl = normalizeUrl(url);
  if (!normalizedUrl) return state;
  const item = { id: String(id).slice(0, 80) || 'recent', title: cleanTitle(title, normalizedUrl), url: normalizedUrl };
  const recent = [item, ...state.recent.filter((entry) => entry.url !== normalizedUrl)].slice(0, RECENT_LIMIT);
  return { ...state, recent };
}
